rabbit.data.layerStore.addLayerFromHtml('<div xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:fn="http://www.w3.org/2005/xpath-functions" id="result">\
   <div xmlns:xs="http://www.w3.org/2001/XMLSchema" xmlns="http://www.w3.org/1999/xhtml" id="__containerId__page877094969-layer" class="layer" name="__containerId__pageLayer" data-layer-id="page877094969" data-layer-type="pageLayer" style="position:absolute;left:0px;top:0px;">\
      <div id="__containerId__-page877094969-layer-1356698599" style="position: absolute; left: 0px; top: 0px; width: 1366px; height: 4000px" data-interactive-element-type="default.image" class="image stencil mobile-interaction-potential-trigger " data-stencil-id="1356698599" data-review-reference-id="1356698599">\
         <div class="stencil-wrapper" style="width: 1366px; height: 4000px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" title="">\
               <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" class="image-cropper" style="height: 4000px;width:1366px;" width="1366" height="4000">\
                  <svg:g width="1366" height="4000">\
                     <svg:svg x="1" y="1" width="1364" height="3998">\
                        <svg:image width="432" height="253" xlink:href="../repoimages/506332.PNG" preserveAspectRatio="none" transform="scale(3.162037037037037,15.810276679841897) translate(-0,-0)  "></svg:image>\
                     </svg:svg>\
                  </svg:g>\
               </svg:svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page877094969-layer-image180943357" style="position: absolute; left: 0px; top: 40px; width: 1366px; height: 5000px" data-interactive-element-type="default.image" class="image stencil mobile-interaction-potential-trigger " data-stencil-id="image180943357" data-review-reference-id="image180943357">\
         <div class="stencil-wrapper" style="width: 1366px; height: 5000px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" title="">\
               <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" class="image-cropper" style="height: 5000px;width:1366px;" width="1366" height="5000">\
                  <svg:g width="1366" height="5000">\
                     <svg:svg x="1" y="1" width="1364" height="4998">\
                        <svg:image width="432" height="253" xlink:href="../repoimages/506332.PNG" preserveAspectRatio="none" transform="scale(3.162037037037037,19.76284584980237) translate(-0,-0)  "></svg:image>\
                     </svg:svg>\
                  </svg:g>\
               </svg:svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page877094969-layer-image66869908" style="position: absolute; left: 30px; top: 105px; width: 1366px; height: 5000px" data-interactive-element-type="default.image" class="image stencil mobile-interaction-potential-trigger " data-stencil-id="image66869908" data-review-reference-id="image66869908">\
         <div class="stencil-wrapper" style="width: 1366px; height: 5000px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" title="">\
               <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" class="image-cropper" style="height: 5000px;width:1366px;" width="1366" height="5000">\
                  <svg:g width="1366" height="5000">\
                     <svg:svg x="1" y="1" width="1364" height="4998">\
                        <svg:image width="432" height="253" xlink:href="../repoimages/506332.PNG" preserveAspectRatio="none" transform="scale(3.162037037037037,19.76284584980237) translate(-0,-0)  "></svg:image>\
                     </svg:svg>\
                  </svg:g>\
               </svg:svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page877094969-layer-1892721953" style="position: absolute; left: 45px; top: 5px; width: 150px; height: 150px" data-interactive-element-type="default.image" class="image stencil mobile-interaction-potential-trigger " data-stencil-id="1892721953" data-review-reference-id="1892721953">\
         <div class="stencil-wrapper" style="width: 150px; height: 150px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" title="">\
               <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" class="image-cropper" style="height: 150px;width:150px;" width="150" height="150">\
                  <svg:g width="150" height="150">\
                     <svg:svg x="1" y="1" width="148" height="148">\
                        <svg:image width="80" height="60" xlink:href="../repoimages/506350.png" preserveAspectRatio="none" transform="scale(1.875,2.5) translate(-0,-0)  "></svg:image>\
                     </svg:svg>\
                  </svg:g>\
               </svg:svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page877094969-layer-1460271852" style="position: absolute; left: 20px; top: 170px; width: 32px; height: 32px" data-interactive-element-type="fonticon.icon" class="icon stencil mobile-interaction-potential-trigger " data-stencil-id="1460271852" data-review-reference-id="1460271852">\
         <div class="stencil-wrapper" style="width: 32px; height: 32px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" style="width:32px;height:32px;" title="">\
               <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" class="fill-blue">\
                  <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#icon-glyph-e004"></use>\
               </svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page877094969-layer-1956328937" style="position: absolute; left: 20px; top: 215px; width: 32px; height: 32px" data-interactive-element-type="fonticon.icon" class="icon stencil mobile-interaction-potential-trigger " data-stencil-id="1956328937" data-review-reference-id="1956328937">\
         <div class="stencil-wrapper" style="width: 32px; height: 32px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" style="width:32px;height:32px;" title="">\
               <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" class="fill-blue">\
                  <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#icon-glyph-e205"></use>\
               </svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page877094969-layer-970032794" style="position: absolute; left: 20px; top: 265px; width: 32px; height: 32px" data-interactive-element-type="fonticon.icon" class="icon stencil mobile-interaction-potential-trigger " data-stencil-id="970032794" data-review-reference-id="970032794">\
         <div class="stencil-wrapper" style="width: 32px; height: 32px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" style="width:32px;height:32px;" title="">\
               <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" class="fill-blue">\
                  <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#icon-glyph-e320"></use>\
               </svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page877094969-layer-43565105" style="position: absolute; left: 20px; top: 440px; width: 32px; height: 32px" data-interactive-element-type="fonticon.icon" class="icon stencil mobile-interaction-potential-trigger " data-stencil-id="43565105" data-review-reference-id="43565105">\
         <div class="stencil-wrapper" style="width: 32px; height: 32px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" style="width:32px;height:32px;" title="">\
               <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" class="fill-blue">\
                  <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#icon-glyph-e041"></use>\
               </svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page877094969-layer-1367693769" style="position: absolute; left: 20px; top: 535px; width: 32px; height: 32px" data-interactive-element-type="fonticon.icon" class="icon stencil mobile-interaction-potential-trigger " data-stencil-id="1367693769" data-review-reference-id="1367693769">\
         <div class="stencil-wrapper" style="width: 32px; height: 32px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" style="width:32px;height:32px;" title="">\
               <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" class="fill-blue">\
                  <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#icon-glyph-e064"></use>\
               </svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page877094969-layer-1398589434" style="position: absolute; left: 60px; top: 180px; width: 133px; height: 23px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="1398589434" data-review-reference-id="1398589434">\
         <div class="stencil-wrapper" style="width: 133px; height: 23px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline22"><p><span style="font-size: 20px; color: #658cd9;">Chủ cửa hàng</span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page877094969-layer-835324706" style="position: absolute; left: 60px; top: 225px; width: 158px; height: 23px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="835324706" data-review-reference-id="835324706">\
         <div class="stencil-wrapper" style="width: 158px; height: 23px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline22"><p><span style="font-size: 20px; color: #658cd9;">Quản lí mật khẩu</span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page877094969-layer-1926295537" style="position: absolute; left: 60px; top: 270px; width: 162px; height: 23px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="1926295537" data-review-reference-id="1926295537">\
         <div class="stencil-wrapper" style="width: 162px; height: 23px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline22"><p><span style="font-size: 20px; color: #658cd9;">Quản lí đơn hàng</span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page877094969-layer-465611662" style="position: absolute; left: 60px; top: 450px; width: 89px; height: 23px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="465611662" data-review-reference-id="465611662">\
         <div class="stencil-wrapper" style="width: 89px; height: 23px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline22"><p><span style="font-size: 20px; color: #658cd9;">Thống kê</span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page877094969-layer-1076491664" style="position: absolute; left: 60px; top: 540px; width: 104px; height: 28px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="1076491664" data-review-reference-id="1076491664">\
         <div class="stencil-wrapper" style="width: 104px; height: 28px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline22"><p class="none" style="font-size: 24px;"><span style="font-size: 20px; color: #658cd9;">Đăng xuất</span></p>\
                     <p class="none" style="font-size: 24px;"> </p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page877094969-layer-2023566405" style="position: absolute; left: 305px; top: 45px; width: 209px; height: 37px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="2023566405" data-review-reference-id="2023566405">\
         <div class="stencil-wrapper" style="width: 209px; height: 37px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline22"><p><span style="font-size: 32px; color: #658cd9;">Chủ cửa hàng</span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page877094969-layer-1570916986" style="position: absolute; left: 215px; top: 45px; width: 33px; height: 4760px" data-interactive-element-type="static.line" class="line stencil mobile-interaction-potential-trigger " data-stencil-id="1570916986" data-review-reference-id="1570916986">\
         <div class="stencil-wrapper" style="width: 33px; height: 4760px">\
            <div title="">\
               <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" style="position: absolute; left: -5px; top: -5px; height: 4770px;width:43px;" viewBox="-5 -5 43 4770" width="43" height="4770"><svg:path d="M 16.00, 0.00 Q 17.23, 10.00, 16.89, 20.00 Q 17.44, 30.00, 17.07, 40.00 Q 16.29, 50.00, 17.20, 60.00 Q 17.34,\
                  70.00, 17.53, 80.00 Q 16.76, 90.00, 16.60, 100.00 Q 16.65, 110.00, 17.42, 120.00 Q 16.83, 130.00, 16.84, 140.00 Q 17.74, 150.00,\
                  17.92, 160.00 Q 17.98, 170.00, 18.18, 180.00 Q 18.24, 190.00, 17.79, 200.00 Q 17.00, 210.00, 16.56, 220.00 Q 16.55, 230.00,\
                  16.59, 240.00 Q 16.73, 250.00, 15.92, 260.00 Q 15.47, 270.00, 15.88, 280.00 Q 16.41, 290.00, 16.88, 300.00 Q 17.04, 310.00,\
                  17.07, 320.00 Q 17.09, 330.00, 16.53, 340.00 Q 17.46, 350.00, 17.04, 360.00 Q 17.44, 370.00, 17.66, 380.00 Q 17.60, 390.00,\
                  17.67, 400.00 Q 17.89, 410.00, 17.98, 420.00 Q 17.96, 430.00, 17.39, 440.00 Q 17.47, 450.00, 17.78, 460.00 Q 17.19, 470.00,\
                  17.35, 480.00 Q 17.15, 490.00, 17.34, 500.00 Q 17.44, 510.00, 16.39, 520.00 Q 17.08, 530.00, 16.37, 540.00 Q 16.59, 550.00,\
                  16.72, 560.00 Q 15.94, 570.00, 16.23, 580.00 Q 16.11, 590.00, 16.09, 600.00 Q 15.90, 610.00, 16.18, 620.00 Q 16.41, 630.00,\
                  16.65, 640.00 Q 16.38, 650.00, 16.74, 660.00 Q 16.05, 670.00, 15.86, 680.00 Q 17.27, 690.00, 17.72, 700.00 Q 17.34, 710.00,\
                  16.22, 720.00 Q 16.95, 730.00, 16.93, 740.00 Q 17.32, 750.00, 17.66, 760.00 Q 17.81, 770.00, 17.70, 780.00 Q 17.71, 790.00,\
                  17.13, 800.00 Q 16.99, 810.00, 17.39, 820.00 Q 17.73, 830.00, 17.62, 840.00 Q 17.58, 850.00, 17.44, 860.00 Q 16.79, 870.00,\
                  16.50, 880.00 Q 16.88, 890.00, 17.41, 900.00 Q 18.01, 910.00, 17.68, 920.00 Q 17.11, 930.00, 16.28, 940.00 Q 16.60, 950.00,\
                  16.76, 960.00 Q 16.77, 970.00, 16.62, 980.00 Q 16.24, 990.00, 16.46, 1000.00 Q 17.78, 1010.00, 17.02, 1020.00 Q 15.84, 1030.00,\
                  16.08, 1040.00 Q 17.37, 1050.00, 17.73, 1060.00 Q 17.21, 1070.00, 16.87, 1080.00 Q 17.14, 1090.00, 17.14, 1100.00 Q 16.91,\
                  1110.00, 17.02, 1120.00 Q 16.48, 1130.00, 15.89, 1140.00 Q 15.79, 1150.00, 15.39, 1160.00 Q 16.23, 1170.00, 15.85, 1180.00\
                  Q 15.47, 1190.00, 15.86, 1200.00 Q 16.76, 1210.00, 15.80, 1220.00 Q 16.06, 1230.00, 16.15, 1240.00 Q 16.84, 1250.00, 16.06,\
                  1260.00 Q 16.44, 1270.00, 16.48, 1280.00 Q 16.36, 1290.00, 16.22, 1300.00 Q 16.21, 1310.00, 16.41, 1320.00 Q 17.05, 1330.00,\
                  14.85, 1340.00 Q 14.48, 1350.00, 15.43, 1360.00 Q 16.39, 1370.00, 16.88, 1380.00 Q 17.68, 1390.00, 17.75, 1400.00 Q 17.08,\
                  1410.00, 16.66, 1420.00 Q 16.79, 1430.00, 15.24, 1440.00 Q 15.44, 1450.00, 16.30, 1460.00 Q 15.72, 1470.00, 16.11, 1480.00\
                  Q 16.60, 1490.00, 16.56, 1500.00 Q 17.21, 1510.00, 17.44, 1520.00 Q 17.50, 1530.00, 17.42, 1540.00 Q 16.96, 1550.00, 16.94,\
                  1560.00 Q 17.49, 1570.00, 17.56, 1580.00 Q 16.03, 1590.00, 16.74, 1600.00 Q 16.57, 1610.00, 16.30, 1620.00 Q 17.19, 1630.00,\
                  16.59, 1640.00 Q 16.64, 1650.00, 16.86, 1660.00 Q 16.91, 1670.00, 16.68, 1680.00 Q 16.56, 1690.00, 17.08, 1700.00 Q 16.24,\
                  1710.00, 16.91, 1720.00 Q 16.20, 1730.00, 15.97, 1740.00 Q 15.37, 1750.00, 15.53, 1760.00 Q 15.36, 1770.00, 15.66, 1780.00\
                  Q 16.47, 1790.00, 16.53, 1800.00 Q 16.99, 1810.00, 17.63, 1820.00 Q 17.59, 1830.00, 17.53, 1840.00 Q 16.47, 1850.00, 16.59,\
                  1860.00 Q 16.69, 1870.00, 16.12, 1880.00 Q 16.28, 1890.00, 16.73, 1900.00 Q 17.03, 1910.00, 16.91, 1920.00 Q 16.66, 1930.00,\
                  16.60, 1940.00 Q 16.64, 1950.00, 16.38, 1960.00 Q 15.98, 1970.00, 15.66, 1980.00 Q 15.80, 1990.00, 15.83, 2000.00 Q 17.29,\
                  2010.00, 17.86, 2020.00 Q 17.75, 2030.00, 16.94, 2040.00 Q 15.56, 2050.00, 15.20, 2060.00 Q 14.88, 2070.00, 15.35, 2080.00\
                  Q 15.08, 2090.00, 17.11, 2100.00 Q 17.91, 2110.00, 17.69, 2120.00 Q 16.74, 2130.00, 16.69, 2140.00 Q 16.67, 2150.00, 16.23,\
                  2160.00 Q 16.14, 2170.00, 16.74, 2180.00 Q 16.20, 2190.00, 15.98, 2200.00 Q 15.81, 2210.00, 15.88, 2220.00 Q 16.05, 2230.00,\
                  16.99, 2240.00 Q 16.89, 2250.00, 16.47, 2260.00 Q 16.10, 2270.00, 15.85, 2280.00 Q 14.96, 2290.00, 15.35, 2300.00 Q 14.87,\
                  2310.00, 15.14, 2320.00 Q 17.00, 2330.00, 17.10, 2340.00 Q 16.62, 2350.00, 16.34, 2360.00 Q 15.01, 2370.00, 14.89, 2380.00\
                  Q 15.65, 2390.00, 16.22, 2400.00 Q 17.64, 2410.00, 17.02, 2420.00 Q 16.19, 2430.00, 15.45, 2440.00 Q 15.79, 2450.00, 16.02,\
                  2460.00 Q 15.81, 2470.00, 15.93, 2480.00 Q 16.42, 2490.00, 16.96, 2500.00 Q 16.33, 2510.00, 15.44, 2520.00 Q 15.69, 2530.00,\
                  16.15, 2540.00 Q 16.34, 2550.00, 16.60, 2560.00 Q 16.21, 2570.00, 16.36, 2580.00 Q 16.58, 2590.00, 16.36, 2600.00 Q 16.14,\
                  2610.00, 16.46, 2620.00 Q 16.30, 2630.00, 16.00, 2640.00 Q 17.28, 2650.00, 17.79, 2660.00 Q 16.57, 2670.00, 15.50, 2680.00\
                  Q 16.62, 2690.00, 15.78, 2700.00 Q 15.95, 2710.00, 16.30, 2720.00 Q 16.69, 2730.00, 17.52, 2740.00 Q 17.41, 2750.00, 17.34,\
                  2760.00 Q 17.35, 2770.00, 17.62, 2780.00 Q 18.20, 2790.00, 17.30, 2800.00 Q 17.78, 2810.00, 17.22, 2820.00 Q 16.58, 2830.00,\
                  16.96, 2840.00 Q 17.75, 2850.00, 17.84, 2860.00 Q 17.35, 2870.00, 16.03, 2880.00 Q 16.24, 2890.00, 16.09, 2900.00 Q 16.41,\
                  2910.00, 17.07, 2920.00 Q 16.39, 2930.00, 16.18, 2940.00 Q 15.77, 2950.00, 16.29, 2960.00 Q 16.57, 2970.00, 16.92, 2980.00\
                  Q 17.28, 2990.00, 17.02, 3000.00 Q 17.45, 3010.00, 17.35, 3020.00 Q 17.57, 3030.00, 17.47, 3040.00 Q 17.30, 3050.00, 17.31,\
                  3060.00 Q 17.14, 3070.00, 17.60, 3080.00 Q 16.91, 3090.00, 16.78, 3100.00 Q 16.70, 3110.00, 17.20, 3120.00 Q 17.74, 3130.00,\
                  17.92, 3140.00 Q 17.93, 3150.00, 18.46, 3160.00 Q 17.42, 3170.00, 16.00, 3180.00 Q 16.39, 3190.00, 16.42, 3200.00 Q 16.56,\
                  3210.00, 16.23, 3220.00 Q 14.92, 3230.00, 16.09, 3240.00 Q 16.75, 3250.00, 16.71, 3260.00 Q 16.70, 3270.00, 16.04, 3280.00\
                  Q 15.92, 3290.00, 16.09, 3300.00 Q 16.27, 3310.00, 16.60, 3320.00 Q 16.56, 3330.00, 17.23, 3340.00 Q 17.54, 3350.00, 16.94,\
                  3360.00 Q 16.42, 3370.00, 16.28, 3380.00 Q 16.77, 3390.00, 16.60, 3400.00 Q 16.37, 3410.00, 15.92, 3420.00 Q 16.08, 3430.00,\
                  16.99, 3440.00 Q 16.46, 3450.00, 15.85, 3460.00 Q 15.63, 3470.00, 15.58, 3480.00 Q 15.93, 3490.00, 15.99, 3500.00 Q 16.56,\
                  3510.00, 16.91, 3520.00 Q 16.98, 3530.00, 16.15, 3540.00 Q 15.26, 3550.00, 15.75, 3560.00 Q 16.79, 3570.00, 17.40, 3580.00\
                  Q 17.83, 3590.00, 17.99, 3600.00 Q 17.73, 3610.00, 17.77, 3620.00 Q 17.68, 3630.00, 18.09, 3640.00 Q 18.21, 3650.00, 18.00,\
                  3660.00 Q 18.21, 3670.00, 18.22, 3680.00 Q 17.06, 3690.00, 17.11, 3700.00 Q 17.74, 3710.00, 17.08, 3720.00 Q 17.77, 3730.00,\
                  17.34, 3740.00 Q 17.18, 3750.00, 16.82, 3760.00 Q 16.03, 3770.00, 16.76, 3780.00 Q 17.51, 3790.00, 17.33, 3800.00 Q 17.34,\
                  3810.00, 17.38, 3820.00 Q 17.22, 3830.00, 16.71, 3840.00 Q 17.07, 3850.00, 16.45, 3860.00 Q 16.95, 3870.00, 16.96, 3880.00\
                  Q 17.06, 3890.00, 17.29, 3900.00 Q 17.36, 3910.00, 17.30, 3920.00 Q 16.99, 3930.00, 16.75, 3940.00 Q 16.98, 3950.00, 16.96,\
                  3960.00 Q 16.66, 3970.00, 17.16, 3980.00 Q 16.10, 3990.00, 15.80, 4000.00 Q 15.35, 4010.00, 17.00, 4020.00 Q 17.19, 4030.00,\
                  16.53, 4040.00 Q 17.20, 4050.00, 16.57, 4060.00 Q 16.89, 4070.00, 16.61, 4080.00 Q 16.08, 4090.00, 16.45, 4100.00 Q 16.84,\
                  4110.00, 16.66, 4120.00 Q 16.09, 4130.00, 16.16, 4140.00 Q 16.43, 4150.00, 16.19, 4160.00 Q 14.57, 4170.00, 14.59, 4180.00\
                  Q 14.98, 4190.00, 16.35, 4200.00 Q 17.17, 4210.00, 17.07, 4220.00 Q 17.72, 4230.00, 17.06, 4240.00 Q 16.43, 4250.00, 16.30,\
                  4260.00 Q 17.84, 4270.00, 16.64, 4280.00 Q 16.93, 4290.00, 17.51, 4300.00 Q 17.46, 4310.00, 17.36, 4320.00 Q 16.94, 4330.00,\
                  17.13, 4340.00 Q 16.20, 4350.00, 17.27, 4360.00 Q 16.45, 4370.00, 17.29, 4380.00 Q 17.09, 4390.00, 16.83, 4400.00 Q 17.23,\
                  4410.00, 16.00, 4420.00 Q 16.26, 4430.00, 16.18, 4440.00 Q 16.53, 4450.00, 16.54, 4460.00 Q 17.44, 4470.00, 17.33, 4480.00\
                  Q 17.39, 4490.00, 16.83, 4500.00 Q 16.41, 4510.00, 16.45, 4520.00 Q 15.81, 4530.00, 17.08, 4540.00 Q 17.16, 4550.00, 17.25,\
                  4560.00 Q 16.51, 4570.00, 16.51, 4580.00 Q 16.29, 4590.00, 16.73, 4600.00 Q 16.19, 4610.00, 15.24, 4620.00 Q 15.19, 4630.00,\
                  14.38, 4640.00 Q 15.85, 4650.00, 16.53, 4660.00 Q 16.39, 4670.00, 16.25, 4680.00 Q 16.33, 4690.00, 16.14, 4700.00 Q 16.02,\
                  4710.00, 16.98, 4720.00 Q 17.05, 4730.00, 15.80, 4740.00 Q 16.00, 4750.00, 16.00, 4760.00" style="marker-start:;marker-end:"\
                  class="svg_unselected_element"/>\
               </svg:svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page877094969-layer-99260106" style="position: absolute; left: 305px; top: 160px; width: 67px; height: 20px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="99260106" data-review-reference-id="99260106">\
         <div class="stencil-wrapper" style="width: 67px; height: 20px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline32"><p><span style="font-size: 18px;">Họ tên:</span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page877094969-layer-1291520326" style="position: absolute; left: 465px; top: 145px; width: 275px; height: 30px" data-interactive-element-type="default.textinput" class="textinput stencil mobile-interaction-potential-trigger " data-stencil-id="1291520326" data-review-reference-id="1291520326">\
         <div class="stencil-wrapper" style="width: 275px; height: 30px">\
            <div>\
               <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" style="height: 30px;width:275px;" width="275" height="30">\
                  <svg:g id="__containerId__-page877094969-layer-1291520326svg" width="275" height="30"><svg:path id="__containerId__-page877094969-layer-1291520326_input_svg_border" d="M 2.00, 2.00 Q 12.42, -0.48, 22.85, -0.06\
                     Q 33.27, 0.31, 43.69, 0.46 Q 54.12, 0.60, 64.54, 0.87 Q 74.96, 1.01, 85.38, 0.79 Q 95.81, 1.40, 106.23, 1.39 Q 116.65, 1.06,\
                     127.08, 0.86 Q 137.50, 1.15, 147.92, 0.67 Q 158.35, 0.60, 168.77, 0.21 Q 179.19, 0.92, 189.62, 1.43 Q 200.04, 1.33, 210.46,\
                     1.43 Q 220.88, 1.03, 231.31, 1.25 Q 241.73, 0.93, 252.15, 0.41 Q 262.58, 0.88, 273.58, 1.42 Q 273.83, 14.72, 273.48, 28.48\
                     Q 262.78, 28.74, 252.27, 29.03 Q 241.79, 29.20, 231.36, 30.09 Q 220.91, 30.05, 210.47, 29.00 Q 200.04, 28.08, 189.62, 28.13\
                     Q 179.19, 28.39, 168.77, 28.10 Q 158.35, 27.92, 147.92, 27.92 Q 137.50, 28.04, 127.08, 28.96 Q 116.65, 28.72, 106.23, 28.54\
                     Q 95.81, 28.21, 85.38, 28.54 Q 74.96, 27.99, 64.54, 29.87 Q 54.12, 29.36, 43.69, 29.44 Q 33.27, 29.53, 22.85, 29.73 Q 12.42,\
                     29.58, 1.38, 28.62 Q 2.00, 15.00, 2.00, 2.00" style=" fill:white;" class="svg_unselected_element"/><svg:path id="__containerId__-page877094969-layer-1291520326_line1" d="M 3.00, 3.00 Q 13.35, 2.19, 23.69, 2.20 Q 34.04, 2.65,\
                     44.38, 1.99 Q 54.73, 2.83, 65.08, 2.63 Q 75.42, 2.11, 85.77, 1.88 Q 96.12, 2.26, 106.46, 2.76 Q 116.81, 2.48, 127.15, 1.57\
                     Q 137.50, 1.13, 147.85, 0.89 Q 158.19, 0.86, 168.54, 1.50 Q 178.88, 1.54, 189.23, 1.83 Q 199.58, 1.53, 209.92, 1.49 Q 220.27,\
                     1.41, 230.62, 1.20 Q 240.96, 1.11, 251.31, 1.46 Q 261.65, 3.00, 272.00, 3.00" style=" fill:none;" class="svg_unselected_element"/><svg:path id="__containerId__-page877094969-layer-1291520326_line2" d="M 3.00, 3.00 Q 3.00, 15.00, 3.00, 27.00" style=" fill:none;"\
                     class="svg_unselected_element"/><svg:path id="__containerId__-page877094969-layer-1291520326_line3" d="M 3.00, 3.00 Q 13.35, 2.20, 23.69, 2.04 Q 34.04, 1.94,\
                     44.38, 2.42 Q 54.73, 1.94, 65.08, 1.79 Q 75.42, 1.75, 85.77, 2.90 Q 96.12, 2.08, 106.46, 2.02 Q 116.81, 2.38, 127.15, 1.30\
                     Q 137.50, 2.01, 147.85, 1.73 Q 158.19, 2.38, 168.54, 3.52 Q 178.88, 3.57, 189.23, 2.32 Q 199.58, 2.09, 209.92, 2.24 Q 220.27,\
                     2.45, 230.62, 2.33 Q 240.96, 1.16, 251.31, 1.25 Q 261.65, 3.00, 272.00, 3.00" style=" fill:none;" class="svg_unselected_element"/><svg:path id="__containerId__-page877094969-layer-1291520326_line4" d="M 3.00, 3.00 Q 3.00, 15.00, 3.00, 27.00" style=" fill:none;"\
                     class="svg_unselected_element"/>\
                  </svg:g>\
               </svg:svg>\
               <div style="position:absolute;left: 6px; top: 1px;" title=""><input id="__containerId__-page877094969-layer-1291520326input" onblur="rabbit.facade.raiseEvent(rabbit.events.svgBlur, new Array(\'__containerId__-page877094969-layer-1291520326_input_svg_border\',\'__containerId__-page877094969-layer-1291520326_line1\',\'__containerId__-page877094969-layer-1291520326_line2\',\'__containerId__-page877094969-layer-1291520326_line3\',\'__containerId__-page877094969-layer-1291520326_line4\'))" onfocus="rabbit.facade.raiseEvent(rabbit.events.svgFocus, new Array(\'__containerId__-page877094969-layer-1291520326_input_svg_border\',\'__containerId__-page877094969-layer-1291520326_line1\',\'__containerId__-page877094969-layer-1291520326_line2\',\'__containerId__-page877094969-layer-1291520326_line3\',\'__containerId__-page877094969-layer-1291520326_line4\'))" value="" style="width:268px;height:28px;padding: 0px;" type="text" /></div>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page877094969-layer-1859232652" style="position: absolute; left: 465px; top: 205px; width: 275px; height: 30px" data-interactive-element-type="default.textinput" class="textinput stencil mobile-interaction-potential-trigger " data-stencil-id="1859232652" data-review-reference-id="1859232652">\
         <div class="stencil-wrapper" style="width: 275px; height: 30px">\
            <div>\
               <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" style="height: 30px;width:275px;" width="275" height="30">\
                  <svg:g id="__containerId__-page877094969-layer-1859232652svg" width="275" height="30"><svg:path id="__containerId__-page877094969-layer-1859232652_input_svg_border" d="M 2.00, 2.00 Q 12.42, 2.23, 22.85, 1.48\
                     Q 33.27, 1.19, 43.69, 1.18 Q 54.12, 0.77, 64.54, 0.66 Q 74.96, 0.73, 85.38, 0.64 Q 95.81, -0.05, 106.23, 0.47 Q 116.65, 1.09,\
                     127.08, 0.48 Q 137.50, 0.71, 147.92, 0.95 Q 158.35, 1.23, 168.77, 1.80 Q 179.19, 1.29, 189.62, 0.40 Q 200.04, 0.31, 210.46,\
                     0.99 Q 220.88, 0.81, 231.31, 2.20 Q 241.73, 1.77, 252.15, 1.20 Q 262.58, 1.05, 273.35, 1.65 Q 273.31, 14.90, 273.31, 28.31\
                     Q 262.69, 28.41, 252.18, 28.23 Q 241.69, 27.20, 231.29, 27.11 Q 220.88, 27.38, 210.46, 27.29 Q 200.04, 28.74, 189.62, 28.87\
                     Q 179.19, 29.32, 168.77, 29.35 Q 158.35, 29.05, 147.92, 28.84 Q 137.50, 29.43, 127.08, 28.85 Q 116.65, 29.20, 106.23, 28.69\
                     Q 95.81, 28.78, 85.38, 29.40 Q 74.96, 29.61, 64.54, 29.33 Q 54.12, 29.12, 43.69, 28.74 Q 33.27, 29.40, 22.85, 29.27 Q 12.42,\
                     29.86, 1.17, 28.83 Q 2.00, 15.00, 2.00, 2.00" style=" fill:white;" class="svg_unselected_element"/><svg:path id="__containerId__-page877094969-layer-1859232652_line1" d="M 3.00, 3.00 Q 13.35, 0.43, 23.69, 0.76 Q 34.04, 1.55,\
                     44.38, 1.25 Q 54.73, 1.68, 65.08, 2.15 Q 75.42, 1.90, 85.77, 1.77 Q 96.12, 1.72, 106.46, 1.77 Q 116.81, 1.80, 127.15, 1.76\
                     Q 137.50, 1.44, 147.85, 1.31 Q 158.19, 1.63, 168.54, 1.84 Q 178.88, 2.03, 189.23, 2.08 Q 199.58, 1.95, 209.92, 1.80 Q 220.27,\
                     1.77, 230.62, 1.72 Q 240.96, 2.41, 251.31, 2.05 Q 261.65, 3.00, 272.00, 3.00" style=" fill:none;" class="svg_unselected_element"/><svg:path id="__containerId__-page877094969-layer-1859232652_line2" d="M 3.00, 3.00 Q 3.00, 15.00, 3.00, 27.00" style=" fill:none;"\
                     class="svg_unselected_element"/><svg:path id="__containerId__-page877094969-layer-1859232652_line3" d="M 3.00, 3.00 Q 13.35, 3.48, 23.69, 2.91 Q 34.04, 2.30,\
                     44.38, 3.24 Q 54.73, 3.14, 65.08, 2.51 Q 75.42, 2.71, 85.77, 3.18 Q 96.12, 3.71, 106.46, 2.31 Q 116.81, 2.54, 127.15, 2.03\
                     Q 137.50, 2.20, 147.85, 2.85 Q 158.19, 3.00, 168.54, 3.58 Q 178.88, 2.43, 189.23, 4.04 Q 199.58, 2.81, 209.92, 2.25 Q 220.27,\
                     2.04, 230.62, 2.86 Q 240.96, 3.16, 251.31, 2.01 Q 261.65, 3.00, 272.00, 3.00" style=" fill:none;" class="svg_unselected_element"/><svg:path id="__containerId__-page877094969-layer-1859232652_line4" d="M 3.00, 3.00 Q 3.00, 15.00, 3.00, 27.00" style=" fill:none;"\
                     class="svg_unselected_element"/>\
                  </svg:g>\
               </svg:svg>\
               <div style="position:absolute;left: 6px; top: 1px;" title=""><input id="__containerId__-page877094969-layer-1859232652input" onblur="rabbit.facade.raiseEvent(rabbit.events.svgBlur, new Array(\'__containerId__-page877094969-layer-1859232652_input_svg_border\',\'__containerId__-page877094969-layer-1859232652_line1\',\'__containerId__-page877094969-layer-1859232652_line2\',\'__containerId__-page877094969-layer-1859232652_line3\',\'__containerId__-page877094969-layer-1859232652_line4\'))" onfocus="rabbit.facade.raiseEvent(rabbit.events.svgFocus, new Array(\'__containerId__-page877094969-layer-1859232652_input_svg_border\',\'__containerId__-page877094969-layer-1859232652_line1\',\'__containerId__-page877094969-layer-1859232652_line2\',\'__containerId__-page877094969-layer-1859232652_line3\',\'__containerId__-page877094969-layer-1859232652_line4\'))" value="" style="width:268px;height:28px;padding: 0px;" type="text" /></div>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page877094969-layer-1578558330" style="position: absolute; left: 305px; top: 220px; width: 56px; height: 21px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="1578558330" data-review-reference-id="1578558330">\
         <div class="stencil-wrapper" style="width: 56px; height: 21px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline32"><p><span style="font-size: 18px;">Email:</span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page877094969-layer-649397398" style="position: absolute; left: 305px; top: 280px; width: 91px; height: 21px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="649397398" data-review-reference-id="649397398">\
         <div class="stencil-wrapper" style="width: 91px; height: 21px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline32"><p><span style="font-size: 18px;">Ngày sinh:</span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page877094969-layer-1115828819" style="position: absolute; left: 780px; top: 275px; width: 81px; height: 21px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="1115828819" data-review-reference-id="1115828819">\
         <div class="stencil-wrapper" style="width: 81px; height: 21px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline32"><p><span style="font-size: 18px;">Giới Tính</span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page877094969-layer-2123886261" style="position: absolute; left: 465px; top: 270px; width: 150px; height: 30px" data-interactive-element-type="default.datepicker" class="datepicker stencil mobile-interaction-potential-trigger " data-stencil-id="2123886261" data-review-reference-id="2123886261">\
         <div class="stencil-wrapper" style="width: 150px; height: 30px">\
            <div>\
               <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" style="position: absolute; height: 30px;width:150px;" width="150" height="30">\
                  <svg:g width="150px" height="30px"><svg:path id="__containerId__-page877094969-layer-2123886261_input_svg_border" d="M 2.00, 2.00 Q 13.20, 0.43, 24.40, 0.02\
                     Q 35.60, -0.12, 46.80, -0.14 Q 58.00, -0.11, 69.20, 0.02 Q 80.40, -0.05, 91.60, -0.18 Q 102.80, -0.20, 115.08, 0.92 Q 115.48,\
                     14.51, 114.77, 28.77 Q 103.06, 28.97, 91.76, 29.45 Q 80.47, 29.37, 69.25, 29.97 Q 58.02, 30.06, 46.81, 30.18 Q 35.61, 30.22,\
                     24.40, 30.11 Q 13.20, 29.55, 1.33, 28.67 Q 2.00, 15.00, 2.00, 2.00" style=" fill:white;" class="svg_unselected_element"/><svg:path id="__containerId__-page877094969-layer-2123886261_line1" d="M 3.00, 3.00 Q 14.90, 1.45, 26.80, 1.35 Q 38.70, 1.26,\
                     50.60, 1.56 Q 62.50, 1.38, 74.40, 1.38 Q 86.30, 1.84, 98.20, 1.87 Q 110.10, 3.00, 122.00, 3.00" style=" fill:none;" class="svg_unselected_element"/><svg:path id="__containerId__-page877094969-layer-2123886261_line2" d="M 3.00, 3.00 Q 3.00, 15.00, 3.00, 27.00" style=" fill:none;"\
                     class="svg_unselected_element"/><svg:path id="__containerId__-page877094969-layer-2123886261_line3" d="M 3.00, 3.00 Q 14.90, 2.06, 26.80, 2.07 Q 38.70, 2.09,\
                     50.60, 2.36 Q 62.50, 3.36, 74.40, 2.50 Q 86.30, 2.99, 98.20, 2.74 Q 110.10, 3.00, 122.00, 3.00" style=" fill:none;" class="svg_unselected_element"/><svg:path id="__containerId__-page877094969-layer-2123886261_line4" d="M 3.00, 3.00 Q 3.00, 15.00, 3.00, 27.00" style=" fill:none;"\
                     class="svg_unselected_element"/>\
                  </svg:g>\
                  <svg:g width="150px" height="30px"><svg:path id="__containerId__-page877094969-layer-2123886261_input_svg_border2" d="M 118.00, 2.00 Q 133.00, 2.92, 147.99,\
                     2.01 Q 148.74, 14.75, 148.39, 28.39 Q 133.13, 28.48, 117.51, 28.41 Q 118.00, 15.00, 118.00, 2.00" style=" fill:white;" class="svg_unselected_element"/>\
                  </svg:g>\
               </svg:svg>\
               <div style="white-space: nowrap;" title=""><input type="text" onblur="rabbit.facade.raiseEvent(rabbit.events.svgBlur, new Array(\'__containerId__-page877094969-layer-2123886261_input_svg_border\',\'__containerId__-page877094969-layer-2123886261_line1\',\'__containerId__-page877094969-layer-2123886261_line2\',\'__containerId__-page877094969-layer-2123886261_line3\',\'__containerId__-page877094969-layer-2123886261_line4\'))" onfocus="rabbit.facade.raiseEvent(rabbit.events.svgFocus, new Array(\'__containerId__-page877094969-layer-2123886261_input_svg_border\',\'__containerId__-page877094969-layer-2123886261_line1\',\'__containerId__-page877094969-layer-2123886261_line2\',\'__containerId__-page877094969-layer-2123886261_line3\',\'__containerId__-page877094969-layer-2123886261_line4\'))" style="width:116px; height:30px;padding: 0px;border-width:1px; position: absolute;" id="__containerId__-page877094969-layer-2123886261_input" /><button type="button" onblur="rabbit.facade.raiseEvent(rabbit.events.svgBlur, \'__containerId__-page877094969-layer-2123886261_input_svg_border2\')" onfocus="rabbit.facade.raiseEvent(rabbit.events.svgFocus, \'__containerId__-page877094969-layer-2123886261_input_svg_border2\')" style="position:absolute; left:116px; top:0px; width:34px; height:30px; vertical-align: top; padding: 0px;border-width:1px; cursor:pointer;" id="__containerId__-page877094969-layer-2123886261_button"><img src="../resources/icons/date.png" /></button></div>\
               <div id="__containerId__-page877094969-layer-2123886261_ov" class="yui-skin-sam" style="position: absolute; width: 16em;visibility:visible;">\
                  <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" style="position: absolute; left: -6px; top: -4px; height: 204px;width:200px;display:none" id="__containerId__-page877094969-layer-2123886261_open_calendar" width="150" height="204"><svg:path id="__containerId__-page877094969-layer-2123886261_open_calendar_border" d="M 2.00, 2.00 Q 12.89, 1.46, 23.78, 2.06\
                     Q 34.67, 3.37, 45.56, 2.35 Q 56.44, 1.72, 67.33, 3.40 Q 78.22, 2.66, 89.11, 1.00 Q 100.00, 0.14, 110.89, -0.36 Q 121.78, 0.67,\
                     132.67, 2.28 Q 143.56, 1.77, 154.44, 2.39 Q 165.33, 2.88, 176.22, 1.61 Q 187.11, 1.23, 198.58, 1.42 Q 199.59, 11.47, 199.88,\
                     21.73 Q 200.06, 31.86, 199.64, 41.95 Q 198.74, 51.99, 198.25, 62.00 Q 199.82, 71.99, 200.25, 82.00 Q 200.03, 92.00, 199.42,\
                     102.00 Q 198.69, 112.00, 198.23, 122.00 Q 198.36, 132.00, 198.79, 142.00 Q 198.38, 152.00, 198.05, 162.00 Q 197.53, 172.00,\
                     197.80, 182.00 Q 199.11, 192.00, 198.70, 202.70 Q 187.50, 203.17, 176.39, 203.18 Q 165.43, 203.40, 154.50, 203.62 Q 143.58,\
                     203.82, 132.68, 203.92 Q 121.79, 203.87, 110.89, 203.86 Q 100.00, 203.53, 89.11, 202.72 Q 78.22, 203.47, 67.33, 203.39 Q 56.44,\
                     203.11, 45.56, 203.13 Q 34.67, 203.17, 23.78, 203.45 Q 12.89, 203.79, 1.18, 202.82 Q 0.88, 192.37, 0.94, 182.15 Q 1.45, 172.04,\
                     1.96, 162.00 Q 1.71, 152.00, 2.22, 142.00 Q 1.57, 132.00, 1.37, 122.00 Q 1.22, 112.00, 1.43, 102.00 Q 1.20, 92.00, 1.49, 82.00\
                     Q 1.49, 72.00, 2.00, 62.00 Q 1.51, 52.00, 1.37, 42.00 Q 1.89, 32.00, 1.21, 22.00 Q 2.00, 12.00, 2.00, 2.00" style=" fill:white;"\
                     class="svg_unselected_element"/>\
                  </svg:svg>\
                  <div id="__containerId__-page877094969-layer-2123886261_cal"></div>\
               </div><script type="text/javascript">\
				rabbit.stencils.datepicker.setupDatepicker("__containerId__-page877094969-layer-2123886261");\
			</script></div>\
         </div>\
      </div>\
      <div id="__containerId__-page877094969-layer-807475562" style="position: absolute; left: 900px; top: 275px; width: 52px; height: 20px" data-interactive-element-type="default.radiobutton" class="radiobutton stencil mobile-interaction-potential-trigger " data-stencil-id="807475562" data-review-reference-id="807475562">\
         <div class="stencil-wrapper" style="width: 52px; height: 20px">\
            <div class="">\
               <div style="font-size:1.17em;" xml:space="preserve" title="" onclick="rabbit.facade.fireMouseOn(\'__containerId__-page877094969-layer-807475562_input\');">\
                  				<input id="__containerId__-page877094969-layer-807475562_input" xml:space="default" type="radio" style="padding-right:8px" class="hidden_class" onblur="rabbit.facade.raiseEvent(rabbit.events.svgBlur, \'__containerId__-page877094969-layer-807475562_input_svg_border\')" onfocus="rabbit.facade.raiseEvent(rabbit.events.svgFocus, \'__containerId__-page877094969-layer-807475562_input_svg_border\')" onclick="rabbit.facade.raiseEvent(rabbit.events.radioButtonClicked, \'__containerId__-page877094969-layer-807475562_input\', \'__containerId__-page877094969-layer-807475562_input_svgChecked\');" name="group1" value="__containerId__-page877094969-layer-807475562" />\
                  				\
                  				\
                  				\
                  					Nam\
                  					\
                  				\
                  			\
               </div>\
               <div title="">\
                  <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" style="position: absolute;  top: 1.0199999999999996px; height: 20px;width:52px;cursor: pointer;" width="52" height="20" onclick="rabbit.facade.fireMouseOn(\'__containerId__-page877094969-layer-807475562_input\');">\
                     <svg:g id="__containerId__-page877094969-layer-807475562_input_svg" x="0" y="1.0199999999999996" width="52" height="20" onclick="rabbit.facade.fireMouseOn(\'__containerId__-page877094969-layer-807475562_input\');"><svg:path id="__containerId__-page877094969-layer-807475562_input_svg_border" d="M 17.00, 10.00 Q 17.67, 10.34, 16.18, 13.90\
                        Q 13.20, 16.69, 9.08, 15.44 Q 5.75, 13.78, 4.40, 9.98 Q 6.24, 6.41, 9.40, 4.59 Q 12.82, 5.04, 16.49, 6.02 Q 17.00, 10.10,\
                        15.79, 13.61" style=" fill:white;" class="svg_unselected_element"/>\
                     </svg:g>\
                     <svg:g id="__containerId__-page877094969-layer-807475562_input_svgChecked" x="0" y="1.0199999999999996" width="52" height="20" onclick="rabbit.facade.fireMouseOn(\'__containerId__-page877094969-layer-807475562_input\');" visibility="hidden"><svg:path d="M 13.00, 10.00 Q 14.40, 10.52, 13.76, 12.08 Q 12.10, 13.00, 10.16, 13.19 Q 8.09, 12.43, 7.33, 10.21 Q 8.23, 8.16,\
                        10.00, 7.22 Q 11.86, 6.99, 13.44, 8.10 Q 13.00, 10.03, 12.60, 11.20" style="" class="svg_unselected_element"/>\
                     </svg:g>\
                  </svg:svg>\
               </div>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page877094969-layer-1806491405" style="position: absolute; left: 1005px; top: 275px; width: 41px; height: 20px" data-interactive-element-type="default.radiobutton" class="radiobutton stencil mobile-interaction-potential-trigger " data-stencil-id="1806491405" data-review-reference-id="1806491405">\
         <div class="stencil-wrapper" style="width: 41px; height: 20px">\
            <div class="">\
               <div style="font-size:1.17em;" xml:space="preserve" title="" onclick="rabbit.facade.fireMouseOn(\'__containerId__-page877094969-layer-1806491405_input\');">\
                  				<input id="__containerId__-page877094969-layer-1806491405_input" xml:space="default" type="radio" style="padding-right:8px" class="hidden_class" onblur="rabbit.facade.raiseEvent(rabbit.events.svgBlur, \'__containerId__-page877094969-layer-1806491405_input_svg_border\')" onfocus="rabbit.facade.raiseEvent(rabbit.events.svgFocus, \'__containerId__-page877094969-layer-1806491405_input_svg_border\')" onclick="rabbit.facade.raiseEvent(rabbit.events.radioButtonClicked, \'__containerId__-page877094969-layer-1806491405_input\', \'__containerId__-page877094969-layer-1806491405_input_svgChecked\');" name="group1" value="__containerId__-page877094969-layer-1806491405" />\
                  				\
                  				\
                  				\
                  					Nữ\
                  					\
                  				\
                  			\
               </div>\
               <div title="">\
                  <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" style="position: absolute;  top: 1.0199999999999996px; height: 20px;width:41px;cursor: pointer;" width="41" height="20" onclick="rabbit.facade.fireMouseOn(\'__containerId__-page877094969-layer-1806491405_input\');">\
                     <svg:g id="__containerId__-page877094969-layer-1806491405_input_svg" x="0" y="1.0199999999999996" width="41" height="20" onclick="rabbit.facade.fireMouseOn(\'__containerId__-page877094969-layer-1806491405_input\');"><svg:path id="__containerId__-page877094969-layer-1806491405_input_svg_border" d="M 17.00, 10.00 Q 18.97, 10.78, 17.39, 14.81\
                        Q 13.59, 17.51, 8.82, 17.25 Q 4.82, 14.72, 3.43, 10.12 Q 4.82, 5.64, 8.66, 3.01 Q 13.28, 2.61, 17.18, 5.37 Q 17.00, 10.10,\
                        15.79, 13.61" style=" fill:white;" class="svg_unselected_element"/>\
                     </svg:g>\
                     <svg:g id="__containerId__-page877094969-layer-1806491405_input_svgChecked" x="0" y="1.0199999999999996" width="41" height="20" onclick="rabbit.facade.fireMouseOn(\'__containerId__-page877094969-layer-1806491405_input\');" visibility="hidden"><svg:path d="M 13.00, 10.00 Q 14.59, 10.58, 13.62, 11.98 Q 11.99, 12.77, 10.27, 12.41 Q 9.05, 11.46, 8.57, 10.03 Q 8.82, 8.48,\
                        10.34, 7.92 Q 11.72, 7.75, 12.77, 8.73 Q 13.00, 10.03, 12.60, 11.20" style="" class="svg_unselected_element"/>\
                     </svg:g>\
                  </svg:svg>\
               </div>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page877094969-layer-1356475940" style="position: absolute; left: 815px; top: 160px; width: 45px; height: 21px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="1356475940" data-review-reference-id="1356475940">\
         <div class="stencil-wrapper" style="width: 45px; height: 21px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline32"><p><span style="font-size: 18px;">SĐT:</span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page877094969-layer-696932043" style="position: absolute; left: 865px; top: 155px; width: 275px; height: 30px" data-interactive-element-type="default.textinput" class="textinput stencil mobile-interaction-potential-trigger " data-stencil-id="696932043" data-review-reference-id="696932043">\
         <div class="stencil-wrapper" style="width: 275px; height: 30px">\
            <div>\
               <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" style="height: 30px;width:275px;" width="275" height="30">\
                  <svg:g id="__containerId__-page877094969-layer-696932043svg" width="275" height="30"><svg:path id="__containerId__-page877094969-layer-696932043_input_svg_border" d="M 2.00, 2.00 Q 12.42, 1.56, 22.85, 2.06 Q\
                     33.27, 2.28, 43.69, 2.81 Q 54.12, 3.20, 64.54, 2.73 Q 74.96, 2.36, 85.38, 2.47 Q 95.81, 3.82, 106.23, 3.12 Q 116.65, 3.20,\
                     127.08, 3.02 Q 137.50, 2.63, 147.92, 2.49 Q 158.35, 1.71, 168.77, 1.91 Q 179.19, 2.12, 189.62, 3.28 Q 200.04, 2.35, 210.46,\
                     2.41 Q 220.88, 0.94, 231.31, 2.83 Q 241.73, 2.62, 252.15, 2.58 Q 262.58, 2.30, 273.20, 1.80 Q 272.73, 15.09, 273.25, 28.25\
                     Q 262.72, 28.54, 252.29, 29.20 Q 241.76, 28.64, 231.31, 28.13 Q 220.89, 28.56, 210.47, 28.71 Q 200.04, 28.82, 189.61, 27.60\
                     Q 179.19, 28.89, 168.77, 28.89 Q 158.35, 29.04, 147.92, 26.66 Q 137.50, 26.96, 127.08, 29.25 Q 116.65, 29.54, 106.23, 27.81\
                     Q 95.81, 27.12, 85.38, 28.40 Q 74.96, 27.36, 64.54, 27.38 Q 54.12, 27.30, 43.69, 27.34 Q 33.27, 28.15, 22.85, 29.06 Q 12.42,\
                     28.89, 1.73, 28.27 Q 2.00, 15.00, 2.00, 2.00" style=" fill:white;" class="svg_unselected_element"/><svg:path id="__containerId__-page877094969-layer-696932043_line1" d="M 3.00, 3.00 Q 13.35, 0.48, 23.69, 0.54 Q 34.04, 0.94,\
                     44.38, 1.39 Q 54.73, 1.49, 65.08, 1.56 Q 75.42, 1.12, 85.77, 2.26 Q 96.12, 2.87, 106.46, 2.77 Q 116.81, 2.65, 127.15, 2.42\
                     Q 137.50, 1.80, 147.85, 2.06 Q 158.19, 2.15, 168.54, 3.31 Q 178.88, 3.85, 189.23, 3.53 Q 199.58, 2.94, 209.92, 2.86 Q 220.27,\
                     2.93, 230.62, 2.41 Q 240.96, 2.75, 251.31, 1.97 Q 261.65, 3.00, 272.00, 3.00" style=" fill:none;" class="svg_unselected_element"/><svg:path id="__containerId__-page877094969-layer-696932043_line2" d="M 3.00, 3.00 Q 3.00, 15.00, 3.00, 27.00" style=" fill:none;"\
                     class="svg_unselected_element"/><svg:path id="__containerId__-page877094969-layer-696932043_line3" d="M 3.00, 3.00 Q 13.35, 2.51, 23.69, 2.64 Q 34.04, 2.57,\
                     44.38, 2.36 Q 54.73, 2.43, 65.08, 2.66 Q 75.42, 2.71, 85.77, 2.61 Q 96.12, 2.90, 106.46, 2.26 Q 116.81, 2.17, 127.15, 2.54\
                     Q 137.50, 1.97, 147.85, 2.77 Q 158.19, 3.12, 168.54, 2.03 Q 178.88, 3.15, 189.23, 3.14 Q 199.58, 3.20, 209.92, 2.10 Q 220.27,\
                     2.26, 230.62, 1.72 Q 240.96, 2.27, 251.31, 2.79 Q 261.65, 3.00, 272.00, 3.00" style=" fill:none;" class="svg_unselected_element"/><svg:path id="__containerId__-page877094969-layer-696932043_line4" d="M 3.00, 3.00 Q 3.00, 15.00, 3.00, 27.00" style=" fill:none;"\
                     class="svg_unselected_element"/>\
                  </svg:g>\
               </svg:svg>\
               <div style="position:absolute;left: 6px; top: 1px;" title=""><input id="__containerId__-page877094969-layer-696932043input" onblur="rabbit.facade.raiseEvent(rabbit.events.svgBlur, new Array(\'__containerId__-page877094969-layer-696932043_input_svg_border\',\'__containerId__-page877094969-layer-696932043_line1\',\'__containerId__-page877094969-layer-696932043_line2\',\'__containerId__-page877094969-layer-696932043_line3\',\'__containerId__-page877094969-layer-696932043_line4\'))" onfocus="rabbit.facade.raiseEvent(rabbit.events.svgFocus, new Array(\'__containerId__-page877094969-layer-696932043_input_svg_border\',\'__containerId__-page877094969-layer-696932043_line1\',\'__containerId__-page877094969-layer-696932043_line2\',\'__containerId__-page877094969-layer-696932043_line3\',\'__containerId__-page877094969-layer-696932043_line4\'))" value="" style="width:268px;height:28px;padding: 0px;" type="text" /></div>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page877094969-layer-icon283732951" style="position: absolute; left: 1140px; top: 155px; width: 32px; height: 32px" data-interactive-element-type="fonticon.icon" class="icon stencil mobile-interaction-potential-trigger " data-stencil-id="icon283732951" data-review-reference-id="icon283732951">\
         <div class="stencil-wrapper" style="width: 32px; height: 32px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" style="width:32px;height:32px;" title="">\
               <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" class="fill-blue">\
                  <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#icon-glyph-e337"></use>\
               </svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page877094969-layer-181957790" style="position: absolute; left: 860px; top: 345px; width: 48px; height: 48px" data-interactive-element-type="fonticon.icon" class="icon stencil mobile-interaction-potential-trigger " data-stencil-id="181957790" data-review-reference-id="181957790">\
         <div class="stencil-wrapper" style="width: 48px; height: 48px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" style="width:48px;height:48px;" title="">\
               <svg xmlns="http://www.w3.org/2000/svg" width="48" height="48" class="fill-green">\
                  <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#icon-glyph-e207"></use>\
               </svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page877094969-layer-997662337" style="position: absolute; left: 910px; top: 360px; width: 166px; height: 21px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="997662337" data-review-reference-id="997662337">\
         <div class="stencil-wrapper" style="width: 166px; height: 21px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline32"><p class="none" style="font-size: 18px;">Đã được phê duyệt </p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page877094969-layer-1647991585" style="position: absolute; left: 300px; top: 355px; width: 111px; height: 21px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="1647991585" data-review-reference-id="1647991585">\
         <div class="stencil-wrapper" style="width: 111px; height: 21px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline32"><p><span style="font-size: 18px;">Số tài khoản:</span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page877094969-layer-1255850099" style="position: absolute; left: 465px; top: 345px; width: 275px; height: 30px" data-interactive-element-type="default.textinput" class="textinput stencil mobile-interaction-potential-trigger " data-stencil-id="1255850099" data-review-reference-id="1255850099">\
         <div class="stencil-wrapper" style="width: 275px; height: 30px">\
            <div>\
               <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" style="height: 30px;width:275px;" width="275" height="30">\
                  <svg:g id="__containerId__-page877094969-layer-1255850099svg" width="275" height="30"><svg:path id="__containerId__-page877094969-layer-1255850099_input_svg_border" d="M 2.00, 2.00 Q 12.42, 0.36, 22.85, 0.36\
                     Q 33.27, 0.33, 43.69, 0.25 Q 54.12, 0.23, 64.54, 0.51 Q 74.96, 0.36, 85.38, 0.32 Q 95.81, 0.19, 106.23, 0.17 Q 116.65, 0.37,\
                     127.08, 0.39 Q 137.50, 0.37, 147.92, 0.22 Q 158.35, 0.77, 168.77, 0.54 Q 179.19, 0.33, 189.62, 0.32 Q 200.04, 0.16, 210.46,\
                     0.12 Q 220.88, 0.59, 231.31, 1.03 Q 241.73, 1.02, 252.15, 0.90 Q 262.58, 0.85, 273.29, 1.71 Q 273.80, 14.73, 273.52, 28.52\
                     Q 262.72, 28.53, 252.20, 28.43 Q 241.80, 29.36, 231.33, 28.80 Q 220.90, 28.93, 210.47, 29.13 Q 200.04, 29.16, 189.62, 28.90\
                     Q 179.19, 28.89, 168.77, 29.07 Q 158.35, 29.20, 147.92, 28.97 Q 137.50, 29.19, 127.08, 28.39 Q 116.65, 29.37, 106.23, 28.46\
                     Q 95.81, 29.04, 85.38, 28.94 Q 74.96, 28.95, 64.54, 29.42 Q 54.12, 29.16, 43.69, 29.49 Q 33.27, 29.68, 22.85, 28.22 Q 12.42,\
                     28.23, 1.49, 28.51 Q 2.00, 15.00, 2.00, 2.00" style=" fill:white;" class="svg_unselected_element"/><svg:path id="__containerId__-page877094969-layer-1255850099_line1" d="M 3.00, 3.00 Q 13.35, 3.89, 23.69, 4.81 Q 34.04, 4.08,\
                     44.38, 4.19 Q 54.73, 3.42, 65.08, 2.61 Q 75.42, 3.26, 85.77, 3.10 Q 96.12, 2.66, 106.46, 1.98 Q 116.81, 1.60, 127.15, 0.51\
                     Q 137.50, 1.79, 147.85, 1.37 Q 158.19, 1.03, 168.54, 1.34 Q 178.88, 1.18, 189.23, 1.14 Q 199.58, 0.87, 209.92, 1.39 Q 220.27,\
                     2.08, 230.62, 1.77 Q 240.96, 0.89, 251.31, 0.84 Q 261.65, 3.00, 272.00, 3.00" style=" fill:none;" class="svg_unselected_element"/><svg:path id="__containerId__-page877094969-layer-1255850099_line2" d="M 3.00, 3.00 Q 3.00, 15.00, 3.00, 27.00" style=" fill:none;"\
                     class="svg_unselected_element"/><svg:path id="__containerId__-page877094969-layer-1255850099_line3" d="M 3.00, 3.00 Q 13.35, 3.64, 23.69, 3.08 Q 34.04, 2.49,\
                     44.38, 2.92 Q 54.73, 3.38, 65.08, 2.32 Q 75.42, 2.28, 85.77, 2.51 Q 96.12, 2.71, 106.46, 2.18 Q 116.81, 2.70, 127.15, 1.78\
                     Q 137.50, 2.91, 147.85, 2.71 Q 158.19, 2.76, 168.54, 3.08 Q 178.88, 2.77, 189.23, 2.83 Q 199.58, 2.90, 209.92, 1.55 Q 220.27,\
                     2.04, 230.62, 2.82 Q 240.96, 3.25, 251.31, 1.64 Q 261.65, 3.00, 272.00, 3.00" style=" fill:none;" class="svg_unselected_element"/><svg:path id="__containerId__-page877094969-layer-1255850099_line4" d="M 3.00, 3.00 Q 3.00, 15.00, 3.00, 27.00" style=" fill:none;"\
                     class="svg_unselected_element"/>\
                  </svg:g>\
               </svg:svg>\
               <div style="position:absolute;left: 6px; top: 1px;" title=""><input id="__containerId__-page877094969-layer-1255850099input" onblur="rabbit.facade.raiseEvent(rabbit.events.svgBlur, new Array(\'__containerId__-page877094969-layer-1255850099_input_svg_border\',\'__containerId__-page877094969-layer-1255850099_line1\',\'__containerId__-page877094969-layer-1255850099_line2\',\'__containerId__-page877094969-layer-1255850099_line3\',\'__containerId__-page877094969-layer-1255850099_line4\'))" onfocus="rabbit.facade.raiseEvent(rabbit.events.svgFocus, new Array(\'__containerId__-page877094969-layer-1255850099_input_svg_border\',\'__containerId__-page877094969-layer-1255850099_line1\',\'__containerId__-page877094969-layer-1255850099_line2\',\'__containerId__-page877094969-layer-1255850099_line3\',\'__containerId__-page877094969-layer-1255850099_line4\'))" value="" style="width:268px;height:28px;padding: 0px;" type="text" /></div>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page877094969-layer-9084711" style="position: absolute; left: 60px; top: 325px; width: 161px; height: 28px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="9084711" data-review-reference-id="9084711">\
         <div class="stencil-wrapper" style="width: 161px; height: 28px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline22"><p class="none" style="font-size: 24px;"><span style="color: #658cd9; font-size: 20px;">Quản lí nhà hàng</span></p>\
                     <p class="none" style="font-size: 24px;"> </p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page877094969-layer-1895045554" style="position: absolute; left: 20px; top: 320px; width: 32px; height: 32px" data-interactive-element-type="fonticon.icon" class="icon stencil mobile-interaction-potential-trigger " data-stencil-id="1895045554" data-review-reference-id="1895045554">\
         <div class="stencil-wrapper" style="width: 32px; height: 32px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" style="width:32px;height:32px;" title="">\
               <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" class="fill-blue">\
                  <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#icon-glyph-e021"></use>\
               </svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page877094969-layer-1694463243" style="position: absolute; left: 295px; top: 545px; width: 251px; height: 37px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="1694463243" data-review-reference-id="1694463243">\
         <div class="stencil-wrapper" style="width: 251px; height: 37px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline22"><p><span style="font-size: 32px; color: #658cd9;">Quản lí nhà hàng</span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page877094969-layer-703985551" style="position: absolute; left: 860px; top: 705px; width: 73px; height: 21px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="703985551" data-review-reference-id="703985551">\
         <div class="stencil-wrapper" style="width: 73px; height: 21px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline32"><p class="none" style="font-size: 18px;"><span style="color: #658cd9;">Ảnh bìa </span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page877094969-layer-image674997378" style="position: absolute; left: 810px; top: 550px; width: 155px; height: 155px" data-interactive-element-type="default.image" class="image stencil mobile-interaction-potential-trigger " data-stencil-id="image674997378" data-review-reference-id="image674997378">\
         <div class="stencil-wrapper" style="width: 155px; height: 155px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" title="">\
               <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" class="image-cropper" style="height: 155px;width:155px;" width="155" height="155">\
                  <svg:g width="155" height="155">\
                     <svg:svg x="1" y="1" width="153" height="153">\
                        <svg:image width="432" height="253" xlink:href="../repoimages/506338.PNG" preserveAspectRatio="none" transform="scale(0.3587962962962963,0.6126482213438735) translate(-0,-0)  "></svg:image>\
                     </svg:svg>\
                  </svg:g>\
               </svg:svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page877094969-layer-icon664229910" style="position: absolute; left: 925px; top: 550px; width: 35px; height: 35px" data-interactive-element-type="fonticon.icon" class="icon stencil mobile-interaction-potential-trigger " data-stencil-id="icon664229910" data-review-reference-id="icon664229910">\
         <div class="stencil-wrapper" style="width: 35px; height: 35px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" style="width:35px;height:35px;" title="">\
               <svg xmlns="http://www.w3.org/2000/svg" width="35" height="35" class="fill-blue">\
                  <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#icon-glyph-e012"></use>\
               </svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page877094969-layer-1491567339" style="position: absolute; left: 295px; top: 790px; width: 64px; height: 21px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="1491567339" data-review-reference-id="1491567339">\
         <div class="stencil-wrapper" style="width: 64px; height: 21px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline32"><p><span style="font-size: 18px; color: #658cd9;">Banner</span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page877094969-layer-image765111263" style="position: absolute; left: 425px; top: 775px; width: 130px; height: 135px" data-interactive-element-type="default.image" class="image stencil mobile-interaction-potential-trigger " data-stencil-id="image765111263" data-review-reference-id="image765111263">\
         <div class="stencil-wrapper" style="width: 130px; height: 135px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" title="">\
               <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" class="image-cropper" style="height: 135px;width:130px;" width="130" height="135">\
                  <svg:g width="130" height="135">\
                     <svg:svg x="1" y="1" width="128" height="133">\
                        <svg:image width="600" height="600" xlink:href="../repoimages/506343.JPG" preserveAspectRatio="none" transform="scale(0.21666666666666667,0.225) translate(-0,-0)  "></svg:image>\
                     </svg:svg>\
                  </svg:g>\
               </svg:svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page877094969-layer-470917823" style="position: absolute; left: 420px; top: 770px; width: 35px; height: 35px" data-interactive-element-type="fonticon.icon" class="icon stencil mobile-interaction-potential-trigger " data-stencil-id="470917823" data-review-reference-id="470917823">\
         <div class="stencil-wrapper" style="width: 35px; height: 35px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" style="width:35px;height:35px;" title="">\
               <svg xmlns="http://www.w3.org/2000/svg" width="35" height="35" class="fill-blue">\
                  <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#icon-glyph-e208"></use>\
               </svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page877094969-layer-1035173814" style="position: absolute; left: 575px; top: 775px; width: 130px; height: 135px" data-interactive-element-type="default.image" class="image stencil mobile-interaction-potential-trigger " data-stencil-id="1035173814" data-review-reference-id="1035173814">\
         <div class="stencil-wrapper" style="width: 130px; height: 135px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" title="">\
               <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" class="image-cropper" style="height: 135px;width:130px;" width="130" height="135">\
                  <svg:g width="130" height="135">\
                     <svg:svg x="1" y="1" width="128" height="133">\
                        <svg:image width="600" height="600" xlink:href="../repoimages/506343.JPG" preserveAspectRatio="none" transform="scale(0.21666666666666667,0.225) translate(-0,-0)  "></svg:image>\
                     </svg:svg>\
                  </svg:g>\
               </svg:svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page877094969-layer-1310545113" style="position: absolute; left: 670px; top: 770px; width: 35px; height: 35px" data-interactive-element-type="fonticon.icon" class="icon stencil mobile-interaction-potential-trigger " data-stencil-id="1310545113" data-review-reference-id="1310545113">\
         <div class="stencil-wrapper" style="width: 35px; height: 35px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" style="width:35px;height:35px;" title="">\
               <svg xmlns="http://www.w3.org/2000/svg" width="35" height="35" class="fill-blue">\
                  <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#icon-glyph-e012"></use>\
               </svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page877094969-layer-icon628173581" style="position: absolute; left: 750px; top: 810px; width: 64px; height: 64px" data-interactive-element-type="fonticon.icon" class="icon stencil mobile-interaction-potential-trigger " data-stencil-id="icon628173581" data-review-reference-id="icon628173581">\
         <div class="stencil-wrapper" style="width: 64px; height: 64px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" style="width:64px;height:64px;" title="">\
               <svg xmlns="http://www.w3.org/2000/svg" width="64" height="64" class="fill-blue">\
                  <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#icon-android-e028"></use>\
               </svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page877094969-layer-1024975303" style="position: absolute; left: 520px; top: 770px; width: 35px; height: 35px" data-interactive-element-type="fonticon.icon" class="icon stencil mobile-interaction-potential-trigger " data-stencil-id="1024975303" data-review-reference-id="1024975303">\
         <div class="stencil-wrapper" style="width: 35px; height: 35px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" style="width:35px;height:35px;" title="">\
               <svg xmlns="http://www.w3.org/2000/svg" width="35" height="35" class="fill-blue">\
                  <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#icon-glyph-e012"></use>\
               </svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page877094969-layer-1646873528" style="position: absolute; left: 575px; top: 770px; width: 35px; height: 35px" data-interactive-element-type="fonticon.icon" class="icon stencil mobile-interaction-potential-trigger " data-stencil-id="1646873528" data-review-reference-id="1646873528">\
         <div class="stencil-wrapper" style="width: 35px; height: 35px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" style="width:35px;height:35px;" title="">\
               <svg xmlns="http://www.w3.org/2000/svg" width="35" height="35" class="fill-blue">\
                  <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#icon-glyph-e208"></use>\
               </svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page877094969-layer-arrow549406372" style="position: absolute; left: 235px; top: 520px; width: 1025px; height: 33px" data-interactive-element-type="static.line" class="line stencil mobile-interaction-potential-trigger " data-stencil-id="arrow549406372" data-review-reference-id="arrow549406372">\
         <div class="stencil-wrapper" style="width: 1025px; height: 33px">\
            <div title="">\
               <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" style="position: absolute; left: -5px; top: -5px; height: 43px;width:1035px;" viewBox="-5 -5 1035 43" width="1035" height="43"><svg:path d="M 0.00, 16.00 Q 10.05, 13.82, 20.10, 14.00 Q 30.15, 14.03, 40.20, 14.38 Q 50.25, 14.50, 60.29, 14.43 Q 70.34,\
                  14.31, 80.39, 14.76 Q 90.44, 15.24, 100.49, 15.51 Q 110.54, 15.60, 120.59, 15.03 Q 130.64, 14.87, 140.69, 14.42 Q 150.74,\
                  14.24, 160.78, 14.36 Q 170.83, 14.64, 180.88, 15.16 Q 190.93, 14.40, 200.98, 15.39 Q 211.03, 15.75, 221.08, 15.46 Q 231.13,\
                  15.61, 241.18, 15.03 Q 251.23, 14.79, 261.27, 15.13 Q 271.32, 14.59, 281.37, 14.02 Q 291.42, 13.75, 301.47, 13.65 Q 311.52,\
                  13.72, 321.57, 13.74 Q 331.62, 14.36, 341.67, 14.53 Q 351.72, 15.18, 361.76, 15.34 Q 371.81, 14.63, 381.86, 14.83 Q 391.91,\
                  15.48, 401.96, 16.07 Q 412.01, 16.31, 422.06, 16.34 Q 432.11, 15.88, 442.16, 16.16 Q 452.21, 17.15, 462.25, 16.10 Q 472.30,\
                  16.20, 482.35, 16.03 Q 492.40, 15.09, 502.45, 15.12 Q 512.50, 15.19, 522.55, 15.53 Q 532.60, 14.99, 542.65, 15.45 Q 552.70,\
                  15.11, 562.74, 15.15 Q 572.79, 15.24, 582.84, 14.51 Q 592.89, 14.59, 602.94, 14.52 Q 612.99, 14.13, 623.04, 14.50 Q 633.09,\
                  14.78, 643.14, 13.79 Q 653.19, 13.82, 663.24, 14.21 Q 673.28, 14.57, 683.33, 15.18 Q 693.38, 15.34, 703.43, 15.65 Q 713.48,\
                  15.33, 723.53, 15.81 Q 733.58, 15.78, 743.63, 14.80 Q 753.68, 15.51, 763.73, 16.39 Q 773.77, 16.11, 783.82, 16.49 Q 793.87,\
                  15.73, 803.92, 15.38 Q 813.97, 15.78, 824.02, 14.97 Q 834.07, 14.80, 844.12, 15.25 Q 854.17, 15.14, 864.22, 14.91 Q 874.26,\
                  14.89, 884.31, 15.39 Q 894.36, 15.34, 904.41, 16.60 Q 914.46, 16.15, 924.51, 15.75 Q 934.56, 16.45, 944.61, 16.20 Q 954.66,\
                  16.61, 964.71, 16.49 Q 974.75, 16.08, 984.80, 15.37 Q 994.85, 15.66, 1004.90, 15.79 Q 1014.95, 16.00, 1025.00, 16.00" style="marker-start:;marker-end:"\
                  class="svg_unselected_element"/>\
               </svg:svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page877094969-layer-1898877713" style="position: absolute; left: 290px; top: 665px; width: 122px; height: 21px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="1898877713" data-review-reference-id="1898877713">\
         <div class="stencil-wrapper" style="width: 122px; height: 21px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline32"><p><span style="font-size: 18px; color: #658cd9;">Tên nhà hàng:</span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page877094969-layer-1512867297" style="position: absolute; left: 415px; top: 925px; width: 495px; height: 30px" data-interactive-element-type="default.textinput" class="textinput stencil mobile-interaction-potential-trigger " data-stencil-id="1512867297" data-review-reference-id="1512867297">\
         <div class="stencil-wrapper" style="width: 495px; height: 30px">\
            <div>\
               <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" style="height: 30px;width:495px;" width="495" height="30">\
                  <svg:g id="__containerId__-page877094969-layer-1512867297svg" width="495" height="30"><svg:path id="__containerId__-page877094969-layer-1512867297_input_svg_border" d="M 2.00, 2.00 Q 12.23, 1.25, 22.46, 1.02\
                     Q 32.69, 1.49, 42.92, 1.64 Q 53.15, 2.16, 63.38, 2.32 Q 73.60, 2.96, 83.83, 2.11 Q 94.06, 1.81, 104.29, 2.57 Q 114.52, 2.47,\
                     124.75, 1.99 Q 134.98, 2.53, 145.21, 3.36 Q 155.44, 3.67, 165.67, 2.04 Q 175.90, 1.70, 186.13, 1.19 Q 196.35, 1.23, 206.58,\
                     1.54 Q 216.81, 2.43, 227.04, 2.27 Q 237.27, 1.15, 247.50, 2.65 Q 257.73, 3.57, 267.96, 3.09 Q 278.19, 1.72, 288.42, 2.61 Q\
                     298.65, 2.54, 308.88, 2.61 Q 319.10, 1.70, 329.33, 0.39 Q 339.56, 1.85, 349.79, 1.78 Q 360.02, 1.11, 370.25, 0.69 Q 380.48,\
                     0.44, 390.71, 0.54 Q 400.94, 0.52, 411.17, 0.54 Q 421.40, 0.86, 431.62, 2.02 Q 441.85, 2.47, 452.08, 1.89 Q 462.31, 0.78,\
                     472.54, 0.64 Q 482.77, 0.90, 493.19, 1.81 Q 493.34, 14.89, 492.75, 27.75 Q 482.57, 27.27, 472.47, 27.36 Q 462.35, 28.75, 452.12,\
                     29.54 Q 441.87, 29.03, 431.63, 28.77 Q 421.40, 28.57, 411.17, 28.14 Q 400.94, 26.84, 390.71, 27.47 Q 380.48, 27.21, 370.25,\
                     28.31 Q 360.02, 29.94, 349.79, 30.18 Q 339.56, 29.27, 329.33, 28.95 Q 319.10, 29.04, 308.88, 28.42 Q 298.65, 29.44, 288.42,\
                     29.04 Q 278.19, 29.34, 267.96, 29.57 Q 257.73, 29.78, 247.50, 29.64 Q 237.27, 29.78, 227.04, 29.82 Q 216.81, 29.82, 206.58,\
                     30.53 Q 196.35, 29.41, 186.13, 30.58 Q 175.90, 30.22, 165.67, 29.88 Q 155.44, 29.00, 145.21, 28.59 Q 134.98, 28.82, 124.75,\
                     27.49 Q 114.52, 27.62, 104.29, 27.67 Q 94.06, 27.84, 83.83, 28.67 Q 73.60, 27.81, 63.38, 28.03 Q 53.15, 28.37, 42.92, 28.08\
                     Q 32.69, 27.92, 22.46, 28.62 Q 12.23, 28.60, 1.12, 28.88 Q 2.00, 15.00, 2.00, 2.00" style=" fill:white;" class="svg_unselected_element"/><svg:path id="__containerId__-page877094969-layer-1512867297_line1" d="M 3.00, 3.00 Q 13.19, 1.55, 23.38, 2.00 Q 33.56, 2.24,\
                     43.75, 3.11 Q 53.94, 2.92, 64.12, 3.69 Q 74.31, 3.78, 84.50, 4.48 Q 94.69, 4.04, 104.88, 3.11 Q 115.06, 2.89, 125.25, 2.59\
                     Q 135.44, 2.27, 145.62, 2.94 Q 155.81, 3.02, 166.00, 3.48 Q 176.19, 3.52, 186.38, 3.34 Q 196.56, 3.12, 206.75, 3.07 Q 216.94,\
                     1.63, 227.12, 2.56 Q 237.31, 2.82, 247.50, 2.76 Q 257.69, 2.32, 267.88, 2.29 Q 278.06, 3.28, 288.25, 3.44 Q 298.44, 3.41,\
                     308.62, 4.17 Q 318.81, 2.37, 329.00, 3.34 Q 339.19, 2.83, 349.38, 2.29 Q 359.56, 3.01, 369.75, 2.72 Q 379.94, 2.68, 390.12,\
                     2.89 Q 400.31, 2.85, 410.50, 3.64 Q 420.69, 2.38, 430.88, 1.77 Q 441.06, 1.99, 451.25, 2.23 Q 461.44, 3.71, 471.62, 2.49 Q\
                     481.81, 3.00, 492.00, 3.00" style=" fill:none;" class="svg_unselected_element"/><svg:path id="__containerId__-page877094969-layer-1512867297_line2" d="M 3.00, 3.00 Q 3.00, 15.00, 3.00, 27.00" style=" fill:none;"\
                     class="svg_unselected_element"/><svg:path id="__containerId__-page877094969-layer-1512867297_line3" d="M 3.00, 3.00 Q 13.19, 2.32, 23.38, 2.48 Q 33.56, 2.36,\
                     43.75, 2.37 Q 53.94, 2.34, 64.12, 2.23 Q 74.31, 2.13, 84.50, 2.35 Q 94.69, 2.44, 104.88, 2.32 Q 115.06, 2.00, 125.25, 2.03\
                     Q 135.44, 2.26, 145.62, 1.95 Q 155.81, 2.69, 166.00, 2.42 Q 176.19, 2.68, 186.38, 2.57 Q 196.56, 2.29, 206.75, 2.24 Q 216.94,\
                     2.20, 227.12, 2.05 Q 237.31, 1.71, 247.50, 2.08 Q 257.69, 2.47, 267.88, 2.63 Q 278.06, 2.19, 288.25, 2.32 Q 298.44, 2.93,\
                     308.62, 3.40 Q 318.81, 2.86, 329.00, 2.43 Q 339.19, 3.03, 349.38, 3.36 Q 359.56, 3.26, 369.75, 3.22 Q 379.94, 2.93, 390.12,\
                     2.95 Q 400.31, 2.83, 410.50, 2.73 Q 420.69, 2.42, 430.88, 2.57 Q 441.06, 1.87, 451.25, 2.44 Q 461.44, 2.19, 471.62, 2.30 Q\
                     481.81, 3.00, 492.00, 3.00" style=" fill:none;" class="svg_unselected_element"/><svg:path id="__containerId__-page877094969-layer-1512867297_line4" d="M 3.00, 3.00 Q 3.00, 15.00, 3.00, 27.00" style=" fill:none;"\
                     class="svg_unselected_element"/>\
                  </svg:g>\
               </svg:svg>\
               <div style="position:absolute;left: 6px; top: 1px;" title=""><input id="__containerId__-page877094969-layer-1512867297input" onblur="rabbit.facade.raiseEvent(rabbit.events.svgBlur, new Array(\'__containerId__-page877094969-layer-1512867297_input_svg_border\',\'__containerId__-page877094969-layer-1512867297_line1\',\'__containerId__-page877094969-layer-1512867297_line2\',\'__containerId__-page877094969-layer-1512867297_line3\',\'__containerId__-page877094969-layer-1512867297_line4\'))" onfocus="rabbit.facade.raiseEvent(rabbit.events.svgFocus, new Array(\'__containerId__-page877094969-layer-1512867297_input_svg_border\',\'__containerId__-page877094969-layer-1512867297_line1\',\'__containerId__-page877094969-layer-1512867297_line2\',\'__containerId__-page877094969-layer-1512867297_line3\',\'__containerId__-page877094969-layer-1512867297_line4\'))" value="" style="width:488px;height:28px;padding: 0px;" type="text" /></div>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page877094969-layer-749439552" style="position: absolute; left: 295px; top: 930px; width: 66px; height: 21px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="749439552" data-review-reference-id="749439552">\
         <div class="stencil-wrapper" style="width: 66px; height: 21px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline32"><p class="none" style="font-size: 18px;"><span style="color: #658cd9;">Địa chỉ:</span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page877094969-layer-2133142998" style="position: absolute; left: 300px; top: 1080px; width: 85px; height: 42px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="2133142998" data-review-reference-id="2133142998">\
         <div class="stencil-wrapper" style="width: 85px; height: 42px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline32"><p class="none" style="font-size: 18px;"><span style="color: #658cd9;">Loại hình </span></p>\
                     <p class="none" style="font-size: 18px;"><span style="color: #658cd9;">ẩm thực </span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page877094969-layer-895159778" style="position: absolute; left: 420px; top: 1071px; width: 46px; height: 20px" data-interactive-element-type="default.checkbox" class="checkbox stencil mobile-interaction-potential-trigger " data-stencil-id="895159778" data-review-reference-id="895159778">\
         <div class="stencil-wrapper" style="width: 46px; height: 20px">\
            <div class="" style="font-size:1.17em;">\
               <div xml:space="preserve" title="" style="position:absolute" onclick="rabbit.facade.fireMouseOn(\'__containerId__-page877094969-layer-895159778_input\');">\
                  				\
                  <nobr>\
                     					<input id="__containerId__-page877094969-layer-895159778_input" xml:space="default" class="hidden_class" style="padding-right:9px" type="checkbox" onpropertychange="rabbit.facade.raiseEvent(rabbit.events.propertyChange, \'__containerId__-page877094969-layer-895159778_input\', \'__containerId__-page877094969-layer-895159778_input_svgChecked\');" onblur="rabbit.facade.raiseEvent(rabbit.events.svgBlur, \'__containerId__-page877094969-layer-895159778_input_svg_border\')" onfocus="rabbit.facade.raiseEvent(rabbit.events.svgFocus, \'__containerId__-page877094969-layer-895159778_input_svg_border\')" onclick="rabbit.facade.raiseEvent(rabbit.events.checkBoxClicked, \'__containerId__-page877094969-layer-895159778_input\', \'__containerId__-page877094969-layer-895159778_input_svgChecked\')" />\
                     				\
                     					\
                     					\
                     						Lẩu\
                     						\
                     					\
                     				\
                  </nobr>\
                  			\
               </div>\
               <div title="">\
                  <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" style="position: absolute; height: 20px;width:46px;" width="46" height="20" onclick="rabbit.facade.fireMouseOn(\'__containerId__-page877094969-layer-895159778_input\');">\
                     <svg:g id="__containerId__-page877094969-layer-895159778_input_svg" x="0" y="1.0199999999999996" width="46" height="20"><svg:path id="__containerId__-page877094969-layer-895159778_input_svg_border" d="M 5.00, 5.00 Q 10.00, 5.46, 14.62, 5.38 Q\
                        14.38, 10.21, 14.60, 14.60 Q 9.84, 14.41, 5.11, 14.91 Q 5.00, 10.00, 5.00, 5.00" style=" fill:white;" class="svg_unselected_element"/>\
                     </svg:g>\
                     <svg:g id="__containerId__-page877094969-layer-895159778_input_svgChecked" x="0" y="1.0199999999999996" width="46" height="20" visibility="hidden"><svg:path d="M 5.00, 9.00 Q 8.00, 12.00, 11.00, 15.00" style=" fill:none;" class="svg_unselected_element"/><svg:path d="M 11.00, 15.00 Q 15.50, 7.00, 20.00, -1.00" style=" fill:none;" class="svg_unselected_element"/></svg:g>\
                  </svg:svg>\
               </div>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page877094969-layer-172347672" style="position: absolute; left: 420px; top: 1111px; width: 81px; height: 20px" data-interactive-element-type="default.checkbox" class="checkbox stencil mobile-interaction-potential-trigger " data-stencil-id="172347672" data-review-reference-id="172347672">\
         <div class="stencil-wrapper" style="width: 81px; height: 20px">\
            <div class="" style="font-size:1.17em;">\
               <div xml:space="preserve" title="" style="position:absolute" onclick="rabbit.facade.fireMouseOn(\'__containerId__-page877094969-layer-172347672_input\');">\
                  				\
                  <nobr>\
                     					<input id="__containerId__-page877094969-layer-172347672_input" xml:space="default" class="hidden_class" style="padding-right:9px" type="checkbox" onpropertychange="rabbit.facade.raiseEvent(rabbit.events.propertyChange, \'__containerId__-page877094969-layer-172347672_input\', \'__containerId__-page877094969-layer-172347672_input_svgChecked\');" onblur="rabbit.facade.raiseEvent(rabbit.events.svgBlur, \'__containerId__-page877094969-layer-172347672_input_svg_border\')" onfocus="rabbit.facade.raiseEvent(rabbit.events.svgFocus, \'__containerId__-page877094969-layer-172347672_input_svg_border\')" onclick="rabbit.facade.raiseEvent(rabbit.events.checkBoxClicked, \'__containerId__-page877094969-layer-172347672_input\', \'__containerId__-page877094969-layer-172347672_input_svgChecked\')" />\
                     				\
                     					\
                     					\
                     						Tùy chọn\
                     						\
                     					\
                     				\
                  </nobr>\
                  			\
               </div>\
               <div title="">\
                  <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" style="position: absolute; height: 20px;width:81px;" width="81" height="20" onclick="rabbit.facade.fireMouseOn(\'__containerId__-page877094969-layer-172347672_input\');">\
                     <svg:g id="__containerId__-page877094969-layer-172347672_input_svg" x="0" y="1.0199999999999996" width="81" height="20"><svg:path id="__containerId__-page877094969-layer-172347672_input_svg_border" d="M 5.00, 5.00 Q 10.00, 4.42, 15.30, 4.70 Q\
                        15.41, 9.86, 15.29, 15.29 Q 10.11, 15.41, 4.80, 15.17 Q 5.00, 10.00, 5.00, 5.00" style=" fill:white;" class="svg_unselected_element"/>\
                     </svg:g>\
                     <svg:g id="__containerId__-page877094969-layer-172347672_input_svgChecked" x="0" y="1.0199999999999996" width="81" height="20" visibility="hidden"><svg:path d="M 5.00, 9.00 Q 8.00, 12.00, 11.00, 15.00" style=" fill:none;" class="svg_unselected_element"/><svg:path d="M 11.00, 15.00 Q 15.50, 7.00, 20.00, -1.00" style=" fill:none;" class="svg_unselected_element"/></svg:g>\
                  </svg:svg>\
               </div>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page877094969-layer-1183321380" style="position: absolute; left: 535px; top: 1115px; width: 74px; height: 20px" data-interactive-element-type="default.checkbox" class="checkbox stencil mobile-interaction-potential-trigger " data-stencil-id="1183321380" data-review-reference-id="1183321380">\
         <div class="stencil-wrapper" style="width: 74px; height: 20px">\
            <div class="" style="font-size:1.17em;">\
               <div xml:space="preserve" title="" style="position:absolute" onclick="rabbit.facade.fireMouseOn(\'__containerId__-page877094969-layer-1183321380_input\');">\
                  				\
                  <nobr>\
                     					<input id="__containerId__-page877094969-layer-1183321380_input" xml:space="default" class="hidden_class" style="padding-right:9px" type="checkbox" onpropertychange="rabbit.facade.raiseEvent(rabbit.events.propertyChange, \'__containerId__-page877094969-layer-1183321380_input\', \'__containerId__-page877094969-layer-1183321380_input_svgChecked\');" onblur="rabbit.facade.raiseEvent(rabbit.events.svgBlur, \'__containerId__-page877094969-layer-1183321380_input_svg_border\')" onfocus="rabbit.facade.raiseEvent(rabbit.events.svgFocus, \'__containerId__-page877094969-layer-1183321380_input_svg_border\')" onclick="rabbit.facade.raiseEvent(rabbit.events.checkBoxClicked, \'__containerId__-page877094969-layer-1183321380_input\', \'__containerId__-page877094969-layer-1183321380_input_svgChecked\')" />\
                     				\
                     					\
                     					\
                     						Ba miền\
                     						\
                     					\
                     				\
                  </nobr>\
                  			\
               </div>\
               <div title="">\
                  <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" style="position: absolute; height: 20px;width:74px;" width="74" height="20" onclick="rabbit.facade.fireMouseOn(\'__containerId__-page877094969-layer-1183321380_input\');">\
                     <svg:g id="__containerId__-page877094969-layer-1183321380_input_svg" x="0" y="1.0199999999999996" width="74" height="20"><svg:path id="__containerId__-page877094969-layer-1183321380_input_svg_border" d="M 5.00, 5.00 Q 10.00, 3.68, 15.75, 4.25\
                        Q 16.20, 9.60, 15.66, 15.66 Q 10.25, 15.91, 4.43, 15.48 Q 5.00, 10.00, 5.00, 5.00" style=" fill:white;" class="svg_unselected_element"/>\
                     </svg:g>\
                     <svg:g id="__containerId__-page877094969-layer-1183321380_input_svgChecked" x="0" y="1.0199999999999996" width="74" height="20" visibility="hidden"><svg:path d="M 5.00, 9.00 Q 8.00, 12.00, 11.00, 15.00" style=" fill:none;" class="svg_unselected_element"/><svg:path d="M 11.00, 15.00 Q 15.50, 7.00, 20.00, -1.00" style=" fill:none;" class="svg_unselected_element"/></svg:g>\
                  </svg:svg>\
               </div>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page877094969-layer-2086924429" style="position: absolute; left: 535px; top: 1071px; width: 66px; height: 20px" data-interactive-element-type="default.checkbox" class="checkbox stencil mobile-interaction-potential-trigger " data-stencil-id="2086924429" data-review-reference-id="2086924429">\
         <div class="stencil-wrapper" style="width: 66px; height: 20px">\
            <div class="" style="font-size:1.17em;">\
               <div xml:space="preserve" title="" style="position:absolute" onclick="rabbit.facade.fireMouseOn(\'__containerId__-page877094969-layer-2086924429_input\');">\
                  				\
                  <nobr>\
                     					<input id="__containerId__-page877094969-layer-2086924429_input" xml:space="default" class="hidden_class" style="padding-right:9px" type="checkbox" onpropertychange="rabbit.facade.raiseEvent(rabbit.events.propertyChange, \'__containerId__-page877094969-layer-2086924429_input\', \'__containerId__-page877094969-layer-2086924429_input_svgChecked\');" onblur="rabbit.facade.raiseEvent(rabbit.events.svgBlur, \'__containerId__-page877094969-layer-2086924429_input_svg_border\')" onfocus="rabbit.facade.raiseEvent(rabbit.events.svgFocus, \'__containerId__-page877094969-layer-2086924429_input_svg_border\')" onclick="rabbit.facade.raiseEvent(rabbit.events.checkBoxClicked, \'__containerId__-page877094969-layer-2086924429_input\', \'__containerId__-page877094969-layer-2086924429_input_svgChecked\')" />\
                     				\
                     					\
                     					\
                     						Nướng\
                     						\
                     					\
                     				\
                  </nobr>\
                  			\
               </div>\
               <div title="">\
                  <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" style="position: absolute; height: 20px;width:66px;" width="66" height="20" onclick="rabbit.facade.fireMouseOn(\'__containerId__-page877094969-layer-2086924429_input\');">\
                     <svg:g id="__containerId__-page877094969-layer-2086924429_input_svg" x="0" y="1.0199999999999996" width="66" height="20"><svg:path id="__containerId__-page877094969-layer-2086924429_input_svg_border" d="M 5.00, 5.00 Q 10.00, 5.30, 14.70, 5.30\
                        Q 14.62, 10.13, 14.76, 14.76 Q 9.95, 14.82, 4.96, 15.04 Q 5.00, 10.00, 5.00, 5.00" style=" fill:white;" class="svg_unselected_element"/>\
                     </svg:g>\
                     <svg:g id="__containerId__-page877094969-layer-2086924429_input_svgChecked" x="0" y="1.0199999999999996" width="66" height="20" visibility="hidden"><svg:path d="M 5.00, 9.00 Q 8.00, 12.00, 11.00, 15.00" style=" fill:none;" class="svg_unselected_element"/><svg:path d="M 11.00, 15.00 Q 15.50, 7.00, 20.00, -1.00" style=" fill:none;" class="svg_unselected_element"/></svg:g>\
                  </svg:svg>\
               </div>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page877094969-layer-1244840165" style="position: absolute; left: 655px; top: 1071px; width: 126px; height: 20px" data-interactive-element-type="default.checkbox" class="checkbox stencil mobile-interaction-potential-trigger " data-stencil-id="1244840165" data-review-reference-id="1244840165">\
         <div class="stencil-wrapper" style="width: 126px; height: 20px">\
            <div class="" style="font-size:1.17em;">\
               <div xml:space="preserve" title="" style="position:absolute" onclick="rabbit.facade.fireMouseOn(\'__containerId__-page877094969-layer-1244840165_input\');">\
                  				\
                  <nobr>\
                     					<input id="__containerId__-page877094969-layer-1244840165_input" xml:space="default" class="hidden_class" style="padding-right:9px" type="checkbox" onpropertychange="rabbit.facade.raiseEvent(rabbit.events.propertyChange, \'__containerId__-page877094969-layer-1244840165_input\', \'__containerId__-page877094969-layer-1244840165_input_svgChecked\');" onblur="rabbit.facade.raiseEvent(rabbit.events.svgBlur, \'__containerId__-page877094969-layer-1244840165_input_svg_border\')" onfocus="rabbit.facade.raiseEvent(rabbit.events.svgFocus, \'__containerId__-page877094969-layer-1244840165_input_svg_border\')" onclick="rabbit.facade.raiseEvent(rabbit.events.checkBoxClicked, \'__containerId__-page877094969-layer-1244840165_input\', \'__containerId__-page877094969-layer-1244840165_input_svgChecked\')" />\
                     				\
                     					\
                     					\
                     						Lẩu băng truyền\
                     						\
                     					\
                     				\
                  </nobr>\
                  			\
               </div>\
               <div title="">\
                  <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" style="position: absolute; height: 20px;width:126px;" width="126" height="20" onclick="rabbit.facade.fireMouseOn(\'__containerId__-page877094969-layer-1244840165_input\');">\
                     <svg:g id="__containerId__-page877094969-layer-1244840165_input_svg" x="0" y="1.0199999999999996" width="126" height="20"><svg:path id="__containerId__-page877094969-layer-1244840165_input_svg_border" d="M 5.00, 5.00 Q 10.00, 2.58, 15.99, 4.01\
                        Q 15.75, 9.75, 15.54, 15.54 Q 10.02, 15.07, 4.91, 15.08 Q 5.00, 10.00, 5.00, 5.00" style=" fill:white;" class="svg_unselected_element"/>\
                     </svg:g>\
                     <svg:g id="__containerId__-page877094969-layer-1244840165_input_svgChecked" x="0" y="1.0199999999999996" width="126" height="20" visibility="hidden"><svg:path d="M 5.00, 9.00 Q 8.00, 12.00, 11.00, 15.00" style=" fill:none;" class="svg_unselected_element"/><svg:path d="M 11.00, 15.00 Q 15.50, 7.00, 20.00, -1.00" style=" fill:none;" class="svg_unselected_element"/></svg:g>\
                  </svg:svg>\
               </div>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page877094969-layer-1139388318" style="position: absolute; left: 655px; top: 1111px; width: 74px; height: 20px" data-interactive-element-type="default.checkbox" class="checkbox stencil mobile-interaction-potential-trigger " data-stencil-id="1139388318" data-review-reference-id="1139388318">\
         <div class="stencil-wrapper" style="width: 74px; height: 20px">\
            <div class="" style="font-size:1.17em;">\
               <div xml:space="preserve" title="" style="position:absolute" onclick="rabbit.facade.fireMouseOn(\'__containerId__-page877094969-layer-1139388318_input\');">\
                  				\
                  <nobr>\
                     					<input id="__containerId__-page877094969-layer-1139388318_input" xml:space="default" class="hidden_class" style="padding-right:9px" type="checkbox" onpropertychange="rabbit.facade.raiseEvent(rabbit.events.propertyChange, \'__containerId__-page877094969-layer-1139388318_input\', \'__containerId__-page877094969-layer-1139388318_input_svgChecked\');" onblur="rabbit.facade.raiseEvent(rabbit.events.svgBlur, \'__containerId__-page877094969-layer-1139388318_input_svg_border\')" onfocus="rabbit.facade.raiseEvent(rabbit.events.svgFocus, \'__containerId__-page877094969-layer-1139388318_input_svg_border\')" onclick="rabbit.facade.raiseEvent(rabbit.events.checkBoxClicked, \'__containerId__-page877094969-layer-1139388318_input\', \'__containerId__-page877094969-layer-1139388318_input_svgChecked\')" />\
                     				\
                     					\
                     					\
                     						Thế giới\
                     						\
                     					\
                     				\
                  </nobr>\
                  			\
               </div>\
               <div title="">\
                  <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" style="position: absolute; height: 20px;width:74px;" width="74" height="20" onclick="rabbit.facade.fireMouseOn(\'__containerId__-page877094969-layer-1139388318_input\');">\
                     <svg:g id="__containerId__-page877094969-layer-1139388318_input_svg" x="0" y="1.0199999999999996" width="74" height="20"><svg:path id="__containerId__-page877094969-layer-1139388318_input_svg_border" d="M 5.00, 5.00 Q 10.00, 3.54, 15.60, 4.40\
                        Q 15.53, 9.82, 15.17, 15.17 Q 9.97, 14.90, 4.91, 15.07 Q 5.00, 10.00, 5.00, 5.00" style=" fill:white;" class="svg_unselected_element"/>\
                     </svg:g>\
                     <svg:g id="__containerId__-page877094969-layer-1139388318_input_svgChecked" x="0" y="1.0199999999999996" width="74" height="20" visibility="hidden"><svg:path d="M 5.00, 9.00 Q 8.00, 12.00, 11.00, 15.00" style=" fill:none;" class="svg_unselected_element"/><svg:path d="M 11.00, 15.00 Q 15.50, 7.00, 20.00, -1.00" style=" fill:none;" class="svg_unselected_element"/></svg:g>\
                  </svg:svg>\
               </div>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page877094969-layer-12397493" style="position: absolute; left: 810px; top: 1111px; width: 54px; height: 20px" data-interactive-element-type="default.checkbox" class="checkbox stencil mobile-interaction-potential-trigger " data-stencil-id="12397493" data-review-reference-id="12397493">\
         <div class="stencil-wrapper" style="width: 54px; height: 20px">\
            <div class="" style="font-size:1.17em;">\
               <div xml:space="preserve" title="" style="position:absolute" onclick="rabbit.facade.fireMouseOn(\'__containerId__-page877094969-layer-12397493_input\');">\
                  				\
                  <nobr>\
                     					<input id="__containerId__-page877094969-layer-12397493_input" xml:space="default" class="hidden_class" style="padding-right:9px" type="checkbox" onpropertychange="rabbit.facade.raiseEvent(rabbit.events.propertyChange, \'__containerId__-page877094969-layer-12397493_input\', \'__containerId__-page877094969-layer-12397493_input_svgChecked\');" onblur="rabbit.facade.raiseEvent(rabbit.events.svgBlur, \'__containerId__-page877094969-layer-12397493_input_svg_border\')" onfocus="rabbit.facade.raiseEvent(rabbit.events.svgFocus, \'__containerId__-page877094969-layer-12397493_input_svg_border\')" onclick="rabbit.facade.raiseEvent(rabbit.events.checkBoxClicked, \'__containerId__-page877094969-layer-12397493_input\', \'__containerId__-page877094969-layer-12397493_input_svgChecked\')" />\
                     				\
                     					\
                     					\
                     						Khác\
                     						\
                     					\
                     				\
                  </nobr>\
                  			\
               </div>\
               <div title="">\
                  <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" style="position: absolute; height: 20px;width:54px;" width="54" height="20" onclick="rabbit.facade.fireMouseOn(\'__containerId__-page877094969-layer-12397493_input\');">\
                     <svg:g id="__containerId__-page877094969-layer-12397493_input_svg" x="0" y="1.0199999999999996" width="54" height="20"><svg:path id="__containerId__-page877094969-layer-12397493_input_svg_border" d="M 5.00, 5.00 Q 10.00, 5.06, 14.81, 5.19 Q\
                        14.40, 10.20, 14.73, 14.73 Q 9.99, 14.98, 4.94, 15.05 Q 5.00, 10.00, 5.00, 5.00" style=" fill:white;" class="svg_unselected_element"/>\
                     </svg:g>\
                     <svg:g id="__containerId__-page877094969-layer-12397493_input_svgChecked" x="0" y="1.0199999999999996" width="54" height="20" visibility="hidden"><svg:path d="M 5.00, 9.00 Q 8.00, 12.00, 11.00, 15.00" style=" fill:none;" class="svg_unselected_element"/><svg:path d="M 11.00, 15.00 Q 15.50, 7.00, 20.00, -1.00" style=" fill:none;" class="svg_unselected_element"/></svg:g>\
                  </svg:svg>\
               </div>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page877094969-layer-1253519179" style="position: absolute; left: 810px; top: 1071px; width: 59px; height: 20px" data-interactive-element-type="default.checkbox" class="checkbox stencil mobile-interaction-potential-trigger " data-stencil-id="1253519179" data-review-reference-id="1253519179">\
         <div class="stencil-wrapper" style="width: 59px; height: 20px">\
            <div class="" style="font-size:1.17em;">\
               <div xml:space="preserve" title="" style="position:absolute" onclick="rabbit.facade.fireMouseOn(\'__containerId__-page877094969-layer-1253519179_input\');">\
                  				\
                  <nobr>\
                     					<input id="__containerId__-page877094969-layer-1253519179_input" xml:space="default" class="hidden_class" style="padding-right:9px" type="checkbox" onpropertychange="rabbit.facade.raiseEvent(rabbit.events.propertyChange, \'__containerId__-page877094969-layer-1253519179_input\', \'__containerId__-page877094969-layer-1253519179_input_svgChecked\');" onblur="rabbit.facade.raiseEvent(rabbit.events.svgBlur, \'__containerId__-page877094969-layer-1253519179_input_svg_border\')" onfocus="rabbit.facade.raiseEvent(rabbit.events.svgFocus, \'__containerId__-page877094969-layer-1253519179_input_svg_border\')" onclick="rabbit.facade.raiseEvent(rabbit.events.checkBoxClicked, \'__containerId__-page877094969-layer-1253519179_input\', \'__containerId__-page877094969-layer-1253519179_input_svgChecked\')" />\
                     				\
                     					\
                     					\
                     						Buffet\
                     						\
                     					\
                     				\
                  </nobr>\
                  			\
               </div>\
               <div title="">\
                  <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" style="position: absolute; height: 20px;width:59px;" width="59" height="20" onclick="rabbit.facade.fireMouseOn(\'__containerId__-page877094969-layer-1253519179_input\');">\
                     <svg:g id="__containerId__-page877094969-layer-1253519179_input_svg" x="0" y="1.0199999999999996" width="59" height="20"><svg:path id="__containerId__-page877094969-layer-1253519179_input_svg_border" d="M 5.00, 5.00 Q 10.00, 2.26, 16.37, 3.63\
                        Q 16.16, 9.61, 15.68, 15.68 Q 10.18, 15.64, 4.71, 15.25 Q 5.00, 10.00, 5.00, 5.00" style=" fill:white;" class="svg_unselected_element"/>\
                     </svg:g>\
                     <svg:g id="__containerId__-page877094969-layer-1253519179_input_svgChecked" x="0" y="1.0199999999999996" width="59" height="20" visibility="hidden"><svg:path d="M 5.00, 9.00 Q 8.00, 12.00, 11.00, 15.00" style=" fill:none;" class="svg_unselected_element"/><svg:path d="M 11.00, 15.00 Q 15.50, 7.00, 20.00, -1.00" style=" fill:none;" class="svg_unselected_element"/></svg:g>\
                  </svg:svg>\
               </div>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page877094969-layer-1453927383" style="position: absolute; left: 900px; top: 1071px; width: 73px; height: 20px" data-interactive-element-type="default.checkbox" class="checkbox stencil mobile-interaction-potential-trigger " data-stencil-id="1453927383" data-review-reference-id="1453927383">\
         <div class="stencil-wrapper" style="width: 73px; height: 20px">\
            <div class="" style="font-size:1.17em;">\
               <div xml:space="preserve" title="" style="position:absolute" onclick="rabbit.facade.fireMouseOn(\'__containerId__-page877094969-layer-1453927383_input\');">\
                  				\
                  <nobr>\
                     					<input id="__containerId__-page877094969-layer-1453927383_input" xml:space="default" class="hidden_class" style="padding-right:9px" type="checkbox" onpropertychange="rabbit.facade.raiseEvent(rabbit.events.propertyChange, \'__containerId__-page877094969-layer-1453927383_input\', \'__containerId__-page877094969-layer-1453927383_input_svgChecked\');" onblur="rabbit.facade.raiseEvent(rabbit.events.svgBlur, \'__containerId__-page877094969-layer-1453927383_input_svg_border\')" onfocus="rabbit.facade.raiseEvent(rabbit.events.svgFocus, \'__containerId__-page877094969-layer-1453927383_input_svg_border\')" onclick="rabbit.facade.raiseEvent(rabbit.events.checkBoxClicked, \'__containerId__-page877094969-layer-1453927383_input\', \'__containerId__-page877094969-layer-1453927383_input_svgChecked\')" />\
                     				\
                     					\
                     					\
                     						Ăn chay\
                     						\
                     					\
                     				\
                  </nobr>\
                  			\
               </div>\
               <div title="">\
                  <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" style="position: absolute; height: 20px;width:73px;" width="73" height="20" onclick="rabbit.facade.fireMouseOn(\'__containerId__-page877094969-layer-1453927383_input\');">\
                     <svg:g id="__containerId__-page877094969-layer-1453927383_input_svg" x="0" y="1.0199999999999996" width="73" height="20"><svg:path id="__containerId__-page877094969-layer-1453927383_input_svg_border" d="M 5.00, 5.00 Q 10.00, 3.33, 15.84, 4.16\
                        Q 16.04, 9.65, 15.49, 15.49 Q 10.20, 15.74, 4.57, 15.36 Q 5.00, 10.00, 5.00, 5.00" style=" fill:white;" class="svg_unselected_element"/>\
                     </svg:g>\
                     <svg:g id="__containerId__-page877094969-layer-1453927383_input_svgChecked" x="0" y="1.0199999999999996" width="73" height="20" visibility="hidden"><svg:path d="M 5.00, 9.00 Q 8.00, 12.00, 11.00, 15.00" style=" fill:none;" class="svg_unselected_element"/><svg:path d="M 11.00, 15.00 Q 15.50, 7.00, 20.00, -1.00" style=" fill:none;" class="svg_unselected_element"/></svg:g>\
                  </svg:svg>\
               </div>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page877094969-layer-442645548" style="position: absolute; left: 935px; top: 925px; width: 32px; height: 32px" data-interactive-element-type="fonticon.icon" class="icon pidoco-clickable-element stencil mobile-interaction-potential-trigger " data-stencil-id="442645548" data-review-reference-id="442645548">\
         <div class="stencil-wrapper" style="width: 32px; height: 32px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" style="width:32px;height:32px;" title="">\
               <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" class="fill-blue">\
                  <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#icon-glyph-e243"></use>\
               </svg>\
            </div>\
         </div><script type="text/javascript">\
			$(document).ready(function(){\
				rabbit.interaction.manager.registerInteraction(\'__containerId__-page877094969-layer-442645548\', \'2095265489\', \
		{\
		\
			\'button\': \'left\'\
			\
				,\
			\
			\'id\': \'1286523301\'\
			\
				,\
			\
			\'numberOfFinger\': \'1\'\
			\
				,\
			\
			\'type\': \'click\'\
			\
		}\
	,  \
					[\
						\
		{\
		\
			\'delay\': \'0\'\
			\
				,\
			\
			\'id\': \'1826156620\'\
			\
				,\
			\
			\'options\': \'withoutReloadOnly\'\
			\
				,\
			\
			\'target\': \'https://www.google.com/maps/place/H%C3%A0+N%E1%BB%99i\'\
			\
				,\
			\
			\'transition\': \'none\'\
			\
				,\
			\
			\'type\': \'showPage\'\
			\
		}\
	\
					]\
				);\
			});\
		</script></div>\
      <div id="__containerId__-page877094969-layer-text807046136" style="position: absolute; left: 295px; top: 1165px; width: 130px; height: 21px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text807046136" data-review-reference-id="text807046136">\
         <div class="stencil-wrapper" style="width: 130px; height: 21px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.text2"><p class="none" style="font-size: 14px;"><span style="font-size: 18px; color: #658cd9;">Giá trung bình: </span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page877094969-layer-textinput390839782" style="position: absolute; left: 425px; top: 1160px; width: 150px; height: 30px" data-interactive-element-type="default.textinput" class="textinput stencil mobile-interaction-potential-trigger " data-stencil-id="textinput390839782" data-review-reference-id="textinput390839782">\
         <div class="stencil-wrapper" style="width: 150px; height: 30px">\
            <div>\
               <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" style="height: 30px;width:150px;" width="150" height="30">\
                  <svg:g id="__containerId__-page877094969-layer-textinput390839782svg" width="150" height="30"><svg:path id="__containerId__-page877094969-layer-textinput390839782_input_svg_border" d="M 2.00, 2.00 Q 12.43, 0.99, 22.86,\
                     0.93 Q 33.29, 0.59, 43.71, 0.92 Q 54.14, 1.09, 64.57, 0.81 Q 75.00, 0.77, 85.43, 1.39 Q 95.86, 0.63, 106.29, 1.09 Q 116.71,\
                     0.55, 127.14, 0.82 Q 137.57, 0.54, 148.34, 1.66 Q 147.96, 15.01, 147.87, 27.87 Q 137.64, 28.27, 127.24, 28.83 Q 116.74, 28.55,\
                     106.30, 28.63 Q 95.86, 28.57, 85.43, 28.92 Q 75.00, 28.63, 64.57, 27.74 Q 54.14, 27.79, 43.71, 27.96 Q 33.29, 28.45, 22.86,\
                     28.17 Q 12.43, 28.82, 2.06, 27.94 Q 2.00, 15.00, 2.00, 2.00" style=" fill:white;" class="svg_unselected_element"/><svg:path id="__containerId__-page877094969-layer-textinput390839782_line1" d="M 3.00, 3.00 Q 13.29, 5.16, 23.57, 4.36 Q 33.86,\
                     4.30, 44.14, 3.37 Q 54.43, 3.38, 64.71, 3.51 Q 75.00, 3.96, 85.29, 3.33 Q 95.57, 3.36, 105.86, 2.40 Q 116.14, 2.45, 126.43,\
                     2.72 Q 136.71, 3.00, 147.00, 3.00" style=" fill:none;" class="svg_unselected_element"/><svg:path id="__containerId__-page877094969-layer-textinput390839782_line2" d="M 3.00, 3.00 Q 3.00, 15.00, 3.00, 27.00" style="\
                     fill:none;" class="svg_unselected_element"/><svg:path id="__containerId__-page877094969-layer-textinput390839782_line3" d="M 3.00, 3.00 Q 13.29, 4.10, 23.57, 3.62 Q 33.86,\
                     3.35, 44.14, 2.52 Q 54.43, 2.61, 64.71, 2.20 Q 75.00, 1.94, 85.29, 2.21 Q 95.57, 2.62, 105.86, 3.21 Q 116.14, 2.56, 126.43,\
                     2.87 Q 136.71, 3.00, 147.00, 3.00" style=" fill:none;" class="svg_unselected_element"/><svg:path id="__containerId__-page877094969-layer-textinput390839782_line4" d="M 3.00, 3.00 Q 3.00, 15.00, 3.00, 27.00" style="\
                     fill:none;" class="svg_unselected_element"/>\
                  </svg:g>\
               </svg:svg>\
               <div style="position:absolute;left: 6px; top: 1px;" title=""><input id="__containerId__-page877094969-layer-textinput390839782input" onblur="rabbit.facade.raiseEvent(rabbit.events.svgBlur, new Array(\'__containerId__-page877094969-layer-textinput390839782_input_svg_border\',\'__containerId__-page877094969-layer-textinput390839782_line1\',\'__containerId__-page877094969-layer-textinput390839782_line2\',\'__containerId__-page877094969-layer-textinput390839782_line3\',\'__containerId__-page877094969-layer-textinput390839782_line4\'))" onfocus="rabbit.facade.raiseEvent(rabbit.events.svgFocus, new Array(\'__containerId__-page877094969-layer-textinput390839782_input_svg_border\',\'__containerId__-page877094969-layer-textinput390839782_line1\',\'__containerId__-page877094969-layer-textinput390839782_line2\',\'__containerId__-page877094969-layer-textinput390839782_line3\',\'__containerId__-page877094969-layer-textinput390839782_line4\'))" value="" style="width:143px;height:28px;padding: 0px;" type="text" /></div>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page877094969-layer-text278627905" style="position: absolute; left: 825px; top: 1165px; width: 102px; height: 20px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text278627905" data-review-reference-id="text278627905">\
         <div class="stencil-wrapper" style="width: 102px; height: 20px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline32"><p><span style="font-size: 18px;">VNĐ/Người</span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page877094969-layer-text956159716" style="position: absolute; left: 300px; top: 1225px; width: 107px; height: 20px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text956159716" data-review-reference-id="text956159716">\
         <div class="stencil-wrapper" style="width: 107px; height: 20px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline32"><p><span style="font-size: 18px; color: #658cd9;">Không gian:</span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page877094969-layer-textinput923480844" style="position: absolute; left: 425px; top: 1215px; width: 680px; height: 50px" data-interactive-element-type="default.textinput" class="textinput stencil mobile-interaction-potential-trigger " data-stencil-id="textinput923480844" data-review-reference-id="textinput923480844">\
         <div class="stencil-wrapper" style="width: 680px; height: 50px">\
            <div>\
               <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" style="height: 50px;width:680px;" width="680" height="50">\
                  <svg:g id="__containerId__-page877094969-layer-textinput923480844svg" width="680" height="50"><svg:path id="__containerId__-page877094969-layer-textinput923480844_input_svg_border" d="M 2.00, 2.00 Q 12.24, 2.28, 22.48,\
                     2.44 Q 32.73, 2.34, 42.97, 2.17 Q 53.21, 2.55, 63.45, 2.21 Q 73.70, 1.76, 83.94, 1.71 Q 94.18, 1.94, 104.42, 2.49 Q 114.67,\
                     1.96, 124.91, 2.17 Q 135.15, 0.83, 145.39, 0.90 Q 155.64, 1.01, 165.88, 0.75 Q 176.12, 0.56, 186.36, 1.23 Q 196.61, 2.71,\
                     206.85, 1.68 Q 217.09, 1.64, 227.33, 0.61 Q 237.58, 1.29, 247.82, 1.69 Q 258.06, 1.24, 268.30, 0.77 Q 278.55, 0.80, 288.79,\
                     0.12 Q 299.03, 0.36, 309.27, -0.27 Q 319.52, -0.09, 329.76, -0.27 Q 340.00, -0.36, 350.24, 0.09 Q 360.49, 0.91, 370.73, 0.97\
                     Q 380.97, 1.15, 391.21, 2.50 Q 401.45, 0.63, 411.70, 0.84 Q 421.94, 1.36, 432.18, 1.95 Q 442.42, 1.94, 452.67, 1.00 Q 462.91,\
                     1.30, 473.15, 2.04 Q 483.39, 2.64, 493.64, 1.50 Q 503.88, 1.65, 514.12, 1.09 Q 524.36, 0.94, 534.61, 0.69 Q 544.85, 1.01,\
                     555.09, 1.27 Q 565.33, 0.43, 575.58, 0.26 Q 585.82, -0.00, 596.06, 0.77 Q 606.30, -0.06, 616.55, -0.12 Q 626.79, 0.00, 637.03,\
                     0.13 Q 647.27, -0.02, 657.52, 0.32 Q 667.76, 0.82, 679.03, 0.97 Q 679.52, 12.99, 679.84, 24.74 Q 679.40, 36.41, 678.35, 48.35\
                     Q 667.85, 48.29, 657.64, 48.90 Q 647.37, 49.54, 637.06, 49.13 Q 626.80, 49.07, 616.54, 47.64 Q 606.30, 47.91, 596.06, 49.52\
                     Q 585.82, 49.52, 575.58, 48.99 Q 565.33, 48.97, 555.09, 49.51 Q 544.85, 49.22, 534.61, 49.01 Q 524.36, 47.93, 514.12, 48.85\
                     Q 503.88, 49.70, 493.64, 49.49 Q 483.39, 48.55, 473.15, 48.94 Q 462.91, 49.89, 452.67, 48.16 Q 442.42, 49.22, 432.18, 47.92\
                     Q 421.94, 48.86, 411.70, 49.27 Q 401.45, 48.11, 391.21, 47.52 Q 380.97, 48.28, 370.73, 47.72 Q 360.48, 47.83, 350.24, 48.17\
                     Q 340.00, 48.41, 329.76, 48.76 Q 319.52, 48.84, 309.27, 48.28 Q 299.03, 47.49, 288.79, 47.57 Q 278.55, 49.00, 268.30, 49.46\
                     Q 258.06, 49.12, 247.82, 49.53 Q 237.58, 49.63, 227.33, 49.75 Q 217.09, 49.42, 206.85, 48.81 Q 196.61, 49.40, 186.36, 49.98\
                     Q 176.12, 50.08, 165.88, 49.40 Q 155.64, 49.33, 145.39, 49.27 Q 135.15, 49.25, 124.91, 49.37 Q 114.67, 49.49, 104.42, 49.83\
                     Q 94.18, 49.88, 83.94, 49.40 Q 73.70, 48.56, 63.45, 48.50 Q 53.21, 48.95, 42.97, 49.46 Q 32.73, 49.60, 22.48, 49.56 Q 12.24,\
                     49.69, 1.15, 48.85 Q 0.97, 36.84, 1.11, 25.13 Q 2.00, 13.50, 2.00, 2.00" style=" fill:white;" class="svg_unselected_element"/><svg:path id="__containerId__-page877094969-layer-textinput923480844_line1" d="M 3.00, 3.00 Q 13.21, 2.59, 23.42, 2.67 Q 33.64,\
                     2.80, 43.85, 2.57 Q 54.06, 3.51, 64.27, 2.68 Q 74.48, 2.14, 84.70, 2.78 Q 94.91, 3.59, 105.12, 4.03 Q 115.33, 3.26, 125.55,\
                     2.74 Q 135.76, 1.89, 145.97, 1.36 Q 156.18, 1.72, 166.39, 1.69 Q 176.61, 2.45, 186.82, 1.92 Q 197.03, 1.46, 207.24, 2.98 Q\
                     217.45, 2.86, 227.67, 2.31 Q 237.88, 1.15, 248.09, 1.97 Q 258.30, 1.39, 268.52, 1.24 Q 278.73, 1.05, 288.94, 1.59 Q 299.15,\
                     2.49, 309.36, 2.44 Q 319.58, 2.03, 329.79, 1.59 Q 340.00, 1.74, 350.21, 1.75 Q 360.42, 2.06, 370.64, 2.32 Q 380.85, 1.99,\
                     391.06, 1.55 Q 401.27, 2.28, 411.49, 2.10 Q 421.70, 1.48, 431.91, 2.12 Q 442.12, 1.83, 452.33, 2.42 Q 462.55, 2.36, 472.76,\
                     1.59 Q 482.97, 2.25, 493.18, 2.24 Q 503.39, 1.66, 513.61, 0.75 Q 523.82, 0.92, 534.03, 1.00 Q 544.24, 1.06, 554.45, 1.47 Q\
                     564.67, 2.33, 574.88, 2.48 Q 585.09, 2.79, 595.30, 2.42 Q 605.52, 1.32, 615.73, 1.73 Q 625.94, 1.71, 636.15, 1.52 Q 646.36,\
                     1.35, 656.58, 1.31 Q 666.79, 3.00, 677.00, 3.00" style=" fill:none;" class="svg_unselected_element"/><svg:path id="__containerId__-page877094969-layer-textinput923480844_line2" d="M 3.00, 3.00 Q 4.02, 14.00, 4.12, 25.00 Q 3.00,\
                     36.00, 3.00, 47.00" style=" fill:none;" class="svg_unselected_element"/><svg:path id="__containerId__-page877094969-layer-textinput923480844_line3" d="M 3.00, 3.00 Q 13.21, 1.82, 23.42, 1.66 Q 33.64,\
                     1.85, 43.85, 1.92 Q 54.06, 1.80, 64.27, 2.13 Q 74.48, 2.63, 84.70, 2.27 Q 94.91, 1.95, 105.12, 1.76 Q 115.33, 1.42, 125.55,\
                     2.67 Q 135.76, 3.49, 145.97, 3.65 Q 156.18, 3.05, 166.39, 3.13 Q 176.61, 2.84, 186.82, 2.25 Q 197.03, 2.90, 207.24, 2.08 Q\
                     217.45, 2.32, 227.67, 1.51 Q 237.88, 2.27, 248.09, 2.27 Q 258.30, 2.71, 268.52, 2.95 Q 278.73, 3.19, 288.94, 3.06 Q 299.15,\
                     2.48, 309.36, 2.48 Q 319.58, 2.68, 329.79, 2.49 Q 340.00, 2.35, 350.21, 2.30 Q 360.42, 1.69, 370.64, 2.13 Q 380.85, 3.33,\
                     391.06, 3.16 Q 401.27, 1.66, 411.49, 1.21 Q 421.70, 2.61, 431.91, 1.88 Q 442.12, 2.22, 452.33, 1.60 Q 462.55, 1.73, 472.76,\
                     2.68 Q 482.97, 2.79, 493.18, 2.26 Q 503.39, 2.09, 513.61, 2.23 Q 523.82, 2.50, 534.03, 2.86 Q 544.24, 3.02, 554.45, 3.66 Q\
                     564.67, 2.99, 574.88, 2.81 Q 585.09, 2.41, 595.30, 2.07 Q 605.52, 1.85, 615.73, 2.16 Q 625.94, 2.45, 636.15, 2.91 Q 646.36,\
                     2.32, 656.58, 2.81 Q 666.79, 3.00, 677.00, 3.00" style=" fill:none;" class="svg_unselected_element"/><svg:path id="__containerId__-page877094969-layer-textinput923480844_line4" d="M 3.00, 3.00 Q 4.60, 14.00, 3.94, 25.00 Q 3.00,\
                     36.00, 3.00, 47.00" style=" fill:none;" class="svg_unselected_element"/>\
                  </svg:g>\
               </svg:svg>\
               <div style="position:absolute;left: 6px; top: 1px;" title=""><textarea id="__containerId__-page877094969-layer-textinput923480844input" onblur="rabbit.facade.raiseEvent(rabbit.events.svgBlur, new Array(\'__containerId__-page877094969-layer-textinput923480844_input_svg_border\',\'__containerId__-page877094969-layer-textinput923480844_line1\',\'__containerId__-page877094969-layer-textinput923480844_line2\',\'__containerId__-page877094969-layer-textinput923480844_line3\',\'__containerId__-page877094969-layer-textinput923480844_line4\'))" onfocus="rabbit.facade.raiseEvent(rabbit.events.svgFocus, new Array(\'__containerId__-page877094969-layer-textinput923480844_input_svg_border\',\'__containerId__-page877094969-layer-textinput923480844_line1\',\'__containerId__-page877094969-layer-textinput923480844_line2\',\'__containerId__-page877094969-layer-textinput923480844_line3\',\'__containerId__-page877094969-layer-textinput923480844_line4\'))" rows="" cols="" style="width:673px;height:44px;"></textarea></div>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page877094969-layer-1357039538" style="position: absolute; left: 425px; top: 660px; width: 365px; height: 30px" data-interactive-element-type="default.textinput" class="textinput stencil mobile-interaction-potential-trigger " data-stencil-id="1357039538" data-review-reference-id="1357039538">\
         <div class="stencil-wrapper" style="width: 365px; height: 30px">\
            <div>\
               <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" style="height: 30px;width:365px;" width="365" height="30">\
                  <svg:g id="__containerId__-page877094969-layer-1357039538svg" width="365" height="30"><svg:path id="__containerId__-page877094969-layer-1357039538_input_svg_border" d="M 2.00, 2.00 Q 12.03, -0.07, 22.06, -0.05\
                     Q 32.08, -0.21, 42.11, 0.08 Q 52.14, -0.07, 62.17, -0.15 Q 72.19, 1.03, 82.22, 0.35 Q 92.25, 1.04, 102.28, -0.05 Q 112.31,\
                     0.92, 122.33, -0.24 Q 132.36, 1.34, 142.39, 1.74 Q 152.42, 0.37, 162.44, 0.38 Q 172.47, 1.24, 182.50, 1.63 Q 192.53, 0.50,\
                     202.56, 0.10 Q 212.58, 0.38, 222.61, 1.67 Q 232.64, 1.14, 242.67, 0.29 Q 252.69, 0.35, 262.72, 2.00 Q 272.75, 1.53, 282.78,\
                     1.12 Q 292.81, 0.49, 302.83, 0.05 Q 312.86, 0.01, 322.89, 0.11 Q 332.92, 0.24, 342.94, 0.19 Q 352.97, 0.83, 363.54, 1.46 Q\
                     364.18, 14.61, 363.58, 28.58 Q 353.15, 28.67, 343.07, 29.16 Q 332.98, 29.35, 322.92, 29.43 Q 312.88, 29.24, 302.84, 28.41\
                     Q 292.81, 28.26, 282.78, 29.20 Q 272.75, 29.97, 262.72, 29.51 Q 252.69, 29.67, 242.67, 29.38 Q 232.64, 29.34, 222.61, 28.29\
                     Q 212.58, 28.82, 202.56, 29.55 Q 192.53, 29.22, 182.50, 29.29 Q 172.47, 28.91, 162.44, 29.27 Q 152.42, 28.83, 142.39, 29.09\
                     Q 132.36, 29.20, 122.33, 29.63 Q 112.31, 29.51, 102.28, 29.51 Q 92.25, 29.61, 82.22, 29.21 Q 72.19, 29.18, 62.17, 29.27 Q\
                     52.14, 28.44, 42.11, 28.04 Q 32.08, 28.03, 22.06, 28.44 Q 12.03, 28.57, 1.44, 28.56 Q 2.00, 15.00, 2.00, 2.00" style=" fill:white;"\
                     class="svg_unselected_element"/><svg:path id="__containerId__-page877094969-layer-1357039538_line1" d="M 3.00, 3.00 Q 13.56, 2.83, 24.12, 3.15 Q 34.68, 2.51,\
                     45.24, 4.20 Q 55.79, 3.02, 66.35, 2.25 Q 76.91, 3.15, 87.47, 4.10 Q 98.03, 4.07, 108.59, 2.87 Q 119.15, 1.59, 129.71, 1.63\
                     Q 140.26, 2.14, 150.82, 1.63 Q 161.38, 1.88, 171.94, 2.49 Q 182.50, 2.66, 193.06, 2.53 Q 203.62, 1.86, 214.18, 2.63 Q 224.74,\
                     1.60, 235.29, 1.45 Q 245.85, 1.43, 256.41, 1.35 Q 266.97, 1.31, 277.53, 1.58 Q 288.09, 1.42, 298.65, 1.42 Q 309.21, 1.27,\
                     319.76, 1.26 Q 330.32, 0.91, 340.88, 1.04 Q 351.44, 3.00, 362.00, 3.00" style=" fill:none;" class="svg_unselected_element"/><svg:path id="__containerId__-page877094969-layer-1357039538_line2" d="M 3.00, 3.00 Q 3.00, 15.00, 3.00, 27.00" style=" fill:none;"\
                     class="svg_unselected_element"/><svg:path id="__containerId__-page877094969-layer-1357039538_line3" d="M 3.00, 3.00 Q 13.56, 0.82, 24.12, 0.73 Q 34.68, 0.64,\
                     45.24, 0.93 Q 55.79, 0.75, 66.35, 0.76 Q 76.91, 1.19, 87.47, 1.25 Q 98.03, 1.36, 108.59, 1.36 Q 119.15, 1.81, 129.71, 1.31\
                     Q 140.26, 1.42, 150.82, 1.44 Q 161.38, 2.23, 171.94, 2.07 Q 182.50, 2.39, 193.06, 2.54 Q 203.62, 1.98, 214.18, 2.31 Q 224.74,\
                     3.00, 235.29, 2.86 Q 245.85, 2.11, 256.41, 1.81 Q 266.97, 2.23, 277.53, 2.25 Q 288.09, 1.97, 298.65, 1.62 Q 309.21, 2.19,\
                     319.76, 2.14 Q 330.32, 1.89, 340.88, 1.69 Q 351.44, 3.00, 362.00, 3.00" style=" fill:none;" class="svg_unselected_element"/><svg:path id="__containerId__-page877094969-layer-1357039538_line4" d="M 3.00, 3.00 Q 3.00, 15.00, 3.00, 27.00" style=" fill:none;"\
                     class="svg_unselected_element"/>\
                  </svg:g>\
               </svg:svg>\
               <div style="position:absolute;left: 6px; top: 1px;" title=""><input id="__containerId__-page877094969-layer-1357039538input" onblur="rabbit.facade.raiseEvent(rabbit.events.svgBlur, new Array(\'__containerId__-page877094969-layer-1357039538_input_svg_border\',\'__containerId__-page877094969-layer-1357039538_line1\',\'__containerId__-page877094969-layer-1357039538_line2\',\'__containerId__-page877094969-layer-1357039538_line3\',\'__containerId__-page877094969-layer-1357039538_line4\'))" onfocus="rabbit.facade.raiseEvent(rabbit.events.svgFocus, new Array(\'__containerId__-page877094969-layer-1357039538_input_svg_border\',\'__containerId__-page877094969-layer-1357039538_line1\',\'__containerId__-page877094969-layer-1357039538_line2\',\'__containerId__-page877094969-layer-1357039538_line3\',\'__containerId__-page877094969-layer-1357039538_line4\'))" value="" style="width:358px;height:28px;padding: 0px;" type="text" /></div>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page877094969-layer-1690980367" style="position: absolute; left: 295px; top: 1270px; width: 119px; height: 21px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="1690980367" data-review-reference-id="1690980367">\
         <div class="stencil-wrapper" style="width: 119px; height: 21px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline32"><p><span style="font-size: 18px; color: #658cd9;">Món tiêu biểu:</span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page877094969-layer-1688949353" style="position: absolute; left: 325px; top: 1300px; width: 370px; height: 90px" data-interactive-element-type="default.textinput" class="textinput stencil mobile-interaction-potential-trigger " data-stencil-id="1688949353" data-review-reference-id="1688949353">\
         <div class="stencil-wrapper" style="width: 370px; height: 90px">\
            <div>\
               <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" style="height: 90px;width:370px;" width="370" height="90">\
                  <svg:g id="__containerId__-page877094969-layer-1688949353svg" width="370" height="90"><svg:path id="__containerId__-page877094969-layer-1688949353_input_svg_border" d="M 2.00, 2.00 Q 12.17, 1.11, 22.33, 0.42\
                     Q 32.50, 0.14, 42.67, 0.32 Q 52.83, 1.22, 63.00, 0.06 Q 73.17, 0.19, 83.33, 0.45 Q 93.50, 1.26, 103.67, 0.78 Q 113.83, 0.05,\
                     124.00, -0.00 Q 134.17, 0.18, 144.33, 0.71 Q 154.50, 0.80, 164.67, 1.34 Q 174.83, 0.70, 185.00, 2.17 Q 195.17, 1.97, 205.33,\
                     1.23 Q 215.50, 0.36, 225.67, -0.05 Q 235.83, -0.15, 246.00, -0.14 Q 256.17, -0.25, 266.33, -0.04 Q 276.50, -0.08, 286.67,\
                     -0.09 Q 296.83, -0.21, 307.00, 0.16 Q 317.17, 1.61, 327.33, 2.36 Q 337.50, 2.16, 347.67, 1.10 Q 357.83, 1.03, 367.88, 2.12\
                     Q 367.91, 12.78, 368.99, 23.36 Q 369.32, 34.16, 369.38, 44.96 Q 369.18, 55.73, 369.34, 66.49 Q 369.39, 77.24, 368.77, 88.77\
                     Q 358.23, 89.21, 347.87, 89.41 Q 337.61, 89.59, 327.39, 89.74 Q 317.19, 89.68, 307.01, 89.54 Q 296.84, 89.58, 286.67, 88.78\
                     Q 276.50, 88.88, 266.33, 88.78 Q 256.17, 89.36, 246.00, 89.43 Q 235.83, 89.57, 225.67, 89.56 Q 215.50, 89.32, 205.33, 89.15\
                     Q 195.17, 89.17, 185.00, 88.23 Q 174.83, 87.32, 164.67, 87.80 Q 154.50, 88.08, 144.33, 88.07 Q 134.17, 88.45, 124.00, 88.42\
                     Q 113.83, 88.32, 103.67, 88.00 Q 93.50, 88.44, 83.33, 88.54 Q 73.17, 88.88, 63.00, 88.57 Q 52.83, 88.35, 42.67, 88.89 Q 32.50,\
                     88.99, 22.33, 88.91 Q 12.17, 88.69, 1.39, 88.61 Q 1.56, 77.40, 1.60, 66.56 Q 1.13, 55.81, 0.80, 45.04 Q 0.87, 34.27, 0.70,\
                     23.51 Q 2.00, 12.75, 2.00, 2.00" style=" fill:white;" class="svg_unselected_element"/><svg:path id="__containerId__-page877094969-layer-1688949353_line1" d="M 3.00, 3.00 Q 13.11, 2.53, 23.22, 1.94 Q 33.33, 2.27,\
                     43.44, 1.50 Q 53.56, 1.77, 63.67, 2.79 Q 73.78, 2.61, 83.89, 2.07 Q 94.00, 1.97, 104.11, 1.52 Q 114.22, 2.24, 124.33, 2.69\
                     Q 134.44, 2.53, 144.56, 3.47 Q 154.67, 3.98, 164.78, 2.71 Q 174.89, 2.43, 185.00, 2.59 Q 195.11, 2.78, 205.22, 1.62 Q 215.33,\
                     2.13, 225.44, 2.06 Q 235.56, 2.87, 245.67, 3.02 Q 255.78, 3.19, 265.89, 2.18 Q 276.00, 3.47, 286.11, 3.50 Q 296.22, 3.29,\
                     306.33, 3.92 Q 316.44, 2.77, 326.56, 2.30 Q 336.67, 2.26, 346.78, 1.92 Q 356.89, 3.00, 367.00, 3.00" style=" fill:none;" class="svg_unselected_element"/><svg:path id="__containerId__-page877094969-layer-1688949353_line2" d="M 3.00, 3.00 Q 0.98, 13.50, 1.48, 24.00 Q 1.86, 34.50,\
                     2.72, 45.00 Q 2.17, 55.50, 3.13, 66.00 Q 3.00, 76.50, 3.00, 87.00" style=" fill:none;" class="svg_unselected_element"/><svg:path id="__containerId__-page877094969-layer-1688949353_line3" d="M 3.00, 3.00 Q 13.11, 1.22, 23.22, 1.42 Q 33.33, 1.58,\
                     43.44, 1.81 Q 53.56, 1.89, 63.67, 2.04 Q 73.78, 2.11, 83.89, 2.57 Q 94.00, 2.60, 104.11, 2.68 Q 114.22, 2.62, 124.33, 3.01\
                     Q 134.44, 2.91, 144.56, 2.97 Q 154.67, 3.47, 164.78, 3.31 Q 174.89, 3.16, 185.00, 2.28 Q 195.11, 2.03, 205.22, 2.26 Q 215.33,\
                     2.04, 225.44, 1.90 Q 235.56, 2.14, 245.67, 2.66 Q 255.78, 2.28, 265.89, 2.79 Q 276.00, 2.29, 286.11, 3.46 Q 296.22, 4.17,\
                     306.33, 3.96 Q 316.44, 3.81, 326.56, 3.62 Q 336.67, 3.55, 346.78, 3.33 Q 356.89, 3.00, 367.00, 3.00" style=" fill:none;" class="svg_unselected_element"/><svg:path id="__containerId__-page877094969-layer-1688949353_line4" d="M 3.00, 3.00 Q 5.26, 13.50, 5.25, 24.00 Q 4.65, 34.50,\
                     4.60, 45.00 Q 3.67, 55.50, 3.47, 66.00 Q 3.00, 76.50, 3.00, 87.00" style=" fill:none;" class="svg_unselected_element"/>\
                  </svg:g>\
               </svg:svg>\
               <div style="position:absolute;left: 6px; top: 1px;" title=""><textarea id="__containerId__-page877094969-layer-1688949353input" onblur="rabbit.facade.raiseEvent(rabbit.events.svgBlur, new Array(\'__containerId__-page877094969-layer-1688949353_input_svg_border\',\'__containerId__-page877094969-layer-1688949353_line1\',\'__containerId__-page877094969-layer-1688949353_line2\',\'__containerId__-page877094969-layer-1688949353_line3\',\'__containerId__-page877094969-layer-1688949353_line4\'))" onfocus="rabbit.facade.raiseEvent(rabbit.events.svgFocus, new Array(\'__containerId__-page877094969-layer-1688949353_input_svg_border\',\'__containerId__-page877094969-layer-1688949353_line1\',\'__containerId__-page877094969-layer-1688949353_line2\',\'__containerId__-page877094969-layer-1688949353_line3\',\'__containerId__-page877094969-layer-1688949353_line4\'))" rows="" cols="" style="width:363px;height:84px;"></textarea></div>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page877094969-layer-image57481914" style="position: absolute; left: 300px; top: 1410px; width: 760px; height: 438px" data-interactive-element-type="default.image" class="image stencil mobile-interaction-potential-trigger " data-stencil-id="image57481914" data-review-reference-id="image57481914">\
         <div class="stencil-wrapper" style="width: 760px; height: 438px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" title="">\
               <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" class="image-cropper" style="height: 438px;width:760px;" width="760" height="438">\
                  <svg:g width="760" height="438">\
                     <svg:svg x="1" y="1" width="758" height="436">\
                        <svg:image width="80" height="60" xlink:href="../repoimages/506426.PNG" preserveAspectRatio="none" transform="scale(9.5,7.3) translate(-0,-0)  "></svg:image>\
                     </svg:svg>\
                  </svg:g>\
               </svg:svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page877094969-layer-1750084529" style="position: absolute; left: 305px; top: 1865px; width: 93px; height: 20px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="1750084529" data-review-reference-id="1750084529">\
         <div class="stencil-wrapper" style="width: 93px; height: 20px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline32"><p class="none" style="font-size: 18px;">Thực đơn </p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page877094969-layer-icon435783622" style="position: absolute; left: 405px; top: 1865px; width: 24px; height: 24px" data-interactive-element-type="fonticon.icon" class="icon stencil mobile-interaction-potential-trigger " data-stencil-id="icon435783622" data-review-reference-id="icon435783622">\
         <div class="stencil-wrapper" style="width: 24px; height: 24px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" style="width:24px;height:24px;" title="">\
               <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" class="fill-blue">\
                  <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#icon-android-e028"></use>\
               </svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page877094969-layer-105616324" style="position: absolute; left: 235px; top: 1895px; width: 990px; height: 33px" data-interactive-element-type="static.line" class="line stencil mobile-interaction-potential-trigger " data-stencil-id="105616324" data-review-reference-id="105616324">\
         <div class="stencil-wrapper" style="width: 990px; height: 33px">\
            <div title="">\
               <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" style="position: absolute; left: -5px; top: -5px; height: 43px;width:1000px;" viewBox="-5 -5 1000 43" width="1000" height="43"><svg:path d="M 0.00, 16.00 Q 10.10, 14.54, 20.20, 15.60 Q 30.31, 16.52, 40.41, 16.88 Q 50.51, 16.57, 60.61, 16.45 Q 70.71,\
                  16.65, 80.82, 15.55 Q 90.92, 15.27, 101.02, 14.81 Q 111.12, 15.50, 121.22, 15.42 Q 131.33, 15.76, 141.43, 16.27 Q 151.53,\
                  16.04, 161.63, 14.97 Q 171.73, 15.43, 181.84, 15.55 Q 191.94, 17.49, 202.04, 15.61 Q 212.14, 16.18, 222.24, 16.07 Q 232.35,\
                  15.82, 242.45, 15.35 Q 252.55, 15.69, 262.65, 15.35 Q 272.76, 15.17, 282.86, 15.98 Q 292.96, 16.34, 303.06, 15.42 Q 313.16,\
                  14.99, 323.27, 14.44 Q 333.37, 15.16, 343.47, 14.50 Q 353.57, 15.53, 363.67, 14.05 Q 373.78, 15.39, 383.88, 16.65 Q 393.98,\
                  16.38, 404.08, 15.30 Q 414.18, 14.54, 424.29, 15.82 Q 434.39, 15.35, 444.49, 15.85 Q 454.59, 16.43, 464.69, 16.58 Q 474.80,\
                  15.95, 484.90, 15.92 Q 495.00, 15.77, 505.10, 15.34 Q 515.20, 15.19, 525.31, 14.65 Q 535.41, 14.57, 545.51, 14.48 Q 555.61,\
                  15.17, 565.71, 14.70 Q 575.82, 14.86, 585.92, 14.80 Q 596.02, 14.68, 606.12, 14.61 Q 616.22, 14.94, 626.33, 15.20 Q 636.43,\
                  15.11, 646.53, 14.97 Q 656.63, 15.29, 666.74, 16.10 Q 676.84, 16.34, 686.94, 15.85 Q 697.04, 16.91, 707.14, 16.96 Q 717.25,\
                  15.02, 727.35, 13.95 Q 737.45, 13.91, 747.55, 13.95 Q 757.65, 14.78, 767.76, 15.12 Q 777.86, 15.66, 787.96, 16.63 Q 798.06,\
                  15.70, 808.16, 16.04 Q 818.27, 15.34, 828.37, 14.62 Q 838.47, 15.08, 848.57, 15.71 Q 858.67, 15.44, 868.78, 15.41 Q 878.88,\
                  15.66, 888.98, 16.07 Q 899.08, 15.34, 909.18, 15.49 Q 919.29, 15.34, 929.39, 15.84 Q 939.49, 15.73, 949.59, 15.49 Q 959.69,\
                  15.21, 969.80, 15.58 Q 979.90, 16.00, 990.00, 16.00" style="marker-start:;marker-end:" class="svg_unselected_element"/>\
               </svg:svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page877094969-layer-text166268084" style="position: absolute; left: 295px; top: 1930px; width: 263px; height: 37px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text166268084" data-review-reference-id="text166268084">\
         <div class="stencil-wrapper" style="width: 263px; height: 37px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline12"><p class="none" style="font-size: 32px;"><span style="color: #658cd9;">Quản lí đơn hàng </span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page877094969-layer-combobox469175857" style="position: absolute; left: 920px; top: 1930px; width: 150px; height: 30px" data-interactive-element-type="default.combobox" class="combobox stencil mobile-interaction-potential-trigger " data-stencil-id="combobox469175857" data-review-reference-id="combobox469175857">\
         <div class="stencil-wrapper" style="width: 150px; height: 30px">\
            <div style="position:absolute;left:2px;top:0px;">\
               <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" style="position: absolute; height: 30px;width:150px;" width="150" height="30">\
                  <svg:g id="__containerId__-page877094969-layer-combobox469175857" width="150" height="30"><svg:path id="__containerId__-page877094969-layer-combobox469175857_input_svg_border" d="M 2.00, 2.00 Q 12.43, 1.47, 22.86,\
                     1.31 Q 33.29, 1.38, 43.71, 1.03 Q 54.14, 1.08, 64.57, 1.25 Q 75.00, 1.99, 85.43, 1.18 Q 95.86, 1.36, 106.29, 0.91 Q 116.71,\
                     1.04, 127.14, 1.09 Q 137.57, 1.38, 147.95, 2.05 Q 148.28, 14.91, 148.26, 28.26 Q 137.74, 28.60, 127.18, 28.29 Q 116.72, 28.16,\
                     106.30, 28.68 Q 95.87, 29.11, 85.43, 29.01 Q 75.00, 28.64, 64.57, 29.27 Q 54.14, 29.83, 43.71, 29.49 Q 33.29, 28.32, 22.86,\
                     28.67 Q 12.43, 28.60, 1.51, 28.49 Q 2.00, 15.00, 2.00, 2.00" style=" fill:white;" class="svg_unselected_element"/>\
                  </svg:g>\
               </svg:svg>\
               <div title="" style="position:absolute"><select id="__containerId__-page877094969-layer-combobox469175857select" onblur="rabbit.facade.raiseEvent(rabbit.events.svgBlur, \'__containerId__-page877094969-layer-combobox469175857_input_svg_border\')" onfocus="rabbit.facade.raiseEvent(rabbit.events.svgFocus, \'__containerId__-page877094969-layer-combobox469175857_input_svg_border\')" style="width:146px; height:26px;" title="">\
                     <option title="">Chờ xác nhận</option>\
                     <option title="">Chua thanh toán</option>\
                     <option title="">Đã thanh toán</option>\
                     <option title="">Đã hủy</option></select></div>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page877094969-layer-iphoneButton802438047" style="position: absolute; left: 845px; top: 1865px; width: 88px; height: 30px" data-interactive-element-type="default.iphoneButton" class="iphoneButton stencil mobile-interaction-potential-trigger " data-stencil-id="iphoneButton802438047" data-review-reference-id="iphoneButton802438047">\
         <div class="stencil-wrapper" style="width: 88px; height: 30px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" title="" style="position: absolute; left: -2px; top: -2px;height: 34px;width:92px;">\
               <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" class="helvetica-font" width="92" height="34" viewBox="-2 -2 92 34">\
                  <svg:a><svg:path d="M 4.00, 29.00 Q 3.69, 27.11, 2.89, 27.11 Q 2.62, 26.20, 1.86, 25.73 Q 2.64, 13.76, 1.57, 2.10 Q 2.08, 1.19, 1.61,\
                     -0.35 Q 3.43, 0.07, 4.38, 0.18 Q 14.30, -0.65, 24.49, -1.19 Q 34.71, -2.04, 45.00, -1.03 Q 55.25, -1.26, 65.49, -2.21 Q 75.75,\
                     -2.26, 85.92, -0.66 Q 86.85, -0.10, 87.64, 0.41 Q 88.33, 1.12, 89.32, 1.90 Q 89.32, 13.95, 89.54, 26.09 Q 89.34, 27.28, 89.05,\
                     28.93 Q 88.22, 30.13, 86.50, 30.54 Q 76.01, 30.76, 65.64, 30.94 Q 55.31, 30.57, 45.03, 30.80 Q 34.77, 31.48, 24.51, 30.16\
                     Q 14.25, 29.00, 4.00, 29.00" style="fill-rule:evenodd;clip-rule:evenodd;fill:#808080;stroke:#666666;" class="svg_unselected_element"/>\
                     <svg:text x="44" y="15" dy="0.3em" fill="#FFFFFF" style="font-size:1em;stroke-width:0pt;" font-family="\'HelveticaNeue-Bold\'" text-anchor="middle" xml:space="preserve">Lưu thay đổi</svg:text>\
                  </svg:a>\
               </svg:svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page877094969-layer-rect677090278" style="position: absolute; left: 280px; top: 1995px; width: 940px; height: 110px" data-interactive-element-type="static.rect" class="rect stencil mobile-interaction-potential-trigger " data-stencil-id="rect677090278" data-review-reference-id="rect677090278">\
         <div class="stencil-wrapper" style="width: 940px; height: 110px">\
            <div title="">\
               <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" style="height: 110px;width:940px;" width="940" height="110">\
                  <svg:g width="940" height="110"><svg:path d="M 2.00, 2.00 Q 12.17, 2.26, 22.35, 2.66 Q 32.52, 2.45, 42.70, 1.90 Q 52.87, 1.27, 63.04, 1.91 Q 73.22, 2.13,\
                     83.39, 1.88 Q 93.57, 1.51, 103.74, 1.87 Q 113.91, 1.45, 124.09, 2.49 Q 134.26, 1.99, 144.43, 1.94 Q 154.61, 3.12, 164.78,\
                     1.79 Q 174.96, 2.10, 185.13, 1.26 Q 195.30, 2.02, 205.48, 1.77 Q 215.65, 1.21, 225.83, 1.44 Q 236.00, 1.97, 246.17, 3.10 Q\
                     256.35, 2.75, 266.52, 2.49 Q 276.70, 1.93, 286.87, 1.97 Q 297.04, 2.76, 307.22, 3.44 Q 317.39, 3.18, 327.57, 2.22 Q 337.74,\
                     2.79, 347.91, 2.80 Q 358.09, 1.86, 368.26, 1.41 Q 378.43, 1.42, 388.61, 2.16 Q 398.78, 2.24, 408.96, 1.69 Q 419.13, 1.87,\
                     429.30, 1.43 Q 439.48, 0.95, 449.65, 2.02 Q 459.83, 1.55, 470.00, 1.84 Q 480.17, 1.21, 490.35, 2.14 Q 500.52, 2.26, 510.70,\
                     2.38 Q 520.87, 2.65, 531.04, 2.74 Q 541.22, 2.46, 551.39, 1.53 Q 561.57, 1.48, 571.74, 0.40 Q 581.91, 1.52, 592.09, 1.50 Q\
                     602.26, 2.10, 612.43, 2.82 Q 622.61, 3.15, 632.78, 2.60 Q 642.96, 1.27, 653.13, 1.77 Q 663.30, 1.21, 673.48, 2.11 Q 683.65,\
                     1.70, 693.83, 1.96 Q 704.00, 2.08, 714.17, 1.91 Q 724.35, 1.76, 734.52, 1.73 Q 744.70, 1.93, 754.87, 1.10 Q 765.04, 1.50,\
                     775.22, 1.11 Q 785.39, 1.25, 795.56, 0.82 Q 805.74, 0.42, 815.91, 0.52 Q 826.09, 0.49, 836.26, 1.23 Q 846.43, 0.91, 856.61,\
                     1.41 Q 866.78, 1.31, 876.96, 1.18 Q 887.13, 1.58, 897.30, 2.13 Q 907.48, 2.93, 917.65, 1.63 Q 927.83, 2.18, 938.01, 1.99 Q\
                     938.42, 12.46, 938.75, 23.09 Q 938.23, 33.78, 938.23, 44.39 Q 938.05, 55.00, 937.99, 65.60 Q 938.38, 76.20, 937.88, 86.80\
                     Q 938.41, 97.40, 937.93, 107.93 Q 927.76, 107.80, 917.61, 107.72 Q 907.46, 107.67, 897.31, 108.07 Q 887.13, 107.92, 876.96,\
                     108.74 Q 866.78, 108.65, 856.61, 107.84 Q 846.43, 108.56, 836.26, 108.87 Q 826.09, 108.80, 815.91, 107.87 Q 805.74, 108.39,\
                     795.56, 108.86 Q 785.39, 109.45, 775.22, 108.74 Q 765.04, 109.37, 754.87, 108.20 Q 744.70, 108.52, 734.52, 107.93 Q 724.35,\
                     107.83, 714.17, 108.73 Q 704.00, 109.42, 693.83, 109.45 Q 683.65, 109.08, 673.48, 107.94 Q 663.30, 108.61, 653.13, 109.36\
                     Q 642.96, 109.03, 632.78, 107.92 Q 622.61, 108.14, 612.43, 108.37 Q 602.26, 108.48, 592.09, 107.97 Q 581.91, 107.64, 571.74,\
                     107.77 Q 561.57, 108.10, 551.39, 107.61 Q 541.22, 107.94, 531.04, 108.24 Q 520.87, 108.51, 510.70, 108.28 Q 500.52, 108.08,\
                     490.35, 107.90 Q 480.17, 108.31, 470.00, 109.14 Q 459.83, 108.85, 449.65, 108.18 Q 439.48, 108.22, 429.30, 108.90 Q 419.13,\
                     109.15, 408.96, 108.67 Q 398.78, 108.43, 388.61, 108.76 Q 378.43, 109.54, 368.26, 109.52 Q 358.09, 109.42, 347.91, 109.51\
                     Q 337.74, 109.59, 327.57, 109.75 Q 317.39, 109.47, 307.22, 108.67 Q 297.04, 108.09, 286.87, 108.75 Q 276.70, 108.66, 266.52,\
                     107.89 Q 256.35, 107.44, 246.17, 107.80 Q 236.00, 108.31, 225.83, 108.18 Q 215.65, 107.68, 205.48, 107.50 Q 195.30, 107.26,\
                     185.13, 107.34 Q 174.96, 107.13, 164.78, 106.07 Q 154.61, 106.70, 144.43, 108.06 Q 134.26, 107.99, 124.09, 107.72 Q 113.91,\
                     108.18, 103.74, 108.73 Q 93.57, 109.18, 83.39, 109.30 Q 73.22, 109.28, 63.04, 109.25 Q 52.87, 109.14, 42.70, 107.88 Q 32.52,\
                     108.15, 22.35, 109.02 Q 12.17, 108.97, 1.39, 108.61 Q 0.82, 97.79, 1.50, 86.87 Q 1.66, 76.22, 1.61, 65.61 Q 2.02, 55.00, 2.73,\
                     44.39 Q 1.76, 33.80, 1.45, 23.20 Q 2.00, 12.60, 2.00, 2.00" style=" fill:white;" class="svg_unselected_element"/>\
                  </svg:g>\
               </svg:svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page877094969-layer-image895596860" style="position: absolute; left: 285px; top: 1995px; width: 110px; height: 110px" data-interactive-element-type="default.image" class="image stencil mobile-interaction-potential-trigger " data-stencil-id="image895596860" data-review-reference-id="image895596860">\
         <div class="stencil-wrapper" style="width: 110px; height: 110px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" title="">\
               <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" class="image-cropper" style="height: 110px;width:110px;" width="110" height="110">\
                  <svg:g width="110" height="110">\
                     <svg:svg x="1" y="1" width="108" height="108">\
                        <svg:image width="256" height="256" xlink:href="../repoimages/506350.png" preserveAspectRatio="none" transform="scale(0.4296875,0.4296875) translate(-0,-0)  "></svg:image>\
                     </svg:svg>\
                  </svg:g>\
               </svg:svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page877094969-layer-text334632003" style="position: absolute; left: 425px; top: 2000px; width: 166px; height: 28px" data-interactive-element-type="default.text2" class="text2 pidoco-clickable-element stencil mobile-interaction-potential-trigger " data-stencil-id="text334632003" data-review-reference-id="text334632003">\
         <div class="stencil-wrapper" style="width: 166px; height: 28px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline12"><p><span style="font-size: 24px; color: #000000;">Nguyễn Hoàng</span></p></span></span></div>\
         </div><script type="text/javascript">\
			$(document).ready(function(){\
				rabbit.interaction.manager.registerInteraction(\'__containerId__-page877094969-layer-text334632003\', \'interaction27284189\', \
		{\
		\
			\'button\': \'left\'\
			\
				,\
			\
			\'id\': \'action902408447\'\
			\
				,\
			\
			\'numberOfFinger\': \'1\'\
			\
				,\
			\
			\'type\': \'click\'\
			\
		}\
	,  \
					[\
						\
		{\
		\
			\'delay\': \'0\'\
			\
				,\
			\
			\'id\': \'reaction727175414\'\
			\
				,\
			\
			\'options\': \'withoutReloadOnly\'\
			\
				,\
			\
			\'target\': \'page497958436\'\
			\
				,\
			\
			\'transition\': \'none\'\
			\
				,\
			\
			\'type\': \'showPage\'\
			\
		}\
	\
					]\
				);\
			});\
		</script></div>\
      <div id="__containerId__-page877094969-layer-text530528228" style="position: absolute; left: 425px; top: 2035px; width: 116px; height: 21px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text530528228" data-review-reference-id="text530528228">\
         <div class="stencil-wrapper" style="width: 116px; height: 21px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline22"><p><span style="font-size: 18px; color: #000000;">01698880299</span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page877094969-layer-text99874521" style="position: absolute; left: 425px; top: 2070px; width: 102px; height: 28px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text99874521" data-review-reference-id="text99874521">\
         <div class="stencil-wrapper" style="width: 102px; height: 28px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline22"><p><span style="font-size: 24px; color: #658cd9;">Mã đơn: </span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page877094969-layer-text359443024" style="position: absolute; left: 520px; top: 2070px; width: 110px; height: 28px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text359443024" data-review-reference-id="text359443024">\
         <div class="stencil-wrapper" style="width: 110px; height: 28px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline22"><p class="none" style="font-size: 24px;">XZ32174 </p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page877094969-layer-icon509341845" style="position: absolute; left: 715px; top: 2005px; width: 32px; height: 32px" data-interactive-element-type="fonticon.icon" class="icon stencil mobile-interaction-potential-trigger " data-stencil-id="icon509341845" data-review-reference-id="icon509341845">\
         <div class="stencil-wrapper" style="width: 32px; height: 32px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" style="width:32px;height:32px;" title="">\
               <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" class="fill-blue">\
                  <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#icon-glyph-e056"></use>\
               </svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page877094969-layer-text627613458" style="position: absolute; left: 765px; top: 2010px; width: 164px; height: 21px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text627613458" data-review-reference-id="text627613458">\
         <div class="stencil-wrapper" style="width: 164px; height: 21px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.text2"><p style="font-size: 14px;"><span style="font-size: 18px;">9h AM - 09/08/2016</span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page877094969-layer-icon17437722" style="position: absolute; left: 715px; top: 2050px; width: 32px; height: 32px" data-interactive-element-type="fonticon.icon" class="icon stencil mobile-interaction-potential-trigger " data-stencil-id="icon17437722" data-review-reference-id="icon17437722">\
         <div class="stencil-wrapper" style="width: 32px; height: 32px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" style="width:32px;height:32px;" title="">\
               <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" class="fill-blue">\
                  <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#icon-glyph-e044"></use>\
               </svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page877094969-layer-text314740325" style="position: absolute; left: 765px; top: 2055px; width: 69px; height: 21px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text314740325" data-review-reference-id="text314740325">\
         <div class="stencil-wrapper" style="width: 69px; height: 21px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline22"><p><span style="font-size: 18px;">5 người</span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page877094969-layer-text488545658" style="position: absolute; left: 815px; top: 1930px; width: 98px; height: 28px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text488545658" data-review-reference-id="text488545658">\
         <div class="stencil-wrapper" style="width: 98px; height: 28px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline12"><p><span style="font-size: 24px; color: #658cd9;">Lọc theo</span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page877094969-layer-icon423266493" style="position: absolute; left: 985px; top: 2005px; width: 32px; height: 32px" data-interactive-element-type="fonticon.icon" class="icon stencil mobile-interaction-potential-trigger " data-stencil-id="icon423266493" data-review-reference-id="icon423266493">\
         <div class="stencil-wrapper" style="width: 32px; height: 32px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" style="width:32px;height:32px;" title="">\
               <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" class="fill-green">\
                  <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#icon-glyph-e203"></use>\
               </svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page877094969-layer-711753760" style="position: absolute; left: 1035px; top: 2005px; width: 150px; height: 30px" data-interactive-element-type="default.combobox" class="combobox stencil mobile-interaction-potential-trigger " data-stencil-id="711753760" data-review-reference-id="711753760">\
         <div class="stencil-wrapper" style="width: 150px; height: 30px">\
            <div style="position:absolute;left:2px;top:0px;">\
               <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" style="position: absolute; height: 30px;width:150px;" width="150" height="30">\
                  <svg:g id="__containerId__-page877094969-layer-711753760" width="150" height="30"><svg:path id="__containerId__-page877094969-layer-711753760_input_svg_border" d="M 2.00, 2.00 Q 12.43, 3.47, 22.86, 3.15 Q\
                     33.29, 2.41, 43.71, 2.50 Q 54.14, 1.40, 64.57, 1.10 Q 75.00, 1.69, 85.43, 1.74 Q 95.86, 0.96, 106.29, 1.33 Q 116.71, 1.38,\
                     127.14, 1.08 Q 137.57, 1.18, 148.20, 1.80 Q 148.27, 14.91, 148.36, 28.35 Q 137.86, 29.06, 127.23, 28.75 Q 116.77, 29.01, 106.31,\
                     28.81 Q 95.86, 27.88, 85.43, 28.93 Q 75.00, 29.34, 64.57, 29.60 Q 54.14, 29.90, 43.71, 29.43 Q 33.29, 29.43, 22.86, 28.89\
                     Q 12.43, 29.53, 1.33, 28.67 Q 2.00, 15.00, 2.00, 2.00" style=" fill:white;" class="svg_unselected_element"/>\
                  </svg:g>\
               </svg:svg>\
               <div title="" style="position:absolute"><select id="__containerId__-page877094969-layer-711753760select" onblur="rabbit.facade.raiseEvent(rabbit.events.svgBlur, \'__containerId__-page877094969-layer-711753760_input_svg_border\')" onfocus="rabbit.facade.raiseEvent(rabbit.events.svgFocus, \'__containerId__-page877094969-layer-711753760_input_svg_border\')" style="width:146px; height:26px;" title="">\
                     <option title="">Chờ xác nhận</option>\
                     <option title="">Chưa thanh toán</option>\
                     <option title="">Đã thanh toán</option>\
                     <option title="">Đã hủy</option></select></div>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page877094969-layer-iphoneButton295393355" style="position: absolute; left: 1060px; top: 2055px; width: 88px; height: 30px" data-interactive-element-type="default.iphoneButton" class="iphoneButton stencil mobile-interaction-potential-trigger " data-stencil-id="iphoneButton295393355" data-review-reference-id="iphoneButton295393355">\
         <div class="stencil-wrapper" style="width: 88px; height: 30px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" title="" style="position: absolute; left: -2px; top: -2px;height: 34px;width:92px;">\
               <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" class="helvetica-font" width="92" height="34" viewBox="-2 -2 92 34">\
                  <svg:a><svg:path d="M 4.00, 29.00 Q 2.80, 28.90, 1.65, 28.35 Q 1.05, 27.32, 0.31, 26.22 Q 0.18, 14.12, 0.67, 1.94 Q 1.37, 0.96, 1.60,\
                     -0.35 Q 3.14, -0.31, 3.79, -1.64 Q 14.16, -1.60, 24.48, -1.23 Q 34.75, -0.86, 44.99, -1.42 Q 55.24, -1.91, 65.50, -1.20 Q\
                     75.75, -0.43, 85.73, 0.14 Q 87.08, -0.73, 88.28, -0.31 Q 88.77, 0.80, 89.17, 1.95 Q 89.34, 13.95, 88.59, 25.93 Q 88.11, 26.87,\
                     87.88, 27.90 Q 86.85, 28.30, 86.29, 29.91 Q 75.96, 30.41, 65.56, 29.79 Q 55.23, 28.50, 45.00, 29.16 Q 34.75, 29.16, 24.50,\
                     28.91 Q 14.25, 29.00, 4.00, 29.00" style="fill-rule:evenodd;clip-rule:evenodd;fill:#808080;stroke:#666666;" class="svg_unselected_element"/>\
                     <svg:text x="44" y="15" dy="0.3em" fill="#FFFFFF" style="font-size:1em;stroke-width:0pt;" font-family="\'HelveticaNeue-Bold\'" text-anchor="middle" xml:space="preserve">Lưu thay đổi</svg:text>\
                  </svg:a>\
               </svg:svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page877094969-layer-iphoneButton545075569" style="position: absolute; left: 955px; top: 1865px; width: 69px; height: 30px" data-interactive-element-type="default.iphoneButton" class="iphoneButton stencil mobile-interaction-potential-trigger " data-stencil-id="iphoneButton545075569" data-review-reference-id="iphoneButton545075569">\
         <div class="stencil-wrapper" style="width: 69px; height: 30px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" title="" style="position: absolute; left: -2px; top: -2px;height: 34px;width:73px;">\
               <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" class="helvetica-font" width="73" height="34" viewBox="-2 -2 73 34">\
                  <svg:a><svg:path d="M 4.00, 29.00 Q 3.87, 28.13, 4.20, 27.50 Q 4.77, 14.66, 4.17, 2.38 Q 4.32, 2.03, 4.35, 1.68 Q 17.84, 1.40, 31.56,\
                     1.62 Q 45.28, 1.55, 58.74, 2.19 Q 59.65, 2.50, 60.47, 2.69 Q 64.95, 9.02, 70.20, 14.99 Q 65.68, 21.56, 61.24, 28.22 Q 59.83,\
                     28.27, 59.14, 29.45 Q 45.24, 28.96, 31.44, 28.13 Q 17.75, 29.00, 4.00, 29.00" style="fill-rule:evenodd;clip-rule:evenodd;fill:#808080;stroke:#666666;"\
                     class="svg_unselected_element"/>\
                     <svg:text x="31.5" y="15" dy="0.3em" fill="#FFFFFF" style="font-size:1em;stroke-width:0pt;" font-family="\'HelveticaNeue-Bold\'" text-anchor="middle" xml:space="preserve">Xem thử </svg:text>\
                  </svg:a>\
               </svg:svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page877094969-layer-441600098" style="position: absolute; left: 230px; top: 2365px; width: 1025px; height: 33px" data-interactive-element-type="static.line" class="line stencil mobile-interaction-potential-trigger " data-stencil-id="441600098" data-review-reference-id="441600098">\
         <div class="stencil-wrapper" style="width: 1025px; height: 33px">\
            <div title="">\
               <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" style="position: absolute; left: -5px; top: -5px; height: 43px;width:1035px;" viewBox="-5 -5 1035 43" width="1035" height="43"><svg:path d="M 0.00, 16.00 Q 10.05, 13.19, 20.10, 13.91 Q 30.15, 13.85, 40.20, 15.06 Q 50.25, 14.25, 60.29, 14.38 Q 70.34,\
                  14.95, 80.39, 15.85 Q 90.44, 16.11, 100.49, 14.66 Q 110.54, 14.69, 120.59, 15.16 Q 130.64, 15.33, 140.69, 15.30 Q 150.74,\
                  15.27, 160.78, 15.63 Q 170.83, 15.71, 180.88, 15.67 Q 190.93, 15.32, 200.98, 14.61 Q 211.03, 14.55, 221.08, 14.63 Q 231.13,\
                  14.53, 241.18, 14.51 Q 251.23, 14.42, 261.27, 14.61 Q 271.32, 14.59, 281.37, 14.51 Q 291.42, 14.45, 301.47, 14.40 Q 311.52,\
                  15.45, 321.57, 15.45 Q 331.62, 15.05, 341.67, 14.83 Q 351.72, 14.24, 361.76, 14.51 Q 371.81, 14.90, 381.86, 14.54 Q 391.91,\
                  15.04, 401.96, 15.04 Q 412.01, 15.50, 422.06, 15.20 Q 432.11, 14.99, 442.16, 15.13 Q 452.21, 15.06, 462.25, 14.90 Q 472.30,\
                  15.20, 482.35, 15.32 Q 492.40, 15.15, 502.45, 15.39 Q 512.50, 15.05, 522.55, 15.35 Q 532.60, 15.04, 542.65, 15.44 Q 552.70,\
                  15.16, 562.74, 14.66 Q 572.79, 14.52, 582.84, 14.49 Q 592.89, 14.98, 602.94, 14.42 Q 612.99, 15.16, 623.04, 16.72 Q 633.09,\
                  16.86, 643.14, 16.61 Q 653.19, 16.57, 663.24, 16.46 Q 673.28, 16.73, 683.33, 16.07 Q 693.38, 15.21, 703.43, 15.15 Q 713.48,\
                  15.11, 723.53, 15.09 Q 733.58, 15.39, 743.63, 15.64 Q 753.68, 15.13, 763.73, 14.99 Q 773.77, 15.76, 783.82, 16.05 Q 793.87,\
                  15.95, 803.92, 15.69 Q 813.97, 15.74, 824.02, 15.54 Q 834.07, 15.21, 844.12, 14.73 Q 854.17, 16.12, 864.22, 14.84 Q 874.26,\
                  14.71, 884.31, 14.87 Q 894.36, 14.83, 904.41, 14.67 Q 914.46, 14.65, 924.51, 14.66 Q 934.56, 14.86, 944.61, 15.42 Q 954.66,\
                  14.78, 964.71, 15.44 Q 974.75, 15.25, 984.80, 15.41 Q 994.85, 15.46, 1004.90, 15.91 Q 1014.95, 16.00, 1025.00, 16.00" style="marker-start:;marker-end:"\
                  class="svg_unselected_element"/>\
               </svg:svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page877094969-layer-text183650169" style="position: absolute; left: 255px; top: 2410px; width: 140px; height: 38px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text183650169" data-review-reference-id="text183650169">\
         <div class="stencil-wrapper" style="width: 140px; height: 38px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline12"><p><span style="font-size: 32px; color: #658cd9;">Thống kê</span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page877094969-layer-text109270929" style="position: absolute; left: 895px; top: 2070px; width: 110px; height: 16px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text109270929" data-review-reference-id="text109270929">\
         <div class="stencil-wrapper" style="width: 110px; height: 16px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.text2"><p class="none" style="font-size: 14px;"><span class="underline" style="color: #658cd9;">Chi tiết đặt hàng</span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page877094969-layer-text117133676" style="position: absolute; left: 245px; top: 2620px; width: 249px; height: 28px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text117133676" data-review-reference-id="text117133676">\
         <div class="stencil-wrapper" style="width: 249px; height: 28px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline12"><p><span style="font-size: 24px; color: #658cd9;">Tổng số đơn hàng: </span><span style="font-size: 24px;">124</span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page877094969-layer-text173144628" style="position: absolute; left: 1100px; top: 2710px; width: 170px; height: 23px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text173144628" data-review-reference-id="text173144628">\
         <div class="stencil-wrapper" style="width: 170px; height: 23px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline32"><p class="none" style="font-size: 18px;"><span style="color: #b1c51a; font-size: 20px;">Đã thanh toán: 67  </span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page877094969-layer-text443182638" style="position: absolute; left: 1100px; top: 2740px; width: 101px; height: 23px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text443182638" data-review-reference-id="text443182638">\
         <div class="stencil-wrapper" style="width: 101px; height: 23px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline32"><p class="none" style="font-size: 18px;"><span style="color: #f2a63f; font-size: 20px;">Đã hủy:33 </span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page877094969-layer-text360191602" style="position: absolute; left: 1100px; top: 2650px; width: 173px; height: 23px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text360191602" data-review-reference-id="text360191602">\
         <div class="stencil-wrapper" style="width: 173px; height: 23px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline32"><p><span style="font-size: 20px; color: #658cd9;">Chờ thanh toán: 10</span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page877094969-layer-text605851011" style="position: absolute; left: 1100px; top: 2680px; width: 183px; height: 23px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text605851011" data-review-reference-id="text605851011">\
         <div class="stencil-wrapper" style="width: 183px; height: 23px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline32"><p class="none" style="font-size: 18px;"><span style="font-size: 20px; color: #d96666;">Chưa xác nhận : 14 </span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page877094969-layer-text808415298" style="position: absolute; left: 240px; top: 2710px; width: 330px; height: 28px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text808415298" data-review-reference-id="text808415298">\
         <div class="stencil-wrapper" style="width: 330px; height: 28px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline32"><p><span style="font-size: 24px; color: #658cd9;">Tổng doanh thu: </span><span style="font-size: 24px;">8.756.000</span><span\
                     style="font-size: 24px; color: #658cd9;"> Vnđ</span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page877094969-layer-icon38206356" style="position: absolute; left: 730px; top: 2550px; width: 360px; height: 360px" data-interactive-element-type="fonticon.icon" class="icon stencil mobile-interaction-potential-trigger " data-stencil-id="icon38206356" data-review-reference-id="icon38206356">\
         <div class="stencil-wrapper" style="width: 360px; height: 360px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" style="width:360px;height:360px;" title="">\
               <svg xmlns="http://www.w3.org/2000/svg" width="360" height="360" class="fill-black">\
                  <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#icon-glyph-e043"></use>\
               </svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page877094969-layer-text156510226" style="position: absolute; left: 415px; top: 965px; width: 113px; height: 20px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text156510226" data-review-reference-id="text156510226">\
         <div class="stencil-wrapper" style="width: 113px; height: 20px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.link2"><p style="font-size: 14px;"><span class="underline" style="font-size: 18px; color: #658cd9;">Thêm địa chỉ</span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page877094969-layer-chart304927956" style="position: absolute; left: 265px; top: 2990px; width: 885px; height: 300px" data-interactive-element-type="static.chart" class="chart stencil mobile-interaction-potential-trigger " data-stencil-id="chart304927956" data-review-reference-id="chart304927956">\
         <div class="stencil-wrapper" style="width: 885px; height: 300px">\
            <div title="">\
               <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" style="height: 300px;width:885px;" viewBox="0 0 885 300" width="885" height="300">\
                  <svg:g width="885" height="300">\
                     <svg:g transform="scale(4.916666666666667, 2)"><svg:path id="defaultID" d="M 0.00, 0.00 Q 10.00, 0.66, 20.00, 0.16 Q 30.00, -0.11, 40.00, -0.99 Q 50.00, -0.90, 60.00, -0.80\
                        Q 70.00, -1.26, 80.00, -0.89 Q 90.00, -0.95, 100.00, -1.69 Q 110.00, -1.73, 120.00, -1.91 Q 130.00, -1.95, 140.00, -2.21 Q\
                        150.00, -1.92, 160.00, -0.43 Q 170.00, -0.13, 180.40, -0.40 Q 180.69, 10.48, 181.56, 21.21 Q 181.42, 32.05, 181.74, 42.80\
                        Q 181.77, 53.54, 181.55, 64.27 Q 181.43, 74.99, 181.80, 85.71 Q 182.21, 96.43, 182.24, 107.14 Q 181.63, 117.86, 181.28, 128.57\
                        Q 179.50, 139.29, 179.75, 149.75 Q 170.03, 150.08, 159.92, 149.41 Q 149.99, 149.87, 140.01, 150.21 Q 130.00, 150.06, 120.00,\
                        149.60 Q 110.00, 151.08, 100.00, 151.52 Q 90.00, 151.34, 80.00, 151.03 Q 70.00, 151.17, 60.00, 151.05 Q 50.00, 151.09, 40.00,\
                        151.13 Q 30.00, 150.91, 20.00, 150.96 Q 10.00, 151.24, -0.49, 150.49 Q -0.55, 139.47, -1.25, 128.75 Q -1.85, 117.98, -1.66,\
                        107.20 Q -1.59, 96.45, -1.69, 85.73 Q -1.80, 75.01, -1.00, 64.29 Q -1.61, 53.57, -0.92, 42.86 Q -0.39, 32.14, 0.37, 21.43\
                        Q 0.00, 10.71, 0.00, -0.00" style="fill:white;stroke:none;" class="svg_unselected_element"/>\
                        <svg:g name="line" style="fill:none;stroke:black;stroke-width:1px;"><svg:path d="M 9.00, 3.00 Q 11.30, 14.42, 10.81, 25.83 Q 10.46, 37.25, 10.24, 48.67 Q 9.95, 60.08, 9.82, 71.50 Q 9.95, 82.92,\
                           10.09, 94.33 Q 10.16, 105.75, 10.09, 117.17 Q 9.90, 128.58, 9.52, 139.48 Q 20.68, 139.02, 31.88, 138.85 Q 43.16, 138.67, 54.48,\
                           138.39 Q 65.80, 138.79, 77.15, 138.66 Q 88.51, 138.62, 99.86, 138.82 Q 111.21, 139.46, 122.57, 139.33 Q 133.93, 138.93, 145.29,\
                           138.71 Q 156.64, 138.82, 168.00, 138.40 Q 172.00, 140.00, 176.00, 140.00" style=" fill:none;" class="svg_unselected_element"/><svg:path d="M 167.00, 135.00 Q 172.40, 136.69, 177.30, 140.00 Q 172.00, 142.50, 167.00, 145.00" style=" fill:none;" class="svg_unselected_element"/><svg:path d="M 4.00, 13.00 Q 6.38, 7.94, 9.00, 2.84 Q 11.50, 8.00, 14.00, 13.00" style=" fill:none;" class="svg_unselected_element"/><svg:path d="M 9.00, 140.00 Q 18.51, 125.26, 28.98, 111.05 Q 36.96, 103.93, 46.01, 97.11 Q 50.44, 101.12, 53.73, 105.11 Q\
                           60.33, 96.61, 67.41, 88.38 Q 70.13, 84.68, 72.82, 81.37 Q 74.00, 77.62, 75.10, 73.46 Q 78.34, 70.02, 82.07, 66.61 Q 87.13,\
                           81.40, 91.94, 95.92 Q 94.26, 85.89, 96.25, 75.47 Q 100.58, 70.26, 105.38, 65.67 Q 108.86, 58.15, 110.60, 49.75 Q 116.03, 43.16,\
                           122.01, 36.84 Q 124.75, 40.69, 127.16, 44.90 Q 128.58, 47.73, 129.29, 50.51 Q 134.09, 50.63, 139.04, 51.08 Q 145.11, 40.10,\
                           150.97, 28.95 Q 155.06, 27.63, 158.33, 25.50 Q 159.16, 20.64, 159.52, 14.85 Q 163.50, 14.00, 166.00, 12.00" style=" fill:none;"\
                           class="svg_unselected_element"/><svg:path d="M 10.00, 140.00 Q 12.77, 123.20, 16.50, 106.33 Q 21.95, 98.13, 27.31, 90.31 Q 29.77, 81.41, 33.68, 72.00 Q 39.36,\
                           75.21, 43.30, 79.12 Q 46.54, 66.97, 50.36, 54.08 Q 55.82, 51.97, 60.89, 50.73 Q 66.57, 41.76, 74.10, 32.84 Q 80.52, 41.80,\
                           85.93, 49.81 Q 92.17, 46.09, 99.31, 42.17 Q 105.52, 50.36, 111.72, 58.26 Q 116.99, 63.54, 122.16, 69.37 Q 125.84, 83.48, 129.22,\
                           97.45 Q 134.52, 108.00, 139.00, 118.41 Q 142.11, 110.12, 147.44, 102.35 Q 150.81, 113.82, 154.32, 124.74 Q 159.50, 130.50,\
                           165.00, 136.00" style=" fill:none;" class="svg_unselected_element"/>\
                        </svg:g>\
                     </svg:g>\
                  </svg:g>\
               </svg:svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page877094969-layer-rating524234324" style="position: absolute; left: 260px; top: 2465px; width: 150px; height: 30px" data-interactive-element-type="default.rating" class="rating stencil mobile-interaction-potential-trigger " data-stencil-id="rating524234324" data-review-reference-id="rating524234324">\
         <div class="stencil-wrapper" style="width: 150px; height: 30px">\
            <div style="width:150px; height:30px" onmouseout="if(rabbit.stencils.rating.checkMouseOutDiv(\'__containerId__-page877094969-layer-rating524234324\', event)) rabbit.facade.raiseEvent(rabbit.events.ratingMouseOut, \'__containerId__-page877094969-layer-rating524234324\');" title=""><img id="__containerId__-page877094969-layer-rating524234324-1" src="../resources/icons/rating_black.png" width="30" height="30" style="position: absolute; left: 0px; cursor: pointer;" onmouseover="rabbit.facade.raiseEvent(rabbit.events.ratingMouseOver, \'__containerId__-page877094969-layer-rating524234324\', \'1\');" onclick="rabbit.facade.raiseEvent(rabbit.events.ratingResultChangedEvent, \'__containerId__-page877094969-layer-rating524234324\', \'1\');" /><img id="__containerId__-page877094969-layer-rating524234324-2" src="../resources/icons/rating_black.png" width="30" height="30" style="position: absolute; left: 30px; cursor: pointer;" onmouseover="rabbit.facade.raiseEvent(rabbit.events.ratingMouseOver, \'__containerId__-page877094969-layer-rating524234324\', \'2\');" onclick="rabbit.facade.raiseEvent(rabbit.events.ratingResultChangedEvent, \'__containerId__-page877094969-layer-rating524234324\', \'2\');" /><img id="__containerId__-page877094969-layer-rating524234324-3" src="../resources/icons/rating_black.png" width="30" height="30" style="position: absolute; left: 60px; cursor: pointer;" onmouseover="rabbit.facade.raiseEvent(rabbit.events.ratingMouseOver, \'__containerId__-page877094969-layer-rating524234324\', \'3\');" onclick="rabbit.facade.raiseEvent(rabbit.events.ratingResultChangedEvent, \'__containerId__-page877094969-layer-rating524234324\', \'3\');" /><img id="__containerId__-page877094969-layer-rating524234324-4" src="../resources/icons/rating_black.png" width="30" height="30" style="position: absolute; left: 90px; cursor: pointer;" onmouseover="rabbit.facade.raiseEvent(rabbit.events.ratingMouseOver, \'__containerId__-page877094969-layer-rating524234324\', \'4\');" onclick="rabbit.facade.raiseEvent(rabbit.events.ratingResultChangedEvent, \'__containerId__-page877094969-layer-rating524234324\', \'4\');" /><img id="__containerId__-page877094969-layer-rating524234324-5" src="../resources/icons/rating_white.png" width="30" height="30" style="position: absolute; left: 120px; cursor: pointer;" onmouseover="rabbit.facade.raiseEvent(rabbit.events.ratingMouseOver, \'__containerId__-page877094969-layer-rating524234324\', \'5\');" onclick="rabbit.facade.raiseEvent(rabbit.events.ratingResultChangedEvent, \'__containerId__-page877094969-layer-rating524234324\', \'5\');" /></div><script type="text/javascript">\
			rabbit.stencils.rating.onLoad("__containerId__-page877094969-layer-rating524234324", "4");\
		</script></div>\
      </div>\
      <div id="__containerId__-page877094969-layer-text235970792" style="position: absolute; left: 675px; top: 2465px; width: 142px; height: 28px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text235970792" data-review-reference-id="text235970792">\
         <div class="stencil-wrapper" style="width: 142px; height: 28px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.link2"><p style="font-size: 14px;"><span class="underline" style="font-size: 24px; color: #658cd9;">12 Nhận xép</span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page877094969-layer-text716186848" style="position: absolute; left: 560px; top: 3290px; width: 361px; height: 37px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text716186848" data-review-reference-id="text716186848">\
         <div class="stencil-wrapper" style="width: 361px; height: 37px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline12"><p class="none" style="font-size: 32px;"><span style="color: #658cd9;">Đơn hàng theo thời gian </span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page877094969-layer-chart653246281" style="position: absolute; left: 915px; top: 3080px; width: 180px; height: 150px" data-interactive-element-type="static.chart" class="chart stencil mobile-interaction-potential-trigger " data-stencil-id="chart653246281" data-review-reference-id="chart653246281">\
         <div class="stencil-wrapper" style="width: 180px; height: 150px">\
            <div title="">\
               <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" style="height: 150px;width:180px;" viewBox="0 0 180 150" width="180" height="150">\
                  <svg:g width="180" height="150">\
                     <svg:g transform="scale(1, 1)"><svg:path id="defaultID" d="M 0.00, 0.00 Q 10.00, 1.93, 20.00, 1.77 Q 30.00, 1.79, 40.00, 1.31 Q 50.00, 1.66, 60.00, 1.08\
                        Q 70.00, 0.46, 80.00, -0.02 Q 90.00, 0.83, 100.00, 1.03 Q 110.00, 0.51, 120.00, -0.20 Q 130.00, -0.44, 140.00, -0.44 Q 150.00,\
                        -0.59, 160.00, -0.16 Q 170.00, -0.37, 179.64, 0.36 Q 179.39, 10.92, 180.02, 21.43 Q 179.74, 32.16, 180.32, 42.85 Q 179.29,\
                        53.58, 180.62, 64.28 Q 180.30, 75.00, 180.20, 85.71 Q 179.95, 96.43, 180.02, 107.14 Q 180.56, 117.86, 180.63, 128.57 Q 180.54,\
                        139.29, 180.00, 150.00 Q 170.16, 150.49, 160.04, 150.25 Q 150.04, 150.54, 139.98, 149.48 Q 129.97, 148.35, 119.99, 149.00\
                        Q 110.00, 149.81, 100.00, 149.97 Q 90.00, 148.89, 80.00, 149.63 Q 70.00, 150.69, 60.00, 150.61 Q 50.00, 149.28, 40.00, 148.81\
                        Q 30.00, 149.58, 20.00, 150.28 Q 10.00, 150.58, 0.19, 149.81 Q 0.18, 139.23, 0.33, 128.52 Q 0.03, 117.85, 0.51, 107.13 Q 0.66,\
                        96.42, -0.14, 85.72 Q -0.38, 75.00, -0.73, 64.29 Q 0.71, 53.57, -0.29, 42.86 Q -0.08, 32.14, -0.38, 21.43 Q 0.00, 10.71, 0.00,\
                        -0.00" style="fill:white;stroke:none;" class="svg_unselected_element"/>\
                        <svg:g style="stroke:black;fill:none;stroke-width:1px;"><svg:path d="M 9.00, 3.00 Q 8.98, 14.42, 8.35, 25.83 Q 8.47, 37.25, 8.74, 48.67 Q 9.86, 60.08, 9.92, 71.50 Q 9.60, 82.92,\
                           9.28, 94.33 Q 9.83, 105.75, 9.72, 117.17 Q 10.06, 128.58, 9.67, 139.33 Q 19.77, 139.19, 30.11, 139.25 Q 40.60, 138.56, 51.02,\
                           139.51 Q 61.50, 140.07, 72.01, 138.78 Q 82.50, 139.50, 93.00, 138.60 Q 103.50, 139.05, 114.00, 138.24 Q 124.50, 138.00, 135.00,\
                           138.02 Q 145.50, 138.59, 156.00, 138.75 Q 166.50, 140.00, 177.00, 140.00" style=" fill:none;" class="svg_unselected_element"/><svg:path d="M 168.00, 135.00 Q 173.81, 135.88, 178.89, 140.00 Q 173.00, 142.50, 168.00, 145.00" style=" fill:none;" class="svg_unselected_element"/><svg:path d="M 4.00, 13.00 Q 6.24, 7.87, 9.00, 2.94 Q 11.50, 8.00, 14.00, 13.00" style=" fill:none;" class="svg_unselected_element"/><svg:path d="M 19.00, 63.00 Q 28.50, 64.89, 37.20, 63.80 Q 37.55, 75.98, 37.44, 88.75 Q 38.21, 101.49, 38.69, 114.31 Q 38.62,\
                           127.16, 37.96, 139.96 Q 28.40, 139.71, 19.33, 139.67 Q 19.93, 126.92, 19.41, 114.29 Q 19.42, 101.48, 18.56, 88.68 Q 19.00,\
                           75.83, 19.00, 63.00" style=" fill:white;" class="svg_unselected_element"/><svg:path d="M 47.00, 47.00 Q 56.50, 44.91, 66.96, 46.04 Q 67.41, 58.16, 67.35, 70.06 Q 67.32, 81.79, 67.43, 93.45 Q 66.79,\
                           105.11, 66.61, 116.75 Q 66.72, 128.37, 66.17, 140.17 Q 56.61, 140.33, 46.73, 140.27 Q 46.36, 128.55, 46.79, 116.77 Q 46.44,\
                           105.15, 46.38, 93.52 Q 46.20, 81.88, 46.40, 70.25 Q 47.00, 58.62, 47.00, 47.00" style=" fill:white;" class="svg_unselected_element"/><svg:path d="M 76.00, 56.00 Q 85.50, 56.42, 95.09, 55.91 Q 95.19, 66.44, 95.12, 76.98 Q 94.99, 87.50, 95.36, 97.99 Q 95.73,\
                           108.49, 95.94, 118.99 Q 95.60, 129.50, 95.28, 140.28 Q 85.71, 140.64, 75.78, 140.22 Q 75.52, 129.63, 75.11, 119.10 Q 74.79,\
                           108.56, 75.03, 98.02 Q 74.70, 87.52, 75.69, 77.00 Q 76.00, 66.50, 76.00, 56.00" style=" fill:white;" class="svg_unselected_element"/><svg:path d="M 104.00, 89.00 Q 113.50, 87.04, 123.98, 88.02 Q 124.58, 101.22, 124.55, 114.28 Q 124.63, 127.14, 123.92, 140.92\
                           Q 113.98, 141.49, 103.37, 140.61 Q 102.95, 127.53, 103.19, 114.59 Q 104.00, 101.75, 104.00, 89.00" style=" fill:white;" class="svg_unselected_element"/><svg:path d="M 133.00, 31.00 Q 142.50, 28.84, 152.92, 30.08 Q 153.32, 41.46, 153.16, 52.63 Q 153.26, 63.62, 153.26, 74.56\
                           Q 153.10, 85.48, 152.93, 96.39 Q 152.99, 107.30, 153.03, 118.20 Q 152.95, 129.10, 152.51, 140.51 Q 142.75, 140.75, 132.52,\
                           140.48 Q 132.11, 129.34, 131.76, 118.34 Q 132.08, 107.35, 131.99, 96.42 Q 131.73, 85.52, 131.67, 74.61 Q 131.97, 63.70, 131.84,\
                           52.80 Q 133.00, 41.90, 133.00, 31.00" style=" fill:white;" class="svg_unselected_element"/>\
                        </svg:g>\
                     </svg:g>\
                  </svg:g>\
               </svg:svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page877094969-layer-629968191" style="position: absolute; left: 295px; top: 1015px; width: 133px; height: 20px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="629968191" data-review-reference-id="629968191">\
         <div class="stencil-wrapper" style="width: 133px; height: 20px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline32"><p class="none" style="font-size: 18px;"><span style="color: #658cd9;">SĐT nhà hàng:</span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page877094969-layer-1183919470" style="position: absolute; left: 415px; top: 1010px; width: 220px; height: 30px" data-interactive-element-type="default.textinput" class="textinput stencil mobile-interaction-potential-trigger " data-stencil-id="1183919470" data-review-reference-id="1183919470">\
         <div class="stencil-wrapper" style="width: 220px; height: 30px">\
            <div>\
               <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" style="height: 30px;width:220px;" width="220" height="30">\
                  <svg:g id="__containerId__-page877094969-layer-1183919470svg" width="220" height="30"><svg:path id="__containerId__-page877094969-layer-1183919470_input_svg_border" d="M 2.00, 2.00 Q 12.80, 1.56, 23.60, 1.43\
                     Q 34.40, 1.34, 45.20, 1.19 Q 56.00, 1.39, 66.80, 1.47 Q 77.60, 1.85, 88.40, 1.80 Q 99.20, 1.28, 110.00, 2.12 Q 120.80, 1.34,\
                     131.60, 1.59 Q 142.40, 1.68, 153.20, 2.09 Q 164.00, 1.60, 174.80, 1.98 Q 185.60, 1.12, 196.40, 1.87 Q 207.20, 1.60, 217.41,\
                     2.59 Q 217.61, 15.13, 218.19, 28.19 Q 207.26, 28.22, 196.40, 28.04 Q 185.59, 27.79, 174.78, 27.31 Q 164.00, 27.70, 153.19,\
                     26.52 Q 142.40, 28.33, 131.60, 27.97 Q 120.80, 27.43, 110.00, 27.91 Q 99.20, 27.22, 88.40, 28.36 Q 77.60, 28.78, 66.80, 27.94\
                     Q 56.00, 28.82, 45.20, 28.79 Q 34.40, 28.11, 23.60, 26.84 Q 12.80, 26.35, 2.32, 27.68 Q 2.00, 15.00, 2.00, 2.00" style=" fill:white;"\
                     class="svg_unselected_element"/><svg:path id="__containerId__-page877094969-layer-1183919470_line1" d="M 3.00, 3.00 Q 13.70, 2.57, 24.40, 3.13 Q 35.10, 2.33,\
                     45.80, 4.23 Q 56.50, 4.14, 67.20, 2.17 Q 77.90, 2.09, 88.60, 3.34 Q 99.30, 3.79, 110.00, 3.22 Q 120.70, 2.94, 131.40, 1.24\
                     Q 142.10, 2.32, 152.80, 1.76 Q 163.50, 1.99, 174.20, 2.65 Q 184.90, 3.35, 195.60, 2.70 Q 206.30, 3.00, 217.00, 3.00" style="\
                     fill:none;" class="svg_unselected_element"/><svg:path id="__containerId__-page877094969-layer-1183919470_line2" d="M 3.00, 3.00 Q 3.00, 15.00, 3.00, 27.00" style=" fill:none;"\
                     class="svg_unselected_element"/><svg:path id="__containerId__-page877094969-layer-1183919470_line3" d="M 3.00, 3.00 Q 13.70, 1.60, 24.40, 1.50 Q 35.10, 1.50,\
                     45.80, 2.02 Q 56.50, 1.84, 67.20, 1.52 Q 77.90, 1.38, 88.60, 1.81 Q 99.30, 1.75, 110.00, 1.57 Q 120.70, 1.58, 131.40, 1.55\
                     Q 142.10, 1.23, 152.80, 1.07 Q 163.50, 1.46, 174.20, 1.62 Q 184.90, 1.57, 195.60, 1.92 Q 206.30, 3.00, 217.00, 3.00" style="\
                     fill:none;" class="svg_unselected_element"/><svg:path id="__containerId__-page877094969-layer-1183919470_line4" d="M 3.00, 3.00 Q 3.00, 15.00, 3.00, 27.00" style=" fill:none;"\
                     class="svg_unselected_element"/>\
                  </svg:g>\
               </svg:svg>\
               <div style="position:absolute;left: 6px; top: 1px;" title=""><input id="__containerId__-page877094969-layer-1183919470input" onblur="rabbit.facade.raiseEvent(rabbit.events.svgBlur, new Array(\'__containerId__-page877094969-layer-1183919470_input_svg_border\',\'__containerId__-page877094969-layer-1183919470_line1\',\'__containerId__-page877094969-layer-1183919470_line2\',\'__containerId__-page877094969-layer-1183919470_line3\',\'__containerId__-page877094969-layer-1183919470_line4\'))" onfocus="rabbit.facade.raiseEvent(rabbit.events.svgFocus, new Array(\'__containerId__-page877094969-layer-1183919470_input_svg_border\',\'__containerId__-page877094969-layer-1183919470_line1\',\'__containerId__-page877094969-layer-1183919470_line2\',\'__containerId__-page877094969-layer-1183919470_line3\',\'__containerId__-page877094969-layer-1183919470_line4\'))" value="" style="width:213px;height:28px;padding: 0px;" type="text" /></div>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page877094969-layer-474477431" style="position: absolute; left: 650px; top: 1015px; width: 83px; height: 20px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="474477431" data-review-reference-id="474477431">\
         <div class="stencil-wrapper" style="width: 83px; height: 20px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.link2"><p style="font-size: 14px;"><span class="underline" style="font-size: 18px; color: #658cd9;">Thêm sđt</span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page877094969-layer-209533827" style="position: absolute; left: 740px; top: 1270px; width: 115px; height: 20px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="209533827" data-review-reference-id="209533827">\
         <div class="stencil-wrapper" style="width: 115px; height: 20px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline32"><p><span style="font-size: 18px; color: #658cd9;">Khuyến mại :</span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page877094969-layer-textinput579084838" style="position: absolute; left: 760px; top: 1300px; width: 360px; height: 90px" data-interactive-element-type="default.textinput" class="textinput stencil mobile-interaction-potential-trigger " data-stencil-id="textinput579084838" data-review-reference-id="textinput579084838">\
         <div class="stencil-wrapper" style="width: 360px; height: 90px">\
            <div>\
               <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" style="height: 90px;width:360px;" width="360" height="90">\
                  <svg:g id="__containerId__-page877094969-layer-textinput579084838svg" width="360" height="90"><svg:path id="__containerId__-page877094969-layer-textinput579084838_input_svg_border" d="M 2.00, 2.00 Q 12.47, 3.01, 22.94,\
                     2.55 Q 33.41, 2.38, 43.88, 1.53 Q 54.35, 1.20, 64.82, 1.63 Q 75.29, 1.79, 85.76, 1.14 Q 96.24, 1.61, 106.71, 1.38 Q 117.18,\
                     1.41, 127.65, 1.71 Q 138.12, 2.26, 148.59, 1.20 Q 159.06, 1.36, 169.53, 0.46 Q 180.00, 1.54, 190.47, 1.70 Q 200.94, 1.58,\
                     211.41, 2.15 Q 221.88, 2.20, 232.35, 1.45 Q 242.82, 0.44, 253.29, 1.45 Q 263.76, 1.82, 274.24, 2.00 Q 284.71, 0.69, 295.18,\
                     1.35 Q 305.65, 2.08, 316.12, 2.44 Q 326.59, 1.76, 337.06, 0.73 Q 347.53, 1.27, 358.25, 1.75 Q 358.49, 12.58, 358.55, 23.42\
                     Q 358.43, 34.22, 358.57, 44.98 Q 357.71, 55.75, 357.94, 66.50 Q 358.75, 77.25, 357.87, 87.87 Q 347.62, 88.28, 337.10, 88.28\
                     Q 326.65, 88.97, 316.14, 88.66 Q 305.66, 88.70, 295.18, 88.46 Q 284.71, 88.84, 274.24, 89.16 Q 263.76, 88.19, 253.29, 88.50\
                     Q 242.82, 89.37, 232.35, 89.50 Q 221.88, 88.47, 211.41, 88.62 Q 200.94, 88.30, 190.47, 87.91 Q 180.00, 88.83, 169.53, 88.12\
                     Q 159.06, 87.75, 148.59, 88.50 Q 138.12, 89.39, 127.65, 89.75 Q 117.18, 89.86, 106.71, 89.89 Q 96.24, 89.63, 85.76, 89.97\
                     Q 75.29, 89.70, 64.82, 89.93 Q 54.35, 89.96, 43.88, 89.97 Q 33.41, 89.43, 22.94, 89.01 Q 12.47, 89.32, 1.47, 88.53 Q 1.08,\
                     77.56, 1.98, 66.50 Q 2.34, 55.73, 1.84, 45.01 Q 0.96, 34.27, 1.54, 23.50 Q 2.00, 12.75, 2.00, 2.00" style=" fill:white;" class="svg_unselected_element"/><svg:path id="__containerId__-page877094969-layer-textinput579084838_line1" d="M 3.00, 3.00 Q 13.41, 0.67, 23.82, 1.10 Q 34.24,\
                     1.32, 44.65, 1.46 Q 55.06, 1.22, 65.47, 1.32 Q 75.88, 1.81, 86.29, 1.77 Q 96.71, 1.39, 107.12, 1.30 Q 117.53, 1.26, 127.94,\
                     1.21 Q 138.35, 0.86, 148.76, 2.06 Q 159.18, 1.92, 169.59, 1.95 Q 180.00, 1.74, 190.41, 1.87 Q 200.82, 1.93, 211.24, 1.53 Q\
                     221.65, 1.42, 232.06, 0.98 Q 242.47, 1.46, 252.88, 1.45 Q 263.29, 1.60, 273.71, 1.01 Q 284.12, 1.64, 294.53, 2.90 Q 304.94,\
                     2.58, 315.35, 2.85 Q 325.76, 2.31, 336.18, 2.42 Q 346.59, 3.00, 357.00, 3.00" style=" fill:none;" class="svg_unselected_element"/><svg:path id="__containerId__-page877094969-layer-textinput579084838_line2" d="M 3.00, 3.00 Q 4.10, 13.50, 4.28, 24.00 Q 4.31,\
                     34.50, 4.14, 45.00 Q 3.99, 55.50, 4.10, 66.00 Q 3.00, 76.50, 3.00, 87.00" style=" fill:none;" class="svg_unselected_element"/><svg:path id="__containerId__-page877094969-layer-textinput579084838_line3" d="M 3.00, 3.00 Q 13.41, 4.15, 23.82, 3.44 Q 34.24,\
                     3.03, 44.65, 2.77 Q 55.06, 2.80, 65.47, 2.33 Q 75.88, 2.29, 86.29, 2.86 Q 96.71, 2.82, 107.12, 2.98 Q 117.53, 2.71, 127.94,\
                     2.22 Q 138.35, 2.03, 148.76, 2.39 Q 159.18, 1.87, 169.59, 2.92 Q 180.00, 2.09, 190.41, 2.28 Q 200.82, 3.16, 211.24, 3.40 Q\
                     221.65, 2.57, 232.06, 2.34 Q 242.47, 1.96, 252.88, 1.71 Q 263.29, 2.17, 273.71, 2.11 Q 284.12, 3.30, 294.53, 2.87 Q 304.94,\
                     1.86, 315.35, 1.63 Q 325.76, 2.54, 336.18, 2.72 Q 346.59, 3.00, 357.00, 3.00" style=" fill:none;" class="svg_unselected_element"/><svg:path id="__containerId__-page877094969-layer-textinput579084838_line4" d="M 3.00, 3.00 Q 4.37, 13.50, 3.27, 24.00 Q 3.29,\
                     34.50, 2.18, 45.00 Q 3.30, 55.50, 3.34, 66.00 Q 3.00, 76.50, 3.00, 87.00" style=" fill:none;" class="svg_unselected_element"/>\
                  </svg:g>\
               </svg:svg>\
               <div style="position:absolute;left: 6px; top: 1px;" title=""><textarea id="__containerId__-page877094969-layer-textinput579084838input" onblur="rabbit.facade.raiseEvent(rabbit.events.svgBlur, new Array(\'__containerId__-page877094969-layer-textinput579084838_input_svg_border\',\'__containerId__-page877094969-layer-textinput579084838_line1\',\'__containerId__-page877094969-layer-textinput579084838_line2\',\'__containerId__-page877094969-layer-textinput579084838_line3\',\'__containerId__-page877094969-layer-textinput579084838_line4\'))" onfocus="rabbit.facade.raiseEvent(rabbit.events.svgFocus, new Array(\'__containerId__-page877094969-layer-textinput579084838_input_svg_border\',\'__containerId__-page877094969-layer-textinput579084838_line1\',\'__containerId__-page877094969-layer-textinput579084838_line2\',\'__containerId__-page877094969-layer-textinput579084838_line3\',\'__containerId__-page877094969-layer-textinput579084838_line4\'))" rows="" cols="" style="width:353px;height:84px;"></textarea></div>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page877094969-layer-2102636194" style="position: absolute; left: 630px; top: 1160px; width: 150px; height: 30px" data-interactive-element-type="default.textinput" class="textinput stencil mobile-interaction-potential-trigger " data-stencil-id="2102636194" data-review-reference-id="2102636194">\
         <div class="stencil-wrapper" style="width: 150px; height: 30px">\
            <div>\
               <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" style="height: 30px;width:150px;" width="150" height="30">\
                  <svg:g id="__containerId__-page877094969-layer-2102636194svg" width="150" height="30"><svg:path id="__containerId__-page877094969-layer-2102636194_input_svg_border" d="M 2.00, 2.00 Q 12.43, -0.59, 22.86, -0.20\
                     Q 33.29, 0.19, 43.71, 0.30 Q 54.14, 0.49, 64.57, 0.77 Q 75.00, 0.79, 85.43, 0.67 Q 95.86, 0.73, 106.29, 0.97 Q 116.71, 1.40,\
                     127.14, 0.74 Q 137.57, 0.47, 148.79, 1.21 Q 149.21, 14.60, 148.71, 28.71 Q 137.86, 29.06, 127.28, 29.19 Q 116.76, 28.81, 106.31,\
                     29.09 Q 95.87, 28.79, 85.43, 27.96 Q 75.00, 29.01, 64.57, 29.38 Q 54.14, 29.29, 43.71, 29.53 Q 33.29, 29.66, 22.86, 29.80\
                     Q 12.43, 29.92, 1.02, 28.98 Q 2.00, 15.00, 2.00, 2.00" style=" fill:white;" class="svg_unselected_element"/><svg:path id="__containerId__-page877094969-layer-2102636194_line1" d="M 3.00, 3.00 Q 13.29, 0.83, 23.57, 1.52 Q 33.86, 2.54,\
                     44.14, 2.03 Q 54.43, 1.85, 64.71, 2.72 Q 75.00, 2.10, 85.29, 1.68 Q 95.57, 1.46, 105.86, 1.61 Q 116.14, 2.88, 126.43, 2.99\
                     Q 136.71, 3.00, 147.00, 3.00" style=" fill:none;" class="svg_unselected_element"/><svg:path id="__containerId__-page877094969-layer-2102636194_line2" d="M 3.00, 3.00 Q 3.00, 15.00, 3.00, 27.00" style=" fill:none;"\
                     class="svg_unselected_element"/><svg:path id="__containerId__-page877094969-layer-2102636194_line3" d="M 3.00, 3.00 Q 13.29, 3.25, 23.57, 2.40 Q 33.86, 2.34,\
                     44.14, 1.92 Q 54.43, 1.90, 64.71, 1.89 Q 75.00, 1.64, 85.29, 0.59 Q 95.57, 0.74, 105.86, 0.69 Q 116.14, 1.32, 126.43, 1.48\
                     Q 136.71, 3.00, 147.00, 3.00" style=" fill:none;" class="svg_unselected_element"/><svg:path id="__containerId__-page877094969-layer-2102636194_line4" d="M 3.00, 3.00 Q 3.00, 15.00, 3.00, 27.00" style=" fill:none;"\
                     class="svg_unselected_element"/>\
                  </svg:g>\
               </svg:svg>\
               <div style="position:absolute;left: 6px; top: 1px;" title=""><input id="__containerId__-page877094969-layer-2102636194input" onblur="rabbit.facade.raiseEvent(rabbit.events.svgBlur, new Array(\'__containerId__-page877094969-layer-2102636194_input_svg_border\',\'__containerId__-page877094969-layer-2102636194_line1\',\'__containerId__-page877094969-layer-2102636194_line2\',\'__containerId__-page877094969-layer-2102636194_line3\',\'__containerId__-page877094969-layer-2102636194_line4\'))" onfocus="rabbit.facade.raiseEvent(rabbit.events.svgFocus, new Array(\'__containerId__-page877094969-layer-2102636194_input_svg_border\',\'__containerId__-page877094969-layer-2102636194_line1\',\'__containerId__-page877094969-layer-2102636194_line2\',\'__containerId__-page877094969-layer-2102636194_line3\',\'__containerId__-page877094969-layer-2102636194_line4\'))" value="" style="width:143px;height:28px;padding: 0px;" type="text" /></div>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page877094969-layer-icon11954582" style="position: absolute; left: 590px; top: 1160px; width: 32px; height: 32px" data-interactive-element-type="fonticon.icon" class="icon stencil mobile-interaction-potential-trigger " data-stencil-id="icon11954582" data-review-reference-id="icon11954582">\
         <div class="stencil-wrapper" style="width: 32px; height: 32px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" style="width:32px;height:32px;" title="">\
               <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" class="fill-black">\
                  <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#icon-glyph-e212"></use>\
               </svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page877094969-layer-280951805" style="position: absolute; left: 290px; top: 725px; width: 111px; height: 20px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="280951805" data-review-reference-id="280951805">\
         <div class="stencil-wrapper" style="width: 111px; height: 20px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline32"><p><span style="font-size: 18px; color: #658cd9;">Giờ mở cửa:</span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page877094969-layer-textinput796526445" style="position: absolute; left: 425px; top: 720px; width: 280px; height: 30px" data-interactive-element-type="default.textinput" class="textinput stencil mobile-interaction-potential-trigger " data-stencil-id="textinput796526445" data-review-reference-id="textinput796526445">\
         <div class="stencil-wrapper" style="width: 280px; height: 30px">\
            <div>\
               <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" style="height: 30px;width:280px;" width="280" height="30">\
                  <svg:g id="__containerId__-page877094969-layer-textinput796526445svg" width="280" height="30"><svg:path id="__containerId__-page877094969-layer-textinput796526445_input_svg_border" d="M 2.00, 2.00 Q 12.62, 1.83, 23.23,\
                     1.51 Q 33.85, 0.95, 44.46, 0.82 Q 55.08, 0.47, 65.69, -0.35 Q 76.31, 0.74, 86.92, 0.93 Q 97.54, 0.50, 108.15, 0.98 Q 118.77,\
                     0.20, 129.38, 0.20 Q 140.00, 0.63, 150.62, 1.60 Q 161.23, 1.93, 171.85, 1.84 Q 182.46, 1.34, 193.08, 1.13 Q 203.69, 1.57,\
                     214.31, 1.90 Q 224.92, 1.28, 235.54, 1.02 Q 246.15, 0.99, 256.77, 0.90 Q 267.38, 0.74, 278.64, 1.36 Q 278.65, 14.78, 278.39,\
                     28.39 Q 267.60, 28.80, 256.89, 29.08 Q 246.22, 29.24, 235.56, 28.88 Q 224.94, 29.82, 214.32, 29.43 Q 203.70, 29.57, 193.08,\
                     29.74 Q 182.46, 29.76, 171.85, 29.89 Q 161.23, 29.91, 150.62, 29.95 Q 140.00, 30.15, 129.38, 29.58 Q 118.77, 29.60, 108.15,\
                     29.24 Q 97.54, 28.67, 86.92, 28.66 Q 76.31, 28.44, 65.69, 28.15 Q 55.08, 29.22, 44.46, 28.18 Q 33.85, 29.43, 23.23, 29.04\
                     Q 12.62, 28.15, 1.88, 28.12 Q 2.00, 15.00, 2.00, 2.00" style=" fill:white;" class="svg_unselected_element"/><svg:path id="__containerId__-page877094969-layer-textinput796526445_line1" d="M 3.00, 3.00 Q 13.54, 2.80, 24.08, 2.29 Q 34.62,\
                     2.10, 45.15, 2.68 Q 55.69, 2.21, 66.23, 2.95 Q 76.77, 3.31, 87.31, 4.35 Q 97.85, 3.26, 108.38, 3.63 Q 118.92, 2.53, 129.46,\
                     2.64 Q 140.00, 1.61, 150.54, 1.83 Q 161.08, 2.62, 171.62, 3.49 Q 182.15, 2.43, 192.69, 2.24 Q 203.23, 2.99, 213.77, 3.38 Q\
                     224.31, 2.48, 234.85, 1.60 Q 245.38, 2.54, 255.92, 2.45 Q 266.46, 3.00, 277.00, 3.00" style=" fill:none;" class="svg_unselected_element"/><svg:path id="__containerId__-page877094969-layer-textinput796526445_line2" d="M 3.00, 3.00 Q 3.00, 15.00, 3.00, 27.00" style="\
                     fill:none;" class="svg_unselected_element"/><svg:path id="__containerId__-page877094969-layer-textinput796526445_line3" d="M 3.00, 3.00 Q 13.54, 1.13, 24.08, 0.96 Q 34.62,\
                     0.86, 45.15, 1.08 Q 55.69, 1.40, 66.23, 1.07 Q 76.77, 1.18, 87.31, 1.54 Q 97.85, 1.89, 108.38, 1.44 Q 118.92, 1.19, 129.46,\
                     1.53 Q 140.00, 1.59, 150.54, 1.76 Q 161.08, 2.08, 171.62, 2.06 Q 182.15, 3.38, 192.69, 2.45 Q 203.23, 1.78, 213.77, 2.14 Q\
                     224.31, 1.90, 234.85, 1.81 Q 245.38, 1.74, 255.92, 2.32 Q 266.46, 3.00, 277.00, 3.00" style=" fill:none;" class="svg_unselected_element"/><svg:path id="__containerId__-page877094969-layer-textinput796526445_line4" d="M 3.00, 3.00 Q 3.00, 15.00, 3.00, 27.00" style="\
                     fill:none;" class="svg_unselected_element"/>\
                  </svg:g>\
               </svg:svg>\
               <div style="position:absolute;left: 6px; top: 1px;" title=""><input id="__containerId__-page877094969-layer-textinput796526445input" onblur="rabbit.facade.raiseEvent(rabbit.events.svgBlur, new Array(\'__containerId__-page877094969-layer-textinput796526445_input_svg_border\',\'__containerId__-page877094969-layer-textinput796526445_line1\',\'__containerId__-page877094969-layer-textinput796526445_line2\',\'__containerId__-page877094969-layer-textinput796526445_line3\',\'__containerId__-page877094969-layer-textinput796526445_line4\'))" onfocus="rabbit.facade.raiseEvent(rabbit.events.svgFocus, new Array(\'__containerId__-page877094969-layer-textinput796526445_input_svg_border\',\'__containerId__-page877094969-layer-textinput796526445_line1\',\'__containerId__-page877094969-layer-textinput796526445_line2\',\'__containerId__-page877094969-layer-textinput796526445_line3\',\'__containerId__-page877094969-layer-textinput796526445_line4\'))" value="" style="width:273px;height:28px;padding: 0px;" type="text" /></div>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page877094969-layer-400717583" style="position: absolute; left: 305px; top: 425px; width: 74px; height: 20px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="400717583" data-review-reference-id="400717583">\
         <div class="stencil-wrapper" style="width: 74px; height: 20px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline32"><p class="none" style="font-size: 18px;">Địa chỉ: </p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page877094969-layer-361464711" style="position: absolute; left: 465px; top: 420px; width: 275px; height: 30px" data-interactive-element-type="default.textinput" class="textinput stencil mobile-interaction-potential-trigger " data-stencil-id="361464711" data-review-reference-id="361464711">\
         <div class="stencil-wrapper" style="width: 275px; height: 30px">\
            <div>\
               <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" style="height: 30px;width:275px;" width="275" height="30">\
                  <svg:g id="__containerId__-page877094969-layer-361464711svg" width="275" height="30"><svg:path id="__containerId__-page877094969-layer-361464711_input_svg_border" d="M 2.00, 2.00 Q 12.42, -0.51, 22.85, 0.03\
                     Q 33.27, 0.35, 43.69, 0.67 Q 54.12, 0.74, 64.54, 1.13 Q 74.96, 0.89, 85.38, 1.03 Q 95.81, 0.87, 106.23, 0.69 Q 116.65, 0.66,\
                     127.08, 1.03 Q 137.50, 1.03, 147.92, 0.55 Q 158.35, 0.69, 168.77, 0.85 Q 179.19, 1.17, 189.62, 0.98 Q 200.04, 0.88, 210.46,\
                     0.73 Q 220.88, 0.70, 231.31, 0.86 Q 241.73, 0.99, 252.15, 1.49 Q 262.58, 1.24, 273.30, 1.70 Q 273.80, 14.73, 273.55, 28.55\
                     Q 262.83, 28.92, 252.23, 28.69 Q 241.76, 28.67, 231.32, 28.62 Q 220.89, 28.28, 210.46, 28.29 Q 200.04, 28.53, 189.62, 28.65\
                     Q 179.19, 28.67, 168.77, 28.69 Q 158.35, 28.63, 147.92, 28.67 Q 137.50, 28.73, 127.08, 28.55 Q 116.65, 29.01, 106.23, 28.82\
                     Q 95.81, 29.02, 85.38, 28.95 Q 74.96, 29.00, 64.54, 29.11 Q 54.12, 29.27, 43.69, 29.06 Q 33.27, 28.62, 22.85, 28.91 Q 12.42,\
                     28.65, 1.33, 28.67 Q 2.00, 15.00, 2.00, 2.00" style=" fill:white;" class="svg_unselected_element"/><svg:path id="__containerId__-page877094969-layer-361464711_line1" d="M 3.00, 3.00 Q 13.35, 1.60, 23.69, 1.43 Q 34.04, 1.25,\
                     44.38, 1.24 Q 54.73, 1.22, 65.08, 1.55 Q 75.42, 1.47, 85.77, 1.51 Q 96.12, 1.48, 106.46, 1.03 Q 116.81, 1.37, 127.15, 1.42\
                     Q 137.50, 2.02, 147.85, 1.84 Q 158.19, 2.05, 168.54, 1.81 Q 178.88, 1.65, 189.23, 1.73 Q 199.58, 1.30, 209.92, 0.98 Q 220.27,\
                     1.48, 230.62, 2.03 Q 240.96, 2.12, 251.31, 2.09 Q 261.65, 3.00, 272.00, 3.00" style=" fill:none;" class="svg_unselected_element"/><svg:path id="__containerId__-page877094969-layer-361464711_line2" d="M 3.00, 3.00 Q 3.00, 15.00, 3.00, 27.00" style=" fill:none;"\
                     class="svg_unselected_element"/><svg:path id="__containerId__-page877094969-layer-361464711_line3" d="M 3.00, 3.00 Q 13.35, 1.79, 23.69, 1.45 Q 34.04, 1.29,\
                     44.38, 1.21 Q 54.73, 1.19, 65.08, 1.47 Q 75.42, 1.32, 85.77, 1.28 Q 96.12, 1.14, 106.46, 1.13 Q 116.81, 1.70, 127.15, 1.51\
                     Q 137.50, 1.96, 147.85, 1.95 Q 158.19, 1.74, 168.54, 1.93 Q 178.88, 2.04, 189.23, 1.46 Q 199.58, 1.46, 209.92, 1.41 Q 220.27,\
                     1.82, 230.62, 2.42 Q 240.96, 2.25, 251.31, 2.10 Q 261.65, 3.00, 272.00, 3.00" style=" fill:none;" class="svg_unselected_element"/><svg:path id="__containerId__-page877094969-layer-361464711_line4" d="M 3.00, 3.00 Q 3.00, 15.00, 3.00, 27.00" style=" fill:none;"\
                     class="svg_unselected_element"/>\
                  </svg:g>\
               </svg:svg>\
               <div style="position:absolute;left: 6px; top: 1px;" title=""><input id="__containerId__-page877094969-layer-361464711input" onblur="rabbit.facade.raiseEvent(rabbit.events.svgBlur, new Array(\'__containerId__-page877094969-layer-361464711_input_svg_border\',\'__containerId__-page877094969-layer-361464711_line1\',\'__containerId__-page877094969-layer-361464711_line2\',\'__containerId__-page877094969-layer-361464711_line3\',\'__containerId__-page877094969-layer-361464711_line4\'))" onfocus="rabbit.facade.raiseEvent(rabbit.events.svgFocus, new Array(\'__containerId__-page877094969-layer-361464711_input_svg_border\',\'__containerId__-page877094969-layer-361464711_line1\',\'__containerId__-page877094969-layer-361464711_line2\',\'__containerId__-page877094969-layer-361464711_line3\',\'__containerId__-page877094969-layer-361464711_line4\'))" value="" style="width:268px;height:28px;padding: 0px;" type="text" /></div>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page877094969-layer-1243270990" style="position: absolute; left: 60px; top: 490px; width: 161px; height: 28px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="1243270990" data-review-reference-id="1243270990">\
         <div class="stencil-wrapper" style="width: 161px; height: 28px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline22"><p class="none" style="font-size: 24px;"><span style="font-size: 20px; color: #658cd9;">Quản lí mật khẩu</span></p>\
                     <p class="none" style="font-size: 24px;"> </p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page877094969-layer-icon635162954" style="position: absolute; left: 20px; top: 490px; width: 32px; height: 32px" data-interactive-element-type="fonticon.icon" class="icon stencil mobile-interaction-potential-trigger " data-stencil-id="icon635162954" data-review-reference-id="icon635162954">\
         <div class="stencil-wrapper" style="width: 32px; height: 32px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" style="width:32px;height:32px;" title="">\
               <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" class="fill-blue">\
                  <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#icon-glyph-e204"></use>\
               </svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page877094969-layer-datepicker846637727" style="position: absolute; left: 330px; top: 2545px; width: 150px; height: 30px" data-interactive-element-type="default.datepicker" class="datepicker stencil mobile-interaction-potential-trigger " data-stencil-id="datepicker846637727" data-review-reference-id="datepicker846637727">\
         <div class="stencil-wrapper" style="width: 150px; height: 30px">\
            <div>\
               <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" style="position: absolute; height: 30px;width:150px;" width="150" height="30">\
                  <svg:g width="150px" height="30px"><svg:path id="__containerId__-page877094969-layer-datepicker846637727_input_svg_border" d="M 2.00, 2.00 Q 13.20, 2.29, 24.40,\
                     2.48 Q 35.60, 2.47, 46.80, 2.68 Q 58.00, 2.01, 69.20, 2.22 Q 80.40, 2.37, 91.60, 2.22 Q 102.80, 2.42, 114.42, 1.58 Q 114.63,\
                     14.79, 114.15, 28.15 Q 102.82, 28.09, 91.65, 28.46 Q 80.45, 28.97, 69.21, 28.50 Q 58.01, 28.59, 46.80, 28.69 Q 35.61, 29.75,\
                     24.40, 29.92 Q 13.20, 29.73, 1.59, 28.40 Q 2.00, 15.00, 2.00, 2.00" style=" fill:white;" class="svg_unselected_element"/><svg:path id="__containerId__-page877094969-layer-datepicker846637727_line1" d="M 3.00, 3.00 Q 14.90, 2.52, 26.80, 2.41 Q\
                     38.70, 2.32, 50.60, 2.12 Q 62.50, 1.82, 74.40, 1.82 Q 86.30, 1.74, 98.20, 1.63 Q 110.10, 3.00, 122.00, 3.00" style=" fill:none;"\
                     class="svg_unselected_element"/><svg:path id="__containerId__-page877094969-layer-datepicker846637727_line2" d="M 3.00, 3.00 Q 3.00, 15.00, 3.00, 27.00" style="\
                     fill:none;" class="svg_unselected_element"/><svg:path id="__containerId__-page877094969-layer-datepicker846637727_line3" d="M 3.00, 3.00 Q 14.90, 4.00, 26.80, 4.01 Q\
                     38.70, 3.91, 50.60, 2.77 Q 62.50, 2.32, 74.40, 2.81 Q 86.30, 2.75, 98.20, 2.27 Q 110.10, 3.00, 122.00, 3.00" style=" fill:none;"\
                     class="svg_unselected_element"/><svg:path id="__containerId__-page877094969-layer-datepicker846637727_line4" d="M 3.00, 3.00 Q 3.00, 15.00, 3.00, 27.00" style="\
                     fill:none;" class="svg_unselected_element"/>\
                  </svg:g>\
                  <svg:g width="150px" height="30px"><svg:path id="__containerId__-page877094969-layer-datepicker846637727_input_svg_border2" d="M 118.00, 2.00 Q 133.00, 1.24,\
                     148.40, 1.60 Q 148.66, 14.78, 148.29, 28.29 Q 133.17, 28.61, 117.81, 28.16 Q 118.00, 15.00, 118.00, 2.00" style=" fill:white;"\
                     class="svg_unselected_element"/>\
                  </svg:g>\
               </svg:svg>\
               <div style="white-space: nowrap;" title=""><input type="text" onblur="rabbit.facade.raiseEvent(rabbit.events.svgBlur, new Array(\'__containerId__-page877094969-layer-datepicker846637727_input_svg_border\',\'__containerId__-page877094969-layer-datepicker846637727_line1\',\'__containerId__-page877094969-layer-datepicker846637727_line2\',\'__containerId__-page877094969-layer-datepicker846637727_line3\',\'__containerId__-page877094969-layer-datepicker846637727_line4\'))" onfocus="rabbit.facade.raiseEvent(rabbit.events.svgFocus, new Array(\'__containerId__-page877094969-layer-datepicker846637727_input_svg_border\',\'__containerId__-page877094969-layer-datepicker846637727_line1\',\'__containerId__-page877094969-layer-datepicker846637727_line2\',\'__containerId__-page877094969-layer-datepicker846637727_line3\',\'__containerId__-page877094969-layer-datepicker846637727_line4\'))" style="width:116px; height:30px;padding: 0px;border-width:1px; position: absolute;" id="__containerId__-page877094969-layer-datepicker846637727_input" /><button type="button" onblur="rabbit.facade.raiseEvent(rabbit.events.svgBlur, \'__containerId__-page877094969-layer-datepicker846637727_input_svg_border2\')" onfocus="rabbit.facade.raiseEvent(rabbit.events.svgFocus, \'__containerId__-page877094969-layer-datepicker846637727_input_svg_border2\')" style="position:absolute; left:116px; top:0px; width:34px; height:30px; vertical-align: top; padding: 0px;border-width:1px; cursor:pointer;" id="__containerId__-page877094969-layer-datepicker846637727_button"><img src="../resources/icons/date.png" /></button></div>\
               <div id="__containerId__-page877094969-layer-datepicker846637727_ov" class="yui-skin-sam" style="position: absolute; width: 16em;visibility:visible;">\
                  <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" style="position: absolute; left: -6px; top: -4px; height: 204px;width:200px;display:none" id="__containerId__-page877094969-layer-datepicker846637727_open_calendar" width="150" height="204"><svg:path id="__containerId__-page877094969-layer-datepicker846637727_open_calendar_border" d="M 2.00, 2.00 Q 12.89, 1.96,\
                     23.78, 1.13 Q 34.67, 0.31, 45.56, -0.17 Q 56.44, -0.20, 67.33, -0.25 Q 78.22, 0.23, 89.11, 0.10 Q 100.00, 0.10, 110.89, 0.03\
                     Q 121.78, -0.23, 132.67, 0.05 Q 143.56, 0.64, 154.44, 0.98 Q 165.33, 0.65, 176.22, 0.38 Q 187.11, -0.04, 198.96, 1.04 Q 199.05,\
                     11.65, 199.07, 21.85 Q 199.49, 31.90, 200.16, 41.93 Q 200.08, 51.97, 199.80, 61.99 Q 199.54, 71.99, 199.11, 82.00 Q 198.73,\
                     92.00, 198.23, 102.00 Q 198.70, 112.00, 198.78, 122.00 Q 199.01, 132.00, 198.87, 142.00 Q 199.12, 152.00, 199.36, 162.00 Q\
                     199.42, 172.00, 199.23, 182.00 Q 199.15, 192.00, 198.36, 202.36 Q 187.43, 202.94, 176.29, 202.51 Q 165.38, 202.69, 154.48,\
                     202.95 Q 143.57, 202.83, 132.68, 203.47 Q 121.78, 203.49, 110.89, 203.41 Q 100.00, 203.27, 89.11, 202.32 Q 78.22, 202.57,\
                     67.33, 202.37 Q 56.44, 202.72, 45.56, 202.72 Q 34.67, 203.06, 23.78, 202.33 Q 12.89, 201.72, 2.27, 201.73 Q 2.18, 191.94,\
                     2.01, 182.00 Q 1.43, 172.04, 1.35, 162.02 Q 1.39, 152.01, 1.12, 142.01 Q 0.99, 132.00, 1.92, 122.00 Q 2.61, 112.00, 1.74,\
                     102.00 Q 1.46, 92.00, 0.90, 82.00 Q 0.61, 72.00, 0.61, 62.00 Q 0.60, 52.00, 0.96, 42.00 Q 1.23, 32.00, 0.70, 22.00 Q 2.00,\
                     12.00, 2.00, 2.00" style=" fill:white;" class="svg_unselected_element"/>\
                  </svg:svg>\
                  <div id="__containerId__-page877094969-layer-datepicker846637727_cal"></div>\
               </div><script type="text/javascript">\
				rabbit.stencils.datepicker.setupDatepicker("__containerId__-page877094969-layer-datepicker846637727");\
			</script></div>\
         </div>\
      </div>\
      <div id="__containerId__-page877094969-layer-datepicker785479217" style="position: absolute; left: 545px; top: 2545px; width: 150px; height: 30px" data-interactive-element-type="default.datepicker" class="datepicker stencil mobile-interaction-potential-trigger " data-stencil-id="datepicker785479217" data-review-reference-id="datepicker785479217">\
         <div class="stencil-wrapper" style="width: 150px; height: 30px">\
            <div>\
               <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" style="position: absolute; height: 30px;width:150px;" width="150" height="30">\
                  <svg:g width="150px" height="30px"><svg:path id="__containerId__-page877094969-layer-datepicker785479217_input_svg_border" d="M 2.00, 2.00 Q 13.20, 2.07, 24.40,\
                     2.42 Q 35.60, 2.12, 46.80, 1.51 Q 58.00, 0.85, 69.20, 1.27 Q 80.40, 1.38, 91.60, 1.09 Q 102.80, 0.37, 114.87, 1.13 Q 115.20,\
                     14.60, 114.60, 28.60 Q 103.21, 29.49, 91.73, 29.17 Q 80.41, 28.26, 69.23, 29.31 Q 58.02, 29.78, 46.81, 29.71 Q 35.61, 29.93,\
                     24.40, 29.96 Q 13.20, 29.79, 1.33, 28.67 Q 2.00, 15.00, 2.00, 2.00" style=" fill:white;" class="svg_unselected_element"/><svg:path id="__containerId__-page877094969-layer-datepicker785479217_line1" d="M 3.00, 3.00 Q 14.90, 0.79, 26.80, 1.38 Q\
                     38.70, 2.19, 50.60, 2.11 Q 62.50, 1.40, 74.40, 3.03 Q 86.30, 2.65, 98.20, 2.62 Q 110.10, 3.00, 122.00, 3.00" style=" fill:none;"\
                     class="svg_unselected_element"/><svg:path id="__containerId__-page877094969-layer-datepicker785479217_line2" d="M 3.00, 3.00 Q 3.00, 15.00, 3.00, 27.00" style="\
                     fill:none;" class="svg_unselected_element"/><svg:path id="__containerId__-page877094969-layer-datepicker785479217_line3" d="M 3.00, 3.00 Q 14.90, 1.14, 26.80, 1.05 Q\
                     38.70, 0.96, 50.60, 1.26 Q 62.50, 1.08, 74.40, 1.08 Q 86.30, 1.54, 98.20, 1.57 Q 110.10, 3.00, 122.00, 3.00" style=" fill:none;"\
                     class="svg_unselected_element"/><svg:path id="__containerId__-page877094969-layer-datepicker785479217_line4" d="M 3.00, 3.00 Q 3.00, 15.00, 3.00, 27.00" style="\
                     fill:none;" class="svg_unselected_element"/>\
                  </svg:g>\
                  <svg:g width="150px" height="30px"><svg:path id="__containerId__-page877094969-layer-datepicker785479217_input_svg_border2" d="M 118.00, 2.00 Q 133.00, 2.70,\
                     147.97, 2.03 Q 147.98, 15.01, 148.04, 28.04 Q 133.09, 28.35, 117.97, 28.02 Q 118.00, 15.00, 118.00, 2.00" style=" fill:white;"\
                     class="svg_unselected_element"/>\
                  </svg:g>\
               </svg:svg>\
               <div style="white-space: nowrap;" title=""><input type="text" onblur="rabbit.facade.raiseEvent(rabbit.events.svgBlur, new Array(\'__containerId__-page877094969-layer-datepicker785479217_input_svg_border\',\'__containerId__-page877094969-layer-datepicker785479217_line1\',\'__containerId__-page877094969-layer-datepicker785479217_line2\',\'__containerId__-page877094969-layer-datepicker785479217_line3\',\'__containerId__-page877094969-layer-datepicker785479217_line4\'))" onfocus="rabbit.facade.raiseEvent(rabbit.events.svgFocus, new Array(\'__containerId__-page877094969-layer-datepicker785479217_input_svg_border\',\'__containerId__-page877094969-layer-datepicker785479217_line1\',\'__containerId__-page877094969-layer-datepicker785479217_line2\',\'__containerId__-page877094969-layer-datepicker785479217_line3\',\'__containerId__-page877094969-layer-datepicker785479217_line4\'))" style="width:116px; height:30px;padding: 0px;border-width:1px; position: absolute;" id="__containerId__-page877094969-layer-datepicker785479217_input" /><button type="button" onblur="rabbit.facade.raiseEvent(rabbit.events.svgBlur, \'__containerId__-page877094969-layer-datepicker785479217_input_svg_border2\')" onfocus="rabbit.facade.raiseEvent(rabbit.events.svgFocus, \'__containerId__-page877094969-layer-datepicker785479217_input_svg_border2\')" style="position:absolute; left:116px; top:0px; width:34px; height:30px; vertical-align: top; padding: 0px;border-width:1px; cursor:pointer;" id="__containerId__-page877094969-layer-datepicker785479217_button"><img src="../resources/icons/date.png" /></button></div>\
               <div id="__containerId__-page877094969-layer-datepicker785479217_ov" class="yui-skin-sam" style="position: absolute; width: 16em;visibility:visible;">\
                  <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" style="position: absolute; left: -6px; top: -4px; height: 204px;width:200px;display:none" id="__containerId__-page877094969-layer-datepicker785479217_open_calendar" width="150" height="204"><svg:path id="__containerId__-page877094969-layer-datepicker785479217_open_calendar_border" d="M 2.00, 2.00 Q 12.89, 1.66,\
                     23.78, 1.49 Q 34.67, 1.48, 45.56, 1.35 Q 56.44, 2.05, 67.33, 1.17 Q 78.22, 1.76, 89.11, 1.56 Q 100.00, 1.40, 110.89, 2.55\
                     Q 121.78, 2.08, 132.67, 1.18 Q 143.56, 0.59, 154.44, 1.63 Q 165.33, 2.72, 176.22, 1.78 Q 187.11, 1.15, 198.20, 1.80 Q 197.99,\
                     12.00, 196.73, 22.18 Q 197.00, 32.07, 197.74, 42.01 Q 197.63, 52.01, 199.13, 61.99 Q 198.97, 72.00, 199.32, 82.00 Q 198.60,\
                     92.00, 197.88, 102.00 Q 197.47, 112.00, 196.75, 122.00 Q 197.03, 132.00, 198.31, 142.00 Q 199.11, 152.00, 199.29, 162.00 Q\
                     198.99, 172.00, 198.28, 182.00 Q 198.74, 192.00, 198.15, 202.15 Q 187.01, 201.69, 176.16, 201.56 Q 165.34, 202.12, 154.46,\
                     202.43 Q 143.56, 202.06, 132.68, 203.17 Q 121.78, 202.07, 110.89, 201.71 Q 100.00, 201.76, 89.11, 202.88 Q 78.22, 203.05,\
                     67.33, 202.34 Q 56.44, 202.69, 45.56, 202.35 Q 34.67, 202.68, 23.78, 202.23 Q 12.89, 203.27, 1.38, 202.62 Q 0.82, 192.39,\
                     0.83, 182.17 Q 1.91, 172.01, 1.92, 162.00 Q 1.97, 152.00, 1.84, 142.00 Q 1.46, 132.00, 0.66, 122.00 Q 0.62, 112.00, 0.56,\
                     102.00 Q 1.25, 92.00, 1.28, 82.00 Q 1.09, 72.00, 1.73, 62.00 Q 2.40, 52.00, 2.30, 42.00 Q 1.39, 32.00, 1.73, 22.00 Q 2.00,\
                     12.00, 2.00, 2.00" style=" fill:white;" class="svg_unselected_element"/>\
                  </svg:svg>\
                  <div id="__containerId__-page877094969-layer-datepicker785479217_cal"></div>\
               </div><script type="text/javascript">\
				rabbit.stencils.datepicker.setupDatepicker("__containerId__-page877094969-layer-datepicker785479217");\
			</script></div>\
         </div>\
      </div>\
      <div id="__containerId__-page877094969-layer-text940926104" style="position: absolute; left: 270px; top: 2550px; width: 31px; height: 23px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text940926104" data-review-reference-id="text940926104">\
         <div class="stencil-wrapper" style="width: 31px; height: 23px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline22"><p><span style="font-size: 20px; color: #658cd9;">Từ</span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page877094969-layer-text573669561" style="position: absolute; left: 495px; top: 2550px; width: 46px; height: 20px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text573669561" data-review-reference-id="text573669561">\
         <div class="stencil-wrapper" style="width: 46px; height: 20px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline32"><p class="none" style="font-size: 18px;"><span style="color: #658cd9;">Đến </span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page877094969-layer-checkbox899510893" style="position: absolute; left: 755px; top: 2555px; width: 61px; height: 20px" data-interactive-element-type="default.checkbox" class="checkbox stencil mobile-interaction-potential-trigger " data-stencil-id="checkbox899510893" data-review-reference-id="checkbox899510893">\
         <div class="stencil-wrapper" style="width: 61px; height: 20px">\
            <div class="" style="font-size:1.17em;">\
               <div xml:space="preserve" title="" style="position:absolute" onclick="rabbit.facade.fireMouseOn(\'__containerId__-page877094969-layer-checkbox899510893_input\');">\
                  				\
                  <nobr>\
                     					<input id="__containerId__-page877094969-layer-checkbox899510893_input" xml:space="default" class="hidden_class" style="padding-right:9px" type="checkbox" onpropertychange="rabbit.facade.raiseEvent(rabbit.events.propertyChange, \'__containerId__-page877094969-layer-checkbox899510893_input\', \'__containerId__-page877094969-layer-checkbox899510893_input_svgChecked\');" onblur="rabbit.facade.raiseEvent(rabbit.events.svgBlur, \'__containerId__-page877094969-layer-checkbox899510893_input_svg_border\')" onfocus="rabbit.facade.raiseEvent(rabbit.events.svgFocus, \'__containerId__-page877094969-layer-checkbox899510893_input_svg_border\')" onclick="rabbit.facade.raiseEvent(rabbit.events.checkBoxClicked, \'__containerId__-page877094969-layer-checkbox899510893_input\', \'__containerId__-page877094969-layer-checkbox899510893_input_svgChecked\')" checked="true" />\
                     				\
                     					\
                     					\
                     						Tất cả\
                     						\
                     					\
                     				\
                  </nobr>\
                  			\
               </div>\
               <div title="">\
                  <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" style="position: absolute; height: 20px;width:61px;" width="61" height="20" onclick="rabbit.facade.fireMouseOn(\'__containerId__-page877094969-layer-checkbox899510893_input\');">\
                     <svg:g id="__containerId__-page877094969-layer-checkbox899510893_input_svg" x="0" y="1.0199999999999996" width="61" height="20"><svg:path id="__containerId__-page877094969-layer-checkbox899510893_input_svg_border" d="M 5.00, 5.00 Q 10.00, 4.26, 15.44,\
                        4.56 Q 15.59, 9.80, 15.22, 15.22 Q 10.10, 15.38, 4.79, 15.18 Q 5.00, 10.00, 5.00, 5.00" style=" fill:white;" class="svg_unselected_element"/>\
                     </svg:g>\
                     <svg:g id="__containerId__-page877094969-layer-checkbox899510893_input_svgChecked" x="0" y="1.0199999999999996" width="61" height="20" visibility="inherit"><svg:path d="M 5.00, 9.00 Q 8.00, 12.00, 11.00, 15.00" style=" fill:none;" class="svg_unselected_element"/><svg:path d="M 11.00, 15.00 Q 15.50, 7.00, 20.00, -1.00" style=" fill:none;" class="svg_unselected_element"/></svg:g>\
                  </svg:svg>\
               </div>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page877094969-layer-245814346" style="position: absolute; left: 475px; top: 2465px; width: 131px; height: 28px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="245814346" data-review-reference-id="245814346">\
         <div class="stencil-wrapper" style="width: 131px; height: 28px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.link2"><p style="font-size: 14px;"><span class="underline" style="font-size: 24px; color: #658cd9;">24 đánh giá</span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page877094969-layer-text195442085" style="position: absolute; left: 295px; top: 605px; width: 133px; height: 47px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text195442085" data-review-reference-id="text195442085">\
         <div class="stencil-wrapper" style="width: 133px; height: 47px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.text2"><p class="none" style="font-size: 14px;"><span style="font-size: 20px;">Post Template</span><br /><span style="font-size:\
                     20px;"> </span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page877094969-layer-arrow10231804" style="position: absolute; left: 250px; top: 3355px; width: 1055px; height: 33px" data-interactive-element-type="static.line" class="line stencil mobile-interaction-potential-trigger " data-stencil-id="arrow10231804" data-review-reference-id="arrow10231804">\
         <div class="stencil-wrapper" style="width: 1055px; height: 33px">\
            <div title="">\
               <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" style="position: absolute; left: -5px; top: -5px; height: 43px;width:1065px;" viewBox="-5 -5 1065 43" width="1065" height="43"><svg:path d="M 0.00, 16.00 Q 10.14, 15.03, 20.29, 15.65 Q 30.43, 15.93, 40.58, 15.95 Q 50.72, 16.72, 60.87, 16.61 Q 71.01,\
                  15.99, 81.15, 16.44 Q 91.30, 17.01, 101.44, 17.18 Q 111.59, 15.81, 121.73, 16.79 Q 131.88, 16.33, 142.02, 15.49 Q 152.16,\
                  15.63, 162.31, 15.71 Q 172.45, 16.48, 182.60, 16.31 Q 192.74, 17.29, 202.88, 16.98 Q 213.03, 15.29, 223.17, 14.98 Q 233.32,\
                  16.50, 243.46, 16.80 Q 253.61, 17.22, 263.75, 16.82 Q 273.89, 17.05, 284.04, 16.55 Q 294.18, 17.19, 304.33, 16.66 Q 314.47,\
                  14.95, 324.62, 15.22 Q 334.76, 15.44, 344.90, 15.39 Q 355.05, 14.72, 365.19, 14.76 Q 375.34, 15.77, 385.48, 15.85 Q 395.62,\
                  15.67, 405.77, 15.75 Q 415.91, 15.89, 426.06, 14.90 Q 436.20, 15.28, 446.35, 15.09 Q 456.49, 15.37, 466.63, 15.77 Q 476.78,\
                  15.35, 486.92, 15.04 Q 497.07, 15.14, 507.21, 15.52 Q 517.36, 15.44, 527.50, 15.61 Q 537.64, 15.50, 547.79, 16.05 Q 557.93,\
                  15.97, 568.08, 15.28 Q 578.22, 15.77, 588.37, 17.06 Q 598.51, 16.98, 608.65, 16.82 Q 618.80, 17.13, 628.94, 14.74 Q 639.09,\
                  13.87, 649.23, 14.35 Q 659.37, 14.29, 669.52, 14.50 Q 679.66, 14.49, 689.81, 14.89 Q 699.95, 14.85, 710.10, 14.57 Q 720.24,\
                  14.13, 730.38, 14.03 Q 740.53, 14.74, 750.67, 15.63 Q 760.82, 15.72, 770.96, 15.90 Q 781.11, 15.52, 791.25, 15.44 Q 801.39,\
                  15.27, 811.54, 15.41 Q 821.68, 15.55, 831.83, 15.73 Q 841.97, 14.78, 852.12, 14.45 Q 862.26, 15.46, 872.40, 15.61 Q 882.55,\
                  15.00, 892.69, 14.70 Q 902.84, 14.54, 912.98, 14.69 Q 923.12, 14.69, 933.27, 15.10 Q 943.41, 14.83, 953.56, 14.95 Q 963.70,\
                  14.57, 973.85, 14.40 Q 983.99, 14.04, 994.13, 13.78 Q 1004.28, 13.71, 1014.42, 13.59 Q 1024.57, 13.68, 1034.71, 14.39 Q 1044.86,\
                  16.00, 1055.00, 16.00" style="marker-start:;marker-end:" class="svg_unselected_element"/>\
               </svg:svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page877094969-layer-737506582" style="position: absolute; left: 20px; top: 380px; width: 32px; height: 32px" data-interactive-element-type="fonticon.icon" class="icon stencil mobile-interaction-potential-trigger " data-stencil-id="737506582" data-review-reference-id="737506582">\
         <div class="stencil-wrapper" style="width: 32px; height: 32px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" style="width:32px;height:32px;" title="">\
               <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" class="fill-blue">\
                  <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#icon-glyph-e236"></use>\
               </svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page877094969-layer-1595050584" style="position: absolute; left: 60px; top: 385px; width: 98px; height: 27px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="1595050584" data-review-reference-id="1595050584">\
         <div class="stencil-wrapper" style="width: 98px; height: 27px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline22"><p class="none" style="font-size: 24px;"><span style="color: #658cd9; font-size: 20px;">Lập Menu</span></p>\
                     <p class="none" style="font-size: 24px;"> </p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page877094969-layer-text437894913" style="position: absolute; left: 265px; top: 3400px; width: 158px; height: 38px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text437894913" data-review-reference-id="text437894913">\
         <div class="stencil-wrapper" style="width: 158px; height: 38px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline22"><p><span style="font-size: 32px; color: #658cd9;">Lập Menu </span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page877094969-layer-text968665467" style="position: absolute; left: 260px; top: 3475px; width: 101px; height: 27px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text968665467" data-review-reference-id="text968665467">\
         <div class="stencil-wrapper" style="width: 101px; height: 27px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline22"><p><span style="font-size: 24px;">Tên món</span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page877094969-layer-text429818731" style="position: absolute; left: 450px; top: 3475px; width: 108px; height: 27px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text429818731" data-review-reference-id="text429818731">\
         <div class="stencil-wrapper" style="width: 108px; height: 27px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline22"><p><span style="font-size: 24px;">Phân loại</span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page877094969-layer-text384356085" style="position: absolute; left: 640px; top: 3475px; width: 156px; height: 27px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text384356085" data-review-reference-id="text384356085">\
         <div class="stencil-wrapper" style="width: 156px; height: 27px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline22"><p><span style="font-size: 24px;">Giá (.000/vnđ)</span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page877094969-layer-text653902833" style="position: absolute; left: 870px; top: 3475px; width: 166px; height: 28px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text653902833" data-review-reference-id="text653902833">\
         <div class="stencil-wrapper" style="width: 166px; height: 28px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline22"><p><span style="font-size: 24px;">Thông tin thêm</span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page877094969-layer-text532729675" style="position: absolute; left: 1145px; top: 3475px; width: 161px; height: 27px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text532729675" data-review-reference-id="text532729675">\
         <div class="stencil-wrapper" style="width: 161px; height: 27px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline22"><p class="none" style="font-size: 24px;">Ảnh minh họa </p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page877094969-layer-textinput656114953" style="position: absolute; left: 245px; top: 3525px; width: 150px; height: 30px" data-interactive-element-type="default.textinput" class="textinput stencil mobile-interaction-potential-trigger " data-stencil-id="textinput656114953" data-review-reference-id="textinput656114953">\
         <div class="stencil-wrapper" style="width: 150px; height: 30px">\
            <div>\
               <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" style="height: 30px;width:150px;" width="150" height="30">\
                  <svg:g id="__containerId__-page877094969-layer-textinput656114953svg" width="150" height="30"><svg:path id="__containerId__-page877094969-layer-textinput656114953_input_svg_border" d="M 2.00, 2.00 Q 12.43, 1.15, 22.86,\
                     1.11 Q 33.29, 0.86, 43.71, 0.73 Q 54.14, 0.37, 64.57, 0.34 Q 75.00, 0.32, 85.43, 0.66 Q 95.86, 0.49, 106.29, 0.12 Q 116.71,\
                     0.02, 127.14, -0.01 Q 137.57, 0.64, 148.94, 1.06 Q 149.24, 14.59, 148.50, 28.50 Q 137.83, 28.95, 127.30, 29.43 Q 116.78, 29.27,\
                     106.32, 29.33 Q 95.87, 29.12, 85.44, 29.26 Q 75.01, 29.75, 64.57, 29.73 Q 54.14, 29.60, 43.71, 28.94 Q 33.29, 29.22, 22.86,\
                     29.79 Q 12.43, 28.69, 1.63, 28.37 Q 2.00, 15.00, 2.00, 2.00" style=" fill:white;" class="svg_unselected_element"/><svg:path id="__containerId__-page877094969-layer-textinput656114953_line1" d="M 3.00, 3.00 Q 13.29, 2.11, 23.57, 2.78 Q 33.86,\
                     3.46, 44.14, 2.53 Q 54.43, 2.77, 64.71, 3.47 Q 75.00, 3.30, 85.29, 2.79 Q 95.57, 2.05, 105.86, 2.92 Q 116.14, 3.87, 126.43,\
                     3.76 Q 136.71, 3.00, 147.00, 3.00" style=" fill:none;" class="svg_unselected_element"/><svg:path id="__containerId__-page877094969-layer-textinput656114953_line2" d="M 3.00, 3.00 Q 3.00, 15.00, 3.00, 27.00" style="\
                     fill:none;" class="svg_unselected_element"/><svg:path id="__containerId__-page877094969-layer-textinput656114953_line3" d="M 3.00, 3.00 Q 13.29, 0.56, 23.57, 0.86 Q 33.86,\
                     1.04, 44.14, 1.20 Q 54.43, 1.12, 64.71, 1.05 Q 75.00, 1.01, 85.29, 1.49 Q 95.57, 1.54, 105.86, 2.31 Q 116.14, 2.26, 126.43,\
                     1.80 Q 136.71, 3.00, 147.00, 3.00" style=" fill:none;" class="svg_unselected_element"/><svg:path id="__containerId__-page877094969-layer-textinput656114953_line4" d="M 3.00, 3.00 Q 3.00, 15.00, 3.00, 27.00" style="\
                     fill:none;" class="svg_unselected_element"/>\
                  </svg:g>\
               </svg:svg>\
               <div style="position:absolute;left: 6px; top: 1px;" title=""><input id="__containerId__-page877094969-layer-textinput656114953input" onblur="rabbit.facade.raiseEvent(rabbit.events.svgBlur, new Array(\'__containerId__-page877094969-layer-textinput656114953_input_svg_border\',\'__containerId__-page877094969-layer-textinput656114953_line1\',\'__containerId__-page877094969-layer-textinput656114953_line2\',\'__containerId__-page877094969-layer-textinput656114953_line3\',\'__containerId__-page877094969-layer-textinput656114953_line4\'))" onfocus="rabbit.facade.raiseEvent(rabbit.events.svgFocus, new Array(\'__containerId__-page877094969-layer-textinput656114953_input_svg_border\',\'__containerId__-page877094969-layer-textinput656114953_line1\',\'__containerId__-page877094969-layer-textinput656114953_line2\',\'__containerId__-page877094969-layer-textinput656114953_line3\',\'__containerId__-page877094969-layer-textinput656114953_line4\'))" value="" style="width:143px;height:28px;padding: 0px;" type="text" /></div>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page877094969-layer-textinput23076400" style="position: absolute; left: 645px; top: 3525px; width: 150px; height: 30px" data-interactive-element-type="default.textinput" class="textinput stencil mobile-interaction-potential-trigger " data-stencil-id="textinput23076400" data-review-reference-id="textinput23076400">\
         <div class="stencil-wrapper" style="width: 150px; height: 30px">\
            <div>\
               <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" style="height: 30px;width:150px;" width="150" height="30">\
                  <svg:g id="__containerId__-page877094969-layer-textinput23076400svg" width="150" height="30"><svg:path id="__containerId__-page877094969-layer-textinput23076400_input_svg_border" d="M 2.00, 2.00 Q 12.43, 1.14, 22.86,\
                     1.94 Q 33.29, 1.99, 43.71, 3.22 Q 54.14, 2.30, 64.57, 1.71 Q 75.00, 2.24, 85.43, 2.54 Q 95.86, 3.28, 106.29, 1.83 Q 116.71,\
                     1.17, 127.14, 1.68 Q 137.57, 2.03, 147.99, 2.01 Q 148.16, 14.95, 148.25, 28.25 Q 137.57, 27.98, 127.10, 27.63 Q 116.69, 27.44,\
                     106.30, 28.53 Q 95.88, 29.60, 85.44, 29.80 Q 75.01, 29.91, 64.57, 29.91 Q 54.14, 29.97, 43.71, 29.77 Q 33.29, 29.83, 22.86,\
                     29.85 Q 12.43, 29.98, 0.98, 29.02 Q 2.00, 15.00, 2.00, 2.00" style=" fill:white;" class="svg_unselected_element"/><svg:path id="__containerId__-page877094969-layer-textinput23076400_line1" d="M 3.00, 3.00 Q 13.29, 3.55, 23.57, 3.59 Q 33.86,\
                     4.52, 44.14, 3.57 Q 54.43, 3.80, 64.71, 3.88 Q 75.00, 3.45, 85.29, 2.02 Q 95.57, 1.51, 105.86, 3.00 Q 116.14, 4.20, 126.43,\
                     3.76 Q 136.71, 3.00, 147.00, 3.00" style=" fill:none;" class="svg_unselected_element"/><svg:path id="__containerId__-page877094969-layer-textinput23076400_line2" d="M 3.00, 3.00 Q 3.00, 15.00, 3.00, 27.00" style="\
                     fill:none;" class="svg_unselected_element"/><svg:path id="__containerId__-page877094969-layer-textinput23076400_line3" d="M 3.00, 3.00 Q 13.29, 0.72, 23.57, 0.92 Q 33.86,\
                     0.99, 44.14, 1.29 Q 54.43, 1.39, 64.71, 1.42 Q 75.00, 1.49, 85.29, 2.54 Q 95.57, 2.56, 105.86, 2.32 Q 116.14, 2.24, 126.43,\
                     2.22 Q 136.71, 3.00, 147.00, 3.00" style=" fill:none;" class="svg_unselected_element"/><svg:path id="__containerId__-page877094969-layer-textinput23076400_line4" d="M 3.00, 3.00 Q 3.00, 15.00, 3.00, 27.00" style="\
                     fill:none;" class="svg_unselected_element"/>\
                  </svg:g>\
               </svg:svg>\
               <div style="position:absolute;left: 6px; top: 1px;" title=""><input id="__containerId__-page877094969-layer-textinput23076400input" onblur="rabbit.facade.raiseEvent(rabbit.events.svgBlur, new Array(\'__containerId__-page877094969-layer-textinput23076400_input_svg_border\',\'__containerId__-page877094969-layer-textinput23076400_line1\',\'__containerId__-page877094969-layer-textinput23076400_line2\',\'__containerId__-page877094969-layer-textinput23076400_line3\',\'__containerId__-page877094969-layer-textinput23076400_line4\'))" onfocus="rabbit.facade.raiseEvent(rabbit.events.svgFocus, new Array(\'__containerId__-page877094969-layer-textinput23076400_input_svg_border\',\'__containerId__-page877094969-layer-textinput23076400_line1\',\'__containerId__-page877094969-layer-textinput23076400_line2\',\'__containerId__-page877094969-layer-textinput23076400_line3\',\'__containerId__-page877094969-layer-textinput23076400_line4\'))" value="" style="width:143px;height:28px;padding: 0px;" type="text" /></div>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page877094969-layer-combobox132242293" style="position: absolute; left: 445px; top: 3525px; width: 150px; height: 30px" data-interactive-element-type="default.combobox" class="combobox stencil mobile-interaction-potential-trigger " data-stencil-id="combobox132242293" data-review-reference-id="combobox132242293">\
         <div class="stencil-wrapper" style="width: 150px; height: 30px">\
            <div style="position:absolute;left:2px;top:0px;">\
               <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" style="position: absolute; height: 30px;width:150px;" width="150" height="30">\
                  <svg:g id="__containerId__-page877094969-layer-combobox132242293" width="150" height="30"><svg:path id="__containerId__-page877094969-layer-combobox132242293_input_svg_border" d="M 2.00, 2.00 Q 12.43, -0.39, 22.86,\
                     -0.35 Q 33.29, -0.27, 43.71, 0.83 Q 54.14, 1.15, 64.57, 0.31 Q 75.00, 0.46, 85.43, 1.30 Q 95.86, 1.69, 106.29, 0.89 Q 116.71,\
                     1.43, 127.14, 1.10 Q 137.57, 0.77, 148.33, 1.67 Q 147.91, 15.03, 147.86, 27.86 Q 137.47, 27.64, 127.12, 27.77 Q 116.78, 29.25,\
                     106.31, 29.06 Q 95.85, 27.76, 85.43, 28.18 Q 75.00, 28.50, 64.57, 28.24 Q 54.14, 28.05, 43.71, 28.94 Q 33.29, 28.23, 22.86,\
                     28.84 Q 12.43, 28.98, 1.53, 28.47 Q 2.00, 15.00, 2.00, 2.00" style=" fill:white;" class="svg_unselected_element"/>\
                  </svg:g>\
               </svg:svg>\
               <div title="" style="position:absolute"><select id="__containerId__-page877094969-layer-combobox132242293select" onblur="rabbit.facade.raiseEvent(rabbit.events.svgBlur, \'__containerId__-page877094969-layer-combobox132242293_input_svg_border\')" onfocus="rabbit.facade.raiseEvent(rabbit.events.svgFocus, \'__containerId__-page877094969-layer-combobox132242293_input_svg_border\')" style="width:146px; height:26px;" title="">\
                     <option title="">Khai vị</option>\
                     <option title="">Món chính</option>\
                     <option title="">Tráng miệng</option>\
                     <option title="">Đồ uống</option>\
                     <option title="">Khác</option>\
                     <option title=""></option></select></div>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page877094969-layer-text605044483" style="position: absolute; left: 815px; top: 3525px; width: 325px; height: 65px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text605044483" data-review-reference-id="text605044483">\
         <div class="stencil-wrapper" style="width: 325px; height: 65px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textblock2"><p style="font-size: 14px;">Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt\
                     ut labore et dolore magna aliquyam erat, sed diam voluptua. At t</p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page877094969-layer-image658241962" style="position: absolute; left: 1160px; top: 3505px; width: 130px; height: 130px" data-interactive-element-type="default.image" class="image stencil mobile-interaction-potential-trigger " data-stencil-id="image658241962" data-review-reference-id="image658241962">\
         <div class="stencil-wrapper" style="width: 130px; height: 130px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" title="">\
               <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" class="image-cropper" style="height: 130px;width:130px;" width="130" height="130">\
                  <svg:g width="130" height="130">\
                     <svg:svg x="1" y="1" width="128" height="128">\
                        <svg:image width="432" height="253" xlink:href="../repoimages/506340.PNG" preserveAspectRatio="none" transform="scale(0.30092592592592593,0.5138339920948617) translate(-0,-0)  "></svg:image>\
                     </svg:svg>\
                  </svg:g>\
               </svg:svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page877094969-layer-icon771960798" style="position: absolute; left: 1255px; top: 3505px; width: 32px; height: 32px" data-interactive-element-type="fonticon.icon" class="icon stencil mobile-interaction-potential-trigger " data-stencil-id="icon771960798" data-review-reference-id="icon771960798">\
         <div class="stencil-wrapper" style="width: 32px; height: 32px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" style="width:32px;height:32px;" title="">\
               <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" class="fill-black">\
                  <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#icon-glyph-e012"></use>\
               </svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page877094969-layer-icon152281576" style="position: absolute; left: 245px; top: 3650px; width: 64px; height: 64px" data-interactive-element-type="fonticon.icon" class="icon stencil mobile-interaction-potential-trigger " data-stencil-id="icon152281576" data-review-reference-id="icon152281576">\
         <div class="stencil-wrapper" style="width: 64px; height: 64px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" style="width:64px;height:64px;" title="">\
               <svg xmlns="http://www.w3.org/2000/svg" width="64" height="64" class="fill-black">\
                  <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#icon-glyph-e191"></use>\
               </svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page877094969-layer-switch794253660" style="position: absolute; left: 1300px; top: 3530px; width: 94px; height: 27px" data-interactive-element-type="default.iphoneSwitch" class="iphoneSwitch stencil mobile-interaction-potential-trigger " data-stencil-id="switch794253660" data-review-reference-id="switch794253660">\
         <div class="stencil-wrapper" style="width: 94px; height: 27px">\
            <div class="switch-selected" title="" style="position: absolute; left: -2px; top: -2px;height: 31px;width:98px;cursor:pointer;">\
               <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" class="helvetica-font" width="98" height="31" viewBox="-2 -2 98 31">\
                  <svg:g stroke="none" onclick="rabbit.facade.raiseEvent(rabbit.events.iphoneSwitchClicked, \'__containerId__-page877094969-layer-switch794253660\');return true;">\
                     <svg:g class="switch-on">\
                        <svg:g>\
                           <svg:g><svg:path d="M 4.00, 26.00 Q 3.00, 25.25, 2.25, 25.39 Q 1.82, 25.03, 1.23, 24.72 Q 0.78, 24.20, 0.41, 23.82 Q 0.22, 12.96,\
                              0.27, 2.09 Q 0.26, 1.35, 0.95, 0.96 Q 1.74, 0.72, 2.04, 0.10 Q 13.02, -0.52, 24.21, -0.41 Q 35.34, -0.72, 46.48, -0.84 Q 57.61,\
                              -1.59, 68.74, -1.66 Q 79.87, -1.69, 91.54, -1.30 Q 91.90, -0.09, 92.78, 0.06 Q 93.25, 0.68, 93.92, 1.60 Q 93.87, 12.83, 93.69,\
                              24.22 Q 93.71, 25.27, 92.83, 25.68 Q 92.77, 26.65, 91.81, 27.86 Q 90.44, 28.24, 89.21, 28.27 Q 78.49, 28.50, 67.81, 28.62\
                              Q 57.15, 28.50, 46.51, 27.78 Q 35.88, 27.17, 25.25, 27.56 Q 14.62, 26.00, 4.00, 26.00" style="fill-rule:evenodd;clip-rule:evenodd;fill:#808080;stroke:#666666;"\
                              class="svg_unselected_element"/>\
                           </svg:g>\
                           <svg:g><svg:path d="M 59.00, 26.00 Q 58.00, 26.25, 56.59, 26.99 Q 55.86, 26.44, 55.83, 25.20 Q 55.67, 24.31, 54.64, 24.16 Q 53.99,\
                              13.20, 55.39, 2.13 Q 55.73, 1.65, 56.77, 1.62 Q 57.52, 1.42, 57.13, 0.29 Q 73.87, -0.64, 91.18, -0.57 Q 91.23, 0.93, 91.04,\
                              2.18 Q 92.01, 2.04, 93.62, 1.73 Q 94.06, 12.79, 93.27, 24.09 Q 92.34, 24.39, 91.95, 24.96 Q 91.86, 25.82, 91.32, 26.74 Q 90.14,\
                              26.73, 89.10, 27.06 Q 74.00, 26.00, 59.00, 26.00" style="fill-rule:evenodd;clip-rule:evenodd;fill:#F2F2F2;stroke:#666666;"\
                              class="svg_unselected_element"/>\
                           </svg:g>\
                        </svg:g>\
                        <svg:text x="14" y="19" fill="#FFFFFF" style="font-size:17px;">ON</svg:text>\
                     </svg:g>\
                     <svg:g class="switch-off">\
                        <svg:g>\
                           <svg:g><svg:path d="M 4.00, 26.00 Q 3.00, 26.45, 1.86, 26.35 Q 1.44, 25.58, 0.46, 25.64 Q 0.68, 24.31, -0.21, 24.09 Q -0.51, 13.10,\
                              -0.61, 1.80 Q 0.40, 1.44, 1.71, 1.58 Q 2.59, 1.48, 1.89, -0.25 Q 13.14, 0.06, 24.18, -0.77 Q 35.39, 0.28, 46.47, -1.16 Q 57.61,\
                              -1.26, 68.75, -0.39 Q 79.87, -0.39, 90.72, 0.69 Q 90.59, 1.84, 91.77, 1.27 Q 93.06, 0.89, 94.70, 1.26 Q 94.28, 12.75, 93.16,\
                              24.05 Q 93.06, 24.86, 92.86, 25.70 Q 91.62, 25.61, 90.63, 25.15 Q 89.90, 25.50, 89.06, 26.59 Q 78.39, 26.39, 67.77, 26.97\
                              Q 57.12, 25.56, 46.50, 25.70 Q 35.88, 26.34, 25.25, 26.66 Q 14.62, 26.00, 4.00, 26.00" style="fill-rule:evenodd;clip-rule:evenodd;fill:#F2F2F2;stroke:#666666;"\
                              class="svg_unselected_element"/>\
                           </svg:g>\
                           <svg:g><svg:path d="M 4.00, 26.00 Q 3.00, 27.37, 1.49, 27.22 Q 1.16, 26.01, 0.24, 25.91 Q -0.16, 25.22, -0.09, 24.04 Q -0.51, 13.10,\
                              -1.01, 1.67 Q -0.37, 0.95, 0.38, 0.49 Q 1.49, 0.49, 2.15, 0.33 Q 19.11, 0.58, 35.94, 0.18 Q 36.76, 0.09, 37.55, 0.33 Q 38.00,\
                              0.95, 38.72, 1.68 Q 38.30, 12.94, 38.33, 24.11 Q 37.79, 24.68, 37.67, 25.54 Q 37.00, 25.95, 36.40, 26.93 Q 35.17, 26.84, 34.07,\
                              26.72 Q 19.00, 26.00, 4.00, 26.00" style="fill-rule:evenodd;clip-rule:evenodd;fill:#F2F2F2;stroke:#666666;" class="svg_unselected_element"/>\
                           </svg:g>\
                        </svg:g>\
                        <svg:text x="48" y="19" fill="#808080" style="font-size:17px;">OFF</svg:text>\
                     </svg:g>\
                  </svg:g>\
               </svg:svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page877094969-layer-text722051159" style="position: absolute; left: 315px; top: 3670px; width: 92px; height: 21px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text722051159" data-review-reference-id="text722051159">\
         <div class="stencil-wrapper" style="width: 92px; height: 21px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline32"><p><span style="font-size: 18px;">Thêm món</span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page877094969-layer-combobox469377898" style="position: absolute; left: 865px; top: 3400px; width: 150px; height: 30px" data-interactive-element-type="default.combobox" class="combobox stencil mobile-interaction-potential-trigger " data-stencil-id="combobox469377898" data-review-reference-id="combobox469377898">\
         <div class="stencil-wrapper" style="width: 150px; height: 30px">\
            <div style="position:absolute;left:2px;top:0px;">\
               <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" style="position: absolute; height: 30px;width:150px;" width="150" height="30">\
                  <svg:g id="__containerId__-page877094969-layer-combobox469377898" width="150" height="30"><svg:path id="__containerId__-page877094969-layer-combobox469377898_input_svg_border" d="M 2.00, 2.00 Q 12.43, 1.75, 22.86,\
                     2.26 Q 33.29, 2.62, 43.71, 2.93 Q 54.14, 2.42, 64.57, 2.78 Q 75.00, 2.66, 85.43, 3.60 Q 95.86, 2.45, 106.29, 2.70 Q 116.71,\
                     2.46, 127.14, 2.82 Q 137.57, 2.21, 148.13, 1.87 Q 147.96, 15.01, 147.76, 27.76 Q 137.55, 27.92, 127.21, 28.57 Q 116.75, 28.67,\
                     106.28, 27.59 Q 95.85, 27.45, 85.43, 28.84 Q 75.00, 28.21, 64.57, 28.08 Q 54.14, 28.72, 43.71, 28.18 Q 33.29, 29.05, 22.86,\
                     28.57 Q 12.43, 28.98, 1.82, 28.18 Q 2.00, 15.00, 2.00, 2.00" style=" fill:white;" class="svg_unselected_element"/>\
                  </svg:g>\
               </svg:svg>\
               <div title="" style="position:absolute"><select id="__containerId__-page877094969-layer-combobox469377898select" onblur="rabbit.facade.raiseEvent(rabbit.events.svgBlur, \'__containerId__-page877094969-layer-combobox469377898_input_svg_border\')" onfocus="rabbit.facade.raiseEvent(rabbit.events.svgFocus, \'__containerId__-page877094969-layer-combobox469377898_input_svg_border\')" style="width:146px; height:26px;" title="">\
                     <option title="">First entry</option>\
                     <option title="">Second entry</option>\
                     <option title="">Third entry</option></select></div>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page877094969-layer-textinput281150857" style="position: absolute; left: 695px; top: 3400px; width: 150px; height: 30px" data-interactive-element-type="default.textinput" class="textinput stencil mobile-interaction-potential-trigger " data-stencil-id="textinput281150857" data-review-reference-id="textinput281150857">\
         <div class="stencil-wrapper" style="width: 150px; height: 30px">\
            <div>\
               <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" style="height: 30px;width:150px;" width="150" height="30">\
                  <svg:g id="__containerId__-page877094969-layer-textinput281150857svg" width="150" height="30"><svg:path id="__containerId__-page877094969-layer-textinput281150857_input_svg_border" d="M 2.00, 2.00 Q 12.43, -0.57, 22.86,\
                     0.05 Q 33.29, 1.20, 43.71, 0.52 Q 54.14, 0.90, 64.57, 1.80 Q 75.00, 1.36, 85.43, 0.74 Q 95.86, 0.40, 106.29, 1.70 Q 116.71,\
                     1.60, 127.14, 1.86 Q 137.57, 1.64, 148.81, 1.19 Q 149.49, 14.50, 148.74, 28.74 Q 137.94, 29.35, 127.34, 29.79 Q 116.78, 29.35,\
                     106.30, 28.70 Q 95.87, 28.73, 85.44, 29.60 Q 75.00, 29.48, 64.57, 28.96 Q 54.14, 29.10, 43.71, 28.73 Q 33.29, 28.71, 22.86,\
                     29.83 Q 12.43, 30.02, 0.90, 29.10 Q 2.00, 15.00, 2.00, 2.00" style=" fill:white;" class="svg_unselected_element"/><svg:path id="__containerId__-page877094969-layer-textinput281150857_line1" d="M 3.00, 3.00 Q 13.29, 2.50, 23.57, 2.29 Q 33.86,\
                     2.17, 44.14, 2.62 Q 54.43, 3.14, 64.71, 2.63 Q 75.00, 3.19, 85.29, 3.14 Q 95.57, 4.32, 105.86, 3.56 Q 116.14, 3.26, 126.43,\
                     3.17 Q 136.71, 3.00, 147.00, 3.00" style=" fill:none;" class="svg_unselected_element"/><svg:path id="__containerId__-page877094969-layer-textinput281150857_line2" d="M 3.00, 3.00 Q 3.00, 15.00, 3.00, 27.00" style="\
                     fill:none;" class="svg_unselected_element"/><svg:path id="__containerId__-page877094969-layer-textinput281150857_line3" d="M 3.00, 3.00 Q 13.29, 1.27, 23.57, 1.23 Q 33.86,\
                     1.08, 44.14, 1.49 Q 54.43, 1.29, 64.71, 1.24 Q 75.00, 1.35, 85.29, 1.71 Q 95.57, 1.58, 105.86, 1.36 Q 116.14, 1.25, 126.43,\
                     1.23 Q 136.71, 3.00, 147.00, 3.00" style=" fill:none;" class="svg_unselected_element"/><svg:path id="__containerId__-page877094969-layer-textinput281150857_line4" d="M 3.00, 3.00 Q 3.00, 15.00, 3.00, 27.00" style="\
                     fill:none;" class="svg_unselected_element"/>\
                  </svg:g>\
               </svg:svg>\
               <div style="position:absolute;left: 6px; top: 1px;" title=""><input id="__containerId__-page877094969-layer-textinput281150857input" onblur="rabbit.facade.raiseEvent(rabbit.events.svgBlur, new Array(\'__containerId__-page877094969-layer-textinput281150857_input_svg_border\',\'__containerId__-page877094969-layer-textinput281150857_line1\',\'__containerId__-page877094969-layer-textinput281150857_line2\',\'__containerId__-page877094969-layer-textinput281150857_line3\',\'__containerId__-page877094969-layer-textinput281150857_line4\'))" onfocus="rabbit.facade.raiseEvent(rabbit.events.svgFocus, new Array(\'__containerId__-page877094969-layer-textinput281150857_input_svg_border\',\'__containerId__-page877094969-layer-textinput281150857_line1\',\'__containerId__-page877094969-layer-textinput281150857_line2\',\'__containerId__-page877094969-layer-textinput281150857_line3\',\'__containerId__-page877094969-layer-textinput281150857_line4\'))" value="" style="width:143px;height:28px;padding: 0px;" type="text" /></div>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page877094969-layer-text457157229" style="position: absolute; left: 595px; top: 3405px; width: 110px; height: 21px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text457157229" data-review-reference-id="text457157229">\
         <div class="stencil-wrapper" style="width: 110px; height: 21px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline32"><p class="none" style="font-size: 18px;"><span style="color: #658cd9;">Lọc theo tên </span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page877094969-layer-iphoneButton840415319" style="position: absolute; left: 1040px; top: 3400px; width: 81px; height: 30px" data-interactive-element-type="default.iphoneButton" class="iphoneButton stencil mobile-interaction-potential-trigger " data-stencil-id="iphoneButton840415319" data-review-reference-id="iphoneButton840415319">\
         <div class="stencil-wrapper" style="width: 81px; height: 30px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" title="" style="position: absolute; left: -2px; top: -2px;height: 34px;width:85px;">\
               <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" class="helvetica-font" width="85" height="34" viewBox="-2 -2 85 34">\
                  <svg:a><svg:path d="M 4.00, 29.00 Q 1.51, 30.49, 1.26, 28.72 Q 1.99, 15.19, 2.08, 1.70 Q 3.38, 1.42, 4.09, 1.17 Q 15.18, 1.05, 26.33,\
                     1.01 Q 37.52, 1.41, 48.68, 1.54 Q 59.84, 1.31, 70.90, 1.42 Q 71.99, 1.54, 73.36, 1.54 Q 78.20, 7.84, 82.27, 14.98 Q 77.57,\
                     21.52, 72.74, 27.76 Q 71.47, 27.76, 70.74, 28.16 Q 59.89, 29.37, 48.67, 29.06 Q 37.48, 28.41, 26.32, 28.16 Q 15.17, 29.00,\
                     4.00, 29.00" style="fill-rule:evenodd;clip-rule:evenodd;fill:#808080;stroke:#666666;" class="svg_unselected_element"/>\
                     <svg:text x="37.5" y="15" dy="0.3em" fill="#FFFFFF" style="font-size:1em;stroke-width:0pt;" font-family="\'HelveticaNeue-Bold\'" text-anchor="middle" xml:space="preserve">Bắt đầu lọc</svg:text>\
                  </svg:a>\
               </svg:svg>\
            </div>\
         </div>\
      </div>\
   </div>\
</div>');