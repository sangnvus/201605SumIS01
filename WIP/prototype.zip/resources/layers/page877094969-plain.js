rabbit.data.layerStore.addLayerFromHtml('<div xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:fn="http://www.w3.org/2005/xpath-functions" id="result">\
   <div xmlns:xs="http://www.w3.org/2001/XMLSchema" xmlns="http://www.w3.org/1999/xhtml" id="__containerId__page877094969-layer" class="layer" name="__containerId__pageLayer" data-layer-id="page877094969" data-layer-type="pageLayer" style="position:absolute;left:0px;top:0px;">\
      <div id="__containerId__-page877094969-layer-1356698599" style="position: absolute; left: 0px; top: 0px; width: 1366px; height: 4000px" data-interactive-element-type="default.image" class="image stencil mobile-interaction-potential-trigger " data-stencil-id="1356698599" data-review-reference-id="1356698599">\
         <div class="stencil-wrapper" style="width: 1366px; height: 4000px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" title="">\
               <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" class="image-cropper" style="height: 4000px;width:1366px;" width="1366" height="4000" viewBox="0 0 1366 4000">\
                  <svg:g width="1366" height="4000">\
                     <svg:svg x="0" y="0" width="1366" height="4000">\
                        <svg:image width="432" height="253" xlink:href="../repoimages/506332.PNG" preserveAspectRatio="none" transform="scale(3.162037037037037,15.810276679841897) translate(-0,-0)  "></svg:image>\
                     </svg:svg>\
                  </svg:g>\
               </svg:svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page877094969-layer-image180943357" style="position: absolute; left: 0px; top: 40px; width: 1366px; height: 5000px" data-interactive-element-type="default.image" class="image stencil mobile-interaction-potential-trigger " data-stencil-id="image180943357" data-review-reference-id="image180943357">\
         <div class="stencil-wrapper" style="width: 1366px; height: 5000px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" title="">\
               <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" class="image-cropper" style="height: 5000px;width:1366px;" width="1366" height="5000" viewBox="0 0 1366 5000">\
                  <svg:g width="1366" height="5000">\
                     <svg:svg x="0" y="0" width="1366" height="5000">\
                        <svg:image width="432" height="253" xlink:href="../repoimages/506332.PNG" preserveAspectRatio="none" transform="scale(3.162037037037037,19.76284584980237) translate(-0,-0)  "></svg:image>\
                     </svg:svg>\
                  </svg:g>\
               </svg:svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page877094969-layer-image66869908" style="position: absolute; left: 30px; top: 105px; width: 1366px; height: 5000px" data-interactive-element-type="default.image" class="image stencil mobile-interaction-potential-trigger " data-stencil-id="image66869908" data-review-reference-id="image66869908">\
         <div class="stencil-wrapper" style="width: 1366px; height: 5000px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" title="">\
               <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" class="image-cropper" style="height: 5000px;width:1366px;" width="1366" height="5000" viewBox="0 0 1366 5000">\
                  <svg:g width="1366" height="5000">\
                     <svg:svg x="0" y="0" width="1366" height="5000">\
                        <svg:image width="432" height="253" xlink:href="../repoimages/506332.PNG" preserveAspectRatio="none" transform="scale(3.162037037037037,19.76284584980237) translate(-0,-0)  "></svg:image>\
                     </svg:svg>\
                  </svg:g>\
               </svg:svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page877094969-layer-1892721953" style="position: absolute; left: 45px; top: 5px; width: 150px; height: 150px" data-interactive-element-type="default.image" class="image stencil mobile-interaction-potential-trigger " data-stencil-id="1892721953" data-review-reference-id="1892721953">\
         <div class="stencil-wrapper" style="width: 150px; height: 150px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" title="">\
               <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" class="image-cropper" style="height: 150px;width:150px;" width="150" height="150" viewBox="0 0 150 150">\
                  <svg:g width="150" height="150">\
                     <svg:svg x="0" y="0" width="150" height="150">\
                        <svg:image width="80" height="60" xlink:href="../repoimages/506350.png" preserveAspectRatio="none" transform="scale(1.875,2.5) translate(-0,-0)  "></svg:image>\
                     </svg:svg>\
                  </svg:g>\
               </svg:svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page877094969-layer-1460271852" style="position: absolute; left: 20px; top: 170px; width: 32px; height: 32px" data-interactive-element-type="fonticon.icon" class="icon stencil mobile-interaction-potential-trigger " data-stencil-id="1460271852" data-review-reference-id="1460271852">\
         <div class="stencil-wrapper" style="width: 32px; height: 32px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" style="width:32px;height:32px;" title="">\
               <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" class="fill-blue">\
                  <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#icon-glyph-e004"></use>\
               </svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page877094969-layer-1956328937" style="position: absolute; left: 20px; top: 215px; width: 32px; height: 32px" data-interactive-element-type="fonticon.icon" class="icon stencil mobile-interaction-potential-trigger " data-stencil-id="1956328937" data-review-reference-id="1956328937">\
         <div class="stencil-wrapper" style="width: 32px; height: 32px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" style="width:32px;height:32px;" title="">\
               <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" class="fill-blue">\
                  <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#icon-glyph-e205"></use>\
               </svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page877094969-layer-970032794" style="position: absolute; left: 20px; top: 265px; width: 32px; height: 32px" data-interactive-element-type="fonticon.icon" class="icon stencil mobile-interaction-potential-trigger " data-stencil-id="970032794" data-review-reference-id="970032794">\
         <div class="stencil-wrapper" style="width: 32px; height: 32px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" style="width:32px;height:32px;" title="">\
               <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" class="fill-blue">\
                  <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#icon-glyph-e320"></use>\
               </svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page877094969-layer-43565105" style="position: absolute; left: 20px; top: 440px; width: 32px; height: 32px" data-interactive-element-type="fonticon.icon" class="icon stencil mobile-interaction-potential-trigger " data-stencil-id="43565105" data-review-reference-id="43565105">\
         <div class="stencil-wrapper" style="width: 32px; height: 32px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" style="width:32px;height:32px;" title="">\
               <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" class="fill-blue">\
                  <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#icon-glyph-e041"></use>\
               </svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page877094969-layer-1367693769" style="position: absolute; left: 20px; top: 535px; width: 32px; height: 32px" data-interactive-element-type="fonticon.icon" class="icon stencil mobile-interaction-potential-trigger " data-stencil-id="1367693769" data-review-reference-id="1367693769">\
         <div class="stencil-wrapper" style="width: 32px; height: 32px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" style="width:32px;height:32px;" title="">\
               <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" class="fill-blue">\
                  <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#icon-glyph-e064"></use>\
               </svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page877094969-layer-1398589434" style="position: absolute; left: 60px; top: 180px; width: 133px; height: 23px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="1398589434" data-review-reference-id="1398589434">\
         <div class="stencil-wrapper" style="width: 133px; height: 23px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline22"><p><span style="font-size: 20px; color: #658cd9;">Chủ cửa hàng</span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page877094969-layer-835324706" style="position: absolute; left: 60px; top: 225px; width: 158px; height: 23px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="835324706" data-review-reference-id="835324706">\
         <div class="stencil-wrapper" style="width: 158px; height: 23px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline22"><p><span style="font-size: 20px; color: #658cd9;">Quản lí mật khẩu</span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page877094969-layer-1926295537" style="position: absolute; left: 60px; top: 270px; width: 162px; height: 23px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="1926295537" data-review-reference-id="1926295537">\
         <div class="stencil-wrapper" style="width: 162px; height: 23px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline22"><p><span style="font-size: 20px; color: #658cd9;">Quản lí đơn hàng</span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page877094969-layer-465611662" style="position: absolute; left: 60px; top: 450px; width: 89px; height: 23px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="465611662" data-review-reference-id="465611662">\
         <div class="stencil-wrapper" style="width: 89px; height: 23px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline22"><p><span style="font-size: 20px; color: #658cd9;">Thống kê</span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page877094969-layer-1076491664" style="position: absolute; left: 60px; top: 540px; width: 104px; height: 28px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="1076491664" data-review-reference-id="1076491664">\
         <div class="stencil-wrapper" style="width: 104px; height: 28px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline22"><p class="none" style="font-size: 24px;"><span style="font-size: 20px; color: #658cd9;">Đăng xuất</span></p>\
                     <p class="none" style="font-size: 24px;"> </p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page877094969-layer-2023566405" style="position: absolute; left: 305px; top: 45px; width: 209px; height: 37px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="2023566405" data-review-reference-id="2023566405">\
         <div class="stencil-wrapper" style="width: 209px; height: 37px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline22"><p><span style="font-size: 32px; color: #658cd9;">Chủ cửa hàng</span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page877094969-layer-1570916986" style="position: absolute; left: 215px; top: 45px; width: 33px; height: 4760px" data-interactive-element-type="static.line" class="line stencil mobile-interaction-potential-trigger " data-stencil-id="1570916986" data-review-reference-id="1570916986">\
         <div class="stencil-wrapper" style="width: 33px; height: 4760px">\
            <div title="">\
               <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" style="position: absolute; left: -5px; top: -5px; height: 4770px;width:43px;" viewBox="-5 -5 43 4770" width="43" height="4770">\
                  <svg:path d="M 16.5,0 L 16.5,4760" marker-start="" marker-end="" style="fill:none; stroke-width:2px;stroke:black;"></svg:path>\
               </svg:svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page877094969-layer-99260106" style="position: absolute; left: 305px; top: 160px; width: 67px; height: 20px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="99260106" data-review-reference-id="99260106">\
         <div class="stencil-wrapper" style="width: 67px; height: 20px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline32"><p><span style="font-size: 18px;">Họ tên:</span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page877094969-layer-1291520326" style="position: absolute; left: 465px; top: 145px; width: 275px; height: 30px" data-interactive-element-type="default.textinput" class="textinput stencil mobile-interaction-potential-trigger " data-stencil-id="1291520326" data-review-reference-id="1291520326">\
         <div class="stencil-wrapper" style="width: 275px; height: 30px">\
            <div title=""><input id="__containerId__-page877094969-layer-1291520326input" value="" style="width:273px;height:28px;padding: 0px;border-width:1px;" type="text" /></div>\
         </div>\
      </div>\
      <div id="__containerId__-page877094969-layer-1859232652" style="position: absolute; left: 465px; top: 205px; width: 275px; height: 30px" data-interactive-element-type="default.textinput" class="textinput stencil mobile-interaction-potential-trigger " data-stencil-id="1859232652" data-review-reference-id="1859232652">\
         <div class="stencil-wrapper" style="width: 275px; height: 30px">\
            <div title=""><input id="__containerId__-page877094969-layer-1859232652input" value="" style="width:273px;height:28px;padding: 0px;border-width:1px;" type="text" /></div>\
         </div>\
      </div>\
      <div id="__containerId__-page877094969-layer-1578558330" style="position: absolute; left: 305px; top: 220px; width: 56px; height: 21px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="1578558330" data-review-reference-id="1578558330">\
         <div class="stencil-wrapper" style="width: 56px; height: 21px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline32"><p><span style="font-size: 18px;">Email:</span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page877094969-layer-649397398" style="position: absolute; left: 305px; top: 280px; width: 91px; height: 21px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="649397398" data-review-reference-id="649397398">\
         <div class="stencil-wrapper" style="width: 91px; height: 21px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline32"><p><span style="font-size: 18px;">Ngày sinh:</span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page877094969-layer-1115828819" style="position: absolute; left: 780px; top: 275px; width: 81px; height: 21px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="1115828819" data-review-reference-id="1115828819">\
         <div class="stencil-wrapper" style="width: 81px; height: 21px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline32"><p><span style="font-size: 18px;">Giới Tính</span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page877094969-layer-2123886261" style="position: absolute; left: 465px; top: 270px; width: 150px; height: 30px" data-interactive-element-type="default.datepicker" class="datepicker stencil mobile-interaction-potential-trigger " data-stencil-id="2123886261" data-review-reference-id="2123886261">\
         <div class="stencil-wrapper" style="width: 150px; height: 30px">\
            <div>\
               <div style="position:absolute; white-space: nowrap;" title=""><input type="text" style="width:114px; height:28px;padding: 0px;border-width:1px;" id="__containerId__-page877094969-layer-2123886261_input" /><button type="button" style="width:34px; height:28px; vertical-align: top; padding: 0px;border-width:1px;" id="__containerId__-page877094969-layer-2123886261_button"><img src="../resources/icons/date.png" /></button></div>\
               <div id="__containerId__-page877094969-layer-2123886261_ov" class="yui-skin-sam" style="position: absolute; width: 16em;visibility:visible;">\
                  <div id="__containerId__-page877094969-layer-2123886261_cal"></div>\
               </div><script type="text/javascript">\
				rabbit.stencils.datepicker.setupDatepicker("__containerId__-page877094969-layer-2123886261");\
			</script></div>\
         </div>\
      </div>\
      <div id="__containerId__-page877094969-layer-807475562" style="position: absolute; left: 900px; top: 275px; width: 52px; height: 20px" data-interactive-element-type="default.radiobutton" class="radiobutton stencil mobile-interaction-potential-trigger " data-stencil-id="807475562" data-review-reference-id="807475562">\
         <div class="stencil-wrapper" style="width: 52px; height: 20px">\
            <div class="" style="font-size:1.17em;" xml:space="preserve" title="">\
               					<input id="__containerId__-page877094969-layer-807475562input" xml:space="default" type="radio" name="group1" value="__containerId__-page877094969-layer-807475562" style="padding-right:8px" />\
               \
               					<label for="__containerId__-page877094969-layer-807475562input">\
                  						\
                  						\
                  							Nam\
                  							\
                  						\
                  					</label>\
               				\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page877094969-layer-1806491405" style="position: absolute; left: 1005px; top: 275px; width: 41px; height: 20px" data-interactive-element-type="default.radiobutton" class="radiobutton stencil mobile-interaction-potential-trigger " data-stencil-id="1806491405" data-review-reference-id="1806491405">\
         <div class="stencil-wrapper" style="width: 41px; height: 20px">\
            <div class="" style="font-size:1.17em;" xml:space="preserve" title="">\
               					<input id="__containerId__-page877094969-layer-1806491405input" xml:space="default" type="radio" name="group1" value="__containerId__-page877094969-layer-1806491405" style="padding-right:8px" />\
               \
               					<label for="__containerId__-page877094969-layer-1806491405input">\
                  						\
                  						\
                  							Nữ\
                  							\
                  						\
                  					</label>\
               				\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page877094969-layer-1356475940" style="position: absolute; left: 815px; top: 160px; width: 45px; height: 21px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="1356475940" data-review-reference-id="1356475940">\
         <div class="stencil-wrapper" style="width: 45px; height: 21px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline32"><p><span style="font-size: 18px;">SĐT:</span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page877094969-layer-696932043" style="position: absolute; left: 865px; top: 155px; width: 275px; height: 30px" data-interactive-element-type="default.textinput" class="textinput stencil mobile-interaction-potential-trigger " data-stencil-id="696932043" data-review-reference-id="696932043">\
         <div class="stencil-wrapper" style="width: 275px; height: 30px">\
            <div title=""><input id="__containerId__-page877094969-layer-696932043input" value="" style="width:273px;height:28px;padding: 0px;border-width:1px;" type="text" /></div>\
         </div>\
      </div>\
      <div id="__containerId__-page877094969-layer-icon283732951" style="position: absolute; left: 1140px; top: 155px; width: 32px; height: 32px" data-interactive-element-type="fonticon.icon" class="icon stencil mobile-interaction-potential-trigger " data-stencil-id="icon283732951" data-review-reference-id="icon283732951">\
         <div class="stencil-wrapper" style="width: 32px; height: 32px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" style="width:32px;height:32px;" title="">\
               <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" class="fill-blue">\
                  <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#icon-glyph-e337"></use>\
               </svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page877094969-layer-181957790" style="position: absolute; left: 860px; top: 345px; width: 48px; height: 48px" data-interactive-element-type="fonticon.icon" class="icon stencil mobile-interaction-potential-trigger " data-stencil-id="181957790" data-review-reference-id="181957790">\
         <div class="stencil-wrapper" style="width: 48px; height: 48px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" style="width:48px;height:48px;" title="">\
               <svg xmlns="http://www.w3.org/2000/svg" width="48" height="48" class="fill-green">\
                  <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#icon-glyph-e207"></use>\
               </svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page877094969-layer-997662337" style="position: absolute; left: 910px; top: 360px; width: 166px; height: 21px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="997662337" data-review-reference-id="997662337">\
         <div class="stencil-wrapper" style="width: 166px; height: 21px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline32"><p class="none" style="font-size: 18px;">Đã được phê duyệt </p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page877094969-layer-1647991585" style="position: absolute; left: 300px; top: 355px; width: 111px; height: 21px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="1647991585" data-review-reference-id="1647991585">\
         <div class="stencil-wrapper" style="width: 111px; height: 21px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline32"><p><span style="font-size: 18px;">Số tài khoản:</span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page877094969-layer-1255850099" style="position: absolute; left: 465px; top: 345px; width: 275px; height: 30px" data-interactive-element-type="default.textinput" class="textinput stencil mobile-interaction-potential-trigger " data-stencil-id="1255850099" data-review-reference-id="1255850099">\
         <div class="stencil-wrapper" style="width: 275px; height: 30px">\
            <div title=""><input id="__containerId__-page877094969-layer-1255850099input" value="" style="width:273px;height:28px;padding: 0px;border-width:1px;" type="text" /></div>\
         </div>\
      </div>\
      <div id="__containerId__-page877094969-layer-9084711" style="position: absolute; left: 60px; top: 325px; width: 161px; height: 28px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="9084711" data-review-reference-id="9084711">\
         <div class="stencil-wrapper" style="width: 161px; height: 28px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline22"><p class="none" style="font-size: 24px;"><span style="color: #658cd9; font-size: 20px;">Quản lí nhà hàng</span></p>\
                     <p class="none" style="font-size: 24px;"> </p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page877094969-layer-1895045554" style="position: absolute; left: 20px; top: 320px; width: 32px; height: 32px" data-interactive-element-type="fonticon.icon" class="icon stencil mobile-interaction-potential-trigger " data-stencil-id="1895045554" data-review-reference-id="1895045554">\
         <div class="stencil-wrapper" style="width: 32px; height: 32px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" style="width:32px;height:32px;" title="">\
               <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" class="fill-blue">\
                  <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#icon-glyph-e021"></use>\
               </svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page877094969-layer-1694463243" style="position: absolute; left: 295px; top: 545px; width: 251px; height: 37px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="1694463243" data-review-reference-id="1694463243">\
         <div class="stencil-wrapper" style="width: 251px; height: 37px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline22"><p><span style="font-size: 32px; color: #658cd9;">Quản lí nhà hàng</span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page877094969-layer-703985551" style="position: absolute; left: 860px; top: 705px; width: 73px; height: 21px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="703985551" data-review-reference-id="703985551">\
         <div class="stencil-wrapper" style="width: 73px; height: 21px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline32"><p class="none" style="font-size: 18px;"><span style="color: #658cd9;">Ảnh bìa </span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page877094969-layer-image674997378" style="position: absolute; left: 810px; top: 550px; width: 155px; height: 155px" data-interactive-element-type="default.image" class="image stencil mobile-interaction-potential-trigger " data-stencil-id="image674997378" data-review-reference-id="image674997378">\
         <div class="stencil-wrapper" style="width: 155px; height: 155px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" title="">\
               <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" class="image-cropper" style="height: 155px;width:155px;" width="155" height="155" viewBox="0 0 155 155">\
                  <svg:g width="155" height="155">\
                     <svg:svg x="0" y="0" width="155" height="155">\
                        <svg:image width="432" height="253" xlink:href="../repoimages/506338.PNG" preserveAspectRatio="none" transform="scale(0.3587962962962963,0.6126482213438735) translate(-0,-0)  "></svg:image>\
                     </svg:svg>\
                  </svg:g>\
               </svg:svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page877094969-layer-icon664229910" style="position: absolute; left: 925px; top: 550px; width: 35px; height: 35px" data-interactive-element-type="fonticon.icon" class="icon stencil mobile-interaction-potential-trigger " data-stencil-id="icon664229910" data-review-reference-id="icon664229910">\
         <div class="stencil-wrapper" style="width: 35px; height: 35px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" style="width:35px;height:35px;" title="">\
               <svg xmlns="http://www.w3.org/2000/svg" width="35" height="35" class="fill-blue">\
                  <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#icon-glyph-e012"></use>\
               </svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page877094969-layer-1491567339" style="position: absolute; left: 295px; top: 790px; width: 64px; height: 21px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="1491567339" data-review-reference-id="1491567339">\
         <div class="stencil-wrapper" style="width: 64px; height: 21px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline32"><p><span style="font-size: 18px; color: #658cd9;">Banner</span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page877094969-layer-image765111263" style="position: absolute; left: 425px; top: 775px; width: 130px; height: 135px" data-interactive-element-type="default.image" class="image stencil mobile-interaction-potential-trigger " data-stencil-id="image765111263" data-review-reference-id="image765111263">\
         <div class="stencil-wrapper" style="width: 130px; height: 135px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" title="">\
               <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" class="image-cropper" style="height: 135px;width:130px;" width="130" height="135" viewBox="0 0 130 135">\
                  <svg:g width="130" height="135">\
                     <svg:svg x="0" y="0" width="130" height="135">\
                        <svg:image width="600" height="600" xlink:href="../repoimages/506343.JPG" preserveAspectRatio="none" transform="scale(0.21666666666666667,0.225) translate(-0,-0)  "></svg:image>\
                     </svg:svg>\
                  </svg:g>\
               </svg:svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page877094969-layer-470917823" style="position: absolute; left: 420px; top: 770px; width: 35px; height: 35px" data-interactive-element-type="fonticon.icon" class="icon stencil mobile-interaction-potential-trigger " data-stencil-id="470917823" data-review-reference-id="470917823">\
         <div class="stencil-wrapper" style="width: 35px; height: 35px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" style="width:35px;height:35px;" title="">\
               <svg xmlns="http://www.w3.org/2000/svg" width="35" height="35" class="fill-blue">\
                  <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#icon-glyph-e208"></use>\
               </svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page877094969-layer-1035173814" style="position: absolute; left: 575px; top: 775px; width: 130px; height: 135px" data-interactive-element-type="default.image" class="image stencil mobile-interaction-potential-trigger " data-stencil-id="1035173814" data-review-reference-id="1035173814">\
         <div class="stencil-wrapper" style="width: 130px; height: 135px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" title="">\
               <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" class="image-cropper" style="height: 135px;width:130px;" width="130" height="135" viewBox="0 0 130 135">\
                  <svg:g width="130" height="135">\
                     <svg:svg x="0" y="0" width="130" height="135">\
                        <svg:image width="600" height="600" xlink:href="../repoimages/506343.JPG" preserveAspectRatio="none" transform="scale(0.21666666666666667,0.225) translate(-0,-0)  "></svg:image>\
                     </svg:svg>\
                  </svg:g>\
               </svg:svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page877094969-layer-1310545113" style="position: absolute; left: 670px; top: 770px; width: 35px; height: 35px" data-interactive-element-type="fonticon.icon" class="icon stencil mobile-interaction-potential-trigger " data-stencil-id="1310545113" data-review-reference-id="1310545113">\
         <div class="stencil-wrapper" style="width: 35px; height: 35px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" style="width:35px;height:35px;" title="">\
               <svg xmlns="http://www.w3.org/2000/svg" width="35" height="35" class="fill-blue">\
                  <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#icon-glyph-e012"></use>\
               </svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page877094969-layer-icon628173581" style="position: absolute; left: 750px; top: 810px; width: 64px; height: 64px" data-interactive-element-type="fonticon.icon" class="icon stencil mobile-interaction-potential-trigger " data-stencil-id="icon628173581" data-review-reference-id="icon628173581">\
         <div class="stencil-wrapper" style="width: 64px; height: 64px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" style="width:64px;height:64px;" title="">\
               <svg xmlns="http://www.w3.org/2000/svg" width="64" height="64" class="fill-blue">\
                  <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#icon-android-e028"></use>\
               </svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page877094969-layer-1024975303" style="position: absolute; left: 520px; top: 770px; width: 35px; height: 35px" data-interactive-element-type="fonticon.icon" class="icon stencil mobile-interaction-potential-trigger " data-stencil-id="1024975303" data-review-reference-id="1024975303">\
         <div class="stencil-wrapper" style="width: 35px; height: 35px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" style="width:35px;height:35px;" title="">\
               <svg xmlns="http://www.w3.org/2000/svg" width="35" height="35" class="fill-blue">\
                  <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#icon-glyph-e012"></use>\
               </svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page877094969-layer-1646873528" style="position: absolute; left: 575px; top: 770px; width: 35px; height: 35px" data-interactive-element-type="fonticon.icon" class="icon stencil mobile-interaction-potential-trigger " data-stencil-id="1646873528" data-review-reference-id="1646873528">\
         <div class="stencil-wrapper" style="width: 35px; height: 35px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" style="width:35px;height:35px;" title="">\
               <svg xmlns="http://www.w3.org/2000/svg" width="35" height="35" class="fill-blue">\
                  <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#icon-glyph-e208"></use>\
               </svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page877094969-layer-arrow549406372" style="position: absolute; left: 235px; top: 520px; width: 1025px; height: 33px" data-interactive-element-type="static.line" class="line stencil mobile-interaction-potential-trigger " data-stencil-id="arrow549406372" data-review-reference-id="arrow549406372">\
         <div class="stencil-wrapper" style="width: 1025px; height: 33px">\
            <div title="">\
               <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" style="position: absolute; left: -5px; top: -5px; height: 43px;width:1035px;" viewBox="-5 -5 1035 43" width="1035" height="43">\
                  <svg:path d="M 0,16.5 L 1025,16.5" marker-start="" marker-end="" style="fill:none; stroke-width:2px;stroke:black;"></svg:path>\
               </svg:svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page877094969-layer-1898877713" style="position: absolute; left: 290px; top: 665px; width: 122px; height: 21px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="1898877713" data-review-reference-id="1898877713">\
         <div class="stencil-wrapper" style="width: 122px; height: 21px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline32"><p><span style="font-size: 18px; color: #658cd9;">Tên nhà hàng:</span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page877094969-layer-1512867297" style="position: absolute; left: 415px; top: 925px; width: 495px; height: 30px" data-interactive-element-type="default.textinput" class="textinput stencil mobile-interaction-potential-trigger " data-stencil-id="1512867297" data-review-reference-id="1512867297">\
         <div class="stencil-wrapper" style="width: 495px; height: 30px">\
            <div title=""><input id="__containerId__-page877094969-layer-1512867297input" value="" style="width:493px;height:28px;padding: 0px;border-width:1px;" type="text" /></div>\
         </div>\
      </div>\
      <div id="__containerId__-page877094969-layer-749439552" style="position: absolute; left: 295px; top: 930px; width: 66px; height: 21px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="749439552" data-review-reference-id="749439552">\
         <div class="stencil-wrapper" style="width: 66px; height: 21px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline32"><p class="none" style="font-size: 18px;"><span style="color: #658cd9;">Địa chỉ:</span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page877094969-layer-2133142998" style="position: absolute; left: 300px; top: 1080px; width: 85px; height: 42px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="2133142998" data-review-reference-id="2133142998">\
         <div class="stencil-wrapper" style="width: 85px; height: 42px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline32"><p class="none" style="font-size: 18px;"><span style="color: #658cd9;">Loại hình </span></p>\
                     <p class="none" style="font-size: 18px;"><span style="color: #658cd9;">ẩm thực </span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page877094969-layer-895159778" style="position: absolute; left: 420px; top: 1071px; width: 46px; height: 20px" data-interactive-element-type="default.checkbox" class="checkbox stencil mobile-interaction-potential-trigger " data-stencil-id="895159778" data-review-reference-id="895159778">\
         <div class="stencil-wrapper" style="width: 46px; height: 20px">\
            <div class="" style="font-size:1.17em;" xml:space="preserve" title="">\
               			\
               <nobr>\
                  				<label>\
                     					<input id="__containerId__-page877094969-layer-895159778input" xml:space="default" style="padding-right:9px" type="checkbox" />\
                     					\
                     						\
                     						Lẩu\
                     						\
                     					\
                     				</label>\
                  			\
               </nobr>\
               		\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page877094969-layer-172347672" style="position: absolute; left: 420px; top: 1111px; width: 81px; height: 20px" data-interactive-element-type="default.checkbox" class="checkbox stencil mobile-interaction-potential-trigger " data-stencil-id="172347672" data-review-reference-id="172347672">\
         <div class="stencil-wrapper" style="width: 81px; height: 20px">\
            <div class="" style="font-size:1.17em;" xml:space="preserve" title="">\
               			\
               <nobr>\
                  				<label>\
                     					<input id="__containerId__-page877094969-layer-172347672input" xml:space="default" style="padding-right:9px" type="checkbox" />\
                     					\
                     						\
                     						Tùy chọn\
                     						\
                     					\
                     				</label>\
                  			\
               </nobr>\
               		\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page877094969-layer-1183321380" style="position: absolute; left: 535px; top: 1115px; width: 74px; height: 20px" data-interactive-element-type="default.checkbox" class="checkbox stencil mobile-interaction-potential-trigger " data-stencil-id="1183321380" data-review-reference-id="1183321380">\
         <div class="stencil-wrapper" style="width: 74px; height: 20px">\
            <div class="" style="font-size:1.17em;" xml:space="preserve" title="">\
               			\
               <nobr>\
                  				<label>\
                     					<input id="__containerId__-page877094969-layer-1183321380input" xml:space="default" style="padding-right:9px" type="checkbox" />\
                     					\
                     						\
                     						Ba miền\
                     						\
                     					\
                     				</label>\
                  			\
               </nobr>\
               		\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page877094969-layer-2086924429" style="position: absolute; left: 535px; top: 1071px; width: 66px; height: 20px" data-interactive-element-type="default.checkbox" class="checkbox stencil mobile-interaction-potential-trigger " data-stencil-id="2086924429" data-review-reference-id="2086924429">\
         <div class="stencil-wrapper" style="width: 66px; height: 20px">\
            <div class="" style="font-size:1.17em;" xml:space="preserve" title="">\
               			\
               <nobr>\
                  				<label>\
                     					<input id="__containerId__-page877094969-layer-2086924429input" xml:space="default" style="padding-right:9px" type="checkbox" />\
                     					\
                     						\
                     						Nướng\
                     						\
                     					\
                     				</label>\
                  			\
               </nobr>\
               		\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page877094969-layer-1244840165" style="position: absolute; left: 655px; top: 1071px; width: 126px; height: 20px" data-interactive-element-type="default.checkbox" class="checkbox stencil mobile-interaction-potential-trigger " data-stencil-id="1244840165" data-review-reference-id="1244840165">\
         <div class="stencil-wrapper" style="width: 126px; height: 20px">\
            <div class="" style="font-size:1.17em;" xml:space="preserve" title="">\
               			\
               <nobr>\
                  				<label>\
                     					<input id="__containerId__-page877094969-layer-1244840165input" xml:space="default" style="padding-right:9px" type="checkbox" />\
                     					\
                     						\
                     						Lẩu băng truyền\
                     						\
                     					\
                     				</label>\
                  			\
               </nobr>\
               		\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page877094969-layer-1139388318" style="position: absolute; left: 655px; top: 1111px; width: 74px; height: 20px" data-interactive-element-type="default.checkbox" class="checkbox stencil mobile-interaction-potential-trigger " data-stencil-id="1139388318" data-review-reference-id="1139388318">\
         <div class="stencil-wrapper" style="width: 74px; height: 20px">\
            <div class="" style="font-size:1.17em;" xml:space="preserve" title="">\
               			\
               <nobr>\
                  				<label>\
                     					<input id="__containerId__-page877094969-layer-1139388318input" xml:space="default" style="padding-right:9px" type="checkbox" />\
                     					\
                     						\
                     						Thế giới\
                     						\
                     					\
                     				</label>\
                  			\
               </nobr>\
               		\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page877094969-layer-12397493" style="position: absolute; left: 810px; top: 1111px; width: 54px; height: 20px" data-interactive-element-type="default.checkbox" class="checkbox stencil mobile-interaction-potential-trigger " data-stencil-id="12397493" data-review-reference-id="12397493">\
         <div class="stencil-wrapper" style="width: 54px; height: 20px">\
            <div class="" style="font-size:1.17em;" xml:space="preserve" title="">\
               			\
               <nobr>\
                  				<label>\
                     					<input id="__containerId__-page877094969-layer-12397493input" xml:space="default" style="padding-right:9px" type="checkbox" />\
                     					\
                     						\
                     						Khác\
                     						\
                     					\
                     				</label>\
                  			\
               </nobr>\
               		\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page877094969-layer-1253519179" style="position: absolute; left: 810px; top: 1071px; width: 59px; height: 20px" data-interactive-element-type="default.checkbox" class="checkbox stencil mobile-interaction-potential-trigger " data-stencil-id="1253519179" data-review-reference-id="1253519179">\
         <div class="stencil-wrapper" style="width: 59px; height: 20px">\
            <div class="" style="font-size:1.17em;" xml:space="preserve" title="">\
               			\
               <nobr>\
                  				<label>\
                     					<input id="__containerId__-page877094969-layer-1253519179input" xml:space="default" style="padding-right:9px" type="checkbox" />\
                     					\
                     						\
                     						Buffet\
                     						\
                     					\
                     				</label>\
                  			\
               </nobr>\
               		\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page877094969-layer-1453927383" style="position: absolute; left: 900px; top: 1071px; width: 73px; height: 20px" data-interactive-element-type="default.checkbox" class="checkbox stencil mobile-interaction-potential-trigger " data-stencil-id="1453927383" data-review-reference-id="1453927383">\
         <div class="stencil-wrapper" style="width: 73px; height: 20px">\
            <div class="" style="font-size:1.17em;" xml:space="preserve" title="">\
               			\
               <nobr>\
                  				<label>\
                     					<input id="__containerId__-page877094969-layer-1453927383input" xml:space="default" style="padding-right:9px" type="checkbox" />\
                     					\
                     						\
                     						Ăn chay\
                     						\
                     					\
                     				</label>\
                  			\
               </nobr>\
               		\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page877094969-layer-442645548" style="position: absolute; left: 935px; top: 925px; width: 32px; height: 32px" data-interactive-element-type="fonticon.icon" class="icon pidoco-clickable-element stencil mobile-interaction-potential-trigger " data-stencil-id="442645548" data-review-reference-id="442645548">\
         <div class="stencil-wrapper" style="width: 32px; height: 32px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" style="width:32px;height:32px;" title="">\
               <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" class="fill-blue">\
                  <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#icon-glyph-e243"></use>\
               </svg>\
            </div>\
         </div><script type="text/javascript">\
			$(document).ready(function(){\
				rabbit.interaction.manager.registerInteraction(\'__containerId__-page877094969-layer-442645548\', \'2095265489\', \
		{\
		\
			\'button\': \'left\'\
			\
				,\
			\
			\'id\': \'1286523301\'\
			\
				,\
			\
			\'numberOfFinger\': \'1\'\
			\
				,\
			\
			\'type\': \'click\'\
			\
		}\
	,  \
					[\
						\
		{\
		\
			\'delay\': \'0\'\
			\
				,\
			\
			\'id\': \'1826156620\'\
			\
				,\
			\
			\'options\': \'withoutReloadOnly\'\
			\
				,\
			\
			\'target\': \'https://www.google.com/maps/place/H%C3%A0+N%E1%BB%99i\'\
			\
				,\
			\
			\'transition\': \'none\'\
			\
				,\
			\
			\'type\': \'showPage\'\
			\
		}\
	\
					]\
				);\
			});\
		</script></div>\
      <div id="__containerId__-page877094969-layer-text807046136" style="position: absolute; left: 295px; top: 1165px; width: 130px; height: 21px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text807046136" data-review-reference-id="text807046136">\
         <div class="stencil-wrapper" style="width: 130px; height: 21px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.text2"><p class="none" style="font-size: 14px;"><span style="font-size: 18px; color: #658cd9;">Giá trung bình: </span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page877094969-layer-textinput390839782" style="position: absolute; left: 425px; top: 1160px; width: 150px; height: 30px" data-interactive-element-type="default.textinput" class="textinput stencil mobile-interaction-potential-trigger " data-stencil-id="textinput390839782" data-review-reference-id="textinput390839782">\
         <div class="stencil-wrapper" style="width: 150px; height: 30px">\
            <div title=""><input id="__containerId__-page877094969-layer-textinput390839782input" value="" style="width:148px;height:28px;padding: 0px;border-width:1px;" type="text" /></div>\
         </div>\
      </div>\
      <div id="__containerId__-page877094969-layer-text278627905" style="position: absolute; left: 825px; top: 1165px; width: 102px; height: 20px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text278627905" data-review-reference-id="text278627905">\
         <div class="stencil-wrapper" style="width: 102px; height: 20px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline32"><p><span style="font-size: 18px;">VNĐ/Người</span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page877094969-layer-text956159716" style="position: absolute; left: 300px; top: 1225px; width: 107px; height: 20px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text956159716" data-review-reference-id="text956159716">\
         <div class="stencil-wrapper" style="width: 107px; height: 20px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline32"><p><span style="font-size: 18px; color: #658cd9;">Không gian:</span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page877094969-layer-textinput923480844" style="position: absolute; left: 425px; top: 1215px; width: 680px; height: 50px" data-interactive-element-type="default.textinput" class="textinput stencil mobile-interaction-potential-trigger " data-stencil-id="textinput923480844" data-review-reference-id="textinput923480844">\
         <div class="stencil-wrapper" style="width: 680px; height: 50px">\
            <div title=""><textarea id="__containerId__-page877094969-layer-textinput923480844input" rows="" cols="" style="width:678px;height:46px;padding: 0px;border-width:1px;"></textarea></div>\
         </div>\
      </div>\
      <div id="__containerId__-page877094969-layer-1357039538" style="position: absolute; left: 425px; top: 660px; width: 365px; height: 30px" data-interactive-element-type="default.textinput" class="textinput stencil mobile-interaction-potential-trigger " data-stencil-id="1357039538" data-review-reference-id="1357039538">\
         <div class="stencil-wrapper" style="width: 365px; height: 30px">\
            <div title=""><input id="__containerId__-page877094969-layer-1357039538input" value="" style="width:363px;height:28px;padding: 0px;border-width:1px;" type="text" /></div>\
         </div>\
      </div>\
      <div id="__containerId__-page877094969-layer-1690980367" style="position: absolute; left: 295px; top: 1270px; width: 119px; height: 21px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="1690980367" data-review-reference-id="1690980367">\
         <div class="stencil-wrapper" style="width: 119px; height: 21px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline32"><p><span style="font-size: 18px; color: #658cd9;">Món tiêu biểu:</span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page877094969-layer-1688949353" style="position: absolute; left: 325px; top: 1300px; width: 370px; height: 90px" data-interactive-element-type="default.textinput" class="textinput stencil mobile-interaction-potential-trigger " data-stencil-id="1688949353" data-review-reference-id="1688949353">\
         <div class="stencil-wrapper" style="width: 370px; height: 90px">\
            <div title=""><textarea id="__containerId__-page877094969-layer-1688949353input" rows="" cols="" style="width:368px;height:86px;padding: 0px;border-width:1px;"></textarea></div>\
         </div>\
      </div>\
      <div id="__containerId__-page877094969-layer-image57481914" style="position: absolute; left: 300px; top: 1410px; width: 760px; height: 438px" data-interactive-element-type="default.image" class="image stencil mobile-interaction-potential-trigger " data-stencil-id="image57481914" data-review-reference-id="image57481914">\
         <div class="stencil-wrapper" style="width: 760px; height: 438px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" title="">\
               <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" class="image-cropper" style="height: 438px;width:760px;" width="760" height="438" viewBox="0 0 760 438">\
                  <svg:g width="760" height="438">\
                     <svg:svg x="0" y="0" width="760" height="438">\
                        <svg:image width="80" height="60" xlink:href="../repoimages/506426.PNG" preserveAspectRatio="none" transform="scale(9.5,7.3) translate(-0,-0)  "></svg:image>\
                     </svg:svg>\
                  </svg:g>\
               </svg:svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page877094969-layer-1750084529" style="position: absolute; left: 305px; top: 1865px; width: 93px; height: 20px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="1750084529" data-review-reference-id="1750084529">\
         <div class="stencil-wrapper" style="width: 93px; height: 20px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline32"><p class="none" style="font-size: 18px;">Thực đơn </p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page877094969-layer-icon435783622" style="position: absolute; left: 405px; top: 1865px; width: 24px; height: 24px" data-interactive-element-type="fonticon.icon" class="icon stencil mobile-interaction-potential-trigger " data-stencil-id="icon435783622" data-review-reference-id="icon435783622">\
         <div class="stencil-wrapper" style="width: 24px; height: 24px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" style="width:24px;height:24px;" title="">\
               <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" class="fill-blue">\
                  <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#icon-android-e028"></use>\
               </svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page877094969-layer-105616324" style="position: absolute; left: 235px; top: 1895px; width: 990px; height: 33px" data-interactive-element-type="static.line" class="line stencil mobile-interaction-potential-trigger " data-stencil-id="105616324" data-review-reference-id="105616324">\
         <div class="stencil-wrapper" style="width: 990px; height: 33px">\
            <div title="">\
               <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" style="position: absolute; left: -5px; top: -5px; height: 43px;width:1000px;" viewBox="-5 -5 1000 43" width="1000" height="43">\
                  <svg:path d="M 0,16.5 L 990,16.5" marker-start="" marker-end="" style="fill:none; stroke-width:2px;stroke:black;"></svg:path>\
               </svg:svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page877094969-layer-text166268084" style="position: absolute; left: 295px; top: 1930px; width: 263px; height: 37px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text166268084" data-review-reference-id="text166268084">\
         <div class="stencil-wrapper" style="width: 263px; height: 37px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline12"><p class="none" style="font-size: 32px;"><span style="color: #658cd9;">Quản lí đơn hàng </span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page877094969-layer-combobox469175857" style="position: absolute; left: 920px; top: 1930px; width: 150px; height: 30px" data-interactive-element-type="default.combobox" class="combobox stencil mobile-interaction-potential-trigger " data-stencil-id="combobox469175857" data-review-reference-id="combobox469175857">\
         <div class="stencil-wrapper" style="width: 150px; height: 30px">\
            <div title=""><select id="__containerId__-page877094969-layer-combobox469175857select" style="width:150px;height:30px;" title="">\
                  <option title="">Chờ xác nhận</option>\
                  <option title="">Chua thanh toán</option>\
                  <option title="">Đã thanh toán</option>\
                  <option title="">Đã hủy</option></select></div>\
         </div>\
      </div>\
      <div id="__containerId__-page877094969-layer-iphoneButton802438047" style="position: absolute; left: 845px; top: 1865px; width: 88px; height: 30px" data-interactive-element-type="default.iphoneButton" class="iphoneButton stencil mobile-interaction-potential-trigger " data-stencil-id="iphoneButton802438047" data-review-reference-id="iphoneButton802438047">\
         <div class="stencil-wrapper" style="width: 88px; height: 30px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" title="" style="height: 30px;width:88px;">\
               <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" width="88" height="30" viewBox="0 0 88 30">\
                  <svg:a>\
                     <svg:path fill-rule="evenodd" clip-rule="evenodd" fill="#808080" stroke="#666666" d="M5,29.5 l-2,-0.5 -1,-1 -1,-1.5 -0.5,-1.5 0,-20 0.5,-2 1,-1 1,-1 2,-0.5 78,0 1.5,0.5 1.5,1 1,1.5 0.5,1.5 0,20 -0.5,1.5 -1,1.5 -1.5,1 -1.5,0.5 z"></svg:path>\
                     <svg:text x="44" y="15" dy="0.3em" fill="#FFFFFF" style="font-size:1em;stroke-width:0pt;" font-family="\'HelveticaNeue-Bold\'" text-anchor="middle" xml:space="preserve">Lưu thay đổi</svg:text>\
                  </svg:a>\
               </svg:svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page877094969-layer-rect677090278" style="position: absolute; left: 280px; top: 1995px; width: 940px; height: 110px" data-interactive-element-type="static.rect" class="rect stencil mobile-interaction-potential-trigger " data-stencil-id="rect677090278" data-review-reference-id="rect677090278">\
         <div class="stencil-wrapper" style="width: 940px; height: 110px">\
            <div title="">\
               <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" style="height: 110px; width:940px;" width="940" height="110" viewBox="0 0 940 110">\
                  <svg:g width="940" height="110">\
                     <svg:rect x="0" y="0" width="940" height="110" style="stroke-width:1;stroke:black;fill:white;"></svg:rect>\
                  </svg:g>\
               </svg:svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page877094969-layer-image895596860" style="position: absolute; left: 285px; top: 1995px; width: 110px; height: 110px" data-interactive-element-type="default.image" class="image stencil mobile-interaction-potential-trigger " data-stencil-id="image895596860" data-review-reference-id="image895596860">\
         <div class="stencil-wrapper" style="width: 110px; height: 110px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" title="">\
               <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" class="image-cropper" style="height: 110px;width:110px;" width="110" height="110" viewBox="0 0 110 110">\
                  <svg:g width="110" height="110">\
                     <svg:svg x="0" y="0" width="110" height="110">\
                        <svg:image width="256" height="256" xlink:href="../repoimages/506350.png" preserveAspectRatio="none" transform="scale(0.4296875,0.4296875) translate(-0,-0)  "></svg:image>\
                     </svg:svg>\
                  </svg:g>\
               </svg:svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page877094969-layer-text334632003" style="position: absolute; left: 425px; top: 2000px; width: 166px; height: 28px" data-interactive-element-type="default.text2" class="text2 pidoco-clickable-element stencil mobile-interaction-potential-trigger " data-stencil-id="text334632003" data-review-reference-id="text334632003">\
         <div class="stencil-wrapper" style="width: 166px; height: 28px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline12"><p><span style="font-size: 24px; color: #000000;">Nguyễn Hoàng</span></p></span></span></div>\
         </div><script type="text/javascript">\
			$(document).ready(function(){\
				rabbit.interaction.manager.registerInteraction(\'__containerId__-page877094969-layer-text334632003\', \'interaction27284189\', \
		{\
		\
			\'button\': \'left\'\
			\
				,\
			\
			\'id\': \'action902408447\'\
			\
				,\
			\
			\'numberOfFinger\': \'1\'\
			\
				,\
			\
			\'type\': \'click\'\
			\
		}\
	,  \
					[\
						\
		{\
		\
			\'delay\': \'0\'\
			\
				,\
			\
			\'id\': \'reaction727175414\'\
			\
				,\
			\
			\'options\': \'withoutReloadOnly\'\
			\
				,\
			\
			\'target\': \'page497958436\'\
			\
				,\
			\
			\'transition\': \'none\'\
			\
				,\
			\
			\'type\': \'showPage\'\
			\
		}\
	\
					]\
				);\
			});\
		</script></div>\
      <div id="__containerId__-page877094969-layer-text530528228" style="position: absolute; left: 425px; top: 2035px; width: 116px; height: 21px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text530528228" data-review-reference-id="text530528228">\
         <div class="stencil-wrapper" style="width: 116px; height: 21px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline22"><p><span style="font-size: 18px; color: #000000;">01698880299</span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page877094969-layer-text99874521" style="position: absolute; left: 425px; top: 2070px; width: 102px; height: 28px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text99874521" data-review-reference-id="text99874521">\
         <div class="stencil-wrapper" style="width: 102px; height: 28px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline22"><p><span style="font-size: 24px; color: #658cd9;">Mã đơn: </span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page877094969-layer-text359443024" style="position: absolute; left: 520px; top: 2070px; width: 110px; height: 28px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text359443024" data-review-reference-id="text359443024">\
         <div class="stencil-wrapper" style="width: 110px; height: 28px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline22"><p class="none" style="font-size: 24px;">XZ32174 </p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page877094969-layer-icon509341845" style="position: absolute; left: 715px; top: 2005px; width: 32px; height: 32px" data-interactive-element-type="fonticon.icon" class="icon stencil mobile-interaction-potential-trigger " data-stencil-id="icon509341845" data-review-reference-id="icon509341845">\
         <div class="stencil-wrapper" style="width: 32px; height: 32px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" style="width:32px;height:32px;" title="">\
               <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" class="fill-blue">\
                  <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#icon-glyph-e056"></use>\
               </svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page877094969-layer-text627613458" style="position: absolute; left: 765px; top: 2010px; width: 164px; height: 21px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text627613458" data-review-reference-id="text627613458">\
         <div class="stencil-wrapper" style="width: 164px; height: 21px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.text2"><p style="font-size: 14px;"><span style="font-size: 18px;">9h AM - 09/08/2016</span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page877094969-layer-icon17437722" style="position: absolute; left: 715px; top: 2050px; width: 32px; height: 32px" data-interactive-element-type="fonticon.icon" class="icon stencil mobile-interaction-potential-trigger " data-stencil-id="icon17437722" data-review-reference-id="icon17437722">\
         <div class="stencil-wrapper" style="width: 32px; height: 32px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" style="width:32px;height:32px;" title="">\
               <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" class="fill-blue">\
                  <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#icon-glyph-e044"></use>\
               </svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page877094969-layer-text314740325" style="position: absolute; left: 765px; top: 2055px; width: 69px; height: 21px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text314740325" data-review-reference-id="text314740325">\
         <div class="stencil-wrapper" style="width: 69px; height: 21px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline22"><p><span style="font-size: 18px;">5 người</span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page877094969-layer-text488545658" style="position: absolute; left: 815px; top: 1930px; width: 98px; height: 28px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text488545658" data-review-reference-id="text488545658">\
         <div class="stencil-wrapper" style="width: 98px; height: 28px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline12"><p><span style="font-size: 24px; color: #658cd9;">Lọc theo</span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page877094969-layer-icon423266493" style="position: absolute; left: 985px; top: 2005px; width: 32px; height: 32px" data-interactive-element-type="fonticon.icon" class="icon stencil mobile-interaction-potential-trigger " data-stencil-id="icon423266493" data-review-reference-id="icon423266493">\
         <div class="stencil-wrapper" style="width: 32px; height: 32px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" style="width:32px;height:32px;" title="">\
               <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" class="fill-green">\
                  <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#icon-glyph-e203"></use>\
               </svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page877094969-layer-711753760" style="position: absolute; left: 1035px; top: 2005px; width: 150px; height: 30px" data-interactive-element-type="default.combobox" class="combobox stencil mobile-interaction-potential-trigger " data-stencil-id="711753760" data-review-reference-id="711753760">\
         <div class="stencil-wrapper" style="width: 150px; height: 30px">\
            <div title=""><select id="__containerId__-page877094969-layer-711753760select" style="width:150px;height:30px;" title="">\
                  <option title="">Chờ xác nhận</option>\
                  <option title="">Chưa thanh toán</option>\
                  <option title="">Đã thanh toán</option>\
                  <option title="">Đã hủy</option></select></div>\
         </div>\
      </div>\
      <div id="__containerId__-page877094969-layer-iphoneButton295393355" style="position: absolute; left: 1060px; top: 2055px; width: 88px; height: 30px" data-interactive-element-type="default.iphoneButton" class="iphoneButton stencil mobile-interaction-potential-trigger " data-stencil-id="iphoneButton295393355" data-review-reference-id="iphoneButton295393355">\
         <div class="stencil-wrapper" style="width: 88px; height: 30px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" title="" style="height: 30px;width:88px;">\
               <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" width="88" height="30" viewBox="0 0 88 30">\
                  <svg:a>\
                     <svg:path fill-rule="evenodd" clip-rule="evenodd" fill="#808080" stroke="#666666" d="M5,29.5 l-2,-0.5 -1,-1 -1,-1.5 -0.5,-1.5 0,-20 0.5,-2 1,-1 1,-1 2,-0.5 78,0 1.5,0.5 1.5,1 1,1.5 0.5,1.5 0,20 -0.5,1.5 -1,1.5 -1.5,1 -1.5,0.5 z"></svg:path>\
                     <svg:text x="44" y="15" dy="0.3em" fill="#FFFFFF" style="font-size:1em;stroke-width:0pt;" font-family="\'HelveticaNeue-Bold\'" text-anchor="middle" xml:space="preserve">Lưu thay đổi</svg:text>\
                  </svg:a>\
               </svg:svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page877094969-layer-iphoneButton545075569" style="position: absolute; left: 955px; top: 1865px; width: 69px; height: 30px" data-interactive-element-type="default.iphoneButton" class="iphoneButton stencil mobile-interaction-potential-trigger " data-stencil-id="iphoneButton545075569" data-review-reference-id="iphoneButton545075569">\
         <div class="stencil-wrapper" style="width: 69px; height: 30px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" title="" style="height: 30px;width:69px;">\
               <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" width="69" height="30" viewBox="0 0 69 30">\
                  <svg:a>\
                     <svg:path fill-rule="evenodd" clip-rule="evenodd" fill="#808080" stroke="#666666" d="M5,29.5 l-2,-0.5 -1,-1 -1,-1.5 -0.5,-1.5 0,-20 0.5,-2 1,-1 1,-1 2,-0.5 51,0 0.5,0.5 1,0 1,1 1.5,1.5 8.5,11 -7.5,11 -2,2.5 -1.5,1 -0.5,0.5 z"></svg:path>\
                     <svg:text x="31.5" y="15" dy="0.3em" fill="#FFFFFF" style="font-size:1em;stroke-width:0pt;" font-family="\'HelveticaNeue-Bold\'" text-anchor="middle" xml:space="preserve">Xem thử </svg:text>\
                  </svg:a>\
               </svg:svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page877094969-layer-441600098" style="position: absolute; left: 230px; top: 2365px; width: 1025px; height: 33px" data-interactive-element-type="static.line" class="line stencil mobile-interaction-potential-trigger " data-stencil-id="441600098" data-review-reference-id="441600098">\
         <div class="stencil-wrapper" style="width: 1025px; height: 33px">\
            <div title="">\
               <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" style="position: absolute; left: -5px; top: -5px; height: 43px;width:1035px;" viewBox="-5 -5 1035 43" width="1035" height="43">\
                  <svg:path d="M 0,16.5 L 1025,16.5" marker-start="" marker-end="" style="fill:none; stroke-width:2px;stroke:black;"></svg:path>\
               </svg:svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page877094969-layer-text183650169" style="position: absolute; left: 255px; top: 2410px; width: 140px; height: 38px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text183650169" data-review-reference-id="text183650169">\
         <div class="stencil-wrapper" style="width: 140px; height: 38px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline12"><p><span style="font-size: 32px; color: #658cd9;">Thống kê</span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page877094969-layer-text109270929" style="position: absolute; left: 895px; top: 2070px; width: 110px; height: 16px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text109270929" data-review-reference-id="text109270929">\
         <div class="stencil-wrapper" style="width: 110px; height: 16px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.text2"><p class="none" style="font-size: 14px;"><span class="underline" style="color: #658cd9;">Chi tiết đặt hàng</span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page877094969-layer-text117133676" style="position: absolute; left: 245px; top: 2620px; width: 249px; height: 28px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text117133676" data-review-reference-id="text117133676">\
         <div class="stencil-wrapper" style="width: 249px; height: 28px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline12"><p><span style="font-size: 24px; color: #658cd9;">Tổng số đơn hàng: </span><span style="font-size: 24px;">124</span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page877094969-layer-text173144628" style="position: absolute; left: 1100px; top: 2710px; width: 170px; height: 23px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text173144628" data-review-reference-id="text173144628">\
         <div class="stencil-wrapper" style="width: 170px; height: 23px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline32"><p class="none" style="font-size: 18px;"><span style="color: #b1c51a; font-size: 20px;">Đã thanh toán: 67  </span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page877094969-layer-text443182638" style="position: absolute; left: 1100px; top: 2740px; width: 101px; height: 23px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text443182638" data-review-reference-id="text443182638">\
         <div class="stencil-wrapper" style="width: 101px; height: 23px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline32"><p class="none" style="font-size: 18px;"><span style="color: #f2a63f; font-size: 20px;">Đã hủy:33 </span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page877094969-layer-text360191602" style="position: absolute; left: 1100px; top: 2650px; width: 173px; height: 23px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text360191602" data-review-reference-id="text360191602">\
         <div class="stencil-wrapper" style="width: 173px; height: 23px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline32"><p><span style="font-size: 20px; color: #658cd9;">Chờ thanh toán: 10</span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page877094969-layer-text605851011" style="position: absolute; left: 1100px; top: 2680px; width: 183px; height: 23px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text605851011" data-review-reference-id="text605851011">\
         <div class="stencil-wrapper" style="width: 183px; height: 23px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline32"><p class="none" style="font-size: 18px;"><span style="font-size: 20px; color: #d96666;">Chưa xác nhận : 14 </span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page877094969-layer-text808415298" style="position: absolute; left: 240px; top: 2710px; width: 330px; height: 28px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text808415298" data-review-reference-id="text808415298">\
         <div class="stencil-wrapper" style="width: 330px; height: 28px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline32"><p><span style="font-size: 24px; color: #658cd9;">Tổng doanh thu: </span><span style="font-size: 24px;">8.756.000</span><span\
                     style="font-size: 24px; color: #658cd9;"> Vnđ</span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page877094969-layer-icon38206356" style="position: absolute; left: 730px; top: 2550px; width: 360px; height: 360px" data-interactive-element-type="fonticon.icon" class="icon stencil mobile-interaction-potential-trigger " data-stencil-id="icon38206356" data-review-reference-id="icon38206356">\
         <div class="stencil-wrapper" style="width: 360px; height: 360px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" style="width:360px;height:360px;" title="">\
               <svg xmlns="http://www.w3.org/2000/svg" width="360" height="360" class="fill-black">\
                  <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#icon-glyph-e043"></use>\
               </svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page877094969-layer-text156510226" style="position: absolute; left: 415px; top: 965px; width: 113px; height: 20px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text156510226" data-review-reference-id="text156510226">\
         <div class="stencil-wrapper" style="width: 113px; height: 20px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.link2"><p style="font-size: 14px;"><span class="underline" style="font-size: 18px; color: #658cd9;">Thêm địa chỉ</span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page877094969-layer-chart304927956" style="position: absolute; left: 265px; top: 2990px; width: 885px; height: 300px" data-interactive-element-type="static.chart" class="chart stencil mobile-interaction-potential-trigger " data-stencil-id="chart304927956" data-review-reference-id="chart304927956">\
         <div class="stencil-wrapper" style="width: 885px; height: 300px">\
            <div title="">\
               <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" style="height: 300px;width:885px;" viewBox="0 0 885 300" width="885" height="300">\
                  <svg:g width="885" height="300">\
                     <svg:g xmlns:xi="http://www.w3.org/2001/XInclude" transform="scale(4.916666666666667, 2)">\
                        <svg:rect x="0" y="0" width="180" height="150" style="fill:white;stroke:none;"></svg:rect>\
                        <svg:g name="line" style="fill:none;stroke:black;stroke-width:1px;">\
                           <svg:path d="M 9,3 L 9,140 L 168,140 L 176,140"></svg:path>\
                           <svg:path d="M 167,135 L 177,140 L 167,145"></svg:path>\
                           <svg:path d="M 4,13 L 9,3 L 14,13"></svg:path>\
                           <svg:path d="M 9,140 L 30,112 L 46,98 L 54,106 L 68,89 L 74,82 L 76,74 L 82,67 L 92,96 L 97,76 L 106,66 L 111,50 L 122,37 L 127,45 L 129,51 L 139,51 L 151,29 L 159,26 L 161,16 L 166,12"></svg:path>\
                           <svg:path d="M 10,140 L 18,107 L 29,91 L 34,73 L 44,80 L 51,55 L 62,52 L 74,34 L 86,51 L 99,43 L 111,59 L 121,70 L 128,98 L 139,119 L 147,103 L 154,125 L 165,136"></svg:path>\
                        </svg:g>\
                     </svg:g>\
                  </svg:g>\
               </svg:svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page877094969-layer-rating524234324" style="position: absolute; left: 260px; top: 2465px; width: 150px; height: 30px" data-interactive-element-type="default.rating" class="rating stencil mobile-interaction-potential-trigger " data-stencil-id="rating524234324" data-review-reference-id="rating524234324">\
         <div class="stencil-wrapper" style="width: 150px; height: 30px">\
            <div style="width:150px; height:30px" onmouseout="if(rabbit.stencils.rating.checkMouseOutDiv(\'__containerId__-page877094969-layer-rating524234324\', event)) rabbit.facade.raiseEvent(rabbit.events.ratingMouseOut, \'__containerId__-page877094969-layer-rating524234324\');" title=""><img id="__containerId__-page877094969-layer-rating524234324-1" src="../resources/icons/rating_black.png" width="30" height="30" style="position: absolute; left: 0px; cursor: pointer;" onmouseover="rabbit.facade.raiseEvent(rabbit.events.ratingMouseOver, \'__containerId__-page877094969-layer-rating524234324\', \'1\');" onclick="rabbit.facade.raiseEvent(rabbit.events.ratingResultChangedEvent, \'__containerId__-page877094969-layer-rating524234324\', \'1\');" /><img id="__containerId__-page877094969-layer-rating524234324-2" src="../resources/icons/rating_black.png" width="30" height="30" style="position: absolute; left: 30px; cursor: pointer;" onmouseover="rabbit.facade.raiseEvent(rabbit.events.ratingMouseOver, \'__containerId__-page877094969-layer-rating524234324\', \'2\');" onclick="rabbit.facade.raiseEvent(rabbit.events.ratingResultChangedEvent, \'__containerId__-page877094969-layer-rating524234324\', \'2\');" /><img id="__containerId__-page877094969-layer-rating524234324-3" src="../resources/icons/rating_black.png" width="30" height="30" style="position: absolute; left: 60px; cursor: pointer;" onmouseover="rabbit.facade.raiseEvent(rabbit.events.ratingMouseOver, \'__containerId__-page877094969-layer-rating524234324\', \'3\');" onclick="rabbit.facade.raiseEvent(rabbit.events.ratingResultChangedEvent, \'__containerId__-page877094969-layer-rating524234324\', \'3\');" /><img id="__containerId__-page877094969-layer-rating524234324-4" src="../resources/icons/rating_black.png" width="30" height="30" style="position: absolute; left: 90px; cursor: pointer;" onmouseover="rabbit.facade.raiseEvent(rabbit.events.ratingMouseOver, \'__containerId__-page877094969-layer-rating524234324\', \'4\');" onclick="rabbit.facade.raiseEvent(rabbit.events.ratingResultChangedEvent, \'__containerId__-page877094969-layer-rating524234324\', \'4\');" /><img id="__containerId__-page877094969-layer-rating524234324-5" src="../resources/icons/rating_white.png" width="30" height="30" style="position: absolute; left: 120px; cursor: pointer;" onmouseover="rabbit.facade.raiseEvent(rabbit.events.ratingMouseOver, \'__containerId__-page877094969-layer-rating524234324\', \'5\');" onclick="rabbit.facade.raiseEvent(rabbit.events.ratingResultChangedEvent, \'__containerId__-page877094969-layer-rating524234324\', \'5\');" /></div><script type="text/javascript">\
			rabbit.stencils.rating.onLoad("__containerId__-page877094969-layer-rating524234324", "4");\
		</script></div>\
      </div>\
      <div id="__containerId__-page877094969-layer-text235970792" style="position: absolute; left: 675px; top: 2465px; width: 142px; height: 28px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text235970792" data-review-reference-id="text235970792">\
         <div class="stencil-wrapper" style="width: 142px; height: 28px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.link2"><p style="font-size: 14px;"><span class="underline" style="font-size: 24px; color: #658cd9;">12 Nhận xép</span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page877094969-layer-text716186848" style="position: absolute; left: 560px; top: 3290px; width: 361px; height: 37px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text716186848" data-review-reference-id="text716186848">\
         <div class="stencil-wrapper" style="width: 361px; height: 37px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline12"><p class="none" style="font-size: 32px;"><span style="color: #658cd9;">Đơn hàng theo thời gian </span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page877094969-layer-chart653246281" style="position: absolute; left: 915px; top: 3080px; width: 180px; height: 150px" data-interactive-element-type="static.chart" class="chart stencil mobile-interaction-potential-trigger " data-stencil-id="chart653246281" data-review-reference-id="chart653246281">\
         <div class="stencil-wrapper" style="width: 180px; height: 150px">\
            <div title="">\
               <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" style="height: 150px;width:180px;" viewBox="0 0 180 150" width="180" height="150">\
                  <svg:g width="180" height="150">\
                     <svg:g xmlns:xi="http://www.w3.org/2001/XInclude" transform="scale(1, 1)">\
                        <svg:rect x="0" y="0" width="180" height="150" style="fill:white;stroke:none;"></svg:rect>\
                        <svg:g name="bar" style="stroke:black;fill:none;stroke-width:1px;">\
                           <svg:path d="M 9,3 L 9,140 L 177,140"></svg:path>\
                           <svg:path d="M 168,135 L 178,140 L 168,145"></svg:path>\
                           <svg:path d="M 4,13 L 9,3 L 14,13"></svg:path>\
                           <svg:rect width="19" height="77" x="19" y="63"></svg:rect>\
                           <svg:rect width="19" height="93" x="47" y="47"></svg:rect>\
                           <svg:rect width="19" height="84" x="76" y="56"></svg:rect>\
                           <svg:rect width="19" height="51" x="104" y="89"></svg:rect>\
                           <svg:rect width="19" height="109" x="133" y="31"></svg:rect>\
                        </svg:g>\
                     </svg:g>\
                  </svg:g>\
               </svg:svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page877094969-layer-629968191" style="position: absolute; left: 295px; top: 1015px; width: 133px; height: 20px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="629968191" data-review-reference-id="629968191">\
         <div class="stencil-wrapper" style="width: 133px; height: 20px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline32"><p class="none" style="font-size: 18px;"><span style="color: #658cd9;">SĐT nhà hàng:</span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page877094969-layer-1183919470" style="position: absolute; left: 415px; top: 1010px; width: 220px; height: 30px" data-interactive-element-type="default.textinput" class="textinput stencil mobile-interaction-potential-trigger " data-stencil-id="1183919470" data-review-reference-id="1183919470">\
         <div class="stencil-wrapper" style="width: 220px; height: 30px">\
            <div title=""><input id="__containerId__-page877094969-layer-1183919470input" value="" style="width:218px;height:28px;padding: 0px;border-width:1px;" type="text" /></div>\
         </div>\
      </div>\
      <div id="__containerId__-page877094969-layer-474477431" style="position: absolute; left: 650px; top: 1015px; width: 83px; height: 20px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="474477431" data-review-reference-id="474477431">\
         <div class="stencil-wrapper" style="width: 83px; height: 20px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.link2"><p style="font-size: 14px;"><span class="underline" style="font-size: 18px; color: #658cd9;">Thêm sđt</span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page877094969-layer-209533827" style="position: absolute; left: 740px; top: 1270px; width: 115px; height: 20px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="209533827" data-review-reference-id="209533827">\
         <div class="stencil-wrapper" style="width: 115px; height: 20px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline32"><p><span style="font-size: 18px; color: #658cd9;">Khuyến mại :</span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page877094969-layer-textinput579084838" style="position: absolute; left: 760px; top: 1300px; width: 360px; height: 90px" data-interactive-element-type="default.textinput" class="textinput stencil mobile-interaction-potential-trigger " data-stencil-id="textinput579084838" data-review-reference-id="textinput579084838">\
         <div class="stencil-wrapper" style="width: 360px; height: 90px">\
            <div title=""><textarea id="__containerId__-page877094969-layer-textinput579084838input" rows="" cols="" style="width:358px;height:86px;padding: 0px;border-width:1px;"></textarea></div>\
         </div>\
      </div>\
      <div id="__containerId__-page877094969-layer-2102636194" style="position: absolute; left: 630px; top: 1160px; width: 150px; height: 30px" data-interactive-element-type="default.textinput" class="textinput stencil mobile-interaction-potential-trigger " data-stencil-id="2102636194" data-review-reference-id="2102636194">\
         <div class="stencil-wrapper" style="width: 150px; height: 30px">\
            <div title=""><input id="__containerId__-page877094969-layer-2102636194input" value="" style="width:148px;height:28px;padding: 0px;border-width:1px;" type="text" /></div>\
         </div>\
      </div>\
      <div id="__containerId__-page877094969-layer-icon11954582" style="position: absolute; left: 590px; top: 1160px; width: 32px; height: 32px" data-interactive-element-type="fonticon.icon" class="icon stencil mobile-interaction-potential-trigger " data-stencil-id="icon11954582" data-review-reference-id="icon11954582">\
         <div class="stencil-wrapper" style="width: 32px; height: 32px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" style="width:32px;height:32px;" title="">\
               <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" class="fill-black">\
                  <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#icon-glyph-e212"></use>\
               </svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page877094969-layer-280951805" style="position: absolute; left: 290px; top: 725px; width: 111px; height: 20px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="280951805" data-review-reference-id="280951805">\
         <div class="stencil-wrapper" style="width: 111px; height: 20px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline32"><p><span style="font-size: 18px; color: #658cd9;">Giờ mở cửa:</span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page877094969-layer-textinput796526445" style="position: absolute; left: 425px; top: 720px; width: 280px; height: 30px" data-interactive-element-type="default.textinput" class="textinput stencil mobile-interaction-potential-trigger " data-stencil-id="textinput796526445" data-review-reference-id="textinput796526445">\
         <div class="stencil-wrapper" style="width: 280px; height: 30px">\
            <div title=""><input id="__containerId__-page877094969-layer-textinput796526445input" value="" style="width:278px;height:28px;padding: 0px;border-width:1px;" type="text" /></div>\
         </div>\
      </div>\
      <div id="__containerId__-page877094969-layer-400717583" style="position: absolute; left: 305px; top: 425px; width: 74px; height: 20px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="400717583" data-review-reference-id="400717583">\
         <div class="stencil-wrapper" style="width: 74px; height: 20px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline32"><p class="none" style="font-size: 18px;">Địa chỉ: </p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page877094969-layer-361464711" style="position: absolute; left: 465px; top: 420px; width: 275px; height: 30px" data-interactive-element-type="default.textinput" class="textinput stencil mobile-interaction-potential-trigger " data-stencil-id="361464711" data-review-reference-id="361464711">\
         <div class="stencil-wrapper" style="width: 275px; height: 30px">\
            <div title=""><input id="__containerId__-page877094969-layer-361464711input" value="" style="width:273px;height:28px;padding: 0px;border-width:1px;" type="text" /></div>\
         </div>\
      </div>\
      <div id="__containerId__-page877094969-layer-1243270990" style="position: absolute; left: 60px; top: 490px; width: 161px; height: 28px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="1243270990" data-review-reference-id="1243270990">\
         <div class="stencil-wrapper" style="width: 161px; height: 28px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline22"><p class="none" style="font-size: 24px;"><span style="font-size: 20px; color: #658cd9;">Quản lí mật khẩu</span></p>\
                     <p class="none" style="font-size: 24px;"> </p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page877094969-layer-icon635162954" style="position: absolute; left: 20px; top: 490px; width: 32px; height: 32px" data-interactive-element-type="fonticon.icon" class="icon stencil mobile-interaction-potential-trigger " data-stencil-id="icon635162954" data-review-reference-id="icon635162954">\
         <div class="stencil-wrapper" style="width: 32px; height: 32px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" style="width:32px;height:32px;" title="">\
               <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" class="fill-blue">\
                  <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#icon-glyph-e204"></use>\
               </svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page877094969-layer-datepicker846637727" style="position: absolute; left: 330px; top: 2545px; width: 150px; height: 30px" data-interactive-element-type="default.datepicker" class="datepicker stencil mobile-interaction-potential-trigger " data-stencil-id="datepicker846637727" data-review-reference-id="datepicker846637727">\
         <div class="stencil-wrapper" style="width: 150px; height: 30px">\
            <div>\
               <div style="position:absolute; white-space: nowrap;" title=""><input type="text" style="width:114px; height:28px;padding: 0px;border-width:1px;" id="__containerId__-page877094969-layer-datepicker846637727_input" /><button type="button" style="width:34px; height:28px; vertical-align: top; padding: 0px;border-width:1px;" id="__containerId__-page877094969-layer-datepicker846637727_button"><img src="../resources/icons/date.png" /></button></div>\
               <div id="__containerId__-page877094969-layer-datepicker846637727_ov" class="yui-skin-sam" style="position: absolute; width: 16em;visibility:visible;">\
                  <div id="__containerId__-page877094969-layer-datepicker846637727_cal"></div>\
               </div><script type="text/javascript">\
				rabbit.stencils.datepicker.setupDatepicker("__containerId__-page877094969-layer-datepicker846637727");\
			</script></div>\
         </div>\
      </div>\
      <div id="__containerId__-page877094969-layer-datepicker785479217" style="position: absolute; left: 545px; top: 2545px; width: 150px; height: 30px" data-interactive-element-type="default.datepicker" class="datepicker stencil mobile-interaction-potential-trigger " data-stencil-id="datepicker785479217" data-review-reference-id="datepicker785479217">\
         <div class="stencil-wrapper" style="width: 150px; height: 30px">\
            <div>\
               <div style="position:absolute; white-space: nowrap;" title=""><input type="text" style="width:114px; height:28px;padding: 0px;border-width:1px;" id="__containerId__-page877094969-layer-datepicker785479217_input" /><button type="button" style="width:34px; height:28px; vertical-align: top; padding: 0px;border-width:1px;" id="__containerId__-page877094969-layer-datepicker785479217_button"><img src="../resources/icons/date.png" /></button></div>\
               <div id="__containerId__-page877094969-layer-datepicker785479217_ov" class="yui-skin-sam" style="position: absolute; width: 16em;visibility:visible;">\
                  <div id="__containerId__-page877094969-layer-datepicker785479217_cal"></div>\
               </div><script type="text/javascript">\
				rabbit.stencils.datepicker.setupDatepicker("__containerId__-page877094969-layer-datepicker785479217");\
			</script></div>\
         </div>\
      </div>\
      <div id="__containerId__-page877094969-layer-text940926104" style="position: absolute; left: 270px; top: 2550px; width: 31px; height: 23px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text940926104" data-review-reference-id="text940926104">\
         <div class="stencil-wrapper" style="width: 31px; height: 23px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline22"><p><span style="font-size: 20px; color: #658cd9;">Từ</span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page877094969-layer-text573669561" style="position: absolute; left: 495px; top: 2550px; width: 46px; height: 20px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text573669561" data-review-reference-id="text573669561">\
         <div class="stencil-wrapper" style="width: 46px; height: 20px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline32"><p class="none" style="font-size: 18px;"><span style="color: #658cd9;">Đến </span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page877094969-layer-checkbox899510893" style="position: absolute; left: 755px; top: 2555px; width: 61px; height: 20px" data-interactive-element-type="default.checkbox" class="checkbox stencil mobile-interaction-potential-trigger " data-stencil-id="checkbox899510893" data-review-reference-id="checkbox899510893">\
         <div class="stencil-wrapper" style="width: 61px; height: 20px">\
            <div class="" style="font-size:1.17em;" xml:space="preserve" title="">\
               			\
               <nobr>\
                  				<label>\
                     					<input id="__containerId__-page877094969-layer-checkbox899510893input" xml:space="default" style="padding-right:9px" type="checkbox" checked="true" />\
                     					\
                     						\
                     						Tất cả\
                     						\
                     					\
                     				</label>\
                  			\
               </nobr>\
               		\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page877094969-layer-245814346" style="position: absolute; left: 475px; top: 2465px; width: 131px; height: 28px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="245814346" data-review-reference-id="245814346">\
         <div class="stencil-wrapper" style="width: 131px; height: 28px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.link2"><p style="font-size: 14px;"><span class="underline" style="font-size: 24px; color: #658cd9;">24 đánh giá</span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page877094969-layer-text195442085" style="position: absolute; left: 295px; top: 605px; width: 133px; height: 47px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text195442085" data-review-reference-id="text195442085">\
         <div class="stencil-wrapper" style="width: 133px; height: 47px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.text2"><p class="none" style="font-size: 14px;"><span style="font-size: 20px;">Post Template</span><br /><span style="font-size:\
                     20px;"> </span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page877094969-layer-arrow10231804" style="position: absolute; left: 250px; top: 3355px; width: 1055px; height: 33px" data-interactive-element-type="static.line" class="line stencil mobile-interaction-potential-trigger " data-stencil-id="arrow10231804" data-review-reference-id="arrow10231804">\
         <div class="stencil-wrapper" style="width: 1055px; height: 33px">\
            <div title="">\
               <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" style="position: absolute; left: -5px; top: -5px; height: 43px;width:1065px;" viewBox="-5 -5 1065 43" width="1065" height="43">\
                  <svg:path d="M 0,16.5 L 1055,16.5" marker-start="" marker-end="" style="fill:none; stroke-width:2px;stroke:black;"></svg:path>\
               </svg:svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page877094969-layer-737506582" style="position: absolute; left: 20px; top: 380px; width: 32px; height: 32px" data-interactive-element-type="fonticon.icon" class="icon stencil mobile-interaction-potential-trigger " data-stencil-id="737506582" data-review-reference-id="737506582">\
         <div class="stencil-wrapper" style="width: 32px; height: 32px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" style="width:32px;height:32px;" title="">\
               <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" class="fill-blue">\
                  <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#icon-glyph-e236"></use>\
               </svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page877094969-layer-1595050584" style="position: absolute; left: 60px; top: 385px; width: 98px; height: 27px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="1595050584" data-review-reference-id="1595050584">\
         <div class="stencil-wrapper" style="width: 98px; height: 27px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline22"><p class="none" style="font-size: 24px;"><span style="color: #658cd9; font-size: 20px;">Lập Menu</span></p>\
                     <p class="none" style="font-size: 24px;"> </p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page877094969-layer-text437894913" style="position: absolute; left: 265px; top: 3400px; width: 158px; height: 38px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text437894913" data-review-reference-id="text437894913">\
         <div class="stencil-wrapper" style="width: 158px; height: 38px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline22"><p><span style="font-size: 32px; color: #658cd9;">Lập Menu </span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page877094969-layer-text968665467" style="position: absolute; left: 260px; top: 3475px; width: 101px; height: 27px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text968665467" data-review-reference-id="text968665467">\
         <div class="stencil-wrapper" style="width: 101px; height: 27px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline22"><p><span style="font-size: 24px;">Tên món</span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page877094969-layer-text429818731" style="position: absolute; left: 450px; top: 3475px; width: 108px; height: 27px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text429818731" data-review-reference-id="text429818731">\
         <div class="stencil-wrapper" style="width: 108px; height: 27px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline22"><p><span style="font-size: 24px;">Phân loại</span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page877094969-layer-text384356085" style="position: absolute; left: 640px; top: 3475px; width: 156px; height: 27px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text384356085" data-review-reference-id="text384356085">\
         <div class="stencil-wrapper" style="width: 156px; height: 27px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline22"><p><span style="font-size: 24px;">Giá (.000/vnđ)</span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page877094969-layer-text653902833" style="position: absolute; left: 870px; top: 3475px; width: 166px; height: 28px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text653902833" data-review-reference-id="text653902833">\
         <div class="stencil-wrapper" style="width: 166px; height: 28px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline22"><p><span style="font-size: 24px;">Thông tin thêm</span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page877094969-layer-text532729675" style="position: absolute; left: 1145px; top: 3475px; width: 161px; height: 27px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text532729675" data-review-reference-id="text532729675">\
         <div class="stencil-wrapper" style="width: 161px; height: 27px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline22"><p class="none" style="font-size: 24px;">Ảnh minh họa </p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page877094969-layer-textinput656114953" style="position: absolute; left: 245px; top: 3525px; width: 150px; height: 30px" data-interactive-element-type="default.textinput" class="textinput stencil mobile-interaction-potential-trigger " data-stencil-id="textinput656114953" data-review-reference-id="textinput656114953">\
         <div class="stencil-wrapper" style="width: 150px; height: 30px">\
            <div title=""><input id="__containerId__-page877094969-layer-textinput656114953input" value="" style="width:148px;height:28px;padding: 0px;border-width:1px;" type="text" /></div>\
         </div>\
      </div>\
      <div id="__containerId__-page877094969-layer-textinput23076400" style="position: absolute; left: 645px; top: 3525px; width: 150px; height: 30px" data-interactive-element-type="default.textinput" class="textinput stencil mobile-interaction-potential-trigger " data-stencil-id="textinput23076400" data-review-reference-id="textinput23076400">\
         <div class="stencil-wrapper" style="width: 150px; height: 30px">\
            <div title=""><input id="__containerId__-page877094969-layer-textinput23076400input" value="" style="width:148px;height:28px;padding: 0px;border-width:1px;" type="text" /></div>\
         </div>\
      </div>\
      <div id="__containerId__-page877094969-layer-combobox132242293" style="position: absolute; left: 445px; top: 3525px; width: 150px; height: 30px" data-interactive-element-type="default.combobox" class="combobox stencil mobile-interaction-potential-trigger " data-stencil-id="combobox132242293" data-review-reference-id="combobox132242293">\
         <div class="stencil-wrapper" style="width: 150px; height: 30px">\
            <div title=""><select id="__containerId__-page877094969-layer-combobox132242293select" style="width:150px;height:30px;" title="">\
                  <option title="">Khai vị</option>\
                  <option title="">Món chính</option>\
                  <option title="">Tráng miệng</option>\
                  <option title="">Đồ uống</option>\
                  <option title="">Khác</option>\
                  <option title=""></option></select></div>\
         </div>\
      </div>\
      <div id="__containerId__-page877094969-layer-text605044483" style="position: absolute; left: 815px; top: 3525px; width: 325px; height: 65px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text605044483" data-review-reference-id="text605044483">\
         <div class="stencil-wrapper" style="width: 325px; height: 65px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textblock2"><p style="font-size: 14px;">Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt\
                     ut labore et dolore magna aliquyam erat, sed diam voluptua. At t</p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page877094969-layer-image658241962" style="position: absolute; left: 1160px; top: 3505px; width: 130px; height: 130px" data-interactive-element-type="default.image" class="image stencil mobile-interaction-potential-trigger " data-stencil-id="image658241962" data-review-reference-id="image658241962">\
         <div class="stencil-wrapper" style="width: 130px; height: 130px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" title="">\
               <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" class="image-cropper" style="height: 130px;width:130px;" width="130" height="130" viewBox="0 0 130 130">\
                  <svg:g width="130" height="130">\
                     <svg:svg x="0" y="0" width="130" height="130">\
                        <svg:image width="432" height="253" xlink:href="../repoimages/506340.PNG" preserveAspectRatio="none" transform="scale(0.30092592592592593,0.5138339920948617) translate(-0,-0)  "></svg:image>\
                     </svg:svg>\
                  </svg:g>\
               </svg:svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page877094969-layer-icon771960798" style="position: absolute; left: 1255px; top: 3505px; width: 32px; height: 32px" data-interactive-element-type="fonticon.icon" class="icon stencil mobile-interaction-potential-trigger " data-stencil-id="icon771960798" data-review-reference-id="icon771960798">\
         <div class="stencil-wrapper" style="width: 32px; height: 32px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" style="width:32px;height:32px;" title="">\
               <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" class="fill-black">\
                  <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#icon-glyph-e012"></use>\
               </svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page877094969-layer-icon152281576" style="position: absolute; left: 245px; top: 3650px; width: 64px; height: 64px" data-interactive-element-type="fonticon.icon" class="icon stencil mobile-interaction-potential-trigger " data-stencil-id="icon152281576" data-review-reference-id="icon152281576">\
         <div class="stencil-wrapper" style="width: 64px; height: 64px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" style="width:64px;height:64px;" title="">\
               <svg xmlns="http://www.w3.org/2000/svg" width="64" height="64" class="fill-black">\
                  <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#icon-glyph-e191"></use>\
               </svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page877094969-layer-switch794253660" style="position: absolute; left: 1300px; top: 3530px; width: 94px; height: 27px" data-interactive-element-type="default.iphoneSwitch" class="iphoneSwitch stencil mobile-interaction-potential-trigger " data-stencil-id="switch794253660" data-review-reference-id="switch794253660">\
         <div class="stencil-wrapper" style="width: 94px; height: 27px">\
            <div class="switch-selected" title="" style="height: 27px;width:94px;cursor:pointer;">\
               <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" width="94" height="27" viewBox="0 0 94 27">\
                  <g xmlns="http://www.w3.org/2000/svg" stroke="none" onclick="rabbit.facade.raiseEvent(rabbit.events.iphoneSwitchClicked, \'__containerId__-page877094969-layer-switch794253660\');return true;">\
                     <g class="switch-on">\
                        <g>\
                           <g>\
                              <path fill-rule="evenodd" clip-rule="evenodd" fill="#808080" stroke="#666666" d="M4,26.5c-1.9,0-3.5-1.6-3.5-3.5V4c0-1.9,1.6-3.5,3.5-3.5h60c1.9,0,3.5,1.6,3.5,3.5v19c0,1.9-1.6,3.5-3.5,3.5H4z"></path>\
                           </g>\
                           <g>\
                              <path fill-rule="evenodd" clip-rule="evenodd" fill="#F2F2F2" stroke="#666666" d="M59,26.5c-1.9,0-3.5-1.6-3.5-3.5V4c0-1.9,1.6-3.5,3.5-3.5h31c1.9,0,3.5,1.6,3.5,3.5v19c0,1.9-1.6,3.5-3.5,3.5H59z"></path>\
                           </g>\
                        </g>\
                        <text transform="matrix(1 0 0 1 14.1494 19.0771)" stroke="none" fill="#FFFFFF" font-family="HelveticaNeue-Bold" style="font-size:17px;">ON</text>\
                     </g>\
                     <g class="switch-off">\
                        <g>\
                           <path fill-rule="evenodd" clip-rule="evenodd" fill="#F2F2F2" stroke="#666666" d="M4,26.5c-1.9,0-3.5-1.6-3.5-3.5V4c0-1.9,1.6-3.5,3.5-3.5h86c1.9,0,3.5,1.6,3.5,3.5v19c0,1.9-1.6,3.5-3.5,3.5H4z"></path>\
                        </g>\
                        <g>\
                           <path fill-rule="evenodd" clip-rule="evenodd" fill="#F2F2F2" stroke="#666666" d="M4,26.5c-1.9,0-3.5-1.6-3.5-3.5V4c0-1.9,1.6-3.5,3.5-3.5h31c1.9,0,3.5,1.6,3.5,3.5v19c0,1.9-1.6,3.5-3.5,3.5H4z"></path>\
                        </g>\
                        <text transform="matrix(1 0 0 1 48.54 19.4692)" stroke="none" fill="#808080" font-family="HelveticaNeue-Bold" style="font-size:17px;">OFF</text>\
                     </g>\
                  </g>\
               </svg:svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page877094969-layer-text722051159" style="position: absolute; left: 315px; top: 3670px; width: 92px; height: 21px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text722051159" data-review-reference-id="text722051159">\
         <div class="stencil-wrapper" style="width: 92px; height: 21px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline32"><p><span style="font-size: 18px;">Thêm món</span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page877094969-layer-combobox469377898" style="position: absolute; left: 865px; top: 3400px; width: 150px; height: 30px" data-interactive-element-type="default.combobox" class="combobox stencil mobile-interaction-potential-trigger " data-stencil-id="combobox469377898" data-review-reference-id="combobox469377898">\
         <div class="stencil-wrapper" style="width: 150px; height: 30px">\
            <div title=""><select id="__containerId__-page877094969-layer-combobox469377898select" style="width:150px;height:30px;" title="">\
                  <option title="">First entry</option>\
                  <option title="">Second entry</option>\
                  <option title="">Third entry</option></select></div>\
         </div>\
      </div>\
      <div id="__containerId__-page877094969-layer-textinput281150857" style="position: absolute; left: 695px; top: 3400px; width: 150px; height: 30px" data-interactive-element-type="default.textinput" class="textinput stencil mobile-interaction-potential-trigger " data-stencil-id="textinput281150857" data-review-reference-id="textinput281150857">\
         <div class="stencil-wrapper" style="width: 150px; height: 30px">\
            <div title=""><input id="__containerId__-page877094969-layer-textinput281150857input" value="" style="width:148px;height:28px;padding: 0px;border-width:1px;" type="text" /></div>\
         </div>\
      </div>\
      <div id="__containerId__-page877094969-layer-text457157229" style="position: absolute; left: 595px; top: 3405px; width: 110px; height: 21px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text457157229" data-review-reference-id="text457157229">\
         <div class="stencil-wrapper" style="width: 110px; height: 21px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline32"><p class="none" style="font-size: 18px;"><span style="color: #658cd9;">Lọc theo tên </span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page877094969-layer-iphoneButton840415319" style="position: absolute; left: 1040px; top: 3400px; width: 81px; height: 30px" data-interactive-element-type="default.iphoneButton" class="iphoneButton stencil mobile-interaction-potential-trigger " data-stencil-id="iphoneButton840415319" data-review-reference-id="iphoneButton840415319">\
         <div class="stencil-wrapper" style="width: 81px; height: 30px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" title="" style="height: 30px;width:81px;">\
               <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" width="81" height="30" viewBox="0 0 81 30">\
                  <svg:a>\
                     <svg:path fill-rule="evenodd" clip-rule="evenodd" fill="#808080" stroke="#666666" d="M5,29.5 l-2,-0.5 -1,-1 -1,-1.5 -0.5,-1.5 0,-20 0.5,-2 1,-1 1,-1 2,-0.5 63,0 0.5,0.5 1,0 1,1 1.5,1.5 8.5,11 -7.5,11 -2,2.5 -1.5,1 -0.5,0.5 z"></svg:path>\
                     <svg:text x="37.5" y="15" dy="0.3em" fill="#FFFFFF" style="font-size:1em;stroke-width:0pt;" font-family="\'HelveticaNeue-Bold\'" text-anchor="middle" xml:space="preserve">Bắt đầu lọc</svg:text>\
                  </svg:a>\
               </svg:svg>\
            </div>\
         </div>\
      </div>\
   </div>\
</div>');