rabbit.data.layerStore.addLayerFromHtml('<div xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:fn="http://www.w3.org/2005/xpath-functions" id="result">\
   <div xmlns:xs="http://www.w3.org/2001/XMLSchema" xmlns="http://www.w3.org/1999/xhtml" id="__containerId__page497958436-layer" class="layer" name="__containerId__pageLayer" data-layer-id="page497958436" data-layer-type="pageLayer" style="position:absolute;left:0px;top:0px;">\
      <div id="__containerId__-page497958436-layer-image513716695" style="position: absolute; left: 0px; top: 0px; width: 1366px; height: 1300px" data-interactive-element-type="default.image" class="image stencil mobile-interaction-potential-trigger " data-stencil-id="image513716695" data-review-reference-id="image513716695">\
         <div class="stencil-wrapper" style="width: 1366px; height: 1300px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" title="">\
               <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" class="image-cropper" style="height: 1300px;width:1366px;" width="1366" height="1300" viewBox="0 0 1366 1300">\
                  <svg:g width="1366" height="1300">\
                     <svg:svg x="0" y="0" width="1366" height="1300">\
                        <svg:image width="432" height="253" xlink:href="../repoimages/506332.PNG" preserveAspectRatio="none" transform="scale(3.162037037037037,5.138339920948616) translate(-0,-0)  "></svg:image>\
                     </svg:svg>\
                  </svg:g>\
               </svg:svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page497958436-layer-image296305840" style="position: absolute; left: 0px; top: 35px; width: 1366px; height: 1300px" data-interactive-element-type="default.image" class="image stencil mobile-interaction-potential-trigger " data-stencil-id="image296305840" data-review-reference-id="image296305840">\
         <div class="stencil-wrapper" style="width: 1366px; height: 1300px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" title="">\
               <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" class="image-cropper" style="height: 1300px;width:1366px;" width="1366" height="1300" viewBox="0 0 1366 1300">\
                  <svg:g width="1366" height="1300">\
                     <svg:svg x="0" y="0" width="1366" height="1300">\
                        <svg:image width="432" height="253" xlink:href="../repoimages/506332.PNG" preserveAspectRatio="none" transform="scale(3.162037037037037,5.138339920948616) translate(-0,-0)  "></svg:image>\
                     </svg:svg>\
                  </svg:g>\
               </svg:svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page497958436-layer-image598229695" style="position: absolute; left: 45px; top: 5px; width: 150px; height: 150px" data-interactive-element-type="default.image" class="image stencil mobile-interaction-potential-trigger " data-stencil-id="image598229695" data-review-reference-id="image598229695">\
         <div class="stencil-wrapper" style="width: 150px; height: 150px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" title="">\
               <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" class="image-cropper" style="height: 150px;width:150px;" width="150" height="150" viewBox="0 0 150 150">\
                  <svg:g width="150" height="150">\
                     <svg:svg x="0" y="0" width="150" height="150">\
                        <svg:image width="80" height="60" xlink:href="../repoimages/506350.png" preserveAspectRatio="none" transform="scale(1.875,2.5) translate(-0,-0)  "></svg:image>\
                     </svg:svg>\
                  </svg:g>\
               </svg:svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page497958436-layer-icon879519200" style="position: absolute; left: 20px; top: 170px; width: 32px; height: 32px" data-interactive-element-type="fonticon.icon" class="icon stencil mobile-interaction-potential-trigger " data-stencil-id="icon879519200" data-review-reference-id="icon879519200">\
         <div class="stencil-wrapper" style="width: 32px; height: 32px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" style="width:32px;height:32px;" title="">\
               <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" class="fill-blue">\
                  <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#icon-glyph-e004"></use>\
               </svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page497958436-layer-1824273119" style="position: absolute; left: 20px; top: 215px; width: 32px; height: 32px" data-interactive-element-type="fonticon.icon" class="icon stencil mobile-interaction-potential-trigger " data-stencil-id="1824273119" data-review-reference-id="1824273119">\
         <div class="stencil-wrapper" style="width: 32px; height: 32px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" style="width:32px;height:32px;" title="">\
               <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" class="fill-blue">\
                  <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#icon-glyph-e205"></use>\
               </svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page497958436-layer-1443885442" style="position: absolute; left: 20px; top: 260px; width: 32px; height: 32px" data-interactive-element-type="fonticon.icon" class="icon stencil mobile-interaction-potential-trigger " data-stencil-id="1443885442" data-review-reference-id="1443885442">\
         <div class="stencil-wrapper" style="width: 32px; height: 32px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" style="width:32px;height:32px;" title="">\
               <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" class="fill-blue">\
                  <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#icon-glyph-e056"></use>\
               </svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page497958436-layer-535877150" style="position: absolute; left: 20px; top: 310px; width: 32px; height: 32px" data-interactive-element-type="fonticon.icon" class="icon stencil mobile-interaction-potential-trigger " data-stencil-id="535877150" data-review-reference-id="535877150">\
         <div class="stencil-wrapper" style="width: 32px; height: 32px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" style="width:32px;height:32px;" title="">\
               <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" class="fill-blue">\
                  <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#icon-glyph-e064"></use>\
               </svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page497958436-layer-text347065447" style="position: absolute; left: 60px; top: 180px; width: 179px; height: 23px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text347065447" data-review-reference-id="text347065447">\
         <div class="stencil-wrapper" style="width: 179px; height: 23px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline22"><p><span style="font-size: 20px; color: #658cd9;">Thông tin tài Khoản</span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page497958436-layer-863393734" style="position: absolute; left: 60px; top: 225px; width: 158px; height: 23px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="863393734" data-review-reference-id="863393734">\
         <div class="stencil-wrapper" style="width: 158px; height: 23px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline22"><p><span style="font-size: 20px; color: #658cd9;">Quản lí mật khẩu</span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page497958436-layer-322332929" style="position: absolute; left: 60px; top: 270px; width: 143px; height: 23px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="322332929" data-review-reference-id="322332929">\
         <div class="stencil-wrapper" style="width: 143px; height: 23px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline22"><p><span style="font-size: 20px; color: #658cd9;">Lịch sử đặt chỗ</span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page497958436-layer-1544584988" style="position: absolute; left: 60px; top: 310px; width: 104px; height: 28px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="1544584988" data-review-reference-id="1544584988">\
         <div class="stencil-wrapper" style="width: 104px; height: 28px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline22"><p class="none" style="font-size: 24px;"><span style="font-size: 20px; color: #658cd9;">Đăng xuất</span></p>\
                     <p class="none" style="font-size: 24px;"> </p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page497958436-layer-12249313" style="position: absolute; left: 305px; top: 45px; width: 284px; height: 37px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="12249313" data-review-reference-id="12249313">\
         <div class="stencil-wrapper" style="width: 284px; height: 37px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline22"><p><span style="font-size: 32px; color: #658cd9;">Thông tin tài Khoản</span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page497958436-layer-arrow45765632" style="position: absolute; left: 235px; top: 40px; width: 33px; height: 365px" data-interactive-element-type="static.line" class="line stencil mobile-interaction-potential-trigger " data-stencil-id="arrow45765632" data-review-reference-id="arrow45765632">\
         <div class="stencil-wrapper" style="width: 33px; height: 365px">\
            <div title="">\
               <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" style="position: absolute; left: -5px; top: -5px; height: 375px;width:43px;" viewBox="-5 -5 43 375" width="43" height="375">\
                  <svg:path d="M 16.5,0 L 16.5,365" marker-start="" marker-end="" style="fill:none; stroke-width:2px;stroke:black;"></svg:path>\
               </svg:svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page497958436-layer-text626355810" style="position: absolute; left: 305px; top: 160px; width: 64px; height: 21px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text626355810" data-review-reference-id="text626355810">\
         <div class="stencil-wrapper" style="width: 64px; height: 21px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline32"><p><span style="font-size: 18px;">Họ tên:</span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page497958436-layer-textinput584172794" style="position: absolute; left: 405px; top: 150px; width: 275px; height: 30px" data-interactive-element-type="default.textinput" class="textinput stencil mobile-interaction-potential-trigger " data-stencil-id="textinput584172794" data-review-reference-id="textinput584172794">\
         <div class="stencil-wrapper" style="width: 275px; height: 30px">\
            <div title=""><input id="__containerId__-page497958436-layer-textinput584172794input" value="" style="width:273px;height:28px;padding: 0px;border-width:1px;" type="text" /></div>\
         </div>\
      </div>\
      <div id="__containerId__-page497958436-layer-2047370980" style="position: absolute; left: 405px; top: 210px; width: 275px; height: 30px" data-interactive-element-type="default.textinput" class="textinput stencil mobile-interaction-potential-trigger " data-stencil-id="2047370980" data-review-reference-id="2047370980">\
         <div class="stencil-wrapper" style="width: 275px; height: 30px">\
            <div title=""><input id="__containerId__-page497958436-layer-2047370980input" value="" style="width:273px;height:28px;padding: 0px;border-width:1px;" type="text" /></div>\
         </div>\
      </div>\
      <div id="__containerId__-page497958436-layer-1388442516" style="position: absolute; left: 305px; top: 220px; width: 51px; height: 21px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="1388442516" data-review-reference-id="1388442516">\
         <div class="stencil-wrapper" style="width: 51px; height: 21px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline32"><p><span style="font-size: 18px;">Email</span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page497958436-layer-1362012371" style="position: absolute; left: 305px; top: 285px; width: 91px; height: 21px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="1362012371" data-review-reference-id="1362012371">\
         <div class="stencil-wrapper" style="width: 91px; height: 21px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline32"><p><span style="font-size: 18px;">Ngày sinh:</span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page497958436-layer-59597839" style="position: absolute; left: 305px; top: 345px; width: 81px; height: 21px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="59597839" data-review-reference-id="59597839">\
         <div class="stencil-wrapper" style="width: 81px; height: 21px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline32"><p><span style="font-size: 18px;">Giới Tính</span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page497958436-layer-datepicker278696836" style="position: absolute; left: 405px; top: 275px; width: 150px; height: 30px" data-interactive-element-type="default.datepicker" class="datepicker stencil mobile-interaction-potential-trigger " data-stencil-id="datepicker278696836" data-review-reference-id="datepicker278696836">\
         <div class="stencil-wrapper" style="width: 150px; height: 30px">\
            <div>\
               <div style="position:absolute; white-space: nowrap;" title=""><input type="text" style="width:114px; height:28px;padding: 0px;border-width:1px;" id="__containerId__-page497958436-layer-datepicker278696836_input" /><button type="button" style="width:34px; height:28px; vertical-align: top; padding: 0px;border-width:1px;" id="__containerId__-page497958436-layer-datepicker278696836_button"><img src="../resources/icons/date.png" /></button></div>\
               <div id="__containerId__-page497958436-layer-datepicker278696836_ov" class="yui-skin-sam" style="position: absolute; width: 16em;visibility:visible;">\
                  <div id="__containerId__-page497958436-layer-datepicker278696836_cal"></div>\
               </div><script type="text/javascript">\
				rabbit.stencils.datepicker.setupDatepicker("__containerId__-page497958436-layer-datepicker278696836");\
			</script></div>\
         </div>\
      </div>\
      <div id="__containerId__-page497958436-layer-radiobutton285398877" style="position: absolute; left: 405px; top: 345px; width: 52px; height: 20px" data-interactive-element-type="default.radiobutton" class="radiobutton stencil mobile-interaction-potential-trigger " data-stencil-id="radiobutton285398877" data-review-reference-id="radiobutton285398877">\
         <div class="stencil-wrapper" style="width: 52px; height: 20px">\
            <div class="" style="font-size:1.17em;" xml:space="preserve" title="">\
               					<input id="__containerId__-page497958436-layer-radiobutton285398877input" xml:space="default" type="radio" name="group1" value="__containerId__-page497958436-layer-radiobutton285398877" style="padding-right:8px" />\
               \
               					<label for="__containerId__-page497958436-layer-radiobutton285398877input">\
                  						\
                  						\
                  							Nam\
                  							\
                  						\
                  					</label>\
               				\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page497958436-layer-1625352149" style="position: absolute; left: 490px; top: 345px; width: 41px; height: 20px" data-interactive-element-type="default.radiobutton" class="radiobutton stencil mobile-interaction-potential-trigger " data-stencil-id="1625352149" data-review-reference-id="1625352149">\
         <div class="stencil-wrapper" style="width: 41px; height: 20px">\
            <div class="" style="font-size:1.17em;" xml:space="preserve" title="">\
               					<input id="__containerId__-page497958436-layer-1625352149input" xml:space="default" type="radio" name="group1" value="__containerId__-page497958436-layer-1625352149" style="padding-right:8px" />\
               \
               					<label for="__containerId__-page497958436-layer-1625352149input">\
                  						\
                  						\
                  							Nữ\
                  							\
                  						\
                  					</label>\
               				\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page497958436-layer-iphoneButton869462933" style="position: absolute; left: 490px; top: 485px; width: 100px; height: 30px" data-interactive-element-type="default.iphoneButton" class="iphoneButton stencil mobile-interaction-potential-trigger " data-stencil-id="iphoneButton869462933" data-review-reference-id="iphoneButton869462933">\
         <div class="stencil-wrapper" style="width: 100px; height: 30px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" title="" style="height: 30px;width:100px;">\
               <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" width="100" height="30" viewBox="0 0 100 30">\
                  <svg:a>\
                     <svg:path fill-rule="evenodd" clip-rule="evenodd" fill="#808080" stroke="#666666" d="M5,29.5 l-2,-0.5 -1,-1 -1,-1.5 -0.5,-1.5 0,-20 0.5,-2 1,-1 1,-1 2,-0.5 90,0 1.5,0.5 1.5,1 1,1.5 0.5,1.5 0,20 -0.5,1.5 -1,1.5 -1.5,1 -1.5,0.5 z"></svg:path>\
                     <svg:text x="50" y="15" dy="0.3em" fill="#FFFFFF" style="font-size:1em;stroke-width:0pt;" font-family="\'HelveticaNeue-Bold\'" text-anchor="middle" xml:space="preserve">Cập nhật</svg:text>\
                  </svg:a>\
               </svg:svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page497958436-layer-1552259828" style="position: absolute; left: 305px; top: 395px; width: 161px; height: 21px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="1552259828" data-review-reference-id="1552259828">\
         <div class="stencil-wrapper" style="width: 161px; height: 21px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline32"><p><span style="font-size: 18px;">Lĩnh vực quan tâm:</span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page497958436-layer-checkbox519710206" style="position: absolute; left: 305px; top: 430px; width: 76px; height: 20px" data-interactive-element-type="default.checkbox" class="checkbox stencil mobile-interaction-potential-trigger " data-stencil-id="checkbox519710206" data-review-reference-id="checkbox519710206">\
         <div class="stencil-wrapper" style="width: 76px; height: 20px">\
            <div class="" style="font-size:1.17em;" xml:space="preserve" title="">\
               			\
               <nobr>\
                  				<label>\
                     					<input id="__containerId__-page497958436-layer-checkbox519710206input" xml:space="default" style="padding-right:9px" type="checkbox" />\
                     					\
                     						\
                     						Bar-cafe\
                     						\
                     					\
                     				</label>\
                  			\
               </nobr>\
               		\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page497958436-layer-1419803245" style="position: absolute; left: 425px; top: 430px; width: 89px; height: 20px" data-interactive-element-type="default.checkbox" class="checkbox stencil mobile-interaction-potential-trigger " data-stencil-id="1419803245" data-review-reference-id="1419803245">\
         <div class="stencil-wrapper" style="width: 89px; height: 20px">\
            <div class="" style="font-size:1.17em;" xml:space="preserve" title="">\
               			\
               <nobr>\
                  				<label>\
                     					<input id="__containerId__-page497958436-layer-1419803245input" xml:space="default" style="padding-right:9px" type="checkbox" />\
                     					\
                     						\
                     						Khách sạn\
                     						\
                     					\
                     				</label>\
                  			\
               </nobr>\
               		\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page497958436-layer-1787666778" style="position: absolute; left: 545px; top: 430px; width: 64px; height: 20px" data-interactive-element-type="default.checkbox" class="checkbox stencil mobile-interaction-potential-trigger " data-stencil-id="1787666778" data-review-reference-id="1787666778">\
         <div class="stencil-wrapper" style="width: 64px; height: 20px">\
            <div class="" style="font-size:1.17em;" xml:space="preserve" title="">\
               			\
               <nobr>\
                  				<label>\
                     					<input id="__containerId__-page497958436-layer-1787666778input" xml:space="default" style="padding-right:9px" type="checkbox" />\
                     					\
                     						\
                     						Giải trí\
                     						\
                     					\
                     				</label>\
                  			\
               </nobr>\
               		\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page497958436-layer-1500199881" style="position: absolute; left: 675px; top: 430px; width: 82px; height: 20px" data-interactive-element-type="default.checkbox" class="checkbox stencil mobile-interaction-potential-trigger " data-stencil-id="1500199881" data-review-reference-id="1500199881">\
         <div class="stencil-wrapper" style="width: 82px; height: 20px">\
            <div class="" style="font-size:1.17em;" xml:space="preserve" title="">\
               			\
               <nobr>\
                  				<label>\
                     					<input id="__containerId__-page497958436-layer-1500199881input" xml:space="default" style="padding-right:9px" type="checkbox" />\
                     					\
                     						\
                     						Sức khỏe\
                     						\
                     					\
                     				</label>\
                  			\
               </nobr>\
               		\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page497958436-layer-964031897" style="position: absolute; left: 290px; top: 560px; width: 225px; height: 37px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="964031897" data-review-reference-id="964031897">\
         <div class="stencil-wrapper" style="width: 225px; height: 37px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline22"><p><span style="font-size: 32px; color: #658cd9;">Lịch sử đặt chỗ</span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page497958436-layer-arrow243142665" style="position: absolute; left: 285px; top: 520px; width: 735px; height: 33px" data-interactive-element-type="static.line" class="line stencil mobile-interaction-potential-trigger " data-stencil-id="arrow243142665" data-review-reference-id="arrow243142665">\
         <div class="stencil-wrapper" style="width: 735px; height: 33px">\
            <div title="">\
               <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" style="position: absolute; left: -5px; top: -5px; height: 43px;width:745px;" viewBox="-5 -5 745 43" width="745" height="43">\
                  <svg:path d="M 0,16.5 L 735,16.5" marker-start="" marker-end="" style="fill:none; stroke-width:2px;stroke:black;"></svg:path>\
               </svg:svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page497958436-layer-image115759317" style="position: absolute; left: 275px; top: 645px; width: 980px; height: 342px" data-interactive-element-type="default.image" class="image stencil mobile-interaction-potential-trigger " data-stencil-id="image115759317" data-review-reference-id="image115759317">\
         <div class="stencil-wrapper" style="width: 980px; height: 342px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" title="">\
               <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" class="image-cropper" style="height: 342px;width:980px;" width="980" height="342" viewBox="0 0 980 342">\
                  <svg:g width="980" height="342">\
                     <svg:svg x="0" y="0" width="980" height="342">\
                        <svg:image width="80" height="60" xlink:href="../repoimages/506362.PNG" preserveAspectRatio="none" transform="scale(12.25,5.7) translate(-0,-0)  "></svg:image>\
                     </svg:svg>\
                  </svg:g>\
               </svg:svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page497958436-layer-453722338" style="position: absolute; left: 70px; top: 160px; width: 108px; height: 17px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="453722338" data-review-reference-id="453722338">\
         <div class="stencil-wrapper" style="width: 108px; height: 17px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline22"><p><span style="font-size: 14px; color: #658cd9;">SĐT 016325483</span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page497958436-layer-text904756561" style="position: absolute; left: 1135px; top: 770px; width: 50px; height: 17px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text904756561" data-review-reference-id="text904756561">\
         <div class="stencil-wrapper" style="width: 50px; height: 17px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.link2"><p style="font-size: 14px;"><span class="underline" style="color: #658cd9;">Chi tiết</span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page497958436-layer-1427091192" style="position: absolute; left: 1135px; top: 940px; width: 50px; height: 17px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="1427091192" data-review-reference-id="1427091192">\
         <div class="stencil-wrapper" style="width: 50px; height: 17px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.link2"><p style="font-size: 14px;"><span class="underline" style="color: #658cd9;">Chi tiết</span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page497958436-layer-1098393805" style="position: absolute; left: 305px; top: 100px; width: 87px; height: 21px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="1098393805" data-review-reference-id="1098393805">\
         <div class="stencil-wrapper" style="width: 87px; height: 21px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline32"><p class="none" style="font-size: 18px;">Ngày lập: </p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page497958436-layer-text591097359" style="position: absolute; left: 410px; top: 100px; width: 96px; height: 21px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text591097359" data-review-reference-id="text591097359">\
         <div class="stencil-wrapper" style="width: 96px; height: 21px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline32"><p><span style="font-size: 18px;">23/07/2016</span></p></span></span></div>\
         </div>\
      </div>\
   </div>\
</div>');