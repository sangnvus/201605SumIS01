rabbit.data.layerStore.addLayerFromHtml('<div xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:fn="http://www.w3.org/2005/xpath-functions" id="result">\
   <div xmlns:xs="http://www.w3.org/2001/XMLSchema" xmlns="http://www.w3.org/1999/xhtml" id="__containerId__page271612227-layer" class="layer" name="__containerId__pageLayer" data-layer-id="page271612227" data-layer-type="pageLayer" style="position:absolute;left:0px;top:0px;">\
      <div id="__containerId__-page271612227-layer-image273698272" style="position: absolute; left: 0px; top: 0px; width: 1366px; height: 6000px" data-interactive-element-type="default.image" class="image stencil mobile-interaction-potential-trigger " data-stencil-id="image273698272" data-review-reference-id="image273698272">\
         <div class="stencil-wrapper" style="width: 1366px; height: 6000px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" title="">\
               <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" class="image-cropper" style="height: 6000px;width:1366px;" width="1366" height="6000">\
                  <svg:g width="1366" height="6000">\
                     <svg:svg x="1" y="1" width="1364" height="5998">\
                        <svg:image width="432" height="253" xlink:href="../repoimages/506332.PNG" preserveAspectRatio="none" transform="scale(3.162037037037037,23.715415019762847) translate(-0,-0)  "></svg:image>\
                     </svg:svg>\
                  </svg:g>\
               </svg:svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page271612227-layer-image498960770" style="position: absolute; left: 0px; top: 55px; width: 1366px; height: 6000px" data-interactive-element-type="default.image" class="image stencil mobile-interaction-potential-trigger " data-stencil-id="image498960770" data-review-reference-id="image498960770">\
         <div class="stencil-wrapper" style="width: 1366px; height: 6000px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" title="">\
               <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" class="image-cropper" style="height: 6000px;width:1366px;" width="1366" height="6000">\
                  <svg:g width="1366" height="6000">\
                     <svg:svg x="1" y="1" width="1364" height="5998">\
                        <svg:image width="432" height="253" xlink:href="../repoimages/506332.PNG" preserveAspectRatio="none" transform="scale(3.162037037037037,23.715415019762847) translate(-0,-0)  "></svg:image>\
                     </svg:svg>\
                  </svg:g>\
               </svg:svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page271612227-layer-image519661798" style="position: absolute; left: 35px; top: 25px; width: 150px; height: 150px" data-interactive-element-type="default.image" class="image stencil mobile-interaction-potential-trigger " data-stencil-id="image519661798" data-review-reference-id="image519661798">\
         <div class="stencil-wrapper" style="width: 150px; height: 150px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" title="">\
               <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" class="image-cropper" style="height: 150px;width:150px;" width="150" height="150">\
                  <svg:g width="150" height="150">\
                     <svg:svg x="1" y="1" width="148" height="148">\
                        <svg:image width="80" height="60" xlink:href="../repoimages/508705.png" preserveAspectRatio="none" transform="scale(1.875,2.5) translate(-0,-0)  "></svg:image>\
                     </svg:svg>\
                  </svg:g>\
               </svg:svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page271612227-layer-text479975646" style="position: absolute; left: 65px; top: 180px; width: 97px; height: 37px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text479975646" data-review-reference-id="text479975646">\
         <div class="stencil-wrapper" style="width: 97px; height: 37px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline12"><p><span style="font-size: 32px; color: #658cd9;">Admin</span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page271612227-layer-arrow535785819" style="position: absolute; left: 245px; top: 35px; width: 25px; height: 4415px" data-interactive-element-type="static.line" class="line stencil mobile-interaction-potential-trigger " data-stencil-id="arrow535785819" data-review-reference-id="arrow535785819">\
         <div class="stencil-wrapper" style="width: 25px; height: 4415px">\
            <div title="">\
               <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" style="position: absolute; left: -5px; top: -5px; height: 4425px;width:35px;" viewBox="-5 -5 35 4425" width="35" height="4425"><svg:path d="M 12.00, 0.00 Q 12.75, 10.03, 12.71, 20.07 Q 11.88, 30.10, 12.52, 40.14 Q 12.90, 50.17, 11.25, 60.20 Q 11.34,\
                  70.24, 11.66, 80.27 Q 12.98, 90.31, 12.90, 100.34 Q 12.52, 110.37, 11.33, 120.41 Q 12.15, 130.44, 11.54, 140.48 Q 11.12, 150.51,\
                  11.43, 160.55 Q 12.27, 170.58, 13.19, 180.61 Q 13.37, 190.65, 13.88, 200.68 Q 13.57, 210.72, 14.08, 220.75 Q 13.09, 230.78,\
                  11.36, 240.82 Q 13.22, 250.85, 13.20, 260.89 Q 13.07, 270.92, 12.66, 280.95 Q 12.75, 290.99, 12.38, 301.02 Q 12.97, 311.06,\
                  12.06, 321.09 Q 12.42, 331.12, 12.80, 341.16 Q 13.33, 351.19, 13.33, 361.23 Q 12.75, 371.26, 12.81, 381.30 Q 12.40, 391.33,\
                  13.51, 401.36 Q 13.25, 411.40, 12.79, 421.43 Q 12.92, 431.47, 13.60, 441.50 Q 13.75, 451.53, 12.67, 461.57 Q 11.73, 471.60,\
                  10.72, 481.64 Q 12.01, 491.67, 12.74, 501.70 Q 12.26, 511.74, 12.18, 521.77 Q 12.15, 531.81, 12.07, 541.84 Q 12.20, 551.88,\
                  11.87, 561.91 Q 11.83, 571.94, 13.09, 581.98 Q 13.30, 592.01, 12.74, 602.05 Q 12.22, 612.08, 13.15, 622.11 Q 12.26, 632.15,\
                  11.56, 642.18 Q 12.26, 652.22, 12.03, 662.25 Q 12.90, 672.28, 12.92, 682.32 Q 12.73, 692.35, 13.43, 702.39 Q 12.90, 712.42,\
                  12.97, 722.46 Q 12.98, 732.49, 12.71, 742.52 Q 13.05, 752.56, 13.45, 762.59 Q 12.55, 772.63, 12.61, 782.66 Q 12.04, 792.69,\
                  13.41, 802.73 Q 13.43, 812.76, 13.00, 822.80 Q 13.14, 832.83, 13.25, 842.86 Q 13.47, 852.90, 13.96, 862.93 Q 13.96, 872.97,\
                  14.00, 883.00 Q 14.11, 893.04, 14.20, 903.07 Q 13.21, 913.10, 13.15, 923.14 Q 12.50, 933.17, 13.02, 943.21 Q 11.60, 953.24,\
                  11.36, 963.27 Q 12.05, 973.31, 12.52, 983.34 Q 13.18, 993.38, 13.00, 1003.41 Q 12.84, 1013.44, 13.30, 1023.48 Q 13.20, 1033.51,\
                  13.30, 1043.55 Q 13.45, 1053.58, 13.61, 1063.61 Q 13.41, 1073.65, 13.26, 1083.68 Q 13.38, 1093.72, 13.52, 1103.75 Q 13.48,\
                  1113.79, 13.17, 1123.82 Q 12.68, 1133.85, 12.20, 1143.89 Q 12.95, 1153.92, 12.99, 1163.96 Q 12.76, 1173.99, 13.62, 1184.02\
                  Q 12.44, 1194.06, 13.76, 1204.09 Q 13.29, 1214.13, 12.56, 1224.16 Q 13.33, 1234.19, 13.87, 1244.23 Q 13.46, 1254.26, 12.28,\
                  1264.30 Q 11.56, 1274.33, 11.26, 1284.36 Q 11.53, 1294.40, 12.71, 1304.43 Q 12.80, 1314.47, 11.86, 1324.50 Q 11.60, 1334.53,\
                  12.78, 1344.57 Q 13.04, 1354.60, 12.74, 1364.64 Q 11.29, 1374.67, 12.21, 1384.70 Q 13.07, 1394.74, 13.58, 1404.77 Q 13.35,\
                  1414.81, 13.16, 1424.84 Q 12.73, 1434.88, 12.90, 1444.91 Q 12.96, 1454.94, 13.20, 1464.98 Q 12.71, 1475.01, 13.16, 1485.05\
                  Q 12.79, 1495.08, 12.57, 1505.11 Q 12.82, 1515.15, 12.65, 1525.18 Q 12.81, 1535.22, 12.31, 1545.25 Q 13.12, 1555.28, 13.71,\
                  1565.32 Q 13.70, 1575.35, 12.93, 1585.39 Q 12.66, 1595.42, 12.97, 1605.45 Q 13.22, 1615.49, 12.73, 1625.52 Q 12.25, 1635.56,\
                  12.29, 1645.59 Q 12.19, 1655.62, 12.40, 1665.66 Q 12.93, 1675.69, 12.02, 1685.73 Q 11.40, 1695.76, 12.10, 1705.79 Q 12.72,\
                  1715.83, 13.22, 1725.86 Q 13.57, 1735.90, 13.60, 1745.93 Q 13.55, 1755.96, 13.19, 1766.00 Q 13.23, 1776.03, 13.10, 1786.07\
                  Q 13.27, 1796.10, 13.19, 1806.14 Q 12.76, 1816.17, 12.22, 1826.20 Q 12.75, 1836.24, 12.21, 1846.27 Q 11.62, 1856.31, 10.52,\
                  1866.34 Q 11.58, 1876.37, 12.11, 1886.41 Q 12.25, 1896.44, 12.59, 1906.48 Q 13.37, 1916.51, 13.04, 1926.54 Q 12.79, 1936.58,\
                  12.95, 1946.61 Q 11.77, 1956.65, 11.28, 1966.68 Q 11.24, 1976.71, 11.61, 1986.75 Q 12.50, 1996.78, 12.39, 2006.82 Q 12.21,\
                  2016.85, 12.33, 2026.88 Q 13.28, 2036.92, 12.85, 2046.95 Q 13.35, 2056.99, 13.44, 2067.02 Q 13.59, 2077.05, 13.66, 2087.09\
                  Q 13.83, 2097.12, 13.43, 2107.16 Q 13.48, 2117.19, 13.63, 2127.23 Q 13.71, 2137.26, 13.38, 2147.29 Q 13.43, 2157.33, 13.47,\
                  2167.36 Q 13.58, 2177.40, 13.67, 2187.43 Q 13.89, 2197.47, 13.49, 2207.50 Q 13.45, 2217.53, 13.36, 2227.57 Q 13.01, 2237.60,\
                  13.00, 2247.64 Q 11.90, 2257.67, 11.97, 2267.70 Q 11.41, 2277.74, 11.36, 2287.77 Q 11.74, 2297.81, 12.28, 2307.84 Q 11.55,\
                  2317.88, 12.82, 2327.91 Q 11.34, 2337.94, 12.41, 2347.98 Q 13.25, 2358.01, 13.21, 2368.05 Q 12.85, 2378.08, 11.66, 2388.11\
                  Q 13.04, 2398.15, 13.38, 2408.18 Q 12.07, 2418.22, 12.49, 2428.25 Q 11.10, 2438.29, 11.03, 2448.32 Q 11.36, 2458.35, 12.05,\
                  2468.39 Q 12.58, 2478.42, 12.84, 2488.46 Q 13.14, 2498.49, 13.65, 2508.52 Q 13.31, 2518.56, 13.45, 2528.59 Q 13.38, 2538.63,\
                  12.69, 2548.66 Q 12.19, 2558.70, 12.14, 2568.73 Q 12.04, 2578.76, 11.84, 2588.80 Q 11.56, 2598.83, 13.22, 2608.87 Q 12.62,\
                  2618.90, 13.71, 2628.93 Q 13.14, 2638.97, 12.42, 2649.00 Q 12.12, 2659.04, 12.35, 2669.07 Q 12.68, 2679.11, 13.23, 2689.14\
                  Q 13.48, 2699.17, 13.89, 2709.21 Q 14.27, 2719.24, 14.25, 2729.28 Q 14.05, 2739.31, 12.04, 2749.34 Q 11.40, 2759.38, 12.35,\
                  2769.41 Q 12.55, 2779.45, 12.53, 2789.48 Q 12.74, 2799.52, 13.25, 2809.55 Q 13.00, 2819.58, 13.33, 2829.62 Q 12.76, 2839.65,\
                  13.03, 2849.69 Q 12.03, 2859.72, 12.03, 2869.76 Q 12.68, 2879.79, 12.87, 2889.82 Q 12.32, 2899.86, 12.38, 2909.89 Q 12.82,\
                  2919.93, 12.94, 2929.96 Q 12.62, 2939.99, 12.23, 2950.03 Q 12.47, 2960.06, 12.89, 2970.10 Q 12.04, 2980.13, 11.81, 2990.17\
                  Q 11.63, 3000.20, 11.99, 3010.23 Q 11.50, 3020.27, 12.36, 3030.30 Q 12.58, 3040.34, 12.04, 3050.37 Q 12.52, 3060.40, 12.35,\
                  3070.44 Q 11.39, 3080.47, 11.31, 3090.51 Q 11.94, 3100.54, 12.53, 3110.58 Q 12.65, 3120.61, 13.34, 3130.64 Q 13.19, 3140.68,\
                  12.67, 3150.71 Q 12.46, 3160.75, 11.88, 3170.78 Q 11.34, 3180.81, 11.72, 3190.85 Q 12.01, 3200.88, 12.29, 3210.92 Q 13.45,\
                  3220.95, 12.69, 3230.99 Q 12.26, 3241.02, 12.51, 3251.05 Q 12.51, 3261.09, 12.25, 3271.12 Q 12.20, 3281.16, 12.36, 3291.19\
                  Q 12.10, 3301.22, 12.19, 3311.26 Q 11.33, 3321.29, 12.25, 3331.33 Q 11.88, 3341.36, 12.40, 3351.40 Q 12.32, 3361.43, 11.52,\
                  3371.46 Q 11.30, 3381.50, 10.93, 3391.53 Q 11.32, 3401.57, 11.73, 3411.60 Q 12.85, 3421.64, 12.64, 3431.67 Q 13.03, 3441.70,\
                  12.70, 3451.74 Q 13.52, 3461.77, 13.71, 3471.81 Q 13.88, 3481.84, 13.72, 3491.87 Q 13.07, 3501.91, 13.24, 3511.94 Q 12.61,\
                  3521.98, 12.51, 3532.01 Q 13.64, 3542.05, 13.24, 3552.08 Q 13.52, 3562.11, 12.71, 3572.15 Q 13.64, 3582.18, 12.99, 3592.22\
                  Q 13.44, 3602.25, 12.47, 3612.28 Q 12.99, 3622.32, 12.11, 3632.35 Q 11.81, 3642.39, 12.20, 3652.42 Q 12.98, 3662.46, 13.26,\
                  3672.49 Q 12.21, 3682.52, 12.05, 3692.56 Q 12.93, 3702.59, 12.46, 3712.63 Q 11.43, 3722.66, 11.11, 3732.69 Q 12.38, 3742.73,\
                  12.59, 3752.76 Q 13.40, 3762.80, 12.53, 3772.83 Q 12.43, 3782.87, 12.00, 3792.90 Q 12.03, 3802.93, 11.27, 3812.97 Q 11.97,\
                  3823.00, 13.19, 3833.04 Q 14.19, 3843.07, 14.33, 3853.10 Q 14.14, 3863.14, 14.00, 3873.17 Q 14.28, 3883.21, 14.29, 3893.24\
                  Q 13.26, 3903.28, 13.04, 3913.31 Q 12.88, 3923.34, 12.66, 3933.38 Q 13.20, 3943.41, 11.84, 3953.45 Q 11.98, 3963.48, 12.06,\
                  3973.51 Q 11.77, 3983.55, 12.58, 3993.58 Q 12.70, 4003.62, 12.64, 4013.65 Q 12.51, 4023.69, 12.50, 4033.72 Q 12.81, 4043.75,\
                  12.28, 4053.79 Q 12.55, 4063.82, 13.28, 4073.86 Q 12.74, 4083.89, 12.65, 4093.93 Q 13.23, 4103.96, 13.06, 4113.99 Q 13.31,\
                  4124.03, 13.20, 4134.06 Q 13.24, 4144.10, 13.88, 4154.13 Q 13.16, 4164.16, 13.99, 4174.20 Q 13.29, 4184.23, 13.96, 4194.27\
                  Q 13.23, 4204.30, 13.07, 4214.33 Q 13.23, 4224.37, 13.09, 4234.40 Q 13.06, 4244.44, 13.47, 4254.47 Q 13.18, 4264.51, 13.92,\
                  4274.54 Q 13.46, 4284.57, 12.88, 4294.61 Q 12.91, 4304.64, 12.78, 4314.68 Q 12.73, 4324.71, 13.35, 4334.75 Q 13.07, 4344.78,\
                  13.59, 4354.81 Q 13.72, 4364.85, 13.68, 4374.88 Q 13.82, 4384.92, 13.98, 4394.95 Q 12.00, 4404.98, 12.00, 4415.02" style="marker-start:;marker-end:"\
                  class="svg_unselected_element"/>\
               </svg:svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page271612227-layer-text174357313" style="position: absolute; left: 70px; top: 240px; width: 89px; height: 23px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text174357313" data-review-reference-id="text174357313">\
         <div class="stencil-wrapper" style="width: 89px; height: 23px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline22"><p><span style="font-size: 20px; color: #658cd9;">Thông tin</span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page271612227-layer-1265587393" style="position: absolute; left: 5px; top: -1125px; width: 32px; height: 32px" data-interactive-element-type="fonticon.icon" class="icon stencil mobile-interaction-potential-trigger " data-stencil-id="1265587393" data-review-reference-id="1265587393">\
         <div class="stencil-wrapper" style="width: 32px; height: 32px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" style="width:32px;height:32px;" title="">\
               <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" class="fill-blue">\
                  <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#icon-glyph-e004"></use>\
               </svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page271612227-layer-1887757013" style="position: absolute; left: 50px; top: -1120px; width: 106px; height: 28px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="1887757013" data-review-reference-id="1887757013">\
         <div class="stencil-wrapper" style="width: 106px; height: 28px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline22"><p><span style="font-size: 24px; color: #658cd9;">Thông tin</span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page271612227-layer-1621736172" style="position: absolute; left: 25px; top: 235px; width: 32px; height: 32px" data-interactive-element-type="fonticon.icon" class="icon stencil mobile-interaction-potential-trigger " data-stencil-id="1621736172" data-review-reference-id="1621736172">\
         <div class="stencil-wrapper" style="width: 32px; height: 32px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" style="width:32px;height:32px;" title="">\
               <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" class="fill-blue">\
                  <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#icon-glyph-e004"></use>\
               </svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page271612227-layer-340966007" style="position: absolute; left: 70px; top: 575px; width: 165px; height: 28px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="340966007" data-review-reference-id="340966007">\
         <div class="stencil-wrapper" style="width: 165px; height: 28px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline22"><p class="none" style="font-size: 24px;"><span style="color: #658cd9; font-size: 20px;">Quản lí mật khẩu</span> </p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page271612227-layer-icon935926720" style="position: absolute; left: 25px; top: 570px; width: 32px; height: 32px" data-interactive-element-type="fonticon.icon" class="icon stencil mobile-interaction-potential-trigger " data-stencil-id="icon935926720" data-review-reference-id="icon935926720">\
         <div class="stencil-wrapper" style="width: 32px; height: 32px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" style="width:32px;height:32px;" title="">\
               <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" class="fill-blue">\
                  <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#icon-glyph-e205"></use>\
               </svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page271612227-layer-1222042112" style="position: absolute; left: 25px; top: 285px; width: 32px; height: 32px" data-interactive-element-type="fonticon.icon" class="icon stencil mobile-interaction-potential-trigger " data-stencil-id="1222042112" data-review-reference-id="1222042112">\
         <div class="stencil-wrapper" style="width: 32px; height: 32px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" style="width:32px;height:32px;" title="">\
               <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" class="fill-blue">\
                  <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#icon-glyph-e025"></use>\
               </svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page271612227-layer-1981890541" style="position: absolute; left: 70px; top: 290px; width: 165px; height: 28px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="1981890541" data-review-reference-id="1981890541">\
         <div class="stencil-wrapper" style="width: 165px; height: 28px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline22"><p class="none" style="font-size: 24px;"><span style="color: #658cd9;">Chủ cửa hàng</span> </p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page271612227-layer-1528972458" style="position: absolute; left: 25px; top: 335px; width: 32px; height: 32px" data-interactive-element-type="fonticon.icon" class="icon stencil mobile-interaction-potential-trigger " data-stencil-id="1528972458" data-review-reference-id="1528972458">\
         <div class="stencil-wrapper" style="width: 32px; height: 32px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" style="width:32px;height:32px;" title="">\
               <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" class="fill-blue">\
                  <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#icon-glyph-e044"></use>\
               </svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page271612227-layer-737490597" style="position: absolute; left: 70px; top: 340px; width: 141px; height: 28px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="737490597" data-review-reference-id="737490597">\
         <div class="stencil-wrapper" style="width: 141px; height: 28px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline22"><p class="none" style="font-size: 24px;"><span style="color: #658cd9;">Khách hàng</span> </p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page271612227-layer-1412662593" style="position: absolute; left: 70px; top: 390px; width: 119px; height: 27px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="1412662593" data-review-reference-id="1412662593">\
         <div class="stencil-wrapper" style="width: 119px; height: 27px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline22"><p class="none" style="font-size: 24px;"><span style="color: #658cd9;">Đơn hàng</span> </p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page271612227-layer-icon911435795" style="position: absolute; left: 25px; top: 385px; width: 32px; height: 32px" data-interactive-element-type="fonticon.icon" class="icon stencil mobile-interaction-potential-trigger " data-stencil-id="icon911435795" data-review-reference-id="icon911435795">\
         <div class="stencil-wrapper" style="width: 32px; height: 32px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" style="width:32px;height:32px;" title="">\
               <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" class="fill-blue">\
                  <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#icon-glyph-e319"></use>\
               </svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page271612227-layer-2087309316" style="position: absolute; left: 65px; top: 515px; width: 89px; height: 23px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="2087309316" data-review-reference-id="2087309316">\
         <div class="stencil-wrapper" style="width: 89px; height: 23px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline22"><p><span style="font-size: 20px; color: #658cd9;">Thống kê</span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page271612227-layer-686516014" style="position: absolute; left: 20px; top: 505px; width: 32px; height: 32px" data-interactive-element-type="fonticon.icon" class="icon stencil mobile-interaction-potential-trigger " data-stencil-id="686516014" data-review-reference-id="686516014">\
         <div class="stencil-wrapper" style="width: 32px; height: 32px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" style="width:32px;height:32px;" title="">\
               <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" class="fill-blue">\
                  <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#icon-glyph-e041"></use>\
               </svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page271612227-layer-text566932881" style="position: absolute; left: 325px; top: 35px; width: 139px; height: 37px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text566932881" data-review-reference-id="text566932881">\
         <div class="stencil-wrapper" style="width: 139px; height: 37px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline12"><p><span style="font-size: 32px; color: #658cd9;">Thông tin</span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page271612227-layer-arrow577384147" style="position: absolute; left: 300px; top: 490px; width: 1020px; height: 33px" data-interactive-element-type="static.line" class="line stencil mobile-interaction-potential-trigger " data-stencil-id="arrow577384147" data-review-reference-id="arrow577384147">\
         <div class="stencil-wrapper" style="width: 1020px; height: 33px">\
            <div title="">\
               <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" style="position: absolute; left: -5px; top: -5px; height: 43px;width:1030px;" viewBox="-5 -5 1030 43" width="1030" height="43"><svg:path d="M 0.00, 16.00 Q 10.00, 15.96, 20.00, 16.53 Q 30.00, 17.11, 40.00, 16.87 Q 50.00, 16.32, 60.00, 17.59 Q 70.00,\
                  16.91, 80.00, 15.67 Q 90.00, 14.09, 100.00, 14.57 Q 110.00, 17.28, 120.00, 17.15 Q 130.00, 16.94, 140.00, 17.00 Q 150.00,\
                  16.68, 160.00, 15.39 Q 170.00, 14.09, 180.00, 14.49 Q 190.00, 15.40, 200.00, 14.36 Q 210.00, 16.44, 220.00, 16.79 Q 230.00,\
                  16.33, 240.00, 15.57 Q 250.00, 14.84, 260.00, 15.10 Q 270.00, 15.66, 280.00, 15.34 Q 290.00, 16.15, 300.00, 15.52 Q 310.00,\
                  15.13, 320.00, 14.85 Q 330.00, 14.29, 340.00, 13.98 Q 350.00, 14.30, 360.00, 15.21 Q 370.00, 16.24, 380.00, 16.07 Q 390.00,\
                  15.34, 400.00, 13.94 Q 410.00, 14.16, 420.00, 16.00 Q 430.00, 16.74, 440.00, 15.70 Q 450.00, 14.34, 460.00, 14.90 Q 470.00,\
                  15.13, 480.00, 14.43 Q 490.00, 13.79, 500.00, 14.16 Q 510.00, 14.52, 520.00, 15.04 Q 530.00, 15.70, 540.00, 16.12 Q 550.00,\
                  16.58, 560.00, 15.32 Q 570.00, 15.35, 580.00, 16.10 Q 590.00, 16.21, 600.00, 15.61 Q 610.00, 15.07, 620.00, 15.25 Q 630.00,\
                  15.65, 640.00, 15.71 Q 650.00, 15.13, 660.00, 15.14 Q 670.00, 14.74, 680.00, 14.90 Q 690.00, 14.89, 700.00, 15.55 Q 710.00,\
                  16.08, 720.00, 16.54 Q 730.00, 16.62, 740.00, 16.68 Q 750.00, 16.11, 760.00, 16.01 Q 770.00, 16.00, 780.00, 15.58 Q 790.00,\
                  14.83, 800.00, 14.50 Q 810.00, 14.38, 820.00, 14.52 Q 830.00, 15.07, 840.00, 15.92 Q 850.00, 16.10, 860.00, 16.14 Q 870.00,\
                  16.07, 880.00, 15.36 Q 890.00, 14.76, 900.00, 14.23 Q 910.00, 14.30, 920.00, 14.80 Q 930.00, 14.58, 940.00, 14.80 Q 950.00,\
                  14.63, 960.00, 14.45 Q 970.00, 14.24, 980.00, 14.33 Q 990.00, 14.04, 1000.00, 14.63 Q 1010.00, 16.00, 1020.00, 16.00" style="marker-start:;marker-end:"\
                  class="svg_unselected_element"/>\
               </svg:svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page271612227-layer-text98494574" style="position: absolute; left: 330px; top: 530px; width: 209px; height: 37px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text98494574" data-review-reference-id="text98494574">\
         <div class="stencil-wrapper" style="width: 209px; height: 37px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline12"><p><span style="font-size: 32px; color: #658cd9;">Chủ cửa hàng</span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page271612227-layer-text27852196" style="position: absolute; left: 1150px; top: 530px; width: 123px; height: 37px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text27852196" data-review-reference-id="text27852196">\
         <div class="stencil-wrapper" style="width: 123px; height: 37px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline12"><p><span style="font-size: 32px; color: #000000;"><span style="color: #658cd9;">4</span> Người</span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page271612227-layer-text725678959" style="position: absolute; left: 340px; top: 580px; width: 62px; height: 23px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text725678959" data-review-reference-id="text725678959">\
         <div class="stencil-wrapper" style="width: 62px; height: 23px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline32"><p><span style="font-size: 20px; color: #658cd9;">Bộ lọc</span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page271612227-layer-textinput704298858" style="position: absolute; left: 395px; top: 625px; width: 150px; height: 30px" data-interactive-element-type="default.textinput" class="textinput stencil mobile-interaction-potential-trigger " data-stencil-id="textinput704298858" data-review-reference-id="textinput704298858">\
         <div class="stencil-wrapper" style="width: 150px; height: 30px">\
            <div>\
               <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" style="height: 30px;width:150px;" width="150" height="30">\
                  <svg:g id="__containerId__-page271612227-layer-textinput704298858svg" width="150" height="30"><svg:path id="__containerId__-page271612227-layer-textinput704298858_input_svg_border" d="M 2.00, 2.00 Q 12.43, 0.94, 22.86,\
                     0.65 Q 33.29, 0.52, 43.71, 0.47 Q 54.14, 0.43, 64.57, 0.10 Q 75.00, 0.45, 85.43, 0.46 Q 95.86, 0.87, 106.29, 0.63 Q 116.71,\
                     0.00, 127.14, -0.22 Q 137.57, 0.05, 148.86, 1.14 Q 148.89, 14.70, 148.51, 28.51 Q 137.71, 28.51, 127.22, 28.71 Q 116.76, 28.90,\
                     106.32, 29.21 Q 95.87, 29.21, 85.44, 29.75 Q 75.01, 29.90, 64.57, 30.00 Q 54.14, 29.92, 43.71, 29.92 Q 33.29, 29.90, 22.86,\
                     29.66 Q 12.43, 29.19, 1.51, 28.49 Q 2.00, 15.00, 2.00, 2.00" style=" fill:white;" class="svg_unselected_element"/><svg:path id="__containerId__-page271612227-layer-textinput704298858_line1" d="M 3.00, 3.00 Q 13.29, 2.87, 23.57, 2.81 Q 33.86,\
                     2.80, 44.14, 2.53 Q 54.43, 2.34, 64.71, 2.40 Q 75.00, 2.21, 85.29, 2.14 Q 95.57, 2.15, 105.86, 2.01 Q 116.14, 2.04, 126.43,\
                     1.96 Q 136.71, 3.00, 147.00, 3.00" style=" fill:none;" class="svg_unselected_element"/><svg:path id="__containerId__-page271612227-layer-textinput704298858_line2" d="M 3.00, 3.00 Q 3.00, 15.00, 3.00, 27.00" style="\
                     fill:none;" class="svg_unselected_element"/><svg:path id="__containerId__-page271612227-layer-textinput704298858_line3" d="M 3.00, 3.00 Q 13.29, 0.67, 23.57, 0.77 Q 33.86,\
                     1.99, 44.14, 1.61 Q 54.43, 2.12, 64.71, 3.24 Q 75.00, 2.68, 85.29, 2.60 Q 95.57, 1.82, 105.86, 2.25 Q 116.14, 3.09, 126.43,\
                     2.68 Q 136.71, 3.00, 147.00, 3.00" style=" fill:none;" class="svg_unselected_element"/><svg:path id="__containerId__-page271612227-layer-textinput704298858_line4" d="M 3.00, 3.00 Q 3.00, 15.00, 3.00, 27.00" style="\
                     fill:none;" class="svg_unselected_element"/>\
                  </svg:g>\
               </svg:svg>\
               <div style="position:absolute;left: 6px; top: 1px;" title=""><input id="__containerId__-page271612227-layer-textinput704298858input" onblur="rabbit.facade.raiseEvent(rabbit.events.svgBlur, new Array(\'__containerId__-page271612227-layer-textinput704298858_input_svg_border\',\'__containerId__-page271612227-layer-textinput704298858_line1\',\'__containerId__-page271612227-layer-textinput704298858_line2\',\'__containerId__-page271612227-layer-textinput704298858_line3\',\'__containerId__-page271612227-layer-textinput704298858_line4\'))" onfocus="rabbit.facade.raiseEvent(rabbit.events.svgFocus, new Array(\'__containerId__-page271612227-layer-textinput704298858_input_svg_border\',\'__containerId__-page271612227-layer-textinput704298858_line1\',\'__containerId__-page271612227-layer-textinput704298858_line2\',\'__containerId__-page271612227-layer-textinput704298858_line3\',\'__containerId__-page271612227-layer-textinput704298858_line4\'))" value="" style="width:143px;height:28px;padding: 0px;" type="text" /></div>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page271612227-layer-text608299457" style="position: absolute; left: 350px; top: 630px; width: 37px; height: 21px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text608299457" data-review-reference-id="text608299457">\
         <div class="stencil-wrapper" style="width: 37px; height: 21px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline32"><p><span style="font-size: 18px; color: #658cd9;">Tên</span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page271612227-layer-combobox385567715" style="position: absolute; left: 600px; top: 625px; width: 150px; height: 30px" data-interactive-element-type="default.combobox" class="combobox stencil mobile-interaction-potential-trigger " data-stencil-id="combobox385567715" data-review-reference-id="combobox385567715">\
         <div class="stencil-wrapper" style="width: 150px; height: 30px">\
            <div style="position:absolute;left:2px;top:0px;">\
               <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" style="position: absolute; height: 30px;width:150px;" width="150" height="30">\
                  <svg:g id="__containerId__-page271612227-layer-combobox385567715" width="150" height="30"><svg:path id="__containerId__-page271612227-layer-combobox385567715_input_svg_border" d="M 2.00, 2.00 Q 12.43, -0.30, 22.86,\
                     0.26 Q 33.29, 0.65, 43.71, 1.53 Q 54.14, 2.13, 64.57, 1.97 Q 75.00, 2.53, 85.43, 2.34 Q 95.86, 1.90, 106.29, 2.05 Q 116.71,\
                     1.75, 127.14, 1.63 Q 137.57, 1.84, 147.56, 2.44 Q 147.90, 15.03, 147.89, 27.89 Q 137.71, 28.51, 127.18, 28.34 Q 116.70, 27.68,\
                     106.29, 28.11 Q 95.86, 28.19, 85.43, 28.41 Q 75.00, 26.98, 64.57, 28.04 Q 54.14, 28.43, 43.71, 28.44 Q 33.29, 27.72, 22.86,\
                     28.14 Q 12.43, 28.89, 1.39, 28.61 Q 2.00, 15.00, 2.00, 2.00" style=" fill:white;" class="svg_unselected_element"/>\
                  </svg:g>\
               </svg:svg>\
               <div title="" style="position:absolute"><select id="__containerId__-page271612227-layer-combobox385567715select" onblur="rabbit.facade.raiseEvent(rabbit.events.svgBlur, \'__containerId__-page271612227-layer-combobox385567715_input_svg_border\')" onfocus="rabbit.facade.raiseEvent(rabbit.events.svgFocus, \'__containerId__-page271612227-layer-combobox385567715_input_svg_border\')" style="width:146px; height:26px;" title="">\
                     <option title="">Trạng thái</option>\
                     <option title="">Active</option>\
                     <option title="">Deactive</option></select></div>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page271612227-layer-iphoneButton485347976" style="position: absolute; left: 1180px; top: 880px; width: 88px; height: 30px" data-interactive-element-type="default.iphoneButton" class="iphoneButton stencil mobile-interaction-potential-trigger " data-stencil-id="iphoneButton485347976" data-review-reference-id="iphoneButton485347976">\
         <div class="stencil-wrapper" style="width: 88px; height: 30px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" title="" style="position: absolute; left: -2px; top: -2px;height: 34px;width:92px;">\
               <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" class="helvetica-font" width="92" height="34" viewBox="-2 -2 92 34">\
                  <svg:a><svg:path d="M 4.00, 29.00 Q 3.41, 27.67, 2.65, 27.35 Q 1.79, 26.79, 1.53, 25.83 Q 0.62, 14.06, 0.65, 1.94 Q 1.92, 1.14, 1.92,\
                     -0.07 Q 3.13, -0.32, 3.80, -1.61 Q 14.18, -1.49, 24.49, -1.20 Q 34.75, -0.90, 45.00, -0.77 Q 55.25, -0.97, 65.50, -1.80 Q\
                     75.75, -0.67, 85.87, -0.45 Q 87.15, -0.90, 88.52, -0.58 Q 88.98, 0.64, 89.43, 1.86 Q 90.02, 13.85, 89.56, 26.09 Q 89.52, 27.34,\
                     88.39, 28.35 Q 87.24, 28.83, 86.26, 29.81 Q 75.82, 29.50, 65.56, 29.84 Q 55.27, 29.42, 45.03, 30.59 Q 34.76, 29.79, 24.50,\
                     29.27 Q 14.25, 29.00, 4.00, 29.00" style="fill-rule:evenodd;clip-rule:evenodd;fill:#808080;stroke:#666666;" class="svg_unselected_element"/>\
                     <svg:text x="44" y="15" dy="0.3em" fill="#FFFFFF" style="font-size:1em;stroke-width:0pt;" font-family="\'HelveticaNeue-Bold\'" text-anchor="middle" xml:space="preserve">Lưu thay đổi</svg:text>\
                  </svg:a>\
               </svg:svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page271612227-layer-857703320" style="position: absolute; left: 315px; top: 125px; width: 67px; height: 20px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="857703320" data-review-reference-id="857703320">\
         <div class="stencil-wrapper" style="width: 67px; height: 20px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline32"><p><span style="font-size: 18px;">Họ tên:</span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page271612227-layer-542178574" style="position: absolute; left: 475px; top: 110px; width: 275px; height: 30px" data-interactive-element-type="default.textinput" class="textinput stencil mobile-interaction-potential-trigger " data-stencil-id="542178574" data-review-reference-id="542178574">\
         <div class="stencil-wrapper" style="width: 275px; height: 30px">\
            <div>\
               <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" style="height: 30px;width:275px;" width="275" height="30">\
                  <svg:g id="__containerId__-page271612227-layer-542178574svg" width="275" height="30"><svg:path id="__containerId__-page271612227-layer-542178574_input_svg_border" d="M 2.00, 2.00 Q 12.42, 1.72, 22.85, 1.58 Q\
                     33.27, 1.53, 43.69, 1.48 Q 54.12, 1.17, 64.54, 1.65 Q 74.96, 1.96, 85.38, 1.53 Q 95.81, 1.45, 106.23, 0.99 Q 116.65, 1.79,\
                     127.08, 1.60 Q 137.50, 2.38, 147.92, 2.13 Q 158.35, 1.51, 168.77, 2.10 Q 179.19, 2.10, 189.62, 2.32 Q 200.04, 1.63, 210.46,\
                     1.65 Q 220.88, 2.14, 231.31, 2.65 Q 241.73, 1.87, 252.15, 1.82 Q 262.58, 2.32, 272.63, 2.37 Q 272.11, 15.30, 272.81, 27.81\
                     Q 262.51, 27.74, 252.20, 28.40 Q 241.72, 27.74, 231.30, 27.88 Q 220.89, 28.20, 210.46, 27.93 Q 200.04, 27.67, 189.61, 27.62\
                     Q 179.19, 28.20, 168.77, 28.52 Q 158.35, 29.21, 147.92, 28.85 Q 137.50, 28.97, 127.08, 28.67 Q 116.65, 28.39, 106.23, 28.72\
                     Q 95.81, 28.63, 85.38, 29.49 Q 74.96, 29.90, 64.54, 28.94 Q 54.12, 27.90, 43.69, 28.02 Q 33.27, 27.90, 22.85, 27.78 Q 12.42,\
                     27.44, 2.39, 27.61 Q 2.00, 15.00, 2.00, 2.00" style=" fill:white;" class="svg_unselected_element"/><svg:path id="__containerId__-page271612227-layer-542178574_line1" d="M 3.00, 3.00 Q 13.35, 0.97, 23.69, 0.81 Q 34.04, 0.72,\
                     44.38, 0.57 Q 54.73, 1.10, 65.08, 0.94 Q 75.42, 1.20, 85.77, 1.48 Q 96.12, 2.28, 106.46, 1.16 Q 116.81, 1.13, 127.15, 1.17\
                     Q 137.50, 1.77, 147.85, 1.77 Q 158.19, 1.46, 168.54, 2.04 Q 178.88, 2.11, 189.23, 3.19 Q 199.58, 2.63, 209.92, 1.81 Q 220.27,\
                     1.94, 230.62, 1.81 Q 240.96, 1.58, 251.31, 1.76 Q 261.65, 3.00, 272.00, 3.00" style=" fill:none;" class="svg_unselected_element"/><svg:path id="__containerId__-page271612227-layer-542178574_line2" d="M 3.00, 3.00 Q 3.00, 15.00, 3.00, 27.00" style=" fill:none;"\
                     class="svg_unselected_element"/><svg:path id="__containerId__-page271612227-layer-542178574_line3" d="M 3.00, 3.00 Q 13.35, 2.49, 23.69, 2.45 Q 34.04, 2.94,\
                     44.38, 2.73 Q 54.73, 2.58, 65.08, 2.96 Q 75.42, 2.88, 85.77, 2.69 Q 96.12, 2.48, 106.46, 2.77 Q 116.81, 3.97, 127.15, 3.78\
                     Q 137.50, 3.47, 147.85, 2.65 Q 158.19, 3.30, 168.54, 2.69 Q 178.88, 2.99, 189.23, 2.51 Q 199.58, 2.76, 209.92, 3.29 Q 220.27,\
                     3.97, 230.62, 4.13 Q 240.96, 2.86, 251.31, 2.74 Q 261.65, 3.00, 272.00, 3.00" style=" fill:none;" class="svg_unselected_element"/><svg:path id="__containerId__-page271612227-layer-542178574_line4" d="M 3.00, 3.00 Q 3.00, 15.00, 3.00, 27.00" style=" fill:none;"\
                     class="svg_unselected_element"/>\
                  </svg:g>\
               </svg:svg>\
               <div style="position:absolute;left: 6px; top: 1px;" title=""><input id="__containerId__-page271612227-layer-542178574input" onblur="rabbit.facade.raiseEvent(rabbit.events.svgBlur, new Array(\'__containerId__-page271612227-layer-542178574_input_svg_border\',\'__containerId__-page271612227-layer-542178574_line1\',\'__containerId__-page271612227-layer-542178574_line2\',\'__containerId__-page271612227-layer-542178574_line3\',\'__containerId__-page271612227-layer-542178574_line4\'))" onfocus="rabbit.facade.raiseEvent(rabbit.events.svgFocus, new Array(\'__containerId__-page271612227-layer-542178574_input_svg_border\',\'__containerId__-page271612227-layer-542178574_line1\',\'__containerId__-page271612227-layer-542178574_line2\',\'__containerId__-page271612227-layer-542178574_line3\',\'__containerId__-page271612227-layer-542178574_line4\'))" value="" style="width:268px;height:28px;padding: 0px;" type="text" /></div>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page271612227-layer-1722534564" style="position: absolute; left: 475px; top: 170px; width: 275px; height: 30px" data-interactive-element-type="default.textinput" class="textinput stencil mobile-interaction-potential-trigger " data-stencil-id="1722534564" data-review-reference-id="1722534564">\
         <div class="stencil-wrapper" style="width: 275px; height: 30px">\
            <div>\
               <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" style="height: 30px;width:275px;" width="275" height="30">\
                  <svg:g id="__containerId__-page271612227-layer-1722534564svg" width="275" height="30"><svg:path id="__containerId__-page271612227-layer-1722534564_input_svg_border" d="M 2.00, 2.00 Q 12.42, 2.83, 22.85, 1.76\
                     Q 33.27, 1.71, 43.69, 0.52 Q 54.12, 1.88, 64.54, 1.72 Q 74.96, 1.12, 85.38, 0.35 Q 95.81, 1.06, 106.23, 1.15 Q 116.65, 0.96,\
                     127.08, 0.85 Q 137.50, 0.26, 147.92, 1.04 Q 158.35, 0.59, 168.77, 1.29 Q 179.19, 1.06, 189.62, 1.47 Q 200.04, 1.76, 210.46,\
                     0.89 Q 220.88, 1.04, 231.31, 0.51 Q 241.73, 0.98, 252.15, 1.39 Q 262.58, 1.07, 273.58, 1.42 Q 273.70, 14.77, 273.21, 28.21\
                     Q 262.74, 28.59, 252.26, 28.97 Q 241.76, 28.48, 231.30, 27.81 Q 220.89, 28.18, 210.46, 27.94 Q 200.04, 27.87, 189.62, 28.07\
                     Q 179.19, 27.62, 168.77, 28.13 Q 158.35, 29.00, 147.92, 29.11 Q 137.50, 28.64, 127.08, 28.59 Q 116.65, 29.48, 106.23, 29.95\
                     Q 95.81, 29.84, 85.38, 29.72 Q 74.96, 29.02, 64.54, 29.28 Q 54.12, 29.66, 43.69, 28.98 Q 33.27, 29.58, 22.85, 29.35 Q 12.42,\
                     29.11, 1.08, 28.92 Q 2.00, 15.00, 2.00, 2.00" style=" fill:white;" class="svg_unselected_element"/><svg:path id="__containerId__-page271612227-layer-1722534564_line1" d="M 3.00, 3.00 Q 13.35, 1.15, 23.69, 1.47 Q 34.04, 2.05,\
                     44.38, 1.77 Q 54.73, 1.52, 65.08, 1.98 Q 75.42, 1.30, 85.77, 1.72 Q 96.12, 1.67, 106.46, 1.49 Q 116.81, 1.91, 127.15, 2.40\
                     Q 137.50, 2.29, 147.85, 1.78 Q 158.19, 2.06, 168.54, 2.70 Q 178.88, 2.94, 189.23, 2.28 Q 199.58, 1.96, 209.92, 1.82 Q 220.27,\
                     2.60, 230.62, 2.20 Q 240.96, 2.58, 251.31, 2.43 Q 261.65, 3.00, 272.00, 3.00" style=" fill:none;" class="svg_unselected_element"/><svg:path id="__containerId__-page271612227-layer-1722534564_line2" d="M 3.00, 3.00 Q 3.00, 15.00, 3.00, 27.00" style=" fill:none;"\
                     class="svg_unselected_element"/><svg:path id="__containerId__-page271612227-layer-1722534564_line3" d="M 3.00, 3.00 Q 13.35, 1.50, 23.69, 1.61 Q 34.04, 1.82,\
                     44.38, 2.06 Q 54.73, 2.47, 65.08, 1.84 Q 75.42, 1.73, 85.77, 2.16 Q 96.12, 2.44, 106.46, 2.81 Q 116.81, 2.16, 127.15, 2.29\
                     Q 137.50, 2.54, 147.85, 2.38 Q 158.19, 2.51, 168.54, 2.70 Q 178.88, 2.90, 189.23, 2.91 Q 199.58, 2.48, 209.92, 2.72 Q 220.27,\
                     2.06, 230.62, 1.53 Q 240.96, 1.76, 251.31, 1.83 Q 261.65, 3.00, 272.00, 3.00" style=" fill:none;" class="svg_unselected_element"/><svg:path id="__containerId__-page271612227-layer-1722534564_line4" d="M 3.00, 3.00 Q 3.00, 15.00, 3.00, 27.00" style=" fill:none;"\
                     class="svg_unselected_element"/>\
                  </svg:g>\
               </svg:svg>\
               <div style="position:absolute;left: 6px; top: 1px;" title=""><input id="__containerId__-page271612227-layer-1722534564input" onblur="rabbit.facade.raiseEvent(rabbit.events.svgBlur, new Array(\'__containerId__-page271612227-layer-1722534564_input_svg_border\',\'__containerId__-page271612227-layer-1722534564_line1\',\'__containerId__-page271612227-layer-1722534564_line2\',\'__containerId__-page271612227-layer-1722534564_line3\',\'__containerId__-page271612227-layer-1722534564_line4\'))" onfocus="rabbit.facade.raiseEvent(rabbit.events.svgFocus, new Array(\'__containerId__-page271612227-layer-1722534564_input_svg_border\',\'__containerId__-page271612227-layer-1722534564_line1\',\'__containerId__-page271612227-layer-1722534564_line2\',\'__containerId__-page271612227-layer-1722534564_line3\',\'__containerId__-page271612227-layer-1722534564_line4\'))" value="" style="width:268px;height:28px;padding: 0px;" type="text" /></div>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page271612227-layer-239335217" style="position: absolute; left: 315px; top: 185px; width: 56px; height: 21px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="239335217" data-review-reference-id="239335217">\
         <div class="stencil-wrapper" style="width: 56px; height: 21px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline32"><p><span style="font-size: 18px;">Email:</span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page271612227-layer-2135516536" style="position: absolute; left: 315px; top: 245px; width: 91px; height: 21px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="2135516536" data-review-reference-id="2135516536">\
         <div class="stencil-wrapper" style="width: 91px; height: 21px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline32"><p><span style="font-size: 18px;">Ngày sinh:</span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page271612227-layer-694368928" style="position: absolute; left: 475px; top: 235px; width: 150px; height: 30px" data-interactive-element-type="default.datepicker" class="datepicker stencil mobile-interaction-potential-trigger " data-stencil-id="694368928" data-review-reference-id="694368928">\
         <div class="stencil-wrapper" style="width: 150px; height: 30px">\
            <div>\
               <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" style="position: absolute; height: 30px;width:150px;" width="150" height="30">\
                  <svg:g width="150px" height="30px"><svg:path id="__containerId__-page271612227-layer-694368928_input_svg_border" d="M 2.00, 2.00 Q 13.20, 1.83, 24.40, 2.15 Q\
                     35.60, 2.37, 46.80, 2.34 Q 58.00, 2.09, 69.20, 1.79 Q 80.40, 1.72, 91.60, 1.68 Q 102.80, 1.79, 114.52, 1.48 Q 114.55, 14.82,\
                     114.55, 28.55 Q 103.06, 28.95, 91.70, 28.87 Q 80.46, 29.21, 69.23, 29.08 Q 58.01, 28.96, 46.81, 28.85 Q 35.60, 29.69, 24.40,\
                     29.94 Q 13.20, 28.84, 1.41, 28.59 Q 2.00, 15.00, 2.00, 2.00" style=" fill:white;" class="svg_unselected_element"/><svg:path id="__containerId__-page271612227-layer-694368928_line1" d="M 3.00, 3.00 Q 14.90, 3.21, 26.80, 3.28 Q 38.70, 2.90,\
                     50.60, 3.10 Q 62.50, 2.52, 74.40, 2.10 Q 86.30, 2.04, 98.20, 2.36 Q 110.10, 3.00, 122.00, 3.00" style=" fill:none;" class="svg_unselected_element"/><svg:path id="__containerId__-page271612227-layer-694368928_line2" d="M 3.00, 3.00 Q 3.00, 15.00, 3.00, 27.00" style=" fill:none;"\
                     class="svg_unselected_element"/><svg:path id="__containerId__-page271612227-layer-694368928_line3" d="M 3.00, 3.00 Q 14.90, 2.29, 26.80, 2.24 Q 38.70, 2.40,\
                     50.60, 2.19 Q 62.50, 2.02, 74.40, 2.50 Q 86.30, 2.27, 98.20, 2.06 Q 110.10, 3.00, 122.00, 3.00" style=" fill:none;" class="svg_unselected_element"/><svg:path id="__containerId__-page271612227-layer-694368928_line4" d="M 3.00, 3.00 Q 3.00, 15.00, 3.00, 27.00" style=" fill:none;"\
                     class="svg_unselected_element"/>\
                  </svg:g>\
                  <svg:g width="150px" height="30px"><svg:path id="__containerId__-page271612227-layer-694368928_input_svg_border2" d="M 118.00, 2.00 Q 133.00, 1.90, 148.57, 1.43\
                     Q 148.90, 14.70, 148.42, 28.42 Q 133.19, 28.70, 117.72, 28.23 Q 118.00, 15.00, 118.00, 2.00" style=" fill:white;" class="svg_unselected_element"/>\
                  </svg:g>\
               </svg:svg>\
               <div style="white-space: nowrap;" title=""><input type="text" onblur="rabbit.facade.raiseEvent(rabbit.events.svgBlur, new Array(\'__containerId__-page271612227-layer-694368928_input_svg_border\',\'__containerId__-page271612227-layer-694368928_line1\',\'__containerId__-page271612227-layer-694368928_line2\',\'__containerId__-page271612227-layer-694368928_line3\',\'__containerId__-page271612227-layer-694368928_line4\'))" onfocus="rabbit.facade.raiseEvent(rabbit.events.svgFocus, new Array(\'__containerId__-page271612227-layer-694368928_input_svg_border\',\'__containerId__-page271612227-layer-694368928_line1\',\'__containerId__-page271612227-layer-694368928_line2\',\'__containerId__-page271612227-layer-694368928_line3\',\'__containerId__-page271612227-layer-694368928_line4\'))" style="width:116px; height:30px;padding: 0px;border-width:1px; position: absolute;" id="__containerId__-page271612227-layer-694368928_input" /><button type="button" onblur="rabbit.facade.raiseEvent(rabbit.events.svgBlur, \'__containerId__-page271612227-layer-694368928_input_svg_border2\')" onfocus="rabbit.facade.raiseEvent(rabbit.events.svgFocus, \'__containerId__-page271612227-layer-694368928_input_svg_border2\')" style="position:absolute; left:116px; top:0px; width:34px; height:30px; vertical-align: top; padding: 0px;border-width:1px; cursor:pointer;" id="__containerId__-page271612227-layer-694368928_button"><img src="../resources/icons/date.png" /></button></div>\
               <div id="__containerId__-page271612227-layer-694368928_ov" class="yui-skin-sam" style="position: absolute; width: 16em;visibility:visible;">\
                  <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" style="position: absolute; left: -6px; top: -4px; height: 204px;width:200px;display:none" id="__containerId__-page271612227-layer-694368928_open_calendar" width="150" height="204"><svg:path id="__containerId__-page271612227-layer-694368928_open_calendar_border" d="M 2.00, 2.00 Q 12.89, 0.62, 23.78, 0.35\
                     Q 34.67, 0.29, 45.56, 0.02 Q 56.44, -0.05, 67.33, 1.19 Q 78.22, 0.19, 89.11, -0.11 Q 100.00, -0.29, 110.89, -0.39 Q 121.78,\
                     0.01, 132.67, 1.41 Q 143.56, 1.02, 154.44, 0.40 Q 165.33, 0.23, 176.22, 0.19 Q 187.11, 0.07, 198.79, 1.21 Q 199.17, 11.61,\
                     199.55, 21.78 Q 199.85, 31.88, 199.76, 41.94 Q 198.21, 52.00, 197.54, 62.00 Q 197.51, 72.00, 198.00, 82.00 Q 198.55, 92.00,\
                     198.50, 102.00 Q 198.79, 112.00, 199.04, 122.00 Q 198.86, 132.00, 199.02, 142.00 Q 199.35, 152.00, 199.42, 162.00 Q 198.50,\
                     172.00, 198.35, 182.00 Q 197.91, 192.00, 198.07, 202.07 Q 187.30, 202.56, 176.33, 202.76 Q 165.42, 203.28, 154.49, 203.33\
                     Q 143.59, 203.86, 132.68, 203.72 Q 121.78, 203.09, 110.89, 203.05 Q 100.00, 203.10, 89.11, 203.05 Q 78.22, 202.81, 67.33,\
                     203.02 Q 56.44, 202.82, 45.56, 202.98 Q 34.67, 202.70, 23.78, 203.34 Q 12.89, 201.77, 2.08, 201.92 Q 1.83, 192.06, 1.41, 182.08\
                     Q 0.74, 172.08, 0.92, 162.03 Q 1.03, 152.02, 1.00, 142.01 Q 0.95, 132.00, 1.61, 122.00 Q 1.51, 112.00, 1.06, 102.00 Q 1.52,\
                     92.00, 0.55, 82.00 Q 1.36, 72.00, 1.70, 62.00 Q 2.10, 52.00, 2.17, 42.00 Q 3.27, 32.00, 2.84, 22.00 Q 2.00, 12.00, 2.00, 2.00"\
                     style=" fill:white;" class="svg_unselected_element"/>\
                  </svg:svg>\
                  <div id="__containerId__-page271612227-layer-694368928_cal"></div>\
               </div><script type="text/javascript">\
				rabbit.stencils.datepicker.setupDatepicker("__containerId__-page271612227-layer-694368928");\
			</script></div>\
         </div>\
      </div>\
      <div id="__containerId__-page271612227-layer-520739904" style="position: absolute; left: 825px; top: 125px; width: 45px; height: 21px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="520739904" data-review-reference-id="520739904">\
         <div class="stencil-wrapper" style="width: 45px; height: 21px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline32"><p><span style="font-size: 18px;">SĐT:</span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page271612227-layer-898593973" style="position: absolute; left: 875px; top: 120px; width: 275px; height: 30px" data-interactive-element-type="default.textinput" class="textinput stencil mobile-interaction-potential-trigger " data-stencil-id="898593973" data-review-reference-id="898593973">\
         <div class="stencil-wrapper" style="width: 275px; height: 30px">\
            <div>\
               <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" style="height: 30px;width:275px;" width="275" height="30">\
                  <svg:g id="__containerId__-page271612227-layer-898593973svg" width="275" height="30"><svg:path id="__containerId__-page271612227-layer-898593973_input_svg_border" d="M 2.00, 2.00 Q 12.42, 1.19, 22.85, 0.66 Q\
                     33.27, 0.69, 43.69, 0.69 Q 54.12, 1.08, 64.54, 0.75 Q 74.96, 0.76, 85.38, 0.60 Q 95.81, 0.82, 106.23, 1.39 Q 116.65, 1.67,\
                     127.08, 1.48 Q 137.50, 1.37, 147.92, 1.43 Q 158.35, 1.43, 168.77, 1.51 Q 179.19, 1.65, 189.62, 1.25 Q 200.04, 1.08, 210.46,\
                     0.70 Q 220.88, 1.06, 231.31, 1.15 Q 241.73, 1.63, 252.15, 1.58 Q 262.58, 1.79, 273.37, 1.63 Q 273.69, 14.77, 273.50, 28.50\
                     Q 262.77, 28.69, 252.26, 28.91 Q 241.78, 28.88, 231.32, 28.59 Q 220.89, 28.47, 210.46, 28.05 Q 200.04, 28.83, 189.62, 28.75\
                     Q 179.19, 29.37, 168.77, 29.50 Q 158.35, 29.53, 147.92, 29.90 Q 137.50, 29.34, 127.08, 29.16 Q 116.65, 28.41, 106.23, 29.04\
                     Q 95.81, 27.42, 85.38, 27.91 Q 74.96, 28.24, 64.54, 28.31 Q 54.12, 27.87, 43.69, 27.75 Q 33.27, 28.04, 22.85, 28.76 Q 12.42,\
                     28.33, 1.89, 28.11 Q 2.00, 15.00, 2.00, 2.00" style=" fill:white;" class="svg_unselected_element"/><svg:path id="__containerId__-page271612227-layer-898593973_line1" d="M 3.00, 3.00 Q 13.35, 1.68, 23.69, 1.41 Q 34.04, 1.31,\
                     44.38, 0.98 Q 54.73, 1.07, 65.08, 1.36 Q 75.42, 1.46, 85.77, 0.88 Q 96.12, 0.77, 106.46, 0.85 Q 116.81, 0.58, 127.15, 1.27\
                     Q 137.50, 2.21, 147.85, 1.79 Q 158.19, 1.18, 168.54, 1.23 Q 178.88, 1.13, 189.23, 0.92 Q 199.58, 2.04, 209.92, 1.18 Q 220.27,\
                     1.17, 230.62, 1.20 Q 240.96, 1.04, 251.31, 1.82 Q 261.65, 3.00, 272.00, 3.00" style=" fill:none;" class="svg_unselected_element"/><svg:path id="__containerId__-page271612227-layer-898593973_line2" d="M 3.00, 3.00 Q 3.00, 15.00, 3.00, 27.00" style=" fill:none;"\
                     class="svg_unselected_element"/><svg:path id="__containerId__-page271612227-layer-898593973_line3" d="M 3.00, 3.00 Q 13.35, 0.74, 23.69, 0.58 Q 34.04, 0.86,\
                     44.38, 0.88 Q 54.73, 0.88, 65.08, 1.20 Q 75.42, 1.22, 85.77, 1.14 Q 96.12, 0.90, 106.46, 0.90 Q 116.81, 1.94, 127.15, 2.15\
                     Q 137.50, 1.85, 147.85, 1.85 Q 158.19, 1.82, 168.54, 1.64 Q 178.88, 1.33, 189.23, 1.27 Q 199.58, 1.61, 209.92, 1.57 Q 220.27,\
                     1.86, 230.62, 2.68 Q 240.96, 2.15, 251.31, 2.56 Q 261.65, 3.00, 272.00, 3.00" style=" fill:none;" class="svg_unselected_element"/><svg:path id="__containerId__-page271612227-layer-898593973_line4" d="M 3.00, 3.00 Q 3.00, 15.00, 3.00, 27.00" style=" fill:none;"\
                     class="svg_unselected_element"/>\
                  </svg:g>\
               </svg:svg>\
               <div style="position:absolute;left: 6px; top: 1px;" title=""><input id="__containerId__-page271612227-layer-898593973input" onblur="rabbit.facade.raiseEvent(rabbit.events.svgBlur, new Array(\'__containerId__-page271612227-layer-898593973_input_svg_border\',\'__containerId__-page271612227-layer-898593973_line1\',\'__containerId__-page271612227-layer-898593973_line2\',\'__containerId__-page271612227-layer-898593973_line3\',\'__containerId__-page271612227-layer-898593973_line4\'))" onfocus="rabbit.facade.raiseEvent(rabbit.events.svgFocus, new Array(\'__containerId__-page271612227-layer-898593973_input_svg_border\',\'__containerId__-page271612227-layer-898593973_line1\',\'__containerId__-page271612227-layer-898593973_line2\',\'__containerId__-page271612227-layer-898593973_line3\',\'__containerId__-page271612227-layer-898593973_line4\'))" value="" style="width:268px;height:28px;padding: 0px;" type="text" /></div>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page271612227-layer-1725358062" style="position: absolute; left: 1150px; top: 120px; width: 32px; height: 32px" data-interactive-element-type="fonticon.icon" class="icon stencil mobile-interaction-potential-trigger " data-stencil-id="1725358062" data-review-reference-id="1725358062">\
         <div class="stencil-wrapper" style="width: 32px; height: 32px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" style="width:32px;height:32px;" title="">\
               <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" class="fill-blue">\
                  <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#icon-glyph-e337"></use>\
               </svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page271612227-layer-715721669" style="position: absolute; left: 310px; top: 320px; width: 111px; height: 21px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="715721669" data-review-reference-id="715721669">\
         <div class="stencil-wrapper" style="width: 111px; height: 21px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline32"><p><span style="font-size: 18px;">Số tài khoản:</span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page271612227-layer-656986165" style="position: absolute; left: 475px; top: 310px; width: 275px; height: 30px" data-interactive-element-type="default.textinput" class="textinput stencil mobile-interaction-potential-trigger " data-stencil-id="656986165" data-review-reference-id="656986165">\
         <div class="stencil-wrapper" style="width: 275px; height: 30px">\
            <div>\
               <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" style="height: 30px;width:275px;" width="275" height="30">\
                  <svg:g id="__containerId__-page271612227-layer-656986165svg" width="275" height="30"><svg:path id="__containerId__-page271612227-layer-656986165_input_svg_border" d="M 2.00, 2.00 Q 12.42, 0.67, 22.85, 0.53 Q\
                     33.27, 0.44, 43.69, 0.16 Q 54.12, 0.66, 64.54, 1.23 Q 74.96, 0.68, 85.38, 0.18 Q 95.81, 0.29, 106.23, 0.87 Q 116.65, 0.27,\
                     127.08, 1.26 Q 137.50, 0.68, 147.92, -0.13 Q 158.35, -0.26, 168.77, 0.18 Q 179.19, 0.69, 189.62, 1.60 Q 200.04, 2.07, 210.46,\
                     2.22 Q 220.88, 1.31, 231.31, 0.85 Q 241.73, 1.21, 252.15, 1.96 Q 262.58, 2.73, 273.18, 1.82 Q 272.98, 15.01, 273.57, 28.57\
                     Q 262.87, 29.08, 252.32, 29.50 Q 241.80, 29.34, 231.34, 29.25 Q 220.90, 29.38, 210.46, 28.56 Q 200.04, 28.84, 189.62, 27.78\
                     Q 179.19, 28.06, 168.77, 28.89 Q 158.35, 29.21, 147.92, 29.08 Q 137.50, 29.13, 127.08, 29.88 Q 116.65, 28.98, 106.23, 29.58\
                     Q 95.81, 29.97, 85.38, 30.12 Q 74.96, 30.18, 64.54, 29.71 Q 54.12, 28.76, 43.69, 28.34 Q 33.27, 29.01, 22.85, 29.56 Q 12.42,\
                     28.98, 1.98, 28.02 Q 2.00, 15.00, 2.00, 2.00" style=" fill:white;" class="svg_unselected_element"/><svg:path id="__containerId__-page271612227-layer-656986165_line1" d="M 3.00, 3.00 Q 13.35, 1.52, 23.69, 1.88 Q 34.04, 2.30,\
                     44.38, 2.66 Q 54.73, 3.32, 65.08, 2.74 Q 75.42, 2.34, 85.77, 2.28 Q 96.12, 3.03, 106.46, 2.97 Q 116.81, 3.51, 127.15, 2.87\
                     Q 137.50, 2.48, 147.85, 2.27 Q 158.19, 2.15, 168.54, 2.06 Q 178.88, 1.68, 189.23, 2.86 Q 199.58, 2.32, 209.92, 2.64 Q 220.27,\
                     2.60, 230.62, 3.36 Q 240.96, 3.79, 251.31, 2.48 Q 261.65, 3.00, 272.00, 3.00" style=" fill:none;" class="svg_unselected_element"/><svg:path id="__containerId__-page271612227-layer-656986165_line2" d="M 3.00, 3.00 Q 3.00, 15.00, 3.00, 27.00" style=" fill:none;"\
                     class="svg_unselected_element"/><svg:path id="__containerId__-page271612227-layer-656986165_line3" d="M 3.00, 3.00 Q 13.35, 2.59, 23.69, 2.35 Q 34.04, 2.00,\
                     44.38, 2.75 Q 54.73, 1.93, 65.08, 1.07 Q 75.42, 0.64, 85.77, 1.74 Q 96.12, 1.77, 106.46, 1.13 Q 116.81, 1.41, 127.15, 1.29\
                     Q 137.50, 1.16, 147.85, 1.13 Q 158.19, 1.65, 168.54, 2.55 Q 178.88, 2.89, 189.23, 2.34 Q 199.58, 1.46, 209.92, 1.43 Q 220.27,\
                     2.12, 230.62, 2.18 Q 240.96, 1.91, 251.31, 2.13 Q 261.65, 3.00, 272.00, 3.00" style=" fill:none;" class="svg_unselected_element"/><svg:path id="__containerId__-page271612227-layer-656986165_line4" d="M 3.00, 3.00 Q 3.00, 15.00, 3.00, 27.00" style=" fill:none;"\
                     class="svg_unselected_element"/>\
                  </svg:g>\
               </svg:svg>\
               <div style="position:absolute;left: 6px; top: 1px;" title=""><input id="__containerId__-page271612227-layer-656986165input" onblur="rabbit.facade.raiseEvent(rabbit.events.svgBlur, new Array(\'__containerId__-page271612227-layer-656986165_input_svg_border\',\'__containerId__-page271612227-layer-656986165_line1\',\'__containerId__-page271612227-layer-656986165_line2\',\'__containerId__-page271612227-layer-656986165_line3\',\'__containerId__-page271612227-layer-656986165_line4\'))" onfocus="rabbit.facade.raiseEvent(rabbit.events.svgFocus, new Array(\'__containerId__-page271612227-layer-656986165_input_svg_border\',\'__containerId__-page271612227-layer-656986165_line1\',\'__containerId__-page271612227-layer-656986165_line2\',\'__containerId__-page271612227-layer-656986165_line3\',\'__containerId__-page271612227-layer-656986165_line4\'))" value="" style="width:268px;height:28px;padding: 0px;" type="text" /></div>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page271612227-layer-445581969" style="position: absolute; left: 315px; top: 390px; width: 74px; height: 20px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="445581969" data-review-reference-id="445581969">\
         <div class="stencil-wrapper" style="width: 74px; height: 20px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline32"><p class="none" style="font-size: 18px;">Địa chỉ: </p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page271612227-layer-411085646" style="position: absolute; left: 475px; top: 385px; width: 275px; height: 30px" data-interactive-element-type="default.textinput" class="textinput stencil mobile-interaction-potential-trigger " data-stencil-id="411085646" data-review-reference-id="411085646">\
         <div class="stencil-wrapper" style="width: 275px; height: 30px">\
            <div>\
               <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" style="height: 30px;width:275px;" width="275" height="30">\
                  <svg:g id="__containerId__-page271612227-layer-411085646svg" width="275" height="30"><svg:path id="__containerId__-page271612227-layer-411085646_input_svg_border" d="M 2.00, 2.00 Q 12.42, -0.41, 22.85, -0.00\
                     Q 33.27, 0.21, 43.69, 0.36 Q 54.12, 0.13, 64.54, 0.25 Q 74.96, 0.59, 85.38, 1.28 Q 95.81, 1.08, 106.23, 1.05 Q 116.65, 0.97,\
                     127.08, 0.97 Q 137.50, 0.47, 147.92, 0.70 Q 158.35, 1.45, 168.77, 1.54 Q 179.19, 1.43, 189.62, 1.22 Q 200.04, 1.04, 210.46,\
                     0.99 Q 220.88, 0.97, 231.31, 0.74 Q 241.73, 0.61, 252.15, 0.81 Q 262.58, 0.46, 273.64, 1.36 Q 274.12, 14.63, 273.35, 28.35\
                     Q 262.58, 28.00, 252.16, 28.07 Q 241.72, 27.70, 231.31, 28.18 Q 220.89, 28.04, 210.46, 28.21 Q 200.04, 28.00, 189.62, 27.98\
                     Q 179.19, 28.14, 168.77, 28.37 Q 158.35, 28.67, 147.92, 29.01 Q 137.50, 28.56, 127.08, 28.89 Q 116.65, 29.05, 106.23, 28.88\
                     Q 95.81, 28.07, 85.38, 28.74 Q 74.96, 28.38, 64.54, 29.09 Q 54.12, 29.13, 43.69, 29.72 Q 33.27, 28.98, 22.85, 28.86 Q 12.42,\
                     29.06, 1.40, 28.60 Q 2.00, 15.00, 2.00, 2.00" style=" fill:white;" class="svg_unselected_element"/><svg:path id="__containerId__-page271612227-layer-411085646_line1" d="M 3.00, 3.00 Q 13.35, 1.80, 23.69, 1.98 Q 34.04, 1.59,\
                     44.38, 2.11 Q 54.73, 1.29, 65.08, 1.84 Q 75.42, 2.43, 85.77, 2.86 Q 96.12, 1.98, 106.46, 1.49 Q 116.81, 2.08, 127.15, 1.77\
                     Q 137.50, 1.57, 147.85, 1.75 Q 158.19, 2.47, 168.54, 2.82 Q 178.88, 3.30, 189.23, 2.73 Q 199.58, 2.34, 209.92, 2.55 Q 220.27,\
                     2.58, 230.62, 2.93 Q 240.96, 2.22, 251.31, 2.69 Q 261.65, 3.00, 272.00, 3.00" style=" fill:none;" class="svg_unselected_element"/><svg:path id="__containerId__-page271612227-layer-411085646_line2" d="M 3.00, 3.00 Q 3.00, 15.00, 3.00, 27.00" style=" fill:none;"\
                     class="svg_unselected_element"/><svg:path id="__containerId__-page271612227-layer-411085646_line3" d="M 3.00, 3.00 Q 13.35, 2.06, 23.69, 1.84 Q 34.04, 1.61,\
                     44.38, 1.34 Q 54.73, 1.06, 65.08, 1.19 Q 75.42, 1.52, 85.77, 1.39 Q 96.12, 1.30, 106.46, 1.06 Q 116.81, 1.20, 127.15, 1.19\
                     Q 137.50, 1.69, 147.85, 1.80 Q 158.19, 1.84, 168.54, 1.66 Q 178.88, 1.91, 189.23, 1.73 Q 199.58, 1.97, 209.92, 1.39 Q 220.27,\
                     1.23, 230.62, 1.66 Q 240.96, 2.14, 251.31, 1.55 Q 261.65, 3.00, 272.00, 3.00" style=" fill:none;" class="svg_unselected_element"/><svg:path id="__containerId__-page271612227-layer-411085646_line4" d="M 3.00, 3.00 Q 3.00, 15.00, 3.00, 27.00" style=" fill:none;"\
                     class="svg_unselected_element"/>\
                  </svg:g>\
               </svg:svg>\
               <div style="position:absolute;left: 6px; top: 1px;" title=""><input id="__containerId__-page271612227-layer-411085646input" onblur="rabbit.facade.raiseEvent(rabbit.events.svgBlur, new Array(\'__containerId__-page271612227-layer-411085646_input_svg_border\',\'__containerId__-page271612227-layer-411085646_line1\',\'__containerId__-page271612227-layer-411085646_line2\',\'__containerId__-page271612227-layer-411085646_line3\',\'__containerId__-page271612227-layer-411085646_line4\'))" onfocus="rabbit.facade.raiseEvent(rabbit.events.svgFocus, new Array(\'__containerId__-page271612227-layer-411085646_input_svg_border\',\'__containerId__-page271612227-layer-411085646_line1\',\'__containerId__-page271612227-layer-411085646_line2\',\'__containerId__-page271612227-layer-411085646_line3\',\'__containerId__-page271612227-layer-411085646_line4\'))" value="" style="width:268px;height:28px;padding: 0px;" type="text" /></div>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page271612227-layer-383946518" style="position: absolute; left: 300px; top: 490px; width: 1020px; height: 33px" data-interactive-element-type="static.line" class="line stencil mobile-interaction-potential-trigger " data-stencil-id="383946518" data-review-reference-id="383946518">\
         <div class="stencil-wrapper" style="width: 1020px; height: 33px">\
            <div title="">\
               <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" style="position: absolute; left: -5px; top: -5px; height: 43px;width:1030px;" viewBox="-5 -5 1030 43" width="1030" height="43"><svg:path d="M 0.00, 16.00 Q 10.00, 16.93, 20.00, 17.04 Q 30.00, 16.95, 40.00, 16.65 Q 50.00, 15.74, 60.00, 15.50 Q 70.00,\
                  15.12, 80.00, 15.58 Q 90.00, 15.35, 100.00, 14.61 Q 110.00, 15.40, 120.00, 15.40 Q 130.00, 15.28, 140.00, 15.96 Q 150.00,\
                  15.30, 160.00, 15.25 Q 170.00, 14.93, 180.00, 14.52 Q 190.00, 15.03, 200.00, 14.04 Q 210.00, 14.16, 220.00, 14.89 Q 230.00,\
                  14.78, 240.00, 14.49 Q 250.00, 14.44, 260.00, 14.35 Q 270.00, 14.98, 280.00, 15.38 Q 290.00, 14.83, 300.00, 14.05 Q 310.00,\
                  13.87, 320.00, 13.78 Q 330.00, 14.17, 340.00, 14.13 Q 350.00, 13.96, 360.00, 14.05 Q 370.00, 14.62, 380.00, 14.55 Q 390.00,\
                  13.90, 400.00, 14.19 Q 410.00, 14.91, 420.00, 14.59 Q 430.00, 15.34, 440.00, 15.38 Q 450.00, 15.10, 460.00, 15.10 Q 470.00,\
                  15.23, 480.00, 15.00 Q 490.00, 14.94, 500.00, 14.84 Q 510.00, 14.46, 520.00, 14.49 Q 530.00, 15.06, 540.00, 15.46 Q 550.00,\
                  15.60, 560.00, 15.98 Q 570.00, 16.22, 580.00, 15.55 Q 590.00, 15.02, 600.00, 14.35 Q 610.00, 13.96, 620.00, 14.47 Q 630.00,\
                  15.23, 640.00, 14.44 Q 650.00, 15.18, 660.00, 14.92 Q 670.00, 14.86, 680.00, 14.90 Q 690.00, 14.68, 700.00, 14.78 Q 710.00,\
                  15.01, 720.00, 14.88 Q 730.00, 14.39, 740.00, 15.58 Q 750.00, 15.83, 760.00, 15.32 Q 770.00, 15.03, 780.00, 14.74 Q 790.00,\
                  14.46, 800.00, 15.31 Q 810.00, 16.82, 820.00, 16.25 Q 830.00, 15.08, 840.00, 14.69 Q 850.00, 14.44, 860.00, 14.67 Q 870.00,\
                  15.04, 880.00, 14.85 Q 890.00, 14.85, 900.00, 14.87 Q 910.00, 14.56, 920.00, 14.35 Q 930.00, 14.61, 940.00, 14.62 Q 950.00,\
                  14.55, 960.00, 14.90 Q 970.00, 15.03, 980.00, 14.88 Q 990.00, 14.98, 1000.00, 14.55 Q 1010.00, 16.00, 1020.00, 16.00" style="marker-start:;marker-end:"\
                  class="svg_unselected_element"/>\
               </svg:svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page271612227-layer-1813156342" style="position: absolute; left: 285px; top: 925px; width: 1020px; height: 33px" data-interactive-element-type="static.line" class="line stencil mobile-interaction-potential-trigger " data-stencil-id="1813156342" data-review-reference-id="1813156342">\
         <div class="stencil-wrapper" style="width: 1020px; height: 33px">\
            <div title="">\
               <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" style="position: absolute; left: -5px; top: -5px; height: 43px;width:1030px;" viewBox="-5 -5 1030 43" width="1030" height="43"><svg:path d="M 0.00, 16.00 Q 10.00, 17.48, 20.00, 16.58 Q 30.00, 15.93, 40.00, 15.58 Q 50.00, 15.94, 60.00, 15.60 Q 70.00,\
                  14.74, 80.00, 16.01 Q 90.00, 15.52, 100.00, 15.97 Q 110.00, 15.49, 120.00, 15.31 Q 130.00, 15.36, 140.00, 14.39 Q 150.00,\
                  15.15, 160.00, 16.53 Q 170.00, 16.02, 180.00, 16.10 Q 190.00, 15.65, 200.00, 16.30 Q 210.00, 16.77, 220.00, 15.37 Q 230.00,\
                  15.56, 240.00, 15.28 Q 250.00, 16.38, 260.00, 16.28 Q 270.00, 15.14, 280.00, 15.03 Q 290.00, 15.20, 300.00, 15.74 Q 310.00,\
                  16.11, 320.00, 16.72 Q 330.00, 16.13, 340.00, 16.00 Q 350.00, 15.85, 360.00, 16.12 Q 370.00, 15.09, 380.00, 15.05 Q 390.00,\
                  14.86, 400.00, 15.30 Q 410.00, 16.42, 420.00, 16.68 Q 430.00, 14.74, 440.00, 14.43 Q 450.00, 14.51, 460.00, 14.90 Q 470.00,\
                  14.82, 480.00, 14.67 Q 490.00, 14.39, 500.00, 16.61 Q 510.00, 17.17, 520.00, 16.36 Q 530.00, 16.07, 540.00, 15.16 Q 550.00,\
                  15.35, 560.00, 15.02 Q 570.00, 15.25, 580.00, 14.55 Q 590.00, 14.57, 600.00, 15.08 Q 610.00, 15.10, 620.00, 15.18 Q 630.00,\
                  15.31, 640.00, 15.32 Q 650.00, 15.14, 660.00, 14.83 Q 670.00, 14.84, 680.00, 15.44 Q 690.00, 16.12, 700.00, 16.17 Q 710.00,\
                  16.46, 720.00, 16.95 Q 730.00, 17.17, 740.00, 16.02 Q 750.00, 15.07, 760.00, 15.55 Q 770.00, 14.77, 780.00, 14.69 Q 790.00,\
                  14.39, 800.00, 15.13 Q 810.00, 14.98, 820.00, 15.46 Q 830.00, 16.02, 840.00, 15.95 Q 850.00, 14.53, 860.00, 15.13 Q 870.00,\
                  15.59, 880.00, 15.34 Q 890.00, 15.64, 900.00, 15.09 Q 910.00, 15.64, 920.00, 15.83 Q 930.00, 15.59, 940.00, 15.49 Q 950.00,\
                  15.35, 960.00, 14.90 Q 970.00, 14.53, 980.00, 14.36 Q 990.00, 15.01, 1000.00, 15.76 Q 1010.00, 16.00, 1020.00, 16.00" style="marker-start:;marker-end:"\
                  class="svg_unselected_element"/>\
               </svg:svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page271612227-layer-1196557919" style="position: absolute; left: 315px; top: 965px; width: 177px; height: 37px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="1196557919" data-review-reference-id="1196557919">\
         <div class="stencil-wrapper" style="width: 177px; height: 37px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline12"><p><span style="font-size: 32px; color: #658cd9;">Khách hàng</span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page271612227-layer-1535468065" style="position: absolute; left: 1135px; top: 965px; width: 123px; height: 37px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="1535468065" data-review-reference-id="1535468065">\
         <div class="stencil-wrapper" style="width: 123px; height: 37px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline12"><p><span style="font-size: 32px; color: #000000;"><span style="color: #658cd9;">4</span> Người</span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page271612227-layer-220910507" style="position: absolute; left: 315px; top: 1135px; width: 952px; height: 150px" data-interactive-element-type="default.table" class="table stencil mobile-interaction-potential-trigger " data-stencil-id="220910507" data-review-reference-id="220910507">\
         <div class="stencil-wrapper" style="width: 952px; height: 150px">\
            <div title="">\
               <svg:svg xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" style="height: 150px;width:952px;" width="952" height="150">\
                  <svg:g x="0" y="0" width="952" height="150" style="stroke:black;stroke-width:1px;fill:white;"><svg:path d="M 2.00, 2.00 Q 12.09, 3.61, 22.17, 3.76 Q 32.26, 3.23, 42.34, 3.16 Q 52.43, 1.89, 62.51, 1.85 Q 72.60, 1.66,\
                     82.68, 2.39 Q 92.77, 2.21, 102.85, 1.42 Q 112.94, 1.62, 123.02, 1.91 Q 133.11, 2.37, 143.19, 0.65 Q 153.28, 0.96, 163.36,\
                     1.29 Q 173.45, 1.81, 183.53, 2.24 Q 193.62, 2.01, 203.70, 1.12 Q 213.79, 0.69, 223.87, 1.13 Q 233.96, 0.00, 244.04, 0.38 Q\
                     254.13, 0.95, 264.21, 1.50 Q 274.30, 1.60, 284.38, 0.83 Q 294.47, 1.53, 304.55, 1.07 Q 314.64, 0.99, 324.72, 1.02 Q 334.81,\
                     2.19, 344.89, 1.62 Q 354.98, 2.28, 365.06, 2.65 Q 375.15, 2.71, 385.23, 2.69 Q 395.32, 1.71, 405.40, 1.49 Q 415.49, 1.50,\
                     425.57, 1.12 Q 435.66, 1.52, 445.74, 1.87 Q 455.83, 1.32, 465.92, 0.30 Q 476.00, 0.06, 486.09, 0.70 Q 496.17, 0.96, 506.26,\
                     0.80 Q 516.34, 1.34, 526.43, 1.12 Q 536.51, 1.95, 546.60, 1.61 Q 556.68, 0.84, 566.77, 1.90 Q 576.85, 1.78, 586.94, 1.96 Q\
                     597.02, 1.28, 607.11, 0.42 Q 617.19, 0.15, 627.28, 0.12 Q 637.36, -0.16, 647.45, 0.90 Q 657.53, 0.65, 667.62, 2.18 Q 677.70,\
                     1.85, 687.79, 1.36 Q 697.87, 1.93, 707.96, 1.86 Q 718.04, 2.19, 728.13, 2.52 Q 738.21, 1.80, 748.30, 2.77 Q 758.38, 2.27,\
                     768.47, 2.82 Q 778.55, 1.87, 788.64, 0.82 Q 798.72, 0.52, 808.81, 0.51 Q 818.89, 1.06, 828.98, 0.79 Q 839.06, 0.49, 849.15,\
                     0.56 Q 859.23, 0.47, 869.32, 0.88 Q 879.40, 0.79, 889.49, 0.50 Q 899.57, 0.61, 909.66, 0.52 Q 919.74, -0.15, 929.83, 0.90\
                     Q 939.91, -0.40, 950.76, 1.24 Q 951.52, 11.92, 951.86, 22.59 Q 952.41, 33.13, 952.46, 43.63 Q 951.53, 54.12, 951.81, 64.56\
                     Q 951.28, 74.99, 950.45, 85.43 Q 950.54, 95.86, 951.29, 106.29 Q 951.31, 116.71, 950.68, 127.14 Q 949.56, 137.57, 949.92,\
                     147.92 Q 940.13, 148.65, 929.80, 147.80 Q 919.73, 147.72, 909.64, 147.34 Q 899.57, 147.73, 889.49, 147.76 Q 879.40, 147.88,\
                     869.32, 147.87 Q 859.23, 148.03, 849.15, 148.73 Q 839.06, 149.45, 828.98, 149.64 Q 818.89, 149.50, 808.81, 149.14 Q 798.72,\
                     148.16, 788.64, 149.10 Q 778.55, 149.95, 768.47, 150.03 Q 758.38, 148.82, 748.30, 148.54 Q 738.21, 149.32, 728.13, 149.42\
                     Q 718.04, 148.70, 707.96, 148.14 Q 697.87, 149.22, 687.79, 149.68 Q 677.70, 149.62, 667.62, 149.13 Q 657.53, 149.27, 647.45,\
                     148.03 Q 637.36, 148.13, 627.28, 148.98 Q 617.19, 149.25, 607.11, 149.07 Q 597.02, 148.41, 586.94, 148.25 Q 576.85, 148.65,\
                     566.77, 149.27 Q 556.68, 148.17, 546.60, 148.35 Q 536.51, 149.06, 526.43, 149.33 Q 516.34, 149.41, 506.26, 148.79 Q 496.17,\
                     148.64, 486.09, 149.19 Q 476.00, 149.42, 465.92, 149.40 Q 455.83, 149.20, 445.74, 148.83 Q 435.66, 148.66, 425.57, 149.39\
                     Q 415.49, 149.29, 405.40, 148.22 Q 395.32, 148.03, 385.23, 148.47 Q 375.15, 148.11, 365.06, 148.67 Q 354.98, 147.82, 344.89,\
                     148.98 Q 334.81, 148.59, 324.72, 148.82 Q 314.64, 148.62, 304.55, 148.40 Q 294.47, 148.34, 284.38, 148.21 Q 274.30, 148.19,\
                     264.21, 148.56 Q 254.13, 148.80, 244.04, 148.87 Q 233.96, 148.15, 223.87, 148.90 Q 213.79, 148.74, 203.70, 149.43 Q 193.62,\
                     147.85, 183.53, 148.61 Q 173.45, 149.34, 163.36, 149.71 Q 153.28, 149.21, 143.19, 148.72 Q 133.11, 148.95, 123.02, 149.45\
                     Q 112.94, 149.16, 102.85, 149.09 Q 92.77, 149.42, 82.68, 149.65 Q 72.60, 149.69, 62.51, 150.35 Q 52.43, 150.43, 42.34, 149.66\
                     Q 32.26, 149.45, 22.17, 150.34 Q 12.09, 150.00, 1.04, 148.96 Q 1.46, 137.75, 0.93, 127.30 Q 0.97, 116.78, 0.74, 106.33 Q 0.59,\
                     95.88, 0.46, 85.44 Q 0.27, 75.01, 0.31, 64.57 Q 0.92, 54.14, 0.95, 43.71 Q 1.11, 33.29, 1.16, 22.86 Q 2.00, 12.43, 2.00, 2.00"\
                     style=" fill:white;" class="svg_unselected_element"/><svg:path d="M 140.00, 0.00 Q 141.96, 10.71, 142.12, 21.43 Q 142.20,\
                     32.14, 142.36, 42.86 Q 141.96, 53.57, 142.03, 64.29 Q 142.14, 75.00, 142.24, 85.71 Q 141.91, 96.43, 141.97, 107.14 Q 141.98,\
                     117.86, 141.98, 128.57 Q 140.00, 139.29, 140.00, 150.00" style=" fill:none;" class="svg_unselected_element"/><svg:path d="M\
                     326.00, 0.00 Q 326.88, 10.71, 327.35, 21.43 Q 327.50, 32.14, 327.73, 42.86 Q 326.72, 53.57, 327.56, 64.29 Q 327.15, 75.00,\
                     327.70, 85.71 Q 326.75, 96.43, 326.36, 107.14 Q 327.02, 117.86, 327.33, 128.57 Q 326.00, 139.29, 326.00, 150.00" style=" fill:none;"\
                     class="svg_unselected_element"/><svg:path d="M 535.00, 0.00 Q 533.63, 10.71, 534.72, 21.43 Q 535.11, 32.14, 535.59, 42.86\
                     Q 534.34, 53.57, 534.36, 64.29 Q 535.07, 75.00, 535.82, 85.71 Q 535.39, 96.43, 535.13, 107.14 Q 535.65, 117.86, 535.48, 128.57\
                     Q 535.00, 139.29, 535.00, 150.00" style=" fill:none;" class="svg_unselected_element"/><svg:path d="M 763.00, 0.00 Q 763.76,\
                     10.71, 764.42, 21.43 Q 764.83, 32.14, 764.91, 42.86 Q 764.93, 53.57, 764.97, 64.29 Q 764.49, 75.00, 764.62, 85.71 Q 764.61,\
                     96.43, 764.69, 107.14 Q 764.93, 117.86, 764.68, 128.57 Q 763.00, 139.29, 763.00, 150.00" style=" fill:none;" class="svg_unselected_element"/><svg:path\
                     d="M 0.00, 30.00 Q 10.13, 28.11, 20.26, 28.11 Q 30.38, 28.37, 40.51, 28.39 Q 50.64, 28.77, 60.77, 28.80 Q 70.89, 28.63, 81.02,\
                     29.01 Q 91.15, 29.54, 101.28, 29.52 Q 111.40, 29.55, 121.53, 30.22 Q 131.66, 29.06, 141.79, 29.67 Q 151.91, 28.74, 162.04,\
                     29.42 Q 172.17, 30.38, 182.30, 29.62 Q 192.43, 29.72, 202.55, 29.54 Q 212.68, 29.30, 222.81, 29.35 Q 232.94, 29.27, 243.06,\
                     30.78 Q 253.19, 29.36, 263.32, 28.72 Q 273.45, 29.29, 283.57, 29.84 Q 293.70, 29.24, 303.83, 28.39 Q 313.96, 28.46, 324.09,\
                     29.78 Q 334.21, 29.02, 344.34, 30.30 Q 354.47, 30.34, 364.60, 29.16 Q 374.72, 30.16, 384.85, 29.89 Q 394.98, 29.66, 405.11,\
                     30.42 Q 415.23, 29.07, 425.36, 30.04 Q 435.49, 28.86, 445.62, 28.91 Q 455.74, 29.85, 465.87, 29.50 Q 476.00, 30.32, 486.13,\
                     31.47 Q 496.26, 31.10, 506.38, 29.29 Q 516.51, 28.00, 526.64, 28.26 Q 536.77, 28.93, 546.89, 29.48 Q 557.02, 30.47, 567.15,\
                     30.38 Q 577.28, 29.45, 587.40, 29.98 Q 597.53, 29.93, 607.66, 28.43 Q 617.79, 28.29, 627.92, 28.07 Q 638.04, 30.06, 648.17,\
                     29.73 Q 658.30, 27.77, 668.43, 27.99 Q 678.55, 28.81, 688.68, 29.04 Q 698.81, 29.59, 708.94, 29.74 Q 719.06, 29.20, 729.19,\
                     28.50 Q 739.32, 28.74, 749.45, 30.34 Q 759.57, 30.21, 769.70, 29.35 Q 779.83, 29.43, 789.96, 29.52 Q 800.09, 30.72, 810.21,\
                     30.73 Q 820.34, 29.60, 830.47, 28.70 Q 840.60, 29.13, 850.72, 30.73 Q 860.85, 30.22, 870.98, 29.13 Q 881.11, 28.84, 891.23,\
                     28.73 Q 901.36, 29.91, 911.49, 30.05 Q 921.62, 29.59, 931.75, 29.11 Q 941.87, 30.00, 952.00, 30.00" style=" fill:none;" class="svg_unselected_element"/><svg:path\
                     d="M 0.00, 60.00 Q 10.13, 58.00, 20.26, 57.84 Q 30.38, 57.80, 40.51, 57.59 Q 50.64, 57.99, 60.77, 58.02 Q 70.89, 57.88, 81.02,\
                     57.73 Q 91.15, 57.75, 101.28, 58.42 Q 111.40, 58.55, 121.53, 58.75 Q 131.66, 58.46, 141.79, 58.26 Q 151.91, 58.45, 162.04,\
                     58.35 Q 172.17, 58.09, 182.30, 58.39 Q 192.43, 58.93, 202.55, 58.96 Q 212.68, 58.73, 222.81, 59.03 Q 232.94, 59.02, 243.06,\
                     59.15 Q 253.19, 58.86, 263.32, 59.26 Q 273.45, 59.17, 283.57, 58.97 Q 293.70, 58.88, 303.83, 59.41 Q 313.96, 59.45, 324.09,\
                     59.29 Q 334.21, 59.90, 344.34, 58.87 Q 354.47, 59.30, 364.60, 59.38 Q 374.72, 59.30, 384.85, 59.72 Q 394.98, 59.31, 405.11,\
                     58.92 Q 415.23, 58.64, 425.36, 58.58 Q 435.49, 58.62, 445.62, 58.94 Q 455.74, 58.94, 465.87, 59.30 Q 476.00, 59.64, 486.13,\
                     59.42 Q 496.26, 58.93, 506.38, 59.00 Q 516.51, 59.39, 526.64, 59.41 Q 536.77, 59.56, 546.89, 59.73 Q 557.02, 59.52, 567.15,\
                     59.67 Q 577.28, 58.94, 587.40, 59.28 Q 597.53, 59.35, 607.66, 60.09 Q 617.79, 60.68, 627.92, 60.10 Q 638.04, 60.08, 648.17,\
                     59.98 Q 658.30, 60.18, 668.43, 61.19 Q 678.55, 60.27, 688.68, 59.37 Q 698.81, 59.18, 708.94, 59.85 Q 719.06, 59.82, 729.19,\
                     59.66 Q 739.32, 59.22, 749.45, 60.39 Q 759.57, 60.62, 769.70, 60.17 Q 779.83, 59.51, 789.96, 58.74 Q 800.09, 59.17, 810.21,\
                     58.48 Q 820.34, 58.46, 830.47, 59.29 Q 840.60, 59.22, 850.72, 59.37 Q 860.85, 58.88, 870.98, 58.64 Q 881.11, 58.26, 891.23,\
                     58.25 Q 901.36, 58.11, 911.49, 58.02 Q 921.62, 57.81, 931.75, 58.84 Q 941.87, 60.00, 952.00, 60.00" style=" fill:none;" class="svg_unselected_element"/><svg:path\
                     d="M 0.00, 90.00 Q 10.13, 89.10, 20.26, 89.01 Q 30.38, 89.20, 40.51, 89.34 Q 50.64, 89.29, 60.77, 89.47 Q 70.89, 89.63, 81.02,\
                     89.72 Q 91.15, 89.62, 101.28, 89.18 Q 111.40, 89.26, 121.53, 89.47 Q 131.66, 89.92, 141.79, 89.67 Q 151.91, 90.21, 162.04,\
                     90.21 Q 172.17, 89.41, 182.30, 90.27 Q 192.43, 89.35, 202.55, 89.20 Q 212.68, 89.33, 222.81, 89.28 Q 232.94, 89.07, 243.06,\
                     89.73 Q 253.19, 90.41, 263.32, 90.59 Q 273.45, 91.29, 283.57, 90.23 Q 293.70, 90.23, 303.83, 90.95 Q 313.96, 91.46, 324.09,\
                     90.37 Q 334.21, 89.26, 344.34, 89.41 Q 354.47, 90.42, 364.60, 91.31 Q 374.72, 89.16, 384.85, 89.37 Q 394.98, 89.13, 405.11,\
                     89.18 Q 415.23, 89.12, 425.36, 89.85 Q 435.49, 89.58, 445.62, 89.58 Q 455.74, 89.74, 465.87, 89.25 Q 476.00, 90.50, 486.13,\
                     90.30 Q 496.26, 90.76, 506.38, 90.55 Q 516.51, 89.94, 526.64, 89.78 Q 536.77, 89.74, 546.89, 90.43 Q 557.02, 89.81, 567.15,\
                     90.28 Q 577.28, 90.27, 587.40, 90.02 Q 597.53, 90.19, 607.66, 90.24 Q 617.79, 90.24, 627.92, 90.33 Q 638.04, 91.25, 648.17,\
                     89.83 Q 658.30, 89.43, 668.43, 90.04 Q 678.55, 90.20, 688.68, 89.42 Q 698.81, 89.59, 708.94, 89.76 Q 719.06, 89.95, 729.19,\
                     90.71 Q 739.32, 89.51, 749.45, 88.76 Q 759.57, 89.08, 769.70, 89.48 Q 779.83, 89.21, 789.96, 89.21 Q 800.09, 89.10, 810.21,\
                     89.09 Q 820.34, 88.93, 830.47, 88.69 Q 840.60, 88.48, 850.72, 89.53 Q 860.85, 89.34, 870.98, 89.00 Q 881.11, 88.69, 891.23,\
                     89.31 Q 901.36, 89.83, 911.49, 89.76 Q 921.62, 89.73, 931.75, 89.07 Q 941.87, 90.00, 952.00, 90.00" style=" fill:none;" class="svg_unselected_element"/><svg:path\
                     d="M 0.00, 120.00 Q 10.13, 118.27, 20.26, 118.10 Q 30.38, 118.02, 40.51, 118.04 Q 50.64, 118.40, 60.77, 118.21 Q 70.89, 118.05,\
                     81.02, 118.18 Q 91.15, 118.56, 101.28, 119.00 Q 111.40, 118.72, 121.53, 118.55 Q 131.66, 119.08, 141.79, 118.52 Q 151.91,\
                     118.06, 162.04, 118.19 Q 172.17, 118.71, 182.30, 118.69 Q 192.43, 119.23, 202.55, 119.62 Q 212.68, 119.80, 222.81, 119.20\
                     Q 232.94, 118.49, 243.06, 118.97 Q 253.19, 119.84, 263.32, 120.19 Q 273.45, 119.46, 283.57, 119.30 Q 293.70, 118.67, 303.83,\
                     118.60 Q 313.96, 118.97, 324.09, 119.14 Q 334.21, 118.93, 344.34, 118.80 Q 354.47, 118.73, 364.60, 118.32 Q 374.72, 118.57,\
                     384.85, 118.93 Q 394.98, 119.69, 405.11, 119.43 Q 415.23, 120.23, 425.36, 120.30 Q 435.49, 119.62, 445.62, 119.21 Q 455.74,\
                     118.92, 465.87, 118.26 Q 476.00, 118.11, 486.13, 118.93 Q 496.26, 119.82, 506.38, 120.82 Q 516.51, 121.28, 526.64, 121.02\
                     Q 536.77, 120.35, 546.89, 119.86 Q 557.02, 119.43, 567.15, 119.45 Q 577.28, 119.03, 587.40, 118.79 Q 597.53, 118.90, 607.66,\
                     118.77 Q 617.79, 119.70, 627.92, 119.51 Q 638.04, 119.18, 648.17, 119.36 Q 658.30, 119.11, 668.43, 119.29 Q 678.55, 118.57,\
                     688.68, 119.00 Q 698.81, 119.81, 708.94, 119.32 Q 719.06, 118.15, 729.19, 117.98 Q 739.32, 117.89, 749.45, 117.98 Q 759.57,\
                     117.93, 769.70, 118.33 Q 779.83, 119.15, 789.96, 119.83 Q 800.09, 119.52, 810.21, 119.47 Q 820.34, 119.34, 830.47, 119.26\
                     Q 840.60, 118.83, 850.72, 119.67 Q 860.85, 119.00, 870.98, 119.56 Q 881.11, 118.88, 891.23, 118.69 Q 901.36, 118.51, 911.49,\
                     118.67 Q 921.62, 118.71, 931.75, 118.89 Q 941.87, 120.00, 952.00, 120.00" style=" fill:none;" class="svg_unselected_element"/>\
                  </svg:g>\
               </svg:svg>\
               <div style="height: 150px;width:952px; position:absolute; top: 0px; left: 0px;"><span style=\'position: absolute; top: 5px;left: 10px;width:110px;\'><span style=\'position: relative;\'>Mã số</span></span><span\
                  style=\'position: absolute; top: 5px;left: 150px;width:156px;\'><span style=\'position: relative;\'>Họ tên</span></span><span\
                  style=\'position: absolute; top: 5px;left: 336px;width:179px;\'><span style=\'position: relative;\'>SĐT</span></span><span style=\'position:\
                  absolute; top: 5px;left: 545px;width:198px;\'><span style=\'position: relative;\'>Số đơn hàng</span></span><span style=\'position:\
                  absolute; top: 5px;left: 773px;width:159px;\'><span style=\'position: relative;\'>Trạng thái</span></span><span style=\'position:\
                  absolute; top: 35px;left: 10px;width:110px;\'><span style=\'position: relative;\'>1</span></span><span style=\'position: absolute;\
                  top: 35px;left: 150px;width:156px;\'><span style=\'position: relative;\'>Nguyễn A</span></span><span style=\'position: absolute;\
                  top: 35px;left: 336px;width:179px;\'><span style=\'position: relative;\'>012153452</span></span><span style=\'position: absolute;\
                  top: 35px;left: 545px;width:198px;\'><span style=\'position: relative;\'>3</span></span><span style=\'position: absolute; top:\
                  35px;left: 773px;width:159px;\'><span style=\'position: relative;\'>Active</span></span><span style=\'position: absolute; top:\
                  65px;left: 10px;width:110px;\'><span style=\'position: relative;\'>2</span></span><span style=\'position: absolute; top: 65px;left:\
                  150px;width:156px;\'><span style=\'position: relative;\'>TRần B</span></span><span style=\'position: absolute; top: 65px;left:\
                  336px;width:179px;\'><span style=\'position: relative;\'>016844245</span></span><span style=\'position: absolute; top: 65px;left:\
                  545px;width:198px;\'><span style=\'position: relative;\'>4</span></span><span style=\'position: absolute; top: 65px;left: 773px;width:159px;\'><span\
                  style=\'position: relative;\'>Active</span></span><span style=\'position: absolute; top: 95px;left: 10px;width:110px;\'><span\
                  style=\'position: relative;\'>3</span></span><span style=\'position: absolute; top: 95px;left: 150px;width:156px;\'><span style=\'position:\
                  relative;\'>Nguyễn C</span></span><span style=\'position: absolute; top: 95px;left: 336px;width:179px;\'><span style=\'position:\
                  relative;\'>016844245</span></span><span style=\'position: absolute; top: 95px;left: 545px;width:198px;\'><span style=\'position:\
                  relative;\'>2</span></span><span style=\'position: absolute; top: 95px;left: 773px;width:159px;\'><span style=\'position: relative;\'>Deactive</span></span><span\
                  style=\'position: absolute; top: 125px;left: 10px;width:110px;\'><span style=\'position: relative;\'>4</span></span><span style=\'position:\
                  absolute; top: 125px;left: 150px;width:156px;\'><span style=\'position: relative;\'>Ngô A</span></span><span style=\'position:\
                  absolute; top: 125px;left: 336px;width:179px;\'><span style=\'position: relative;\'>016844245</span></span><span style=\'position:\
                  absolute; top: 125px;left: 545px;width:198px;\'><span style=\'position: relative;\'>5</span></span><span style=\'position: absolute;\
                  top: 125px;left: 773px;width:159px;\'><span style=\'position: relative;\'>Active</span></span>\
               </div>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page271612227-layer-1333927778" style="position: absolute; left: 315px; top: 1010px; width: 955px; height: 100px" data-interactive-element-type="static.rect" class="rect stencil mobile-interaction-potential-trigger " data-stencil-id="1333927778" data-review-reference-id="1333927778">\
         <div class="stencil-wrapper" style="width: 955px; height: 100px">\
            <div title="">\
               <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" style="height: 100px;width:955px;" width="955" height="100">\
                  <svg:g width="955" height="100"><svg:path d="M 2.00, 2.00 Q 12.12, 0.74, 22.23, 0.70 Q 32.35, 1.49, 42.47, 1.21 Q 52.59, 1.08, 62.70, 1.99 Q 72.82, 1.72,\
                     82.94, 1.45 Q 93.05, 1.52, 103.17, 1.92 Q 113.29, 2.56, 123.40, 3.46 Q 133.52, 2.41, 143.64, 2.13 Q 153.76, 2.30, 163.87,\
                     1.68 Q 173.99, 1.87, 184.11, 2.09 Q 194.22, 1.88, 204.34, 2.00 Q 214.46, 1.61, 224.57, 1.52 Q 234.69, 2.00, 244.81, 2.70 Q\
                     254.93, 2.55, 265.04, 1.14 Q 275.16, 1.11, 285.28, 1.46 Q 295.39, 1.63, 305.51, 1.56 Q 315.63, 1.04, 325.74, 0.66 Q 335.86,\
                     1.17, 345.98, 0.85 Q 356.10, 1.08, 366.21, 1.40 Q 376.33, 1.39, 386.45, 1.80 Q 396.56, 2.18, 406.68, 1.89 Q 416.80, 1.26,\
                     426.92, 1.84 Q 437.03, 2.34, 447.15, 1.89 Q 457.27, 2.31, 467.38, 2.37 Q 477.50, 2.71, 487.62, 2.89 Q 497.73, 2.09, 507.85,\
                     2.89 Q 517.97, 1.56, 528.09, 1.66 Q 538.20, 0.87, 548.32, 1.43 Q 558.44, 1.38, 568.55, 1.35 Q 578.67, 1.24, 588.79, 0.88 Q\
                     598.90, 1.50, 609.02, 0.68 Q 619.14, 1.08, 629.26, 1.24 Q 639.37, 1.61, 649.49, 0.35 Q 659.61, 0.43, 669.72, 0.87 Q 679.84,\
                     0.10, 689.96, 0.66 Q 700.07, 0.32, 710.19, 0.63 Q 720.31, 0.95, 730.43, 0.99 Q 740.54, 0.96, 750.66, 1.17 Q 760.78, 0.71,\
                     770.89, 1.30 Q 781.01, 1.73, 791.13, 1.27 Q 801.24, 2.12, 811.36, 0.71 Q 821.48, 0.75, 831.60, 0.65 Q 841.71, 0.82, 851.83,\
                     1.24 Q 861.95, 1.29, 872.06, 1.96 Q 882.18, 1.27, 892.30, 1.62 Q 902.41, 1.59, 912.53, 2.19 Q 922.65, 1.70, 932.77, 1.90 Q\
                     942.88, 1.98, 953.03, 1.97 Q 952.54, 14.15, 953.38, 25.95 Q 954.37, 37.91, 954.46, 49.95 Q 953.53, 61.99, 952.39, 74.00 Q\
                     952.84, 86.00, 953.08, 98.08 Q 942.91, 98.09, 932.71, 97.63 Q 922.62, 97.64, 912.54, 98.29 Q 902.42, 98.24, 892.30, 97.95\
                     Q 882.18, 98.05, 872.06, 98.09 Q 861.95, 97.32, 851.83, 97.53 Q 841.71, 96.60, 831.60, 97.63 Q 821.48, 97.70, 811.36, 98.27\
                     Q 801.24, 97.62, 791.13, 97.49 Q 781.01, 98.23, 770.89, 98.78 Q 760.78, 98.36, 750.66, 97.81 Q 740.54, 98.07, 730.43, 97.64\
                     Q 720.31, 97.72, 710.19, 97.55 Q 700.07, 98.49, 689.96, 99.25 Q 679.84, 99.07, 669.72, 98.60 Q 659.61, 98.55, 649.49, 98.60\
                     Q 639.37, 97.73, 629.26, 99.38 Q 619.14, 99.07, 609.02, 98.85 Q 598.90, 98.97, 588.79, 98.85 Q 578.67, 98.37, 568.55, 98.51\
                     Q 558.44, 98.39, 548.32, 98.71 Q 538.20, 99.08, 528.09, 99.46 Q 517.97, 99.28, 507.85, 99.48 Q 497.73, 99.50, 487.62, 99.25\
                     Q 477.50, 98.80, 467.38, 100.00 Q 457.27, 98.65, 447.15, 98.60 Q 437.03, 98.13, 426.92, 98.03 Q 416.80, 98.50, 406.68, 98.93\
                     Q 396.56, 98.58, 386.45, 97.86 Q 376.33, 98.59, 366.21, 99.30 Q 356.10, 99.61, 345.98, 99.48 Q 335.86, 99.41, 325.74, 99.61\
                     Q 315.63, 99.62, 305.51, 99.26 Q 295.39, 98.45, 285.28, 98.48 Q 275.16, 98.66, 265.04, 98.49 Q 254.93, 97.82, 244.81, 97.48\
                     Q 234.69, 97.70, 224.57, 98.15 Q 214.46, 97.40, 204.34, 97.58 Q 194.22, 98.29, 184.11, 98.28 Q 173.99, 97.52, 163.87, 97.04\
                     Q 153.76, 97.13, 143.64, 97.90 Q 133.52, 98.48, 123.40, 97.89 Q 113.29, 97.65, 103.17, 98.06 Q 93.05, 98.28, 82.94, 98.13\
                     Q 72.82, 97.48, 62.70, 97.84 Q 52.59, 98.77, 42.47, 98.80 Q 32.35, 99.14, 22.23, 99.91 Q 12.12, 100.01, 1.04, 98.96 Q 0.40,\
                     86.53, 0.34, 74.24 Q 0.75, 62.08, 1.20, 50.03 Q 1.13, 38.01, 1.07, 26.01 Q 2.00, 14.00, 2.00, 2.00" style=" fill:white;" class="svg_unselected_element"/>\
                  </svg:g>\
               </svg:svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page271612227-layer-1452645800" style="position: absolute; left: 325px; top: 1015px; width: 62px; height: 23px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="1452645800" data-review-reference-id="1452645800">\
         <div class="stencil-wrapper" style="width: 62px; height: 23px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline32"><p><span style="font-size: 20px; color: #658cd9;">Bộ lọc</span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page271612227-layer-1742869886" style="position: absolute; left: 380px; top: 1060px; width: 150px; height: 30px" data-interactive-element-type="default.textinput" class="textinput stencil mobile-interaction-potential-trigger " data-stencil-id="1742869886" data-review-reference-id="1742869886">\
         <div class="stencil-wrapper" style="width: 150px; height: 30px">\
            <div>\
               <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" style="height: 30px;width:150px;" width="150" height="30">\
                  <svg:g id="__containerId__-page271612227-layer-1742869886svg" width="150" height="30"><svg:path id="__containerId__-page271612227-layer-1742869886_input_svg_border" d="M 2.00, 2.00 Q 12.43, 1.92, 22.86, 2.02\
                     Q 33.29, 2.36, 43.71, 2.31 Q 54.14, 1.32, 64.57, 2.22 Q 75.00, 1.74, 85.43, 1.61 Q 95.86, 0.85, 106.29, 0.83 Q 116.71, 1.33,\
                     127.14, 1.48 Q 137.57, 1.05, 148.77, 1.23 Q 148.04, 14.99, 148.38, 28.38 Q 137.69, 28.43, 127.20, 28.52 Q 116.69, 27.55, 106.29,\
                     28.36 Q 95.86, 28.57, 85.43, 28.96 Q 75.00, 28.44, 64.57, 28.95 Q 54.14, 28.28, 43.71, 28.74 Q 33.29, 29.58, 22.86, 29.25\
                     Q 12.43, 28.31, 1.80, 28.20 Q 2.00, 15.00, 2.00, 2.00" style=" fill:white;" class="svg_unselected_element"/><svg:path id="__containerId__-page271612227-layer-1742869886_line1" d="M 3.00, 3.00 Q 13.29, 1.62, 23.57, 1.61 Q 33.86, 2.19,\
                     44.14, 2.39 Q 54.43, 2.62, 64.71, 3.15 Q 75.00, 2.22, 85.29, 2.66 Q 95.57, 3.23, 105.86, 3.65 Q 116.14, 4.13, 126.43, 4.58\
                     Q 136.71, 3.00, 147.00, 3.00" style=" fill:none;" class="svg_unselected_element"/><svg:path id="__containerId__-page271612227-layer-1742869886_line2" d="M 3.00, 3.00 Q 3.00, 15.00, 3.00, 27.00" style=" fill:none;"\
                     class="svg_unselected_element"/><svg:path id="__containerId__-page271612227-layer-1742869886_line3" d="M 3.00, 3.00 Q 13.29, 2.68, 23.57, 3.82 Q 33.86, 3.95,\
                     44.14, 3.07 Q 54.43, 2.56, 64.71, 3.30 Q 75.00, 3.52, 85.29, 3.71 Q 95.57, 3.74, 105.86, 3.38 Q 116.14, 3.56, 126.43, 3.54\
                     Q 136.71, 3.00, 147.00, 3.00" style=" fill:none;" class="svg_unselected_element"/><svg:path id="__containerId__-page271612227-layer-1742869886_line4" d="M 3.00, 3.00 Q 3.00, 15.00, 3.00, 27.00" style=" fill:none;"\
                     class="svg_unselected_element"/>\
                  </svg:g>\
               </svg:svg>\
               <div style="position:absolute;left: 6px; top: 1px;" title=""><input id="__containerId__-page271612227-layer-1742869886input" onblur="rabbit.facade.raiseEvent(rabbit.events.svgBlur, new Array(\'__containerId__-page271612227-layer-1742869886_input_svg_border\',\'__containerId__-page271612227-layer-1742869886_line1\',\'__containerId__-page271612227-layer-1742869886_line2\',\'__containerId__-page271612227-layer-1742869886_line3\',\'__containerId__-page271612227-layer-1742869886_line4\'))" onfocus="rabbit.facade.raiseEvent(rabbit.events.svgFocus, new Array(\'__containerId__-page271612227-layer-1742869886_input_svg_border\',\'__containerId__-page271612227-layer-1742869886_line1\',\'__containerId__-page271612227-layer-1742869886_line2\',\'__containerId__-page271612227-layer-1742869886_line3\',\'__containerId__-page271612227-layer-1742869886_line4\'))" value="" style="width:143px;height:28px;padding: 0px;" type="text" /></div>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page271612227-layer-1037648139" style="position: absolute; left: 335px; top: 1065px; width: 37px; height: 21px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="1037648139" data-review-reference-id="1037648139">\
         <div class="stencil-wrapper" style="width: 37px; height: 21px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline32"><p><span style="font-size: 18px; color: #658cd9;">Tên</span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page271612227-layer-2068706232" style="position: absolute; left: 590px; top: 1065px; width: 82px; height: 20px" data-interactive-element-type="default.checkbox" class="checkbox stencil mobile-interaction-potential-trigger " data-stencil-id="2068706232" data-review-reference-id="2068706232">\
         <div class="stencil-wrapper" style="width: 82px; height: 20px">\
            <div class="" style="font-size:1.17em;">\
               <div xml:space="preserve" title="" style="position:absolute" onclick="rabbit.facade.fireMouseOn(\'__containerId__-page271612227-layer-2068706232_input\');">\
                  				\
                  <nobr>\
                     					<input id="__containerId__-page271612227-layer-2068706232_input" xml:space="default" class="hidden_class" style="padding-right:9px" type="checkbox" onpropertychange="rabbit.facade.raiseEvent(rabbit.events.propertyChange, \'__containerId__-page271612227-layer-2068706232_input\', \'__containerId__-page271612227-layer-2068706232_input_svgChecked\');" onblur="rabbit.facade.raiseEvent(rabbit.events.svgBlur, \'__containerId__-page271612227-layer-2068706232_input_svg_border\')" onfocus="rabbit.facade.raiseEvent(rabbit.events.svgFocus, \'__containerId__-page271612227-layer-2068706232_input_svg_border\')" onclick="rabbit.facade.raiseEvent(rabbit.events.checkBoxClicked, \'__containerId__-page271612227-layer-2068706232_input\', \'__containerId__-page271612227-layer-2068706232_input_svgChecked\')" checked="true" />\
                     				\
                     					\
                     					\
                     						Ngày lập \
                     						\
                     					\
                     				\
                  </nobr>\
                  			\
               </div>\
               <div title="">\
                  <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" style="position: absolute; height: 20px;width:82px;" width="82" height="20" onclick="rabbit.facade.fireMouseOn(\'__containerId__-page271612227-layer-2068706232_input\');">\
                     <svg:g id="__containerId__-page271612227-layer-2068706232_input_svg" x="0" y="1.0199999999999996" width="82" height="20"><svg:path id="__containerId__-page271612227-layer-2068706232_input_svg_border" d="M 5.00, 5.00 Q 10.00, 4.17, 15.47, 4.53\
                        Q 15.50, 9.83, 15.31, 15.31 Q 10.09, 15.34, 4.87, 15.11 Q 5.00, 10.00, 5.00, 5.00" style=" fill:white;" class="svg_unselected_element"/>\
                     </svg:g>\
                     <svg:g id="__containerId__-page271612227-layer-2068706232_input_svgChecked" x="0" y="1.0199999999999996" width="82" height="20" visibility="inherit"><svg:path d="M 5.00, 9.00 Q 8.00, 12.00, 11.00, 15.00" style=" fill:none;" class="svg_unselected_element"/><svg:path d="M 11.00, 15.00 Q 15.50, 7.00, 20.00, -1.00" style=" fill:none;" class="svg_unselected_element"/></svg:g>\
                  </svg:svg>\
               </div>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page271612227-layer-2004676189" style="position: absolute; left: 710px; top: 1065px; width: 104px; height: 20px" data-interactive-element-type="default.checkbox" class="checkbox stencil mobile-interaction-potential-trigger " data-stencil-id="2004676189" data-review-reference-id="2004676189">\
         <div class="stencil-wrapper" style="width: 104px; height: 20px">\
            <div class="" style="font-size:1.17em;">\
               <div xml:space="preserve" title="" style="position:absolute" onclick="rabbit.facade.fireMouseOn(\'__containerId__-page271612227-layer-2004676189_input\');">\
                  				\
                  <nobr>\
                     					<input id="__containerId__-page271612227-layer-2004676189_input" xml:space="default" class="hidden_class" style="padding-right:9px" type="checkbox" onpropertychange="rabbit.facade.raiseEvent(rabbit.events.propertyChange, \'__containerId__-page271612227-layer-2004676189_input\', \'__containerId__-page271612227-layer-2004676189_input_svgChecked\');" onblur="rabbit.facade.raiseEvent(rabbit.events.svgBlur, \'__containerId__-page271612227-layer-2004676189_input_svg_border\')" onfocus="rabbit.facade.raiseEvent(rabbit.events.svgFocus, \'__containerId__-page271612227-layer-2004676189_input_svg_border\')" onclick="rabbit.facade.raiseEvent(rabbit.events.checkBoxClicked, \'__containerId__-page271612227-layer-2004676189_input\', \'__containerId__-page271612227-layer-2004676189_input_svgChecked\')" checked="true" />\
                     				\
                     					\
                     					\
                     						Số đơn hàng\
                     						\
                     					\
                     				\
                  </nobr>\
                  			\
               </div>\
               <div title="">\
                  <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" style="position: absolute; height: 20px;width:104px;" width="104" height="20" onclick="rabbit.facade.fireMouseOn(\'__containerId__-page271612227-layer-2004676189_input\');">\
                     <svg:g id="__containerId__-page271612227-layer-2004676189_input_svg" x="0" y="1.0199999999999996" width="104" height="20"><svg:path id="__containerId__-page271612227-layer-2004676189_input_svg_border" d="M 5.00, 5.00 Q 10.00, 7.10, 14.33, 5.67\
                        Q 14.72, 10.09, 14.95, 14.95 Q 10.09, 15.34, 4.54, 15.39 Q 5.00, 10.00, 5.00, 5.00" style=" fill:white;" class="svg_unselected_element"/>\
                     </svg:g>\
                     <svg:g id="__containerId__-page271612227-layer-2004676189_input_svgChecked" x="0" y="1.0199999999999996" width="104" height="20" visibility="inherit"><svg:path d="M 5.00, 9.00 Q 8.00, 12.00, 11.00, 15.00" style=" fill:none;" class="svg_unselected_element"/><svg:path d="M 11.00, 15.00 Q 15.50, 7.00, 20.00, -1.00" style=" fill:none;" class="svg_unselected_element"/></svg:g>\
                  </svg:svg>\
               </div>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page271612227-layer-132386789" style="position: absolute; left: 845px; top: 1060px; width: 150px; height: 30px" data-interactive-element-type="default.combobox" class="combobox stencil mobile-interaction-potential-trigger " data-stencil-id="132386789" data-review-reference-id="132386789">\
         <div class="stencil-wrapper" style="width: 150px; height: 30px">\
            <div style="position:absolute;left:2px;top:0px;">\
               <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" style="position: absolute; height: 30px;width:150px;" width="150" height="30">\
                  <svg:g id="__containerId__-page271612227-layer-132386789" width="150" height="30"><svg:path id="__containerId__-page271612227-layer-132386789_input_svg_border" d="M 2.00, 2.00 Q 12.43, 3.63, 22.86, 2.55 Q\
                     33.29, 1.72, 43.71, 1.58 Q 54.14, 1.64, 64.57, 0.86 Q 75.00, 1.16, 85.43, 1.41 Q 95.86, 2.18, 106.29, 2.65 Q 116.71, 2.34,\
                     127.14, 1.64 Q 137.57, 2.01, 148.30, 1.70 Q 148.51, 14.83, 147.98, 27.98 Q 137.65, 28.30, 127.11, 27.68 Q 116.77, 29.10, 106.29,\
                     28.05 Q 95.85, 27.01, 85.43, 28.16 Q 75.00, 28.92, 64.57, 28.96 Q 54.14, 28.28, 43.71, 28.72 Q 33.29, 29.55, 22.86, 29.67\
                     Q 12.43, 29.53, 1.46, 28.54 Q 2.00, 15.00, 2.00, 2.00" style=" fill:white;" class="svg_unselected_element"/>\
                  </svg:g>\
               </svg:svg>\
               <div title="" style="position:absolute"><select id="__containerId__-page271612227-layer-132386789select" onblur="rabbit.facade.raiseEvent(rabbit.events.svgBlur, \'__containerId__-page271612227-layer-132386789_input_svg_border\')" onfocus="rabbit.facade.raiseEvent(rabbit.events.svgFocus, \'__containerId__-page271612227-layer-132386789_input_svg_border\')" style="width:146px; height:26px;" title="">\
                     <option title="">Trạng thái</option>\
                     <option title="">Active</option>\
                     <option title="">Deactive</option></select></div>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page271612227-layer-1661348270" style="position: absolute; left: 1165px; top: 1050px; width: 80px; height: 30px" data-interactive-element-type="default.iphoneButton" class="iphoneButton stencil mobile-interaction-potential-trigger " data-stencil-id="1661348270" data-review-reference-id="1661348270">\
         <div class="stencil-wrapper" style="width: 80px; height: 30px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" title="" style="position: absolute; left: -2px; top: -2px;height: 34px;width:84px;">\
               <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" class="helvetica-font" width="84" height="34" viewBox="-2 -2 84 34">\
                  <svg:a><svg:path d="M 4.00, 29.00 Q 1.86, 30.14, 0.88, 28.88 Q 1.43, 15.30, 1.21, 1.42 Q 1.77, 0.40, 3.61, 0.25 Q 14.82, 0.16, 25.88,\
                     -0.15 Q 36.97, 0.41, 47.95, -1.26 Q 58.99, 0.31, 69.91, 1.41 Q 70.74, 2.21, 71.86, 2.18 Q 76.95, 8.08, 81.33, 14.98 Q 76.57,\
                     21.52, 71.73, 27.75 Q 71.78, 29.57, 70.45, 30.45 Q 59.18, 30.26, 48.02, 29.30 Q 37.02, 29.66, 26.01, 29.34 Q 15.00, 29.00,\
                     4.00, 29.00" style="fill-rule:evenodd;clip-rule:evenodd;fill:#808080;stroke:#666666;" class="svg_unselected_element"/>\
                     <svg:text x="37" y="15" dy="0.3em" fill="#FFFFFF" style="font-size:1em;stroke-width:0pt;" font-family="\'HelveticaNeue-Bold\'" text-anchor="middle" xml:space="preserve">Lọc</svg:text>\
                  </svg:a>\
               </svg:svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page271612227-layer-1089734820" style="position: absolute; left: 1165px; top: 1315px; width: 88px; height: 30px" data-interactive-element-type="default.iphoneButton" class="iphoneButton stencil mobile-interaction-potential-trigger " data-stencil-id="1089734820" data-review-reference-id="1089734820">\
         <div class="stencil-wrapper" style="width: 88px; height: 30px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" title="" style="position: absolute; left: -2px; top: -2px;height: 34px;width:92px;">\
               <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" class="helvetica-font" width="92" height="34" viewBox="-2 -2 92 34">\
                  <svg:a><svg:path d="M 4.00, 29.00 Q 2.59, 29.31, 1.36, 28.64 Q 0.63, 27.62, 0.48, 26.16 Q 0.34, 14.10, -0.29, 1.78 Q 0.75, 0.75,\
                     1.79, -0.18 Q 2.50, -1.16, 3.97, -1.11 Q 14.18, -1.49, 24.44, -1.87 Q 34.74, -1.34, 45.00, -1.16 Q 55.25, -0.76, 65.50, -0.91\
                     Q 75.75, -1.01, 86.13, -1.55 Q 86.91, -0.25, 87.62, 0.42 Q 88.02, 1.36, 89.03, 1.99 Q 89.48, 13.93, 89.59, 26.10 Q 88.62,\
                     27.04, 87.57, 27.62 Q 87.15, 28.71, 86.04, 29.11 Q 75.79, 29.24, 65.52, 29.33 Q 55.26, 29.41, 45.01, 29.66 Q 34.75, 28.98,\
                     24.50, 28.97 Q 14.25, 29.00, 4.00, 29.00" style="fill-rule:evenodd;clip-rule:evenodd;fill:#808080;stroke:#666666;" class="svg_unselected_element"/>\
                     <svg:text x="44" y="15" dy="0.3em" fill="#FFFFFF" style="font-size:1em;stroke-width:0pt;" font-family="\'HelveticaNeue-Bold\'" text-anchor="middle" xml:space="preserve">Lưu thay đổi</svg:text>\
                  </svg:a>\
               </svg:svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page271612227-layer-1618779882" style="position: absolute; left: 285px; top: 1390px; width: 1020px; height: 33px" data-interactive-element-type="static.line" class="line stencil mobile-interaction-potential-trigger " data-stencil-id="1618779882" data-review-reference-id="1618779882">\
         <div class="stencil-wrapper" style="width: 1020px; height: 33px">\
            <div title="">\
               <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" style="position: absolute; left: -5px; top: -5px; height: 43px;width:1030px;" viewBox="-5 -5 1030 43" width="1030" height="43"><svg:path d="M 0.00, 16.00 Q 10.00, 16.03, 20.00, 15.46 Q 30.00, 15.39, 40.00, 15.13 Q 50.00, 15.44, 60.00, 14.99 Q 70.00,\
                  13.70, 80.00, 14.17 Q 90.00, 14.23, 100.00, 15.71 Q 110.00, 16.58, 120.00, 16.22 Q 130.00, 14.52, 140.00, 14.26 Q 150.00,\
                  14.57, 160.00, 14.84 Q 170.00, 15.77, 180.00, 15.21 Q 190.00, 14.85, 200.00, 15.97 Q 210.00, 16.30, 220.00, 15.71 Q 230.00,\
                  16.19, 240.00, 15.56 Q 250.00, 15.65, 260.00, 15.05 Q 270.00, 14.63, 280.00, 14.56 Q 290.00, 14.57, 300.00, 14.45 Q 310.00,\
                  14.16, 320.00, 14.48 Q 330.00, 14.88, 340.00, 15.41 Q 350.00, 15.53, 360.00, 15.45 Q 370.00, 15.44, 380.00, 14.73 Q 390.00,\
                  15.15, 400.00, 14.54 Q 410.00, 15.26, 420.00, 14.47 Q 430.00, 14.20, 440.00, 13.78 Q 450.00, 13.93, 460.00, 14.60 Q 470.00,\
                  14.83, 480.00, 15.24 Q 490.00, 15.76, 500.00, 16.15 Q 510.00, 15.58, 520.00, 15.60 Q 530.00, 14.52, 540.00, 14.89 Q 550.00,\
                  14.66, 560.00, 14.86 Q 570.00, 14.88, 580.00, 14.80 Q 590.00, 14.65, 600.00, 14.60 Q 610.00, 14.49, 620.00, 14.28 Q 630.00,\
                  14.23, 640.00, 14.58 Q 650.00, 15.29, 660.00, 15.63 Q 670.00, 15.72, 680.00, 16.44 Q 690.00, 16.78, 700.00, 16.53 Q 710.00,\
                  16.26, 720.00, 16.35 Q 730.00, 16.31, 740.00, 16.56 Q 750.00, 16.21, 760.00, 15.77 Q 770.00, 15.82, 780.00, 16.40 Q 790.00,\
                  15.75, 800.00, 15.03 Q 810.00, 14.95, 820.00, 15.98 Q 830.00, 16.06, 840.00, 15.54 Q 850.00, 15.22, 860.00, 15.12 Q 870.00,\
                  14.75, 880.00, 14.06 Q 890.00, 13.76, 900.00, 14.09 Q 910.00, 14.30, 920.00, 14.39 Q 930.00, 14.69, 940.00, 14.32 Q 950.00,\
                  14.45, 960.00, 14.76 Q 970.00, 15.25, 980.00, 15.43 Q 990.00, 15.87, 1000.00, 16.41 Q 1010.00, 16.00, 1020.00, 16.00" style="marker-start:;marker-end:"\
                  class="svg_unselected_element"/>\
               </svg:svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page271612227-layer-1924773091" style="position: absolute; left: 25px; top: 628px; width: 32px; height: 32px" data-interactive-element-type="fonticon.icon" class="icon stencil mobile-interaction-potential-trigger " data-stencil-id="1924773091" data-review-reference-id="1924773091">\
         <div class="stencil-wrapper" style="width: 32px; height: 32px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" style="width:32px;height:32px;" title="">\
               <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" class="fill-blue">\
                  <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#icon-glyph-e064"></use>\
               </svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page271612227-layer-1260812243" style="position: absolute; left: 70px; top: 632px; width: 115px; height: 28px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="1260812243" data-review-reference-id="1260812243">\
         <div class="stencil-wrapper" style="width: 115px; height: 28px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline22"><p class="none" style="font-size: 24px;"><span style="color: #658cd9;">Đăng xuất</span></p>\
                     <p class="none" style="font-size: 24px;"> </p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page271612227-layer-text292740648" style="position: absolute; left: 315px; top: 1440px; width: 139px; height: 37px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text292740648" data-review-reference-id="text292740648">\
         <div class="stencil-wrapper" style="width: 139px; height: 37px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline12"><p><span style="font-size: 32px; color: #658cd9;">Thống kê</span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page271612227-layer-icon463696794" style="position: absolute; left: 340px; top: 1565px; width: 32px; height: 32px" data-interactive-element-type="fonticon.icon" class="icon stencil mobile-interaction-potential-trigger " data-stencil-id="icon463696794" data-review-reference-id="icon463696794">\
         <div class="stencil-wrapper" style="width: 32px; height: 32px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" style="width:32px;height:32px;" title="">\
               <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" class="fill-blue">\
                  <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#icon-glyph-e052"></use>\
               </svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page271612227-layer-text11504227" style="position: absolute; left: 390px; top: 1570px; width: 55px; height: 20px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text11504227" data-review-reference-id="text11504227">\
         <div class="stencil-wrapper" style="width: 55px; height: 20px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline32"><p><span style="font-size: 18px;">Views</span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page271612227-layer-icon356173002" style="position: absolute; left: 485px; top: 1565px; width: 32px; height: 32px" data-interactive-element-type="fonticon.icon" class="icon stencil mobile-interaction-potential-trigger " data-stencil-id="icon356173002" data-review-reference-id="icon356173002">\
         <div class="stencil-wrapper" style="width: 32px; height: 32px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" style="width:32px;height:32px;" title="">\
               <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" class="fill-blue">\
                  <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#icon-glyph-e044"></use>\
               </svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page271612227-layer-text154822595" style="position: absolute; left: 535px; top: 1570px; width: 66px; height: 20px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text154822595" data-review-reference-id="text154822595">\
         <div class="stencil-wrapper" style="width: 66px; height: 20px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline32"><p><span style="font-size: 18px;">Visitors</span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page271612227-layer-icon380171137" style="position: absolute; left: 615px; top: 1565px; width: 32px; height: 32px" data-interactive-element-type="fonticon.icon" class="icon stencil mobile-interaction-potential-trigger " data-stencil-id="icon380171137" data-review-reference-id="icon380171137">\
         <div class="stencil-wrapper" style="width: 32px; height: 32px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" style="width:32px;height:32px;" title="">\
               <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" class="fill-blue">\
                  <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#icon-glyph-e007"></use>\
               </svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page271612227-layer-text608930030" style="position: absolute; left: 655px; top: 1570px; width: 113px; height: 20px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text608930030" data-review-reference-id="text608930030">\
         <div class="stencil-wrapper" style="width: 113px; height: 20px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline32"><p class="none" style="font-size: 18px;">Đăng kí mới </p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page271612227-layer-text289762378" style="position: absolute; left: 305px; top: 1515px; width: 226px; height: 28px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text289762378" data-review-reference-id="text289762378">\
         <div class="stencil-wrapper" style="width: 226px; height: 28px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline22"><p><span style="font-size: 24px; color: #658cd9;">Thống kê trong ngày</span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page271612227-layer-icon297474552" style="position: absolute; left: 980px; top: 1565px; width: 32px; height: 32px" data-interactive-element-type="fonticon.icon" class="icon stencil mobile-interaction-potential-trigger " data-stencil-id="icon297474552" data-review-reference-id="icon297474552">\
         <div class="stencil-wrapper" style="width: 32px; height: 32px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" style="width:32px;height:32px;" title="">\
               <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" class="fill-blue">\
                  <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#icon-glyph-e310"></use>\
               </svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page271612227-layer-text244109582" style="position: absolute; left: 1020px; top: 1570px; width: 118px; height: 20px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text244109582" data-review-reference-id="text244109582">\
         <div class="stencil-wrapper" style="width: 118px; height: 20px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline32"><p><span style="font-size: 18px;">Nhận xét mới</span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page271612227-layer-text673474919" style="position: absolute; left: 360px; top: 1605px; width: 77px; height: 37px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text673474919" data-review-reference-id="text673474919">\
         <div class="stencil-wrapper" style="width: 77px; height: 37px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline12"><p><span style="font-size: 32px;">2563</span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page271612227-layer-text628782145" style="position: absolute; left: 495px; top: 1605px; width: 59px; height: 37px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text628782145" data-review-reference-id="text628782145">\
         <div class="stencil-wrapper" style="width: 59px; height: 37px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline12"><p><span style="font-size: 32px;">142</span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page271612227-layer-text80495280" style="position: absolute; left: 665px; top: 1605px; width: 42px; height: 37px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text80495280" data-review-reference-id="text80495280">\
         <div class="stencil-wrapper" style="width: 42px; height: 37px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline12"><p><span style="font-size: 32px;">12</span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page271612227-layer-text748817498" style="position: absolute; left: 1040px; top: 1605px; width: 42px; height: 37px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text748817498" data-review-reference-id="text748817498">\
         <div class="stencil-wrapper" style="width: 42px; height: 37px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline12"><p><span style="font-size: 32px;">12</span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page271612227-layer-icon216596433" style="position: absolute; left: 1150px; top: 1565px; width: 32px; height: 32px" data-interactive-element-type="fonticon.icon" class="icon stencil mobile-interaction-potential-trigger " data-stencil-id="icon216596433" data-review-reference-id="icon216596433">\
         <div class="stencil-wrapper" style="width: 32px; height: 32px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" style="width:32px;height:32px;" title="">\
               <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" class="fill-blue">\
                  <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#icon-glyph-e203"></use>\
               </svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page271612227-layer-text164821205" style="position: absolute; left: 1185px; top: 1570px; width: 89px; height: 20px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text164821205" data-review-reference-id="text164821205">\
         <div class="stencil-wrapper" style="width: 89px; height: 20px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline32"><p class="none" style="font-size: 18px;">Đơn hàng </p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page271612227-layer-text988426186" style="position: absolute; left: 1205px; top: 1605px; width: 42px; height: 37px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text988426186" data-review-reference-id="text988426186">\
         <div class="stencil-wrapper" style="width: 42px; height: 37px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline12"><p><span style="font-size: 32px;">26</span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page271612227-layer-text955728268" style="position: absolute; left: 310px; top: 1680px; width: 166px; height: 28px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text955728268" data-review-reference-id="text955728268">\
         <div class="stencil-wrapper" style="width: 166px; height: 28px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline22"><p class="none" style="font-size: 24px;"><span style="color: #658cd9;">Thống kê tổng </span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page271612227-layer-icon866859006" style="position: absolute; left: 345px; top: 1740px; width: 32px; height: 32px" data-interactive-element-type="fonticon.icon" class="icon stencil mobile-interaction-potential-trigger " data-stencil-id="icon866859006" data-review-reference-id="icon866859006">\
         <div class="stencil-wrapper" style="width: 32px; height: 32px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" style="width:32px;height:32px;" title="">\
               <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" class="fill-blue">\
                  <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#icon-glyph-e021"></use>\
               </svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page271612227-layer-text14344760" style="position: absolute; left: 390px; top: 1745px; width: 131px; height: 20px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text14344760" data-review-reference-id="text14344760">\
         <div class="stencil-wrapper" style="width: 131px; height: 20px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline32"><p class="none" style="font-size: 18px;">Chủ cửa hàng </p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page271612227-layer-icon660216018" style="position: absolute; left: 535px; top: 1740px; width: 32px; height: 32px" data-interactive-element-type="fonticon.icon" class="icon stencil mobile-interaction-potential-trigger " data-stencil-id="icon660216018" data-review-reference-id="icon660216018">\
         <div class="stencil-wrapper" style="width: 32px; height: 32px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" style="width:32px;height:32px;" title="">\
               <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" class="fill-blue">\
                  <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#icon-glyph-e004"></use>\
               </svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page271612227-layer-text845570909" style="position: absolute; left: 580px; top: 1750px; width: 105px; height: 20px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text845570909" data-review-reference-id="text845570909">\
         <div class="stencil-wrapper" style="width: 105px; height: 20px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline32"><p class="none" style="font-size: 18px;">Thực khách</p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page271612227-layer-text638612662" style="position: absolute; left: 755px; top: 1745px; width: 137px; height: 20px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text638612662" data-review-reference-id="text638612662">\
         <div class="stencil-wrapper" style="width: 137px; height: 20px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline32"><p><span style="font-size: 18px;">Giá trị giao dịch</span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page271612227-layer-icon521107790" style="position: absolute; left: 710px; top: 1740px; width: 32px; height: 32px" data-interactive-element-type="fonticon.icon" class="icon stencil mobile-interaction-potential-trigger " data-stencil-id="icon521107790" data-review-reference-id="icon521107790">\
         <div class="stencil-wrapper" style="width: 32px; height: 32px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" style="width:32px;height:32px;" title="">\
               <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" class="fill-blue">\
                  <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#icon-glyph-e228"></use>\
               </svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page271612227-layer-icon77868297" style="position: absolute; left: 935px; top: 1740px; width: 32px; height: 32px" data-interactive-element-type="fonticon.icon" class="icon stencil mobile-interaction-potential-trigger " data-stencil-id="icon77868297" data-review-reference-id="icon77868297">\
         <div class="stencil-wrapper" style="width: 32px; height: 32px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" style="width:32px;height:32px;" title="">\
               <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" class="fill-blue">\
                  <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#icon-glyph-e203"></use>\
               </svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page271612227-layer-text892191880" style="position: absolute; left: 980px; top: 1745px; width: 95px; height: 20px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text892191880" data-review-reference-id="text892191880">\
         <div class="stencil-wrapper" style="width: 95px; height: 20px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline32"><p class="none" style="font-size: 18px;">Đơn hàng </p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page271612227-layer-icon868419500" style="position: absolute; left: 1100px; top: 1740px; width: 32px; height: 32px" data-interactive-element-type="fonticon.icon" class="icon stencil mobile-interaction-potential-trigger " data-stencil-id="icon868419500" data-review-reference-id="icon868419500">\
         <div class="stencil-wrapper" style="width: 32px; height: 32px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" style="width:32px;height:32px;" title="">\
               <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" class="fill-blue">\
                  <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#icon-glyph-e050"></use>\
               </svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page271612227-layer-text472859988" style="position: absolute; left: 1155px; top: 1745px; width: 178px; height: 20px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text472859988" data-review-reference-id="text472859988">\
         <div class="stencil-wrapper" style="width: 178px; height: 20px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline32"><p class="none" style="font-size: 18px;">Đánh giá trung bình </p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page271612227-layer-text568304008" style="position: absolute; left: 400px; top: 1800px; width: 69px; height: 37px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text568304008" data-review-reference-id="text568304008">\
         <div class="stencil-wrapper" style="width: 69px; height: 37px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline12"><p class="none" style="font-size: 32px;">210 </p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page271612227-layer-text415412555" style="position: absolute; left: 570px; top: 1800px; width: 59px; height: 37px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text415412555" data-review-reference-id="text415412555">\
         <div class="stencil-wrapper" style="width: 59px; height: 37px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline12"><p><span style="font-size: 32px;">489</span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page271612227-layer-text213620098" style="position: absolute; left: 740px; top: 1805px; width: 137px; height: 31px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text213620098" data-review-reference-id="text213620098">\
         <div class="stencil-wrapper" style="width: 137px; height: 31px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline12"><p><span style="font-size: 26px;">23.246.000</span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page271612227-layer-text116651954" style="position: absolute; left: 990px; top: 1800px; width: 59px; height: 37px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text116651954" data-review-reference-id="text116651954">\
         <div class="stencil-wrapper" style="width: 59px; height: 37px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline12"><p class="none" style="font-size: 32px;">568</p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page271612227-layer-text548221057" style="position: absolute; left: 1190px; top: 1800px; width: 50px; height: 37px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text548221057" data-review-reference-id="text548221057">\
         <div class="stencil-wrapper" style="width: 50px; height: 37px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline12"><p><span style="font-size: 32px;">3.5</span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page271612227-layer-text589256156" style="position: absolute; left: 315px; top: 1860px; width: 215px; height: 28px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text589256156" data-review-reference-id="text589256156">\
         <div class="stencil-wrapper" style="width: 215px; height: 28px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline22"><p><span style="font-size: 24px; color: #658cd9;">Thống kê đơn hàng</span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page271612227-layer-837931805" style="position: absolute; left: 1160px; top: 2050px; width: 176px; height: 23px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="837931805" data-review-reference-id="837931805">\
         <div class="stencil-wrapper" style="width: 176px; height: 23px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline32"><p class="none" style="font-size: 18px;"><span style="color: #b1c51a; font-size: 20px;">Đã thanh toán: 374</span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page271612227-layer-910786443" style="position: absolute; left: 1160px; top: 2080px; width: 108px; height: 23px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="910786443" data-review-reference-id="910786443">\
         <div class="stencil-wrapper" style="width: 108px; height: 23px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline32"><p class="none" style="font-size: 18px;"><span style="color: #f2a63f; font-size: 20px;">Đã hủy: 59 </span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page271612227-layer-815507455" style="position: absolute; left: 1160px; top: 1990px; width: 189px; height: 23px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="815507455" data-review-reference-id="815507455">\
         <div class="stencil-wrapper" style="width: 189px; height: 23px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline32"><p><span style="font-size: 20px; color: #658cd9;">Chờ thanh toán: 124</span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page271612227-layer-682707788" style="position: absolute; left: 1160px; top: 2020px; width: 178px; height: 23px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="682707788" data-review-reference-id="682707788">\
         <div class="stencil-wrapper" style="width: 178px; height: 23px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline32"><p class="none" style="font-size: 18px;"><span style="font-size: 20px; color: #d96666;">Chưa xác nhận : 34</span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page271612227-layer-1560535390" style="position: absolute; left: 790px; top: 1890px; width: 360px; height: 360px" data-interactive-element-type="fonticon.icon" class="icon stencil mobile-interaction-potential-trigger " data-stencil-id="1560535390" data-review-reference-id="1560535390">\
         <div class="stencil-wrapper" style="width: 360px; height: 360px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" style="width:360px;height:360px;" title="">\
               <svg xmlns="http://www.w3.org/2000/svg" width="360" height="360" class="fill-black">\
                  <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#icon-glyph-e043"></use>\
               </svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page271612227-layer-1563436380" style="position: absolute; left: 600px; top: 2050px; width: 94px; height: 23px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="1563436380" data-review-reference-id="1563436380">\
         <div class="stencil-wrapper" style="width: 94px; height: 23px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline32"><p class="none" style="font-size: 18px;"><span style="color: #b1c51a; font-size: 20px;">Bufet: 374</span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page271612227-layer-1059445969" style="position: absolute; left: 600px; top: 2080px; width: 125px; height: 23px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="1059445969" data-review-reference-id="1059445969">\
         <div class="stencil-wrapper" style="width: 125px; height: 23px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline32"><p class="none" style="font-size: 18px;"><span style="color: #f2a63f; font-size: 20px;">Tùy chọn: 59 </span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page271612227-layer-931132211" style="position: absolute; left: 600px; top: 1990px; width: 81px; height: 23px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="931132211" data-review-reference-id="931132211">\
         <div class="stencil-wrapper" style="width: 81px; height: 23px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline32"><p><span style="font-size: 20px; color: #658cd9;">Lẩu: 124</span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page271612227-layer-344698266" style="position: absolute; left: 600px; top: 2020px; width: 101px; height: 23px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="344698266" data-review-reference-id="344698266">\
         <div class="stencil-wrapper" style="width: 101px; height: 23px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline32"><p class="none" style="font-size: 18px;"><span style="font-size: 20px; color: #d96666;">Nướng: 34</span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page271612227-layer-1262139680" style="position: absolute; left: 230px; top: 1890px; width: 360px; height: 360px" data-interactive-element-type="fonticon.icon" class="icon stencil mobile-interaction-potential-trigger " data-stencil-id="1262139680" data-review-reference-id="1262139680">\
         <div class="stencil-wrapper" style="width: 360px; height: 360px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" style="width:360px;height:360px;" title="">\
               <svg xmlns="http://www.w3.org/2000/svg" width="360" height="360" class="fill-black">\
                  <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#icon-glyph-e043"></use>\
               </svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page271612227-layer-text986626586" style="position: absolute; left: 565px; top: 1900px; width: 321px; height: 28px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text986626586" data-review-reference-id="text986626586">\
         <div class="stencil-wrapper" style="width: 321px; height: 28px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline22"><p class="none" style="font-size: 24px;">Đơn hàng từ 350 thực khách </p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page271612227-layer-text814209321" style="position: absolute; left: 600px; top: 2115px; width: 82px; height: 20px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text814209321" data-review-reference-id="text814209321">\
         <div class="stencil-wrapper" style="width: 82px; height: 20px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline32"><p><span style="font-size: 18px; color: #d9d9d9;">Chay: 56</span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page271612227-layer-chart57168250" style="position: absolute; left: 285px; top: 2305px; width: 955px; height: 450px" data-interactive-element-type="static.chart" class="chart stencil mobile-interaction-potential-trigger " data-stencil-id="chart57168250" data-review-reference-id="chart57168250">\
         <div class="stencil-wrapper" style="width: 955px; height: 450px">\
            <div title="">\
               <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" style="height: 450px;width:955px;" viewBox="0 0 955 450" width="955" height="450">\
                  <svg:g width="955" height="450">\
                     <svg:g transform="scale(5.305555555555555, 3)"><svg:path id="defaultID" d="M 0.00, 0.00 Q 10.00, -2.43, 20.00, -2.40 Q 30.00, -2.14, 40.00, -2.16 Q 50.00, -1.82, 60.00,\
                        -1.81 Q 70.00, -1.93, 80.00, -1.89 Q 90.00, -1.59, 100.00, -0.71 Q 110.00, -1.06, 120.00, -0.70 Q 130.00, -1.22, 140.00, -1.44\
                        Q 150.00, -1.74, 160.00, -1.71 Q 170.00, -1.83, 180.74, -0.74 Q 181.20, 10.31, 180.58, 21.35 Q 181.11, 32.07, 181.20, 42.82\
                        Q 180.67, 53.56, 180.63, 64.28 Q 181.50, 74.99, 181.47, 85.71 Q 181.21, 96.43, 181.58, 107.14 Q 181.82, 117.86, 182.03, 128.57\
                        Q 182.08, 139.29, 181.08, 151.08 Q 170.52, 151.56, 160.29, 152.03 Q 150.10, 151.48, 140.05, 151.43 Q 130.02, 151.48, 120.01,\
                        151.61 Q 110.00, 150.64, 100.00, 150.02 Q 90.00, 150.28, 80.00, 150.79 Q 70.00, 151.74, 60.00, 151.09 Q 50.00, 150.61, 40.00,\
                        150.23 Q 30.00, 150.56, 20.00, 149.62 Q 10.00, 150.57, -0.55, 150.55 Q -0.98, 139.61, -1.04, 128.72 Q -0.65, 117.90, -0.90,\
                        107.17 Q -0.98, 96.44, -1.19, 85.72 Q -0.90, 75.00, -1.04, 64.29 Q -1.14, 53.57, -1.09, 42.86 Q -1.43, 32.14, -1.64, 21.43\
                        Q 0.00, 10.71, 0.00, -0.00" style="fill:white;stroke:none;" class="svg_unselected_element"/>\
                        <svg:g name="line" style="fill:none;stroke:black;stroke-width:1px;"><svg:path d="M 9.00, 3.00 Q 10.47, 14.42, 9.51, 25.83 Q 9.42, 37.25, 8.30, 48.67 Q 8.75, 60.08, 9.43, 71.50 Q 9.15, 82.92,\
                           8.98, 94.33 Q 8.97, 105.75, 9.15, 117.17 Q 8.69, 128.58, 9.07, 139.93 Q 20.12, 140.70, 31.73, 139.88 Q 43.09, 139.66, 54.46,\
                           139.12 Q 65.80, 139.21, 77.15, 139.12 Q 88.50, 139.25, 99.86, 139.40 Q 111.22, 139.20, 122.57, 140.21 Q 133.93, 139.68, 145.29,\
                           138.72 Q 156.64, 139.13, 168.00, 139.88 Q 172.00, 140.00, 176.00, 140.00" style=" fill:none;" class="svg_unselected_element"/><svg:path d="M 167.00, 135.00 Q 171.28, 138.94, 176.50, 140.00 Q 172.00, 142.50, 167.00, 145.00" style=" fill:none;" class="svg_unselected_element"/><svg:path d="M 4.00, 13.00 Q 6.19, 7.85, 9.00, 2.83 Q 11.50, 8.00, 14.00, 13.00" style=" fill:none;" class="svg_unselected_element"/><svg:path d="M 9.00, 140.00 Q 18.07, 124.92, 28.63, 110.73 Q 36.59, 103.55, 46.01, 96.79 Q 50.58, 100.85, 53.61, 104.75 Q\
                           60.05, 96.23, 67.03, 87.99 Q 70.21, 84.75, 73.14, 81.54 Q 74.09, 77.65, 74.58, 73.15 Q 77.87, 69.69, 82.11, 66.36 Q 87.69,\
                           80.97, 91.84, 95.78 Q 94.05, 85.79, 97.02, 76.01 Q 101.97, 71.38, 106.09, 66.05 Q 108.57, 58.03, 110.96, 49.98 Q 116.07, 43.19,\
                           122.03, 36.43 Q 124.76, 40.68, 127.27, 44.84 Q 128.02, 47.99, 129.42, 50.29 Q 134.05, 50.81, 138.60, 50.21 Q 144.80, 39.81,\
                           150.83, 28.74 Q 154.99, 27.49, 158.63, 25.72 Q 158.34, 20.29, 161.34, 16.26 Q 163.50, 14.00, 166.00, 12.00" style=" fill:none;"\
                           class="svg_unselected_element"/><svg:path d="M 10.00, 140.00 Q 12.14, 123.05, 16.27, 106.23 Q 22.13, 98.23, 27.47, 90.37 Q 30.18, 81.55, 33.77, 72.27 Q 39.26,\
                           75.58, 43.71, 79.63 Q 47.02, 67.23, 50.83, 54.76 Q 56.21, 52.86, 61.67, 51.62 Q 67.43, 42.50, 74.03, 33.68 Q 79.88, 42.66,\
                           86.03, 51.52 Q 92.51, 47.02, 98.90, 43.28 Q 105.32, 50.61, 111.11, 58.89 Q 116.53, 63.99, 121.88, 69.52 Q 125.32, 83.68, 128.36,\
                           97.84 Q 133.77, 108.37, 139.00, 118.76 Q 143.10, 111.09, 147.05, 102.92 Q 150.48, 114.01, 153.63, 125.29 Q 159.50, 130.50,\
                           165.00, 136.00" style=" fill:none;" class="svg_unselected_element"/>\
                        </svg:g>\
                     </svg:g>\
                  </svg:g>\
               </svg:svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page271612227-layer-text374185035" style="position: absolute; left: 325px; top: 2245px; width: 259px; height: 28px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text374185035" data-review-reference-id="text374185035">\
         <div class="stencil-wrapper" style="width: 259px; height: 28px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline22"><p><span style="font-size: 24px; color: #658cd9;">Thống kê theo thời gian</span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page271612227-layer-icon873397376" style="position: absolute; left: 400px; top: 2755px; width: 32px; height: 32px" data-interactive-element-type="fonticon.icon" class="icon stencil mobile-interaction-potential-trigger " data-stencil-id="icon873397376" data-review-reference-id="icon873397376">\
         <div class="stencil-wrapper" style="width: 32px; height: 32px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" style="width:32px;height:32px;" title="">\
               <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" class="fill-blue">\
                  <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#icon-glyph-e052"></use>\
               </svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page271612227-layer-icon161794730" style="position: absolute; left: 515px; top: 2755px; width: 32px; height: 32px" data-interactive-element-type="fonticon.icon" class="icon stencil mobile-interaction-potential-trigger " data-stencil-id="icon161794730" data-review-reference-id="icon161794730">\
         <div class="stencil-wrapper" style="width: 32px; height: 32px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" style="width:32px;height:32px;" title="">\
               <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" class="fill-blue">\
                  <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#icon-glyph-e004"></use>\
               </svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page271612227-layer-icon584919311" style="position: absolute; left: 630px; top: 2755px; width: 32px; height: 32px" data-interactive-element-type="fonticon.icon" class="icon stencil mobile-interaction-potential-trigger " data-stencil-id="icon584919311" data-review-reference-id="icon584919311">\
         <div class="stencil-wrapper" style="width: 32px; height: 32px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" style="width:32px;height:32px;" title="">\
               <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" class="fill-blue">\
                  <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#icon-glyph-e203"></use>\
               </svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page271612227-layer-icon778384437" style="position: absolute; left: 735px; top: 2755px; width: 32px; height: 32px" data-interactive-element-type="fonticon.icon" class="icon stencil mobile-interaction-potential-trigger " data-stencil-id="icon778384437" data-review-reference-id="icon778384437">\
         <div class="stencil-wrapper" style="width: 32px; height: 32px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" style="width:32px;height:32px;" title="">\
               <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" class="fill-blue">\
                  <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#icon-glyph-e007"></use>\
               </svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page271612227-layer-icon520909763" style="position: absolute; left: 840px; top: 2755px; width: 32px; height: 32px" data-interactive-element-type="fonticon.icon" class="icon stencil mobile-interaction-potential-trigger " data-stencil-id="icon520909763" data-review-reference-id="icon520909763">\
         <div class="stencil-wrapper" style="width: 32px; height: 32px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" style="width:32px;height:32px;" title="">\
               <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" class="fill-blue">\
                  <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#icon-glyph-e228"></use>\
               </svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page271612227-layer-datepicker142658128" style="position: absolute; left: 815px; top: 2245px; width: 150px; height: 30px" data-interactive-element-type="default.datepicker" class="datepicker stencil mobile-interaction-potential-trigger " data-stencil-id="datepicker142658128" data-review-reference-id="datepicker142658128">\
         <div class="stencil-wrapper" style="width: 150px; height: 30px">\
            <div>\
               <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" style="position: absolute; height: 30px;width:150px;" width="150" height="30">\
                  <svg:g width="150px" height="30px"><svg:path id="__containerId__-page271612227-layer-datepicker142658128_input_svg_border" d="M 2.00, 2.00 Q 13.20, 0.31, 24.40,\
                     0.55 Q 35.60, 1.53, 46.80, 1.20 Q 58.00, 1.30, 69.20, 2.33 Q 80.40, 2.65, 91.60, 2.44 Q 102.80, 1.57, 114.32, 1.68 Q 114.49,\
                     14.84, 114.20, 28.20 Q 102.88, 28.28, 91.60, 28.03 Q 80.39, 27.76, 69.18, 27.34 Q 57.99, 27.07, 46.80, 27.76 Q 35.60, 28.21,\
                     24.40, 28.22 Q 13.20, 27.77, 1.82, 28.18 Q 2.00, 15.00, 2.00, 2.00" style=" fill:white;" class="svg_unselected_element"/><svg:path id="__containerId__-page271612227-layer-datepicker142658128_line1" d="M 3.00, 3.00 Q 14.90, 4.71, 26.80, 4.34 Q\
                     38.70, 4.14, 50.60, 3.32 Q 62.50, 3.04, 74.40, 2.89 Q 86.30, 2.67, 98.20, 2.07 Q 110.10, 3.00, 122.00, 3.00" style=" fill:none;"\
                     class="svg_unselected_element"/><svg:path id="__containerId__-page271612227-layer-datepicker142658128_line2" d="M 3.00, 3.00 Q 3.00, 15.00, 3.00, 27.00" style="\
                     fill:none;" class="svg_unselected_element"/><svg:path id="__containerId__-page271612227-layer-datepicker142658128_line3" d="M 3.00, 3.00 Q 14.90, 1.15, 26.80, 0.93 Q\
                     38.70, 1.58, 50.60, 1.16 Q 62.50, 1.23, 74.40, 2.21 Q 86.30, 1.22, 98.20, 1.13 Q 110.10, 3.00, 122.00, 3.00" style=" fill:none;"\
                     class="svg_unselected_element"/><svg:path id="__containerId__-page271612227-layer-datepicker142658128_line4" d="M 3.00, 3.00 Q 3.00, 15.00, 3.00, 27.00" style="\
                     fill:none;" class="svg_unselected_element"/>\
                  </svg:g>\
                  <svg:g width="150px" height="30px"><svg:path id="__containerId__-page271612227-layer-datepicker142658128_input_svg_border2" d="M 118.00, 2.00 Q 133.00, -0.23,\
                     148.77, 1.23 Q 149.04, 14.65, 148.30, 28.30 Q 133.07, 28.24, 117.75, 28.21 Q 118.00, 15.00, 118.00, 2.00" style=" fill:white;"\
                     class="svg_unselected_element"/>\
                  </svg:g>\
               </svg:svg>\
               <div style="white-space: nowrap;" title=""><input type="text" onblur="rabbit.facade.raiseEvent(rabbit.events.svgBlur, new Array(\'__containerId__-page271612227-layer-datepicker142658128_input_svg_border\',\'__containerId__-page271612227-layer-datepicker142658128_line1\',\'__containerId__-page271612227-layer-datepicker142658128_line2\',\'__containerId__-page271612227-layer-datepicker142658128_line3\',\'__containerId__-page271612227-layer-datepicker142658128_line4\'))" onfocus="rabbit.facade.raiseEvent(rabbit.events.svgFocus, new Array(\'__containerId__-page271612227-layer-datepicker142658128_input_svg_border\',\'__containerId__-page271612227-layer-datepicker142658128_line1\',\'__containerId__-page271612227-layer-datepicker142658128_line2\',\'__containerId__-page271612227-layer-datepicker142658128_line3\',\'__containerId__-page271612227-layer-datepicker142658128_line4\'))" style="width:116px; height:30px;padding: 0px;border-width:1px; position: absolute;" id="__containerId__-page271612227-layer-datepicker142658128_input" /><button type="button" onblur="rabbit.facade.raiseEvent(rabbit.events.svgBlur, \'__containerId__-page271612227-layer-datepicker142658128_input_svg_border2\')" onfocus="rabbit.facade.raiseEvent(rabbit.events.svgFocus, \'__containerId__-page271612227-layer-datepicker142658128_input_svg_border2\')" style="position:absolute; left:116px; top:0px; width:34px; height:30px; vertical-align: top; padding: 0px;border-width:1px; cursor:pointer;" id="__containerId__-page271612227-layer-datepicker142658128_button"><img src="../resources/icons/date.png" /></button></div>\
               <div id="__containerId__-page271612227-layer-datepicker142658128_ov" class="yui-skin-sam" style="position: absolute; width: 16em;visibility:visible;">\
                  <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" style="position: absolute; left: -6px; top: -4px; height: 204px;width:200px;display:none" id="__containerId__-page271612227-layer-datepicker142658128_open_calendar" width="150" height="204"><svg:path id="__containerId__-page271612227-layer-datepicker142658128_open_calendar_border" d="M 2.00, 2.00 Q 12.89, 1.61,\
                     23.78, 2.07 Q 34.67, 1.88, 45.56, 1.88 Q 56.44, 2.07, 67.33, 1.87 Q 78.22, 0.89, 89.11, 0.70 Q 100.00, 1.60, 110.89, 1.75\
                     Q 121.78, 0.76, 132.67, 1.69 Q 143.56, 1.83, 154.44, 0.52 Q 165.33, -0.08, 176.22, -0.11 Q 187.11, 1.30, 198.30, 1.70 Q 198.60,\
                     11.80, 198.53, 21.92 Q 199.63, 31.89, 199.93, 41.94 Q 198.79, 51.99, 198.03, 62.00 Q 197.31, 72.00, 197.12, 82.00 Q 197.09,\
                     92.00, 198.76, 102.00 Q 198.66, 112.00, 199.77, 122.00 Q 199.23, 132.00, 198.98, 142.00 Q 197.54, 152.00, 197.78, 162.00 Q\
                     197.88, 172.00, 198.01, 182.00 Q 198.39, 192.00, 198.60, 202.60 Q 187.35, 202.71, 176.27, 202.37 Q 165.39, 202.92, 154.49,\
                     203.37 Q 143.57, 203.05, 132.68, 203.58 Q 121.78, 203.15, 110.89, 202.26 Q 100.00, 202.75, 89.11, 202.37 Q 78.22, 202.14,\
                     67.33, 202.69 Q 56.44, 203.17, 45.56, 202.84 Q 34.67, 202.16, 23.78, 202.07 Q 12.89, 202.19, 1.80, 202.20 Q 2.05, 191.98,\
                     2.38, 181.95 Q 1.88, 172.01, 1.17, 162.03 Q 0.94, 152.02, 1.65, 142.00 Q 0.55, 132.01, 1.76, 122.00 Q 3.29, 112.00, 3.35,\
                     102.00 Q 2.37, 92.00, 2.27, 82.00 Q 1.62, 72.00, 0.99, 62.00 Q 1.14, 52.00, 0.66, 42.00 Q 0.53, 32.00, 0.63, 22.00 Q 2.00,\
                     12.00, 2.00, 2.00" style=" fill:white;" class="svg_unselected_element"/>\
                  </svg:svg>\
                  <div id="__containerId__-page271612227-layer-datepicker142658128_cal"></div>\
               </div><script type="text/javascript">\
				rabbit.stencils.datepicker.setupDatepicker("__containerId__-page271612227-layer-datepicker142658128");\
			</script></div>\
         </div>\
      </div>\
      <div id="__containerId__-page271612227-layer-datepicker318945540" style="position: absolute; left: 1035px; top: 2245px; width: 150px; height: 30px" data-interactive-element-type="default.datepicker" class="datepicker stencil mobile-interaction-potential-trigger " data-stencil-id="datepicker318945540" data-review-reference-id="datepicker318945540">\
         <div class="stencil-wrapper" style="width: 150px; height: 30px">\
            <div>\
               <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" style="position: absolute; height: 30px;width:150px;" width="150" height="30">\
                  <svg:g width="150px" height="30px"><svg:path id="__containerId__-page271612227-layer-datepicker318945540_input_svg_border" d="M 2.00, 2.00 Q 13.20, 2.49, 24.40,\
                     2.94 Q 35.60, 2.72, 46.80, 2.78 Q 58.00, 1.42, 69.20, 1.88 Q 80.40, 2.20, 91.60, 2.11 Q 102.80, 1.60, 114.29, 1.71 Q 114.32,\
                     14.89, 114.03, 28.03 Q 102.90, 28.38, 91.66, 28.52 Q 80.44, 28.74, 69.22, 28.71 Q 58.01, 28.53, 46.80, 27.81 Q 35.60, 27.41,\
                     24.40, 27.50 Q 13.20, 28.47, 1.89, 28.11 Q 2.00, 15.00, 2.00, 2.00" style=" fill:white;" class="svg_unselected_element"/><svg:path id="__containerId__-page271612227-layer-datepicker318945540_line1" d="M 3.00, 3.00 Q 14.90, 2.11, 26.80, 2.27 Q\
                     38.70, 2.23, 50.60, 2.16 Q 62.50, 2.19, 74.40, 2.85 Q 86.30, 2.59, 98.20, 2.12 Q 110.10, 3.00, 122.00, 3.00" style=" fill:none;"\
                     class="svg_unselected_element"/><svg:path id="__containerId__-page271612227-layer-datepicker318945540_line2" d="M 3.00, 3.00 Q 3.00, 15.00, 3.00, 27.00" style="\
                     fill:none;" class="svg_unselected_element"/><svg:path id="__containerId__-page271612227-layer-datepicker318945540_line3" d="M 3.00, 3.00 Q 14.90, 1.71, 26.80, 2.34 Q\
                     38.70, 2.41, 50.60, 3.06 Q 62.50, 3.23, 74.40, 2.98 Q 86.30, 3.39, 98.20, 3.91 Q 110.10, 3.00, 122.00, 3.00" style=" fill:none;"\
                     class="svg_unselected_element"/><svg:path id="__containerId__-page271612227-layer-datepicker318945540_line4" d="M 3.00, 3.00 Q 3.00, 15.00, 3.00, 27.00" style="\
                     fill:none;" class="svg_unselected_element"/>\
                  </svg:g>\
                  <svg:g width="150px" height="30px"><svg:path id="__containerId__-page271612227-layer-datepicker318945540_input_svg_border2" d="M 118.00, 2.00 Q 133.00, 1.35,\
                     148.35, 1.65 Q 148.73, 14.76, 148.40, 28.40 Q 133.26, 28.97, 117.38, 28.52 Q 118.00, 15.00, 118.00, 2.00" style=" fill:white;"\
                     class="svg_unselected_element"/>\
                  </svg:g>\
               </svg:svg>\
               <div style="white-space: nowrap;" title=""><input type="text" onblur="rabbit.facade.raiseEvent(rabbit.events.svgBlur, new Array(\'__containerId__-page271612227-layer-datepicker318945540_input_svg_border\',\'__containerId__-page271612227-layer-datepicker318945540_line1\',\'__containerId__-page271612227-layer-datepicker318945540_line2\',\'__containerId__-page271612227-layer-datepicker318945540_line3\',\'__containerId__-page271612227-layer-datepicker318945540_line4\'))" onfocus="rabbit.facade.raiseEvent(rabbit.events.svgFocus, new Array(\'__containerId__-page271612227-layer-datepicker318945540_input_svg_border\',\'__containerId__-page271612227-layer-datepicker318945540_line1\',\'__containerId__-page271612227-layer-datepicker318945540_line2\',\'__containerId__-page271612227-layer-datepicker318945540_line3\',\'__containerId__-page271612227-layer-datepicker318945540_line4\'))" style="width:116px; height:30px;padding: 0px;border-width:1px; position: absolute;" id="__containerId__-page271612227-layer-datepicker318945540_input" /><button type="button" onblur="rabbit.facade.raiseEvent(rabbit.events.svgBlur, \'__containerId__-page271612227-layer-datepicker318945540_input_svg_border2\')" onfocus="rabbit.facade.raiseEvent(rabbit.events.svgFocus, \'__containerId__-page271612227-layer-datepicker318945540_input_svg_border2\')" style="position:absolute; left:116px; top:0px; width:34px; height:30px; vertical-align: top; padding: 0px;border-width:1px; cursor:pointer;" id="__containerId__-page271612227-layer-datepicker318945540_button"><img src="../resources/icons/date.png" /></button></div>\
               <div id="__containerId__-page271612227-layer-datepicker318945540_ov" class="yui-skin-sam" style="position: absolute; width: 16em;visibility:visible;">\
                  <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" style="position: absolute; left: -6px; top: -4px; height: 204px;width:200px;display:none" id="__containerId__-page271612227-layer-datepicker318945540_open_calendar" width="150" height="204"><svg:path id="__containerId__-page271612227-layer-datepicker318945540_open_calendar_border" d="M 2.00, 2.00 Q 12.89, 0.74,\
                     23.78, 0.66 Q 34.67, 0.88, 45.56, 1.04 Q 56.44, 1.43, 67.33, 1.21 Q 78.22, 1.04, 89.11, 1.15 Q 100.00, 0.83, 110.89, 1.27\
                     Q 121.78, 0.70, 132.67, 0.76 Q 143.56, 0.84, 154.44, 1.06 Q 165.33, 1.72, 176.22, 1.58 Q 187.11, 1.49, 198.42, 1.58 Q 198.61,\
                     11.80, 198.29, 21.96 Q 198.74, 31.95, 198.67, 41.98 Q 198.41, 51.99, 197.90, 62.00 Q 198.04, 72.00, 197.78, 82.00 Q 198.76,\
                     92.00, 198.93, 102.00 Q 199.17, 112.00, 198.71, 122.00 Q 198.71, 132.00, 198.97, 142.00 Q 198.66, 152.00, 198.12, 162.00 Q\
                     198.24, 172.00, 198.61, 182.00 Q 198.88, 192.00, 198.80, 202.80 Q 187.41, 202.89, 176.37, 203.01 Q 165.40, 203.07, 154.48,\
                     202.97 Q 143.58, 203.72, 132.68, 203.47 Q 121.78, 203.60, 110.89, 202.72 Q 100.00, 203.25, 89.11, 202.05 Q 78.22, 202.56,\
                     67.33, 201.78 Q 56.44, 201.37, 45.56, 201.03 Q 34.67, 202.40, 23.78, 202.29 Q 12.89, 202.43, 1.59, 202.41 Q 1.44, 192.19,\
                     0.78, 182.17 Q 0.83, 172.08, 1.27, 162.02 Q 1.27, 152.01, 1.16, 142.01 Q 1.30, 132.00, 1.32, 122.00 Q 1.25, 112.00, 1.69,\
                     102.00 Q 1.46, 92.00, 2.22, 82.00 Q 2.43, 72.00, 1.94, 62.00 Q 1.22, 52.00, 2.22, 42.00 Q 2.21, 32.00, 1.50, 22.00 Q 2.00,\
                     12.00, 2.00, 2.00" style=" fill:white;" class="svg_unselected_element"/>\
                  </svg:svg>\
                  <div id="__containerId__-page271612227-layer-datepicker318945540_cal"></div>\
               </div><script type="text/javascript">\
				rabbit.stencils.datepicker.setupDatepicker("__containerId__-page271612227-layer-datepicker318945540");\
			</script></div>\
         </div>\
      </div>\
      <div id="__containerId__-page271612227-layer-icon521035252" style="position: absolute; left: 975px; top: 2245px; width: 32px; height: 32px" data-interactive-element-type="fonticon.icon" class="icon stencil mobile-interaction-potential-trigger " data-stencil-id="icon521035252" data-review-reference-id="icon521035252">\
         <div class="stencil-wrapper" style="width: 32px; height: 32px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" style="width:32px;height:32px;" title="">\
               <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" class="fill-black">\
                  <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#icon-glyph-e212"></use>\
               </svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page271612227-layer-1078109739" style="position: absolute; left: 70px; top: 445px; width: 146px; height: 28px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="1078109739" data-review-reference-id="1078109739">\
         <div class="stencil-wrapper" style="width: 146px; height: 28px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline22"><p class="none" style="font-size: 24px;"><span style="color: #658cd9;">Quản lí Web</span> </p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page271612227-layer-936737504" style="position: absolute; left: 25px; top: 440px; width: 32px; height: 32px" data-interactive-element-type="fonticon.icon" class="icon stencil mobile-interaction-potential-trigger " data-stencil-id="936737504" data-review-reference-id="936737504">\
         <div class="stencil-wrapper" style="width: 32px; height: 32px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" style="width:32px;height:32px;" title="">\
               <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" class="fill-blue">\
                  <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#icon-glyph-e281"></use>\
               </svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page271612227-layer-icon638930188" style="position: absolute; left: 780px; top: 1565px; width: 32px; height: 32px" data-interactive-element-type="fonticon.icon" class="icon stencil mobile-interaction-potential-trigger " data-stencil-id="icon638930188" data-review-reference-id="icon638930188">\
         <div class="stencil-wrapper" style="width: 32px; height: 32px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" style="width:32px;height:32px;" title="">\
               <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" class="fill-blue">\
                  <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#icon-glyph-e021"></use>\
               </svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page271612227-layer-text702135114" style="position: absolute; left: 815px; top: 1575px; width: 95px; height: 17px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text702135114" data-review-reference-id="text702135114">\
         <div class="stencil-wrapper" style="width: 95px; height: 17px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.text2"><p style="font-size: 14px;">Nhà hàng mới</p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page271612227-layer-arrow53562341" style="position: absolute; left: 265px; top: 2810px; width: 965px; height: 33px" data-interactive-element-type="static.line" class="line stencil mobile-interaction-potential-trigger " data-stencil-id="arrow53562341" data-review-reference-id="arrow53562341">\
         <div class="stencil-wrapper" style="width: 965px; height: 33px">\
            <div title="">\
               <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" style="position: absolute; left: -5px; top: -5px; height: 43px;width:975px;" viewBox="-5 -5 975 43" width="975" height="43"><svg:path d="M 0.00, 16.00 Q 10.05, 15.68, 20.10, 16.06 Q 30.16, 15.51, 40.21, 16.16 Q 50.26, 16.27, 60.31, 15.63 Q 70.36,\
                  16.52, 80.42, 16.86 Q 90.47, 16.30, 100.52, 16.72 Q 110.57, 16.20, 120.63, 15.64 Q 130.68, 14.95, 140.73, 15.95 Q 150.78,\
                  16.16, 160.83, 15.68 Q 170.89, 15.34, 180.94, 15.56 Q 190.99, 14.90, 201.04, 16.39 Q 211.09, 16.63, 221.15, 15.75 Q 231.20,\
                  15.76, 241.25, 15.76 Q 251.30, 14.98, 261.35, 14.86 Q 271.41, 14.43, 281.46, 15.15 Q 291.51, 15.48, 301.56, 15.59 Q 311.61,\
                  14.54, 321.67, 15.25 Q 331.72, 16.54, 341.77, 15.15 Q 351.82, 14.98, 361.88, 15.44 Q 371.93, 14.79, 381.98, 14.08 Q 392.03,\
                  15.68, 402.08, 15.91 Q 412.14, 17.23, 422.19, 16.75 Q 432.24, 15.11, 442.29, 14.80 Q 452.34, 14.15, 462.40, 14.55 Q 472.45,\
                  14.45, 482.50, 15.22 Q 492.55, 14.89, 502.60, 14.74 Q 512.66, 15.03, 522.71, 14.69 Q 532.76, 14.80, 542.81, 13.65 Q 552.86,\
                  13.74, 562.92, 13.73 Q 572.97, 14.32, 583.02, 14.85 Q 593.07, 15.18, 603.12, 15.39 Q 613.18, 14.83, 623.23, 14.04 Q 633.28,\
                  13.51, 643.33, 13.66 Q 653.39, 14.99, 663.44, 15.54 Q 673.49, 15.07, 683.54, 14.68 Q 693.59, 15.30, 703.65, 15.72 Q 713.70,\
                  16.30, 723.75, 16.28 Q 733.80, 16.38, 743.85, 15.58 Q 753.91, 14.83, 763.96, 14.24 Q 774.01, 15.16, 784.06, 15.81 Q 794.11,\
                  15.89, 804.17, 15.60 Q 814.22, 17.13, 824.27, 16.55 Q 834.32, 15.78, 844.37, 15.45 Q 854.43, 15.12, 864.48, 14.75 Q 874.53,\
                  15.43, 884.58, 15.53 Q 894.63, 15.28, 904.69, 14.36 Q 914.74, 15.13, 924.79, 14.89 Q 934.84, 14.41, 944.90, 14.42 Q 954.95,\
                  16.00, 965.00, 16.00" style="marker-start:;marker-end:" class="svg_unselected_element"/>\
               </svg:svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page271612227-layer-table566536323" style="position: absolute; left: 330px; top: 765px; width: 682px; height: 148px" data-interactive-element-type="default.table" class="table stencil mobile-interaction-potential-trigger " data-stencil-id="table566536323" data-review-reference-id="table566536323">\
         <div class="stencil-wrapper" style="width: 682px; height: 148px">\
            <div title="">\
               <svg:svg xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" style="height: 148px;width:682px;" width="682" height="148">\
                  <svg:g x="0" y="0" width="682" height="148" style="stroke:black;stroke-width:1px;fill:white;"><svg:path d="M 2.00, 2.00 Q 12.27, 3.21, 22.55, 2.57 Q 32.82, 2.38, 43.09, 2.06 Q 53.36, 3.30, 63.64, 2.28 Q 73.91, 2.40,\
                     84.18, 1.65 Q 94.45, 2.44, 104.73, 2.46 Q 115.00, 1.90, 125.27, 1.12 Q 135.55, 1.66, 145.82, 2.67 Q 156.09, 1.95, 166.36,\
                     2.23 Q 176.64, 2.44, 186.91, 2.43 Q 197.18, 1.50, 207.45, 1.61 Q 217.73, 1.38, 228.00, 1.67 Q 238.27, 2.55, 248.55, 1.10 Q\
                     258.82, 1.04, 269.09, 1.14 Q 279.36, 1.86, 289.64, 1.88 Q 299.91, 2.22, 310.18, 1.76 Q 320.45, 2.32, 330.73, 2.87 Q 341.00,\
                     2.66, 351.27, 3.58 Q 361.55, 2.46, 371.82, 2.70 Q 382.09, 2.46, 392.36, 1.78 Q 402.64, 0.52, 412.91, 1.43 Q 423.18, 1.67,\
                     433.45, 1.12 Q 443.73, 1.56, 454.00, 1.10 Q 464.27, 1.73, 474.55, 2.33 Q 484.82, 1.59, 495.09, 0.80 Q 505.36, 0.81, 515.64,\
                     1.07 Q 525.91, 0.80, 536.18, 0.58 Q 546.45, 0.38, 556.73, 0.22 Q 567.00, 0.61, 577.27, 0.41 Q 587.55, 0.34, 597.82, 1.81 Q\
                     608.09, 2.30, 618.36, 1.54 Q 628.64, 1.68, 638.91, 1.66 Q 649.18, 1.71, 659.45, 1.91 Q 669.73, 1.14, 680.24, 1.76 Q 679.50,\
                     12.45, 678.98, 22.72 Q 679.76, 32.87, 680.77, 43.12 Q 680.71, 53.42, 680.52, 63.71 Q 680.52, 74.00, 681.11, 84.28 Q 681.98,\
                     94.57, 681.06, 104.86 Q 681.20, 115.14, 682.19, 125.43 Q 681.80, 135.71, 680.52, 146.52 Q 669.86, 146.39, 659.62, 147.16 Q\
                     649.29, 147.60, 638.95, 147.32 Q 628.66, 147.18, 618.37, 146.70 Q 608.10, 147.10, 597.82, 147.48 Q 587.55, 146.69, 577.27,\
                     147.05 Q 567.00, 146.94, 556.73, 146.28 Q 546.45, 146.30, 536.18, 146.19 Q 525.91, 146.18, 515.64, 145.91 Q 505.36, 147.42,\
                     495.09, 146.87 Q 484.82, 147.08, 474.55, 147.33 Q 464.27, 147.14, 454.00, 147.62 Q 443.73, 147.72, 433.45, 148.03 Q 423.18,\
                     148.02, 412.91, 148.05 Q 402.64, 148.27, 392.36, 148.37 Q 382.09, 147.27, 371.82, 147.02 Q 361.55, 147.22, 351.27, 146.90\
                     Q 341.00, 147.92, 330.73, 146.75 Q 320.45, 147.41, 310.18, 145.69 Q 299.91, 145.25, 289.64, 145.85 Q 279.36, 146.28, 269.09,\
                     146.82 Q 258.82, 147.09, 248.55, 146.50 Q 238.27, 146.34, 228.00, 146.92 Q 217.73, 146.51, 207.45, 147.42 Q 197.18, 147.46,\
                     186.91, 147.00 Q 176.64, 147.04, 166.36, 147.18 Q 156.09, 146.69, 145.82, 146.85 Q 135.55, 147.23, 125.27, 145.85 Q 115.00,\
                     145.72, 104.73, 145.66 Q 94.45, 146.85, 84.18, 147.10 Q 73.91, 147.44, 63.64, 148.05 Q 53.36, 148.07, 43.09, 147.74 Q 32.82,\
                     147.93, 22.55, 147.88 Q 12.27, 147.94, 0.94, 147.06 Q 0.93, 136.07, 0.06, 125.71 Q -0.02, 115.28, 0.24, 104.91 Q 1.12, 94.59,\
                     2.01, 84.29 Q 2.30, 74.00, 1.69, 63.71 Q 0.56, 53.43, 0.08, 43.14 Q 0.81, 32.86, 1.06, 22.57 Q 2.00, 12.29, 2.00, 2.00" style="\
                     fill:white;" class="svg_unselected_element"/><svg:path d="M 64.00, 0.00 Q 65.07, 10.57, 65.19, 21.14 Q 65.28, 31.71, 65.43,\
                     42.29 Q 65.46, 52.86, 65.07, 63.43 Q 65.15, 74.00, 65.25, 84.57 Q 65.28, 95.14, 65.20, 105.71 Q 64.82, 116.29, 65.29, 126.86\
                     Q 64.00, 137.43, 64.00, 148.00" style=" fill:none;" class="svg_unselected_element"/><svg:path d="M 149.00, 0.00 Q 148.49,\
                     10.57, 149.25, 21.14 Q 148.61, 31.71, 150.52, 42.29 Q 149.27, 52.86, 148.68, 63.43 Q 150.58, 74.00, 150.46, 84.57 Q 150.62,\
                     95.14, 149.45, 105.71 Q 149.11, 116.29, 148.55, 126.86 Q 149.00, 137.43, 149.00, 148.00" style=" fill:none;" class="svg_unselected_element"/><svg:path\
                     d="M 245.00, 0.00 Q 246.13, 10.57, 245.37, 21.14 Q 244.77, 31.71, 244.72, 42.29 Q 244.90, 52.86, 245.48, 63.43 Q 245.49, 74.00,\
                     245.82, 84.57 Q 245.43, 95.14, 245.15, 105.71 Q 244.72, 116.29, 245.65, 126.86 Q 245.00, 137.43, 245.00, 148.00" style=" fill:none;"\
                     class="svg_unselected_element"/><svg:path d="M 349.00, 0.00 Q 348.64, 10.57, 349.14, 21.14 Q 349.42, 31.71, 349.29, 42.29\
                     Q 349.29, 52.86, 349.57, 63.43 Q 349.51, 74.00, 348.92, 84.57 Q 349.31, 95.14, 348.66, 105.71 Q 349.94, 116.29, 349.16, 126.86\
                     Q 349.00, 137.43, 349.00, 148.00" style=" fill:none;" class="svg_unselected_element"/><svg:path d="M 435.00, 0.00 Q 436.72,\
                     10.57, 436.82, 21.14 Q 436.91, 31.71, 436.61, 42.29 Q 436.79, 52.86, 436.78, 63.43 Q 436.37, 74.00, 436.29, 84.57 Q 436.61,\
                     95.14, 436.76, 105.71 Q 436.73, 116.29, 436.83, 126.86 Q 435.00, 137.43, 435.00, 148.00" style=" fill:none;" class="svg_unselected_element"/><svg:path\
                     d="M 522.00, 0.00 Q 522.78, 10.57, 521.92, 21.14 Q 521.78, 31.71, 521.75, 42.29 Q 521.88, 52.86, 522.49, 63.43 Q 522.09, 74.00,\
                     522.20, 84.57 Q 522.32, 95.14, 521.98, 105.71 Q 522.31, 116.29, 522.41, 126.86 Q 522.00, 137.43, 522.00, 148.00" style=" fill:none;"\
                     class="svg_unselected_element"/><svg:path d="M 588.00, 0.00 Q 588.93, 10.57, 587.95, 21.14 Q 587.63, 31.71, 587.49, 42.29\
                     Q 588.65, 52.86, 588.01, 63.43 Q 588.48, 74.00, 587.94, 84.57 Q 588.87, 95.14, 588.86, 105.71 Q 588.36, 116.29, 588.25, 126.86\
                     Q 588.00, 137.43, 588.00, 148.00" style=" fill:none;" class="svg_unselected_element"/><svg:path d="M 0.00, 37.00 Q 10.03,\
                     35.98, 20.06, 35.97 Q 30.09, 35.95, 40.12, 35.88 Q 50.15, 36.40, 60.18, 36.25 Q 70.21, 35.70, 80.24, 35.40 Q 90.26, 35.77,\
                     100.29, 36.22 Q 110.32, 36.39, 120.35, 36.96 Q 130.38, 35.96, 140.41, 35.64 Q 150.44, 35.50, 160.47, 35.06 Q 170.50, 35.15,\
                     180.53, 35.80 Q 190.56, 36.06, 200.59, 36.06 Q 210.62, 35.88, 220.65, 35.88 Q 230.68, 36.45, 240.71, 37.45 Q 250.74, 37.48,\
                     260.76, 36.61 Q 270.79, 36.32, 280.82, 36.35 Q 290.85, 36.15, 300.88, 35.83 Q 310.91, 35.11, 320.94, 34.79 Q 330.97, 34.79,\
                     341.00, 34.89 Q 351.03, 35.06, 361.06, 35.95 Q 371.09, 36.64, 381.12, 36.01 Q 391.15, 35.54, 401.18, 35.80 Q 411.21, 35.86,\
                     421.24, 35.56 Q 431.26, 35.61, 441.29, 36.22 Q 451.32, 36.23, 461.35, 37.02 Q 471.38, 38.02, 481.41, 37.55 Q 491.44, 37.55,\
                     501.47, 37.24 Q 511.50, 36.34, 521.53, 36.03 Q 531.56, 35.80, 541.59, 35.92 Q 551.62, 36.20, 561.65, 36.41 Q 571.68, 36.00,\
                     581.71, 36.10 Q 591.74, 36.15, 601.77, 35.88 Q 611.79, 35.60, 621.82, 35.47 Q 631.85, 35.44, 641.88, 35.10 Q 651.91, 35.07,\
                     661.94, 35.01 Q 671.97, 37.00, 682.00, 37.00" style=" fill:none;" class="svg_unselected_element"/><svg:path d="M 0.00, 74.00\
                     Q 10.03, 72.42, 20.06, 72.42 Q 30.09, 72.27, 40.12, 72.61 Q 50.15, 72.64, 60.18, 72.41 Q 70.21, 72.34, 80.24, 72.73 Q 90.26,\
                     72.78, 100.29, 72.66 Q 110.32, 72.43, 120.35, 72.35 Q 130.38, 72.25, 140.41, 72.34 Q 150.44, 72.86, 160.47, 73.11 Q 170.50,\
                     73.27, 180.53, 73.03 Q 190.56, 72.92, 200.59, 73.27 Q 210.62, 73.10, 220.65, 73.03 Q 230.68, 73.02, 240.71, 72.91 Q 250.74,\
                     72.71, 260.76, 72.61 Q 270.79, 72.33, 280.82, 72.87 Q 290.85, 73.40, 300.88, 73.33 Q 310.91, 73.09, 320.94, 73.01 Q 330.97,\
                     73.00, 341.00, 72.87 Q 351.03, 72.66, 361.06, 72.24 Q 371.09, 72.34, 381.12, 72.86 Q 391.15, 73.15, 401.18, 73.23 Q 411.21,\
                     73.28, 421.24, 72.95 Q 431.26, 72.80, 441.29, 72.72 Q 451.32, 72.56, 461.35, 72.40 Q 471.38, 72.81, 481.41, 72.96 Q 491.44,\
                     73.28, 501.47, 72.75 Q 511.50, 72.12, 521.53, 72.17 Q 531.56, 71.81, 541.59, 71.61 Q 551.62, 71.80, 561.65, 73.02 Q 571.68,\
                     72.95, 581.71, 73.75 Q 591.74, 73.82, 601.77, 73.26 Q 611.79, 72.97, 621.82, 72.70 Q 631.85, 73.10, 641.88, 72.93 Q 651.91,\
                     73.39, 661.94, 72.95 Q 671.97, 74.00, 682.00, 74.00" style=" fill:none;" class="svg_unselected_element"/><svg:path d="M 0.00,\
                     111.00 Q 10.03, 109.78, 20.06, 110.41 Q 30.09, 110.00, 40.12, 110.93 Q 50.15, 110.60, 60.18, 110.11 Q 70.21, 110.44, 80.24,\
                     111.10 Q 90.26, 111.20, 100.29, 111.21 Q 110.32, 111.53, 120.35, 111.39 Q 130.38, 111.95, 140.41, 111.30 Q 150.44, 110.95,\
                     160.47, 110.14 Q 170.50, 110.25, 180.53, 109.96 Q 190.56, 110.24, 200.59, 110.75 Q 210.62, 111.49, 220.65, 112.06 Q 230.68,\
                     111.27, 240.71, 111.62 Q 250.74, 111.87, 260.76, 111.65 Q 270.79, 111.81, 280.82, 111.03 Q 290.85, 111.47, 300.88, 111.33\
                     Q 310.91, 110.13, 320.94, 109.57 Q 330.97, 109.31, 341.00, 109.67 Q 351.03, 109.84, 361.06, 109.58 Q 371.09, 109.14, 381.12,\
                     109.65 Q 391.15, 109.85, 401.18, 109.72 Q 411.21, 109.76, 421.24, 110.33 Q 431.26, 110.57, 441.29, 111.21 Q 451.32, 111.95,\
                     461.35, 110.79 Q 471.38, 110.95, 481.41, 111.42 Q 491.44, 112.37, 501.47, 110.96 Q 511.50, 110.29, 521.53, 110.60 Q 531.56,\
                     111.23, 541.59, 111.42 Q 551.62, 110.95, 561.65, 111.50 Q 571.68, 112.36, 581.71, 111.88 Q 591.74, 111.02, 601.77, 110.93\
                     Q 611.79, 109.68, 621.82, 109.29 Q 631.85, 109.26, 641.88, 109.12 Q 651.91, 109.09, 661.94, 108.96 Q 671.97, 111.00, 682.00,\
                     111.00" style=" fill:none;" class="svg_unselected_element"/>\
                  </svg:g>\
               </svg:svg>\
               <div style="height: 148px;width:682px; position:absolute; top: 0px; left: 0px;"><span style=\'position: absolute; top: 5px;left: 10px;width:34px;\'><span style=\'position: relative;\'>Mã số</span></span><span\
                  style=\'position: absolute; top: 5px;left: 74px;width:55px;\'><span style=\'position: relative;\'>Họ tên</span></span><span style=\'position:\
                  absolute; top: 5px;left: 159px;width:66px;\'><span style=\'position: relative;\'>SĐT</span></span><span style=\'position: absolute;\
                  top: 5px;left: 255px;width:74px;\'><span style=\'position: relative;\'>Số đơn hàng</span></span><span style=\'position: absolute;\
                  top: 5px;left: 359px;width:56px;\'><span style=\'position: relative;\'>Trạng thái</span></span><span style=\'position: absolute;\
                  top: 5px;left: 445px;width:57px;\'><span style=\'position: relative;\'>Nhà Hàng</span></span><span style=\'position: absolute;\
                  top: 5px;left: 532px;width:36px;\'><span style=\'position: relative;\'>Uy Tín</span></span><span style=\'position: absolute; top:\
                  5px;left: 598px;width:64px;\'><span style=\'position: relative;\'>Phí phải trả</span></span><span style=\'position: absolute;\
                  top: 42px;left: 10px;width:34px;\'><span style=\'position: relative;\'>1</span></span><span style=\'position: absolute; top: 42px;left:\
                  74px;width:55px;\'><span style=\'position: relative;\'>Nguyễn A</span></span><span style=\'position: absolute; top: 42px;left:\
                  159px;width:66px;\'><span style=\'position: relative;\'>012153452</span></span><span style=\'position: absolute; top: 42px;left:\
                  255px;width:74px;\'><span style=\'position: relative;\'>23</span></span><span style=\'position: absolute; top: 42px;left: 359px;width:56px;\'><span\
                  style=\'position: relative;\'>Active</span></span><span style=\'position: absolute; top: 42px;left: 445px;width:57px;\'><span\
                  style=\'position: relative;\'>Nhà A</span></span><span style=\'position: absolute; top: 42px;left: 532px;width:36px;\'><span style=\'position:\
                  relative;\'>3</span></span><span style=\'position: absolute; top: 42px;left: 598px;width:64px;\'><span style=\'position: relative;\'>0</span></span><span\
                  style=\'position: absolute; top: 79px;left: 10px;width:34px;\'><span style=\'position: relative;\'>2</span></span><span style=\'position:\
                  absolute; top: 79px;left: 74px;width:55px;\'><span style=\'position: relative;\'>TRần B</span></span><span style=\'position: absolute;\
                  top: 79px;left: 159px;width:66px;\'><span style=\'position: relative;\'>016844245</span></span><span style=\'position: absolute;\
                  top: 79px;left: 255px;width:74px;\'><span style=\'position: relative;\'>47</span></span><span style=\'position: absolute; top:\
                  79px;left: 359px;width:56px;\'><span style=\'position: relative;\'>Active</span></span><span style=\'position: absolute; top:\
                  79px;left: 445px;width:57px;\'><span style=\'position: relative;\'>Nhà B</span></span><span style=\'position: absolute; top: 79px;left:\
                  532px;width:36px;\'><span style=\'position: relative;\'>2</span></span><span style=\'position: absolute; top: 79px;left: 598px;width:64px;\'><span\
                  style=\'position: relative;\'>0</span></span><span style=\'position: absolute; top: 116px;left: 10px;width:34px;\'><span style=\'position:\
                  relative;\'>3</span></span><span style=\'position: absolute; top: 116px;left: 74px;width:55px;\'><span style=\'position: relative;\'>Nguyễn C</span></span><span\
                  style=\'position: absolute; top: 116px;left: 159px;width:66px;\'><span style=\'position: relative;\'>016844245</span></span><span\
                  style=\'position: absolute; top: 116px;left: 255px;width:74px;\'><span style=\'position: relative;\'>112</span></span><span style=\'position:\
                  absolute; top: 116px;left: 359px;width:56px;\'><span style=\'position: relative;\'>Deactive</span></span><span style=\'position:\
                  absolute; top: 116px;left: 445px;width:57px;\'><span style=\'position: relative;\'>Nhà C</span></span><span style=\'position:\
                  absolute; top: 116px;left: 532px;width:36px;\'><span style=\'position: relative;\'>4</span></span><span style=\'position: absolute;\
                  top: 116px;left: 598px;width:64px;\'><span style=\'position: relative;\'>10.000</span></span>\
               </div>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page271612227-layer-datepicker381481445" style="position: absolute; left: 400px; top: 690px; width: 150px; height: 30px" data-interactive-element-type="default.datepicker" class="datepicker stencil mobile-interaction-potential-trigger " data-stencil-id="datepicker381481445" data-review-reference-id="datepicker381481445">\
         <div class="stencil-wrapper" style="width: 150px; height: 30px">\
            <div>\
               <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" style="position: absolute; height: 30px;width:150px;" width="150" height="30">\
                  <svg:g width="150px" height="30px"><svg:path id="__containerId__-page271612227-layer-datepicker381481445_input_svg_border" d="M 2.00, 2.00 Q 13.20, 2.67, 24.40,\
                     2.07 Q 35.60, 0.69, 46.80, 0.61 Q 58.00, -0.39, 69.20, -0.29 Q 80.40, 0.33, 91.60, 0.91 Q 102.80, 0.83, 115.09, 0.91 Q 115.20,\
                     14.60, 114.69, 28.69 Q 102.93, 28.47, 91.76, 29.40 Q 80.48, 29.65, 69.25, 29.85 Q 58.03, 30.23, 46.81, 30.34 Q 35.61, 30.07,\
                     24.40, 29.84 Q 13.20, 30.13, 1.61, 28.39 Q 2.00, 15.00, 2.00, 2.00" style=" fill:white;" class="svg_unselected_element"/><svg:path id="__containerId__-page271612227-layer-datepicker381481445_line1" d="M 3.00, 3.00 Q 14.90, 0.65, 26.80, 0.61 Q\
                     38.70, 0.47, 50.60, 0.87 Q 62.50, 0.89, 74.40, 0.62 Q 86.30, 0.73, 98.20, 1.09 Q 110.10, 3.00, 122.00, 3.00" style=" fill:none;"\
                     class="svg_unselected_element"/><svg:path id="__containerId__-page271612227-layer-datepicker381481445_line2" d="M 3.00, 3.00 Q 3.00, 15.00, 3.00, 27.00" style="\
                     fill:none;" class="svg_unselected_element"/><svg:path id="__containerId__-page271612227-layer-datepicker381481445_line3" d="M 3.00, 3.00 Q 14.90, 0.92, 26.80, 0.88 Q\
                     38.70, 0.76, 50.60, 1.01 Q 62.50, 1.15, 74.40, 1.30 Q 86.30, 1.72, 98.20, 1.86 Q 110.10, 3.00, 122.00, 3.00" style=" fill:none;"\
                     class="svg_unselected_element"/><svg:path id="__containerId__-page271612227-layer-datepicker381481445_line4" d="M 3.00, 3.00 Q 3.00, 15.00, 3.00, 27.00" style="\
                     fill:none;" class="svg_unselected_element"/>\
                  </svg:g>\
                  <svg:g width="150px" height="30px"><svg:path id="__containerId__-page271612227-layer-datepicker381481445_input_svg_border2" d="M 118.00, 2.00 Q 133.00, 1.23,\
                     148.20, 1.80 Q 148.38, 14.87, 147.99, 27.99 Q 132.88, 27.58, 117.72, 28.24 Q 118.00, 15.00, 118.00, 2.00" style=" fill:white;"\
                     class="svg_unselected_element"/>\
                  </svg:g>\
               </svg:svg>\
               <div style="white-space: nowrap;" title=""><input type="text" onblur="rabbit.facade.raiseEvent(rabbit.events.svgBlur, new Array(\'__containerId__-page271612227-layer-datepicker381481445_input_svg_border\',\'__containerId__-page271612227-layer-datepicker381481445_line1\',\'__containerId__-page271612227-layer-datepicker381481445_line2\',\'__containerId__-page271612227-layer-datepicker381481445_line3\',\'__containerId__-page271612227-layer-datepicker381481445_line4\'))" onfocus="rabbit.facade.raiseEvent(rabbit.events.svgFocus, new Array(\'__containerId__-page271612227-layer-datepicker381481445_input_svg_border\',\'__containerId__-page271612227-layer-datepicker381481445_line1\',\'__containerId__-page271612227-layer-datepicker381481445_line2\',\'__containerId__-page271612227-layer-datepicker381481445_line3\',\'__containerId__-page271612227-layer-datepicker381481445_line4\'))" style="width:116px; height:30px;padding: 0px;border-width:1px; position: absolute;" id="__containerId__-page271612227-layer-datepicker381481445_input" /><button type="button" onblur="rabbit.facade.raiseEvent(rabbit.events.svgBlur, \'__containerId__-page271612227-layer-datepicker381481445_input_svg_border2\')" onfocus="rabbit.facade.raiseEvent(rabbit.events.svgFocus, \'__containerId__-page271612227-layer-datepicker381481445_input_svg_border2\')" style="position:absolute; left:116px; top:0px; width:34px; height:30px; vertical-align: top; padding: 0px;border-width:1px; cursor:pointer;" id="__containerId__-page271612227-layer-datepicker381481445_button"><img src="../resources/icons/date.png" /></button></div>\
               <div id="__containerId__-page271612227-layer-datepicker381481445_ov" class="yui-skin-sam" style="position: absolute; width: 16em;visibility:visible;">\
                  <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" style="position: absolute; left: -6px; top: -4px; height: 204px;width:200px;display:none" id="__containerId__-page271612227-layer-datepicker381481445_open_calendar" width="150" height="204"><svg:path id="__containerId__-page271612227-layer-datepicker381481445_open_calendar_border" d="M 2.00, 2.00 Q 12.89, 0.45,\
                     23.78, 1.16 Q 34.67, 2.50, 45.56, 2.46 Q 56.44, 3.74, 67.33, 3.76 Q 78.22, 2.63, 89.11, 2.47 Q 100.00, 3.50, 110.89, 3.37\
                     Q 121.78, 2.76, 132.67, 2.91 Q 143.56, 2.30, 154.44, 1.67 Q 165.33, 2.02, 176.22, 2.13 Q 187.11, 2.04, 197.64, 2.35 Q 197.10,\
                     12.30, 198.16, 21.98 Q 198.73, 31.95, 199.07, 41.97 Q 198.63, 51.99, 197.73, 62.00 Q 199.09, 72.00, 199.12, 82.00 Q 198.76,\
                     92.00, 200.16, 102.00 Q 200.09, 112.00, 199.58, 122.00 Q 199.05, 132.00, 198.67, 142.00 Q 198.70, 152.00, 198.77, 162.00 Q\
                     198.89, 172.00, 198.55, 182.00 Q 197.78, 192.00, 197.99, 201.99 Q 187.30, 202.57, 176.38, 203.13 Q 165.44, 203.66, 154.48,\
                     203.20 Q 143.56, 202.04, 132.68, 203.79 Q 121.78, 203.49, 110.89, 204.27 Q 100.00, 203.14, 89.11, 202.60 Q 78.22, 203.31,\
                     67.33, 203.86 Q 56.44, 203.67, 45.56, 203.78 Q 34.67, 202.98, 23.78, 202.67 Q 12.89, 203.28, 0.96, 203.04 Q 0.49, 192.50,\
                     -0.16, 182.31 Q 0.00, 172.13, 0.08, 162.06 Q 0.48, 152.02, 1.13, 142.01 Q 1.65, 132.00, 1.20, 122.00 Q 1.09, 112.00, 0.96,\
                     102.00 Q 0.90, 92.00, 0.63, 82.00 Q 0.62, 72.00, 0.46, 62.00 Q 0.70, 52.00, 1.05, 42.00 Q 1.61, 32.00, 1.26, 22.00 Q 2.00,\
                     12.00, 2.00, 2.00" style=" fill:white;" class="svg_unselected_element"/>\
                  </svg:svg>\
                  <div id="__containerId__-page271612227-layer-datepicker381481445_cal"></div>\
               </div><script type="text/javascript">\
				rabbit.stencils.datepicker.setupDatepicker("__containerId__-page271612227-layer-datepicker381481445");\
			</script></div>\
         </div>\
      </div>\
      <div id="__containerId__-page271612227-layer-datepicker148793522" style="position: absolute; left: 665px; top: 690px; width: 150px; height: 30px" data-interactive-element-type="default.datepicker" class="datepicker stencil mobile-interaction-potential-trigger " data-stencil-id="datepicker148793522" data-review-reference-id="datepicker148793522">\
         <div class="stencil-wrapper" style="width: 150px; height: 30px">\
            <div>\
               <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" style="position: absolute; height: 30px;width:150px;" width="150" height="30">\
                  <svg:g width="150px" height="30px"><svg:path id="__containerId__-page271612227-layer-datepicker148793522_input_svg_border" d="M 2.00, 2.00 Q 13.20, 2.66, 24.40,\
                     3.22 Q 35.60, 3.18, 46.80, 3.43 Q 58.00, 3.20, 69.20, 2.94 Q 80.40, 3.12, 91.60, 3.05 Q 102.80, 3.94, 113.81, 2.19 Q 113.56,\
                     15.15, 113.89, 27.89 Q 102.61, 27.31, 91.56, 27.64 Q 80.42, 28.37, 69.21, 28.49 Q 58.00, 27.63, 46.80, 27.29 Q 35.60, 29.16,\
                     24.40, 29.36 Q 13.20, 28.40, 1.50, 28.50 Q 2.00, 15.00, 2.00, 2.00" style=" fill:white;" class="svg_unselected_element"/><svg:path id="__containerId__-page271612227-layer-datepicker148793522_line1" d="M 3.00, 3.00 Q 14.90, 0.33, 26.80, 0.49 Q\
                     38.70, 1.57, 50.60, 0.97 Q 62.50, 1.36, 74.40, 2.38 Q 86.30, 2.01, 98.20, 1.85 Q 110.10, 3.00, 122.00, 3.00" style=" fill:none;"\
                     class="svg_unselected_element"/><svg:path id="__containerId__-page271612227-layer-datepicker148793522_line2" d="M 3.00, 3.00 Q 3.00, 15.00, 3.00, 27.00" style="\
                     fill:none;" class="svg_unselected_element"/><svg:path id="__containerId__-page271612227-layer-datepicker148793522_line3" d="M 3.00, 3.00 Q 14.90, 0.45, 26.80, 0.50 Q\
                     38.70, 1.20, 50.60, 1.24 Q 62.50, 1.72, 74.40, 2.48 Q 86.30, 1.42, 98.20, 2.17 Q 110.10, 3.00, 122.00, 3.00" style=" fill:none;"\
                     class="svg_unselected_element"/><svg:path id="__containerId__-page271612227-layer-datepicker148793522_line4" d="M 3.00, 3.00 Q 3.00, 15.00, 3.00, 27.00" style="\
                     fill:none;" class="svg_unselected_element"/>\
                  </svg:g>\
                  <svg:g width="150px" height="30px"><svg:path id="__containerId__-page271612227-layer-datepicker148793522_input_svg_border2" d="M 118.00, 2.00 Q 133.00, 0.31,\
                     148.93, 1.07 Q 149.46, 14.51, 148.79, 28.79 Q 133.32, 29.17, 117.28, 28.61 Q 118.00, 15.00, 118.00, 2.00" style=" fill:white;"\
                     class="svg_unselected_element"/>\
                  </svg:g>\
               </svg:svg>\
               <div style="white-space: nowrap;" title=""><input type="text" onblur="rabbit.facade.raiseEvent(rabbit.events.svgBlur, new Array(\'__containerId__-page271612227-layer-datepicker148793522_input_svg_border\',\'__containerId__-page271612227-layer-datepicker148793522_line1\',\'__containerId__-page271612227-layer-datepicker148793522_line2\',\'__containerId__-page271612227-layer-datepicker148793522_line3\',\'__containerId__-page271612227-layer-datepicker148793522_line4\'))" onfocus="rabbit.facade.raiseEvent(rabbit.events.svgFocus, new Array(\'__containerId__-page271612227-layer-datepicker148793522_input_svg_border\',\'__containerId__-page271612227-layer-datepicker148793522_line1\',\'__containerId__-page271612227-layer-datepicker148793522_line2\',\'__containerId__-page271612227-layer-datepicker148793522_line3\',\'__containerId__-page271612227-layer-datepicker148793522_line4\'))" style="width:116px; height:30px;padding: 0px;border-width:1px; position: absolute;" id="__containerId__-page271612227-layer-datepicker148793522_input" /><button type="button" onblur="rabbit.facade.raiseEvent(rabbit.events.svgBlur, \'__containerId__-page271612227-layer-datepicker148793522_input_svg_border2\')" onfocus="rabbit.facade.raiseEvent(rabbit.events.svgFocus, \'__containerId__-page271612227-layer-datepicker148793522_input_svg_border2\')" style="position:absolute; left:116px; top:0px; width:34px; height:30px; vertical-align: top; padding: 0px;border-width:1px; cursor:pointer;" id="__containerId__-page271612227-layer-datepicker148793522_button"><img src="../resources/icons/date.png" /></button></div>\
               <div id="__containerId__-page271612227-layer-datepicker148793522_ov" class="yui-skin-sam" style="position: absolute; width: 16em;visibility:visible;">\
                  <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" style="position: absolute; left: -6px; top: -4px; height: 204px;width:200px;display:none" id="__containerId__-page271612227-layer-datepicker148793522_open_calendar" width="150" height="204"><svg:path id="__containerId__-page271612227-layer-datepicker148793522_open_calendar_border" d="M 2.00, 2.00 Q 12.89, 1.37,\
                     23.78, 2.09 Q 34.67, 2.38, 45.56, 2.51 Q 56.44, 1.41, 67.33, 1.82 Q 78.22, 1.86, 89.11, 2.22 Q 100.00, 1.59, 110.89, 1.95\
                     Q 121.78, 1.15, 132.67, 1.35 Q 143.56, 1.11, 154.44, 1.18 Q 165.33, 1.42, 176.22, 1.93 Q 187.11, 1.71, 198.43, 1.57 Q 198.60,\
                     11.80, 198.51, 21.93 Q 199.22, 31.92, 199.34, 41.96 Q 199.08, 51.98, 199.56, 61.99 Q 198.20, 72.00, 199.72, 82.00 Q 199.17,\
                     92.00, 199.53, 102.00 Q 199.78, 112.00, 199.85, 122.00 Q 198.82, 132.00, 198.66, 142.00 Q 199.15, 152.00, 198.26, 162.00 Q\
                     198.49, 172.00, 198.93, 182.00 Q 198.64, 192.00, 198.14, 202.14 Q 186.90, 201.36, 176.12, 201.25 Q 165.31, 201.60, 154.46,\
                     202.61 Q 143.58, 203.41, 132.67, 202.94 Q 121.78, 202.39, 110.89, 202.33 Q 100.00, 202.98, 89.11, 202.98 Q 78.22, 201.63,\
                     67.33, 201.07 Q 56.44, 202.40, 45.56, 203.29 Q 34.67, 203.18, 23.78, 202.62 Q 12.89, 201.56, 1.45, 202.55 Q 1.11, 192.30,\
                     0.93, 182.15 Q 1.29, 172.05, 0.73, 162.04 Q 1.14, 152.01, 2.35, 142.00 Q 3.73, 131.99, 2.79, 122.00 Q 1.95, 112.00, 2.00,\
                     102.00 Q 2.48, 92.00, 3.74, 82.00 Q 2.81, 72.00, 2.68, 62.00 Q 1.82, 52.00, 1.92, 42.00 Q 1.92, 32.00, 1.49, 22.00 Q 2.00,\
                     12.00, 2.00, 2.00" style=" fill:white;" class="svg_unselected_element"/>\
                  </svg:svg>\
                  <div id="__containerId__-page271612227-layer-datepicker148793522_cal"></div>\
               </div><script type="text/javascript">\
				rabbit.stencils.datepicker.setupDatepicker("__containerId__-page271612227-layer-datepicker148793522");\
			</script></div>\
         </div>\
      </div>\
      <div id="__containerId__-page271612227-layer-text592765247" style="position: absolute; left: 355px; top: 695px; width: 29px; height: 20px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text592765247" data-review-reference-id="text592765247">\
         <div class="stencil-wrapper" style="width: 29px; height: 20px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline32"><p><span style="font-size: 18px;">Từ</span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page271612227-layer-text45589307" style="position: absolute; left: 620px; top: 695px; width: 46px; height: 20px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text45589307" data-review-reference-id="text45589307">\
         <div class="stencil-wrapper" style="width: 46px; height: 20px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline32"><p class="none" style="font-size: 18px;">Đến </p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page271612227-layer-text229832826" style="position: absolute; left: 290px; top: 2845px; width: 177px; height: 37px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text229832826" data-review-reference-id="text229832826">\
         <div class="stencil-wrapper" style="width: 177px; height: 37px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline12"><p><span style="font-size: 32px; color: #658cd9;">Quản lí web</span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page271612227-layer-text964548013" style="position: absolute; left: 295px; top: 2910px; width: 146px; height: 28px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text964548013" data-review-reference-id="text964548013">\
         <div class="stencil-wrapper" style="width: 146px; height: 28px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline22"><p><span style="font-size: 24px;">Số điện thoại</span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page271612227-layer-textinput920362722" style="position: absolute; left: 490px; top: 2910px; width: 325px; height: 30px" data-interactive-element-type="default.textinput" class="textinput stencil mobile-interaction-potential-trigger " data-stencil-id="textinput920362722" data-review-reference-id="textinput920362722">\
         <div class="stencil-wrapper" style="width: 325px; height: 30px">\
            <div>\
               <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" style="height: 30px;width:325px;" width="325" height="30">\
                  <svg:g id="__containerId__-page271612227-layer-textinput920362722svg" width="325" height="30"><svg:path id="__containerId__-page271612227-layer-textinput920362722_input_svg_border" d="M 2.00, 2.00 Q 12.03, 1.16, 22.06,\
                     1.57 Q 32.09, 1.45, 42.12, 2.15 Q 52.16, 2.41, 62.19, 1.36 Q 72.22, 1.36, 82.25, 2.34 Q 92.28, 3.16, 102.31, 2.24 Q 112.34,\
                     0.56, 122.38, 0.95 Q 132.41, 0.93, 142.44, 0.78 Q 152.47, 1.57, 162.50, 1.93 Q 172.53, 3.01, 182.56, 2.50 Q 192.59, 2.73,\
                     202.62, 2.28 Q 212.66, 0.58, 222.69, 0.60 Q 232.72, 0.52, 242.75, 0.73 Q 252.78, 1.89, 262.81, 1.45 Q 272.84, 2.33, 282.88,\
                     1.37 Q 292.91, 1.69, 302.94, 1.78 Q 312.97, 1.22, 323.26, 1.74 Q 323.01, 15.00, 323.09, 28.09 Q 312.95, 27.92, 303.07, 29.23\
                     Q 292.94, 28.64, 282.90, 29.22 Q 272.85, 28.45, 262.81, 28.32 Q 252.78, 28.44, 242.75, 29.51 Q 232.72, 29.65, 222.69, 28.72\
                     Q 212.66, 28.59, 202.63, 29.05 Q 192.59, 29.29, 182.56, 28.11 Q 172.53, 26.51, 162.50, 27.21 Q 152.47, 28.45, 142.44, 28.21\
                     Q 132.41, 27.28, 122.38, 26.87 Q 112.34, 28.31, 102.31, 28.76 Q 92.28, 27.85, 82.25, 28.69 Q 72.22, 27.64, 62.19, 27.76 Q\
                     52.16, 27.83, 42.12, 28.20 Q 32.09, 28.59, 22.06, 28.55 Q 12.03, 27.80, 2.05, 27.95 Q 2.00, 15.00, 2.00, 2.00" style=" fill:white;"\
                     class="svg_unselected_element"/><svg:path id="__containerId__-page271612227-layer-textinput920362722_line1" d="M 3.00, 3.00 Q 13.63, 2.86, 24.27, 3.10 Q 34.90,\
                     2.97, 45.53, 3.02 Q 56.17, 3.25, 66.80, 2.61 Q 77.43, 2.19, 88.07, 2.07 Q 98.70, 2.05, 109.33, 1.93 Q 119.97, 2.02, 130.60,\
                     1.96 Q 141.23, 1.83, 151.87, 1.81 Q 162.50, 1.79, 173.13, 2.42 Q 183.77, 1.50, 194.40, 1.85 Q 205.03, 1.79, 215.67, 1.65 Q\
                     226.30, 1.99, 236.93, 1.79 Q 247.57, 1.53, 258.20, 1.56 Q 268.83, 1.64, 279.47, 1.67 Q 290.10, 1.56, 300.73, 1.58 Q 311.37,\
                     3.00, 322.00, 3.00" style=" fill:none;" class="svg_unselected_element"/><svg:path id="__containerId__-page271612227-layer-textinput920362722_line2" d="M 3.00, 3.00 Q 3.00, 15.00, 3.00, 27.00" style="\
                     fill:none;" class="svg_unselected_element"/><svg:path id="__containerId__-page271612227-layer-textinput920362722_line3" d="M 3.00, 3.00 Q 13.63, 3.04, 24.27, 2.95 Q 34.90,\
                     3.20, 45.53, 2.39 Q 56.17, 2.97, 66.80, 3.03 Q 77.43, 2.34, 88.07, 2.47 Q 98.70, 2.11, 109.33, 3.37 Q 119.97, 3.62, 130.60,\
                     2.91 Q 141.23, 3.39, 151.87, 1.56 Q 162.50, 3.01, 173.13, 1.64 Q 183.77, 1.52, 194.40, 2.01 Q 205.03, 2.62, 215.67, 4.02 Q\
                     226.30, 3.64, 236.93, 2.59 Q 247.57, 1.37, 258.20, 1.16 Q 268.83, 2.44, 279.47, 3.54 Q 290.10, 2.37, 300.73, 1.59 Q 311.37,\
                     3.00, 322.00, 3.00" style=" fill:none;" class="svg_unselected_element"/><svg:path id="__containerId__-page271612227-layer-textinput920362722_line4" d="M 3.00, 3.00 Q 3.00, 15.00, 3.00, 27.00" style="\
                     fill:none;" class="svg_unselected_element"/>\
                  </svg:g>\
               </svg:svg>\
               <div style="position:absolute;left: 6px; top: 1px;" title=""><input id="__containerId__-page271612227-layer-textinput920362722input" onblur="rabbit.facade.raiseEvent(rabbit.events.svgBlur, new Array(\'__containerId__-page271612227-layer-textinput920362722_input_svg_border\',\'__containerId__-page271612227-layer-textinput920362722_line1\',\'__containerId__-page271612227-layer-textinput920362722_line2\',\'__containerId__-page271612227-layer-textinput920362722_line3\',\'__containerId__-page271612227-layer-textinput920362722_line4\'))" onfocus="rabbit.facade.raiseEvent(rabbit.events.svgFocus, new Array(\'__containerId__-page271612227-layer-textinput920362722_input_svg_border\',\'__containerId__-page271612227-layer-textinput920362722_line1\',\'__containerId__-page271612227-layer-textinput920362722_line2\',\'__containerId__-page271612227-layer-textinput920362722_line3\',\'__containerId__-page271612227-layer-textinput920362722_line4\'))" value="" style="width:318px;height:28px;padding: 0px;" type="text" /></div>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page271612227-layer-text707230980" style="position: absolute; left: 295px; top: 2970px; width: 155px; height: 28px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text707230980" data-review-reference-id="text707230980">\
         <div class="stencil-wrapper" style="width: 155px; height: 28px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline22"><p class="none" style="font-size: 24px;">Địa chỉ trụ sở </p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page271612227-layer-textinput374163465" style="position: absolute; left: 490px; top: 2970px; width: 330px; height: 30px" data-interactive-element-type="default.textinput" class="textinput stencil mobile-interaction-potential-trigger " data-stencil-id="textinput374163465" data-review-reference-id="textinput374163465">\
         <div class="stencil-wrapper" style="width: 330px; height: 30px">\
            <div>\
               <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" style="height: 30px;width:330px;" width="330" height="30">\
                  <svg:g id="__containerId__-page271612227-layer-textinput374163465svg" width="330" height="30"><svg:path id="__containerId__-page271612227-layer-textinput374163465_input_svg_border" d="M 2.00, 2.00 Q 12.19, 1.30, 22.38,\
                     1.21 Q 32.56, 1.75, 42.75, 1.68 Q 52.94, 1.06, 63.12, 0.97 Q 73.31, 0.86, 83.50, 1.06 Q 93.69, 0.83, 103.88, 1.35 Q 114.06,\
                     2.13, 124.25, 2.76 Q 134.44, 2.31, 144.62, 2.36 Q 154.81, 2.01, 165.00, 2.14 Q 175.19, 1.88, 185.38, 1.21 Q 195.56, 0.79,\
                     205.75, 1.09 Q 215.94, 2.24, 226.12, 1.30 Q 236.31, 1.12, 246.50, 1.78 Q 256.69, 1.42, 266.88, 1.15 Q 277.06, 1.32, 287.25,\
                     1.49 Q 297.44, 1.46, 307.62, 0.63 Q 317.81, 1.13, 328.84, 1.16 Q 329.45, 14.52, 328.78, 28.78 Q 318.23, 29.54, 307.86, 30.07\
                     Q 297.54, 29.93, 287.30, 29.88 Q 277.09, 30.01, 266.89, 30.08 Q 256.69, 29.61, 246.50, 28.87 Q 236.31, 29.01, 226.13, 29.45\
                     Q 215.94, 29.44, 205.75, 29.09 Q 195.56, 28.15, 185.38, 28.19 Q 175.19, 27.14, 165.00, 28.38 Q 154.81, 27.65, 144.62, 28.11\
                     Q 134.44, 28.33, 124.25, 28.32 Q 114.06, 28.55, 103.88, 28.16 Q 93.69, 27.82, 83.50, 27.81 Q 73.31, 28.90, 63.12, 28.98 Q\
                     52.94, 28.35, 42.75, 28.27 Q 32.56, 28.06, 22.38, 28.82 Q 12.19, 29.39, 1.24, 28.76 Q 2.00, 15.00, 2.00, 2.00" style=" fill:white;"\
                     class="svg_unselected_element"/><svg:path id="__containerId__-page271612227-layer-textinput374163465_line1" d="M 3.00, 3.00 Q 13.12, 4.05, 23.25, 4.97 Q 33.38,\
                     5.40, 43.50, 5.07 Q 53.62, 4.34, 63.75, 4.52 Q 73.88, 3.77, 84.00, 4.06 Q 94.12, 3.50, 104.25, 3.97 Q 114.38, 4.38, 124.50,\
                     4.28 Q 134.62, 4.09, 144.75, 2.69 Q 154.88, 2.98, 165.00, 3.01 Q 175.12, 3.81, 185.25, 2.91 Q 195.38, 3.78, 205.50, 4.37 Q\
                     215.62, 3.59, 225.75, 4.06 Q 235.88, 2.34, 246.00, 2.94 Q 256.12, 2.81, 266.25, 3.06 Q 276.38, 2.51, 286.50, 2.29 Q 296.62,\
                     2.75, 306.75, 2.69 Q 316.88, 3.00, 327.00, 3.00" style=" fill:none;" class="svg_unselected_element"/><svg:path id="__containerId__-page271612227-layer-textinput374163465_line2" d="M 3.00, 3.00 Q 3.00, 15.00, 3.00, 27.00" style="\
                     fill:none;" class="svg_unselected_element"/><svg:path id="__containerId__-page271612227-layer-textinput374163465_line3" d="M 3.00, 3.00 Q 13.12, 2.14, 23.25, 3.00 Q 33.38,\
                     3.55, 43.50, 2.78 Q 53.62, 2.80, 63.75, 3.07 Q 73.88, 2.75, 84.00, 2.79 Q 94.12, 1.93, 104.25, 3.43 Q 114.38, 3.28, 124.50,\
                     3.25 Q 134.62, 3.21, 144.75, 2.14 Q 154.88, 2.19, 165.00, 1.74 Q 175.12, 1.73, 185.25, 0.59 Q 195.38, 1.71, 205.50, 2.49 Q\
                     215.62, 3.14, 225.75, 2.59 Q 235.88, 2.25, 246.00, 2.04 Q 256.12, 2.84, 266.25, 2.64 Q 276.38, 1.50, 286.50, 1.77 Q 296.62,\
                     1.54, 306.75, 1.80 Q 316.88, 3.00, 327.00, 3.00" style=" fill:none;" class="svg_unselected_element"/><svg:path id="__containerId__-page271612227-layer-textinput374163465_line4" d="M 3.00, 3.00 Q 3.00, 15.00, 3.00, 27.00" style="\
                     fill:none;" class="svg_unselected_element"/>\
                  </svg:g>\
               </svg:svg>\
               <div style="position:absolute;left: 6px; top: 1px;" title=""><input id="__containerId__-page271612227-layer-textinput374163465input" onblur="rabbit.facade.raiseEvent(rabbit.events.svgBlur, new Array(\'__containerId__-page271612227-layer-textinput374163465_input_svg_border\',\'__containerId__-page271612227-layer-textinput374163465_line1\',\'__containerId__-page271612227-layer-textinput374163465_line2\',\'__containerId__-page271612227-layer-textinput374163465_line3\',\'__containerId__-page271612227-layer-textinput374163465_line4\'))" onfocus="rabbit.facade.raiseEvent(rabbit.events.svgFocus, new Array(\'__containerId__-page271612227-layer-textinput374163465_input_svg_border\',\'__containerId__-page271612227-layer-textinput374163465_line1\',\'__containerId__-page271612227-layer-textinput374163465_line2\',\'__containerId__-page271612227-layer-textinput374163465_line3\',\'__containerId__-page271612227-layer-textinput374163465_line4\'))" value="" style="width:323px;height:28px;padding: 0px;" type="text" /></div>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page271612227-layer-text649843400" style="position: absolute; left: 295px; top: 3030px; width: 202px; height: 28px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text649843400" data-review-reference-id="text649843400">\
         <div class="stencil-wrapper" style="width: 202px; height: 28px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline22"><p><span style="font-size: 24px;">Banner quảng cáo</span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page271612227-layer-image48855182" style="position: absolute; left: 530px; top: 3025px; width: 130px; height: 130px" data-interactive-element-type="default.image" class="image stencil mobile-interaction-potential-trigger " data-stencil-id="image48855182" data-review-reference-id="image48855182">\
         <div class="stencil-wrapper" style="width: 130px; height: 130px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" title="">\
               <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" class="image-cropper" style="height: 130px;width:130px;" width="130" height="130">\
                  <svg:g width="130" height="130">\
                     <svg:svg x="1" y="1" width="128" height="128">\
                        <svg:image width="432" height="253" xlink:href="../repoimages/506339.PNG" preserveAspectRatio="none" transform="scale(0.30092592592592593,0.5138339920948617) translate(-0,-0)  "></svg:image>\
                     </svg:svg>\
                  </svg:g>\
               </svg:svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page271612227-layer-text207434747" style="position: absolute; left: 300px; top: 3215px; width: 161px; height: 28px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text207434747" data-review-reference-id="text207434747">\
         <div class="stencil-wrapper" style="width: 161px; height: 28px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline22"><p><span style="font-size: 24px;">Banner đối tác</span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page271612227-layer-image401667591" style="position: absolute; left: 530px; top: 3210px; width: 130px; height: 130px" data-interactive-element-type="default.image" class="image stencil mobile-interaction-potential-trigger " data-stencil-id="image401667591" data-review-reference-id="image401667591">\
         <div class="stencil-wrapper" style="width: 130px; height: 130px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" title="">\
               <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" class="image-cropper" style="height: 130px;width:130px;" width="130" height="130">\
                  <svg:g width="130" height="130">\
                     <svg:svg x="1" y="1" width="128" height="128">\
                        <svg:image width="432" height="253" xlink:href="../repoimages/506339.PNG" preserveAspectRatio="none" transform="scale(0.30092592592592593,0.5138339920948617) translate(-0,-0)  "></svg:image>\
                     </svg:svg>\
                  </svg:g>\
               </svg:svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page271612227-layer-icon109801539" style="position: absolute; left: 715px; top: 3245px; width: 64px; height: 64px" data-interactive-element-type="fonticon.icon" class="icon stencil mobile-interaction-potential-trigger " data-stencil-id="icon109801539" data-review-reference-id="icon109801539">\
         <div class="stencil-wrapper" style="width: 64px; height: 64px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" style="width:64px;height:64px;" title="">\
               <svg xmlns="http://www.w3.org/2000/svg" width="64" height="64" class="fill-black">\
                  <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#icon-glyph-e191"></use>\
               </svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page271612227-layer-icon885109286" style="position: absolute; left: 710px; top: 3060px; width: 64px; height: 64px" data-interactive-element-type="fonticon.icon" class="icon stencil mobile-interaction-potential-trigger " data-stencil-id="icon885109286" data-review-reference-id="icon885109286">\
         <div class="stencil-wrapper" style="width: 64px; height: 64px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" style="width:64px;height:64px;" title="">\
               <svg xmlns="http://www.w3.org/2000/svg" width="64" height="64" class="fill-black">\
                  <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#icon-glyph-e191"></use>\
               </svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page271612227-layer-text128644248" style="position: absolute; left: 880px; top: 2915px; width: 59px; height: 28px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text128644248" data-review-reference-id="text128644248">\
         <div class="stencil-wrapper" style="width: 59px; height: 28px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline22"><p><span style="font-size: 24px;">Logo</span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page271612227-layer-image628768360" style="position: absolute; left: 965px; top: 2875px; width: 130px; height: 130px" data-interactive-element-type="default.image" class="image stencil mobile-interaction-potential-trigger " data-stencil-id="image628768360" data-review-reference-id="image628768360">\
         <div class="stencil-wrapper" style="width: 130px; height: 130px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" title="">\
               <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" class="image-cropper" style="height: 130px;width:130px;" width="130" height="130">\
                  <svg:g width="130" height="130">\
                     <svg:svg x="1" y="1" width="128" height="128">\
                        <svg:image width="432" height="253" xlink:href="../repoimages/506339.PNG" preserveAspectRatio="none" transform="scale(0.30092592592592593,0.5138339920948617) translate(-0,-0)  "></svg:image>\
                     </svg:svg>\
                  </svg:g>\
               </svg:svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page271612227-layer-image77752952" style="position: absolute; left: 965px; top: 2900px; width: 130px; height: 130px" data-interactive-element-type="default.image" class="image stencil mobile-interaction-potential-trigger " data-stencil-id="image77752952" data-review-reference-id="image77752952">\
         <div class="stencil-wrapper" style="width: 130px; height: 130px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" title="">\
               <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" class="image-cropper" style="height: 130px;width:130px;" width="130" height="130">\
                  <svg:g width="130" height="130">\
                     <svg:svg x="1" y="1" width="128" height="128">\
                        <svg:image width="432" height="253" xlink:href="../repoimages/506339.PNG" preserveAspectRatio="none" transform="scale(0.30092592592592593,0.5138339920948617) translate(-0,-0)  "></svg:image>\
                     </svg:svg>\
                  </svg:g>\
               </svg:svg>\
            </div>\
         </div>\
      </div>\
   </div>\
</div>');