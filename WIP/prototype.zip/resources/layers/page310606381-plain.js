rabbit.data.layerStore.addLayerFromHtml('<div xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:fn="http://www.w3.org/2005/xpath-functions" id="result">\
   <div xmlns:xs="http://www.w3.org/2001/XMLSchema" xmlns="http://www.w3.org/1999/xhtml" id="__containerId__page310606381-layer" class="layer" name="__containerId__pageLayer" data-layer-id="page310606381" data-layer-type="pageLayer" style="position:absolute;left:0px;top:0px;">\
      <div id="__containerId__-page310606381-layer-image377306962" style="position: absolute; left: 0px; top: 0px; width: 1366px; height: 2000px" data-interactive-element-type="default.image" class="image stencil mobile-interaction-potential-trigger " data-stencil-id="image377306962" data-review-reference-id="image377306962">\
         <div class="stencil-wrapper" style="width: 1366px; height: 2000px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" title="">\
               <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" class="image-cropper" style="height: 2000px;width:1366px;" width="1366" height="2000" viewBox="0 0 1366 2000">\
                  <svg:g width="1366" height="2000">\
                     <svg:svg x="0" y="0" width="1366" height="2000">\
                        <svg:image width="432" height="253" xlink:href="../repoimages/508372.PNG" preserveAspectRatio="none" transform="scale(3.162037037037037,7.905138339920948) translate(-0,-0)  "></svg:image>\
                     </svg:svg>\
                  </svg:g>\
               </svg:svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page310606381-layer-image290283686" style="position: absolute; left: 0px; top: 40px; width: 1366px; height: 2500px" data-interactive-element-type="default.image" class="image stencil mobile-interaction-potential-trigger " data-stencil-id="image290283686" data-review-reference-id="image290283686">\
         <div class="stencil-wrapper" style="width: 1366px; height: 2500px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" title="">\
               <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" class="image-cropper" style="height: 2500px;width:1366px;" width="1366" height="2500" viewBox="0 0 1366 2500">\
                  <svg:g width="1366" height="2500">\
                     <svg:svg x="0" y="0" width="1366" height="2500">\
                        <svg:image width="432" height="253" xlink:href="../repoimages/508372.PNG" preserveAspectRatio="none" transform="scale(3.162037037037037,9.881422924901186) translate(-0,-0)  "></svg:image>\
                     </svg:svg>\
                  </svg:g>\
               </svg:svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page310606381-layer-image48482458" style="position: absolute; left: 0px; top: 75px; width: 1366px; height: 2500px" data-interactive-element-type="default.image" class="image stencil mobile-interaction-potential-trigger " data-stencil-id="image48482458" data-review-reference-id="image48482458">\
         <div class="stencil-wrapper" style="width: 1366px; height: 2500px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" title="">\
               <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" class="image-cropper" style="height: 2500px;width:1366px;" width="1366" height="2500" viewBox="0 0 1366 2500">\
                  <svg:g width="1366" height="2500">\
                     <svg:svg x="0" y="0" width="1366" height="2500">\
                        <svg:image width="432" height="253" xlink:href="../repoimages/508372.PNG" preserveAspectRatio="none" transform="scale(3.162037037037037,9.881422924901186) translate(-0,-0)  "></svg:image>\
                     </svg:svg>\
                  </svg:g>\
               </svg:svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page310606381-layer-image422146603" style="position: absolute; left: 0px; top: 0px; width: 1366px; height: 145px" data-interactive-element-type="default.image" class="image stencil mobile-interaction-potential-trigger " data-stencil-id="image422146603" data-review-reference-id="image422146603">\
         <div class="stencil-wrapper" style="width: 1366px; height: 145px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" title="">\
               <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" class="image-cropper" style="height: 145px;width:1366px;" width="1366" height="145" viewBox="0 0 1366 145">\
                  <svg:g width="1366" height="145">\
                     <svg:svg x="0" y="0" width="1366" height="145">\
                        <svg:image width="80" height="60" xlink:href="../repoimages/508394.PNG" preserveAspectRatio="none" transform="scale(17.075,2.4166666666666665) translate(-0,-0)  "></svg:image>\
                     </svg:svg>\
                  </svg:g>\
               </svg:svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page310606381-layer-image229590994" style="position: absolute; left: 10px; top: 155px; width: 866px; height: 577px" data-interactive-element-type="default.image" class="image stencil mobile-interaction-potential-trigger " data-stencil-id="image229590994" data-review-reference-id="image229590994">\
         <div class="stencil-wrapper" style="width: 866px; height: 577px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" title="">\
               <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" class="image-cropper" style="height: 577px;width:866px;" width="866" height="577" viewBox="0 0 866 577">\
                  <svg:g width="866" height="577">\
                     <svg:svg x="0" y="0" width="866" height="577">\
                        <svg:image width="80" height="60" xlink:href="../repoimages/508395.JPG" preserveAspectRatio="none" transform="scale(10.825,9.616666666666667) translate(-0,-0)  "></svg:image>\
                     </svg:svg>\
                  </svg:g>\
               </svg:svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page310606381-layer-image732056455" style="position: absolute; left: 295px; top: 740px; width: 100px; height: 100px" data-interactive-element-type="default.image" class="image stencil mobile-interaction-potential-trigger " data-stencil-id="image732056455" data-review-reference-id="image732056455">\
         <div class="stencil-wrapper" style="width: 100px; height: 100px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" title="">\
               <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" class="image-cropper" style="height: 100px;width:100px;" width="100" height="100" viewBox="0 0 100 100">\
                  <svg:g width="100" height="100">\
                     <svg:svg x="0" y="0" width="100" height="100">\
                        <svg:image width="80" height="60" xlink:href="../repoimages/508400.JPG" preserveAspectRatio="none" transform="scale(1.25,1.6666666666666667) translate(-0,-0)  "></svg:image>\
                     </svg:svg>\
                  </svg:g>\
               </svg:svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page310606381-layer-image159827258" style="position: absolute; left: 675px; top: 740px; width: 100px; height: 100px" data-interactive-element-type="default.image" class="image stencil mobile-interaction-potential-trigger " data-stencil-id="image159827258" data-review-reference-id="image159827258">\
         <div class="stencil-wrapper" style="width: 100px; height: 100px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" title="">\
               <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" class="image-cropper" style="height: 100px;width:100px;" width="100" height="100" viewBox="0 0 100 100">\
                  <svg:g width="100" height="100">\
                     <svg:svg x="0" y="0" width="100" height="100">\
                        <svg:image width="80" height="60" xlink:href="../repoimages/508401.jpg" preserveAspectRatio="none" transform="scale(1.25,1.6666666666666667) translate(-0,-0)  "></svg:image>\
                     </svg:svg>\
                  </svg:g>\
               </svg:svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page310606381-layer-image798264162" style="position: absolute; left: 550px; top: 740px; width: 100px; height: 100px" data-interactive-element-type="default.image" class="image stencil mobile-interaction-potential-trigger " data-stencil-id="image798264162" data-review-reference-id="image798264162">\
         <div class="stencil-wrapper" style="width: 100px; height: 100px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" title="">\
               <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" class="image-cropper" style="height: 100px;width:100px;" width="100" height="100" viewBox="0 0 100 100">\
                  <svg:g width="100" height="100">\
                     <svg:svg x="0" y="0" width="100" height="100">\
                        <svg:image width="80" height="60" xlink:href="../repoimages/508402.jpg" preserveAspectRatio="none" transform="scale(1.25,1.6666666666666667) translate(-0,-0)  "></svg:image>\
                     </svg:svg>\
                  </svg:g>\
               </svg:svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page310606381-layer-image351591010" style="position: absolute; left: 425px; top: 740px; width: 100px; height: 100px" data-interactive-element-type="default.image" class="image stencil mobile-interaction-potential-trigger " data-stencil-id="image351591010" data-review-reference-id="image351591010">\
         <div class="stencil-wrapper" style="width: 100px; height: 100px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" title="">\
               <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" class="image-cropper" style="height: 100px;width:100px;" width="100" height="100" viewBox="0 0 100 100">\
                  <svg:g width="100" height="100">\
                     <svg:svg x="0" y="0" width="100" height="100">\
                        <svg:image width="80" height="60" xlink:href="../repoimages/508403.JPG" preserveAspectRatio="none" transform="scale(1.25,1.6666666666666667) translate(-0,-0)  "></svg:image>\
                     </svg:svg>\
                  </svg:g>\
               </svg:svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page310606381-layer-icon811601317" style="position: absolute; left: 5px; top: 400px; width: 48px; height: 48px" data-interactive-element-type="fonticon.icon" class="icon stencil mobile-interaction-potential-trigger " data-stencil-id="icon811601317" data-review-reference-id="icon811601317">\
         <div class="stencil-wrapper" style="width: 48px; height: 48px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" style="width:48px;height:48px;" title="">\
               <svg xmlns="http://www.w3.org/2000/svg" width="48" height="48" class="fill-black">\
                  <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#icon-glyph-e225"></use>\
               </svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page310606381-layer-icon191086089" style="position: absolute; left: 830px; top: 400px; width: 48px; height: 48px" data-interactive-element-type="fonticon.icon" class="icon stencil mobile-interaction-potential-trigger " data-stencil-id="icon191086089" data-review-reference-id="icon191086089">\
         <div class="stencil-wrapper" style="width: 48px; height: 48px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" style="width:48px;height:48px;" title="">\
               <svg xmlns="http://www.w3.org/2000/svg" width="48" height="48" class="fill-black">\
                  <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#icon-glyph-e224"></use>\
               </svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page310606381-layer-image40186489" style="position: absolute; left: 885px; top: 155px; width: 470px; height: 1330px" data-interactive-element-type="default.image" class="image stencil mobile-interaction-potential-trigger " data-stencil-id="image40186489" data-review-reference-id="image40186489">\
         <div class="stencil-wrapper" style="width: 470px; height: 1330px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" title="">\
               <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" class="image-cropper" style="height: 1330px;width:470px;" width="470" height="1330" viewBox="0 0 470 1330">\
                  <svg:g width="470" height="1330">\
                     <svg:svg x="0" y="0" width="470" height="1330">\
                        <svg:image width="93" height="25" xlink:href="../repoimages/508405.PNG" preserveAspectRatio="none" transform="scale(5.053763440860215,53.2) translate(-0,-0)  "></svg:image>\
                     </svg:svg>\
                  </svg:g>\
               </svg:svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page310606381-layer-icon890675694" style="position: absolute; left: 1320px; top: 145px; width: 32px; height: 32px" data-interactive-element-type="fonticon.icon" class="icon stencil mobile-interaction-potential-trigger " data-stencil-id="icon890675694" data-review-reference-id="icon890675694">\
         <div class="stencil-wrapper" style="width: 32px; height: 32px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" style="width:32px;height:32px;" title="">\
               <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" class="fill-black">\
                  <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#icon-glyph-e336"></use>\
               </svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page310606381-layer-text906924579" style="position: absolute; left: 900px; top: 425px; width: 235px; height: 37px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text906924579" data-review-reference-id="text906924579">\
         <div class="stencil-wrapper" style="width: 235px; height: 37px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline12"><p class="none" style="font-size: 32px;"><span style="color: #658cd9;">Điểm đặc trưng </span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page310606381-layer-rating586227224" style="position: absolute; left: 900px; top: 160px; width: 170px; height: 40px" data-interactive-element-type="default.rating" class="rating stencil mobile-interaction-potential-trigger " data-stencil-id="rating586227224" data-review-reference-id="rating586227224">\
         <div class="stencil-wrapper" style="width: 170px; height: 40px">\
            <div style="width:170px; height:40px" onmouseout="if(rabbit.stencils.rating.checkMouseOutDiv(\'__containerId__-page310606381-layer-rating586227224\', event)) rabbit.facade.raiseEvent(rabbit.events.ratingMouseOut, \'__containerId__-page310606381-layer-rating586227224\');" title=""><img id="__containerId__-page310606381-layer-rating586227224-1" src="../resources/icons/rating_black.png" width="34" height="40" style="position: absolute; left: 0px; cursor: pointer;" onmouseover="rabbit.facade.raiseEvent(rabbit.events.ratingMouseOver, \'__containerId__-page310606381-layer-rating586227224\', \'1\');" onclick="rabbit.facade.raiseEvent(rabbit.events.ratingResultChangedEvent, \'__containerId__-page310606381-layer-rating586227224\', \'1\');" /><img id="__containerId__-page310606381-layer-rating586227224-2" src="../resources/icons/rating_black.png" width="34" height="40" style="position: absolute; left: 34px; cursor: pointer;" onmouseover="rabbit.facade.raiseEvent(rabbit.events.ratingMouseOver, \'__containerId__-page310606381-layer-rating586227224\', \'2\');" onclick="rabbit.facade.raiseEvent(rabbit.events.ratingResultChangedEvent, \'__containerId__-page310606381-layer-rating586227224\', \'2\');" /><img id="__containerId__-page310606381-layer-rating586227224-3" src="../resources/icons/rating_black.png" width="34" height="40" style="position: absolute; left: 68px; cursor: pointer;" onmouseover="rabbit.facade.raiseEvent(rabbit.events.ratingMouseOver, \'__containerId__-page310606381-layer-rating586227224\', \'3\');" onclick="rabbit.facade.raiseEvent(rabbit.events.ratingResultChangedEvent, \'__containerId__-page310606381-layer-rating586227224\', \'3\');" /><img id="__containerId__-page310606381-layer-rating586227224-4" src="../resources/icons/rating_black.png" width="34" height="40" style="position: absolute; left: 102px; cursor: pointer;" onmouseover="rabbit.facade.raiseEvent(rabbit.events.ratingMouseOver, \'__containerId__-page310606381-layer-rating586227224\', \'4\');" onclick="rabbit.facade.raiseEvent(rabbit.events.ratingResultChangedEvent, \'__containerId__-page310606381-layer-rating586227224\', \'4\');" /><img id="__containerId__-page310606381-layer-rating586227224-5" src="../resources/icons/rating_white.png" width="34" height="40" style="position: absolute; left: 136px; cursor: pointer;" onmouseover="rabbit.facade.raiseEvent(rabbit.events.ratingMouseOver, \'__containerId__-page310606381-layer-rating586227224\', \'5\');" onclick="rabbit.facade.raiseEvent(rabbit.events.ratingResultChangedEvent, \'__containerId__-page310606381-layer-rating586227224\', \'5\');" /></div><script type="text/javascript">\
			rabbit.stencils.rating.onLoad("__containerId__-page310606381-layer-rating586227224", "4");\
		</script></div>\
      </div>\
      <div id="__containerId__-page310606381-layer-text184817720" style="position: absolute; left: 1090px; top: 170px; width: 111px; height: 23px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text184817720" data-review-reference-id="text184817720">\
         <div class="stencil-wrapper" style="width: 111px; height: 23px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.text2"><p class="none" style="font-size: 14px;"><span style="font-size: 20px;">13 đánh giá </span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page310606381-layer-text24658791" style="position: absolute; left: 1215px; top: 170px; width: 99px; height: 20px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text24658791" data-review-reference-id="text24658791">\
         <div class="stencil-wrapper" style="width: 99px; height: 20px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.link2"><p class="underline" style="font-size: 14px;"><span style="font-size: 18px;">1 nhận xét</span></p>\
                     <p class="underline" style="font-size: 14px;"> </p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page310606381-layer-text91490634" style="position: absolute; left: 900px; top: 265px; width: 403px; height: 20px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text91490634" data-review-reference-id="text91490634">\
         <div class="stencil-wrapper" style="width: 403px; height: 20px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline32"><span style="font-size: 18px;">AEON Mall Long Biên, Quận Long Biên, Hà Nội</span></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page310606381-layer-text790498912" style="position: absolute; left: 900px; top: 320px; width: 234px; height: 20px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text790498912" data-review-reference-id="text790498912">\
         <div class="stencil-wrapper" style="width: 234px; height: 20px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline32"><p><span class="bold" style="font-size: 18px; color: #658cd9;">Chương trình khuyến mại:</span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page310606381-layer-text4154276" style="position: absolute; left: 900px; top: 215px; width: 177px; height: 37px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text4154276" data-review-reference-id="text4154276">\
         <div class="stencil-wrapper" style="width: 177px; height: 37px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline12"><p><span style="font-size: 32px; color: #658cd9;">0121456756</span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page310606381-layer-text155070247" style="position: absolute; left: 895px; top: 355px; width: 295px; height: 76px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text155070247" data-review-reference-id="text155070247">\
         <div class="stencil-wrapper" style="width: 295px; height: 76px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textblock2"><p style="font-size: 14px;"><span style="font-size: 18px;">_ Giảm 30% cho khách mới</span><br /><span style="font-size: 18px;">_\
                     Giảm 10% cho đơn hàng trên 1 tr</span><br /><span style="font-size: 18px;"> </span><br /><br /></p>\
                     <p style="font-size: 14px;"> </p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page310606381-layer-text963000291" style="position: absolute; left: 900px; top: 475px; width: 370px; height: 20px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text963000291" data-review-reference-id="text963000291">\
         <div class="stencil-wrapper" style="width: 370px; height: 20px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline12"><p><span style="font-size: 18px;"><span class="bold">Loại hình ẩm thực</span> : Lẩu - Nướng - Ba miền</span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page310606381-layer-42333538" style="position: absolute; left: 900px; top: 515px; width: 435px; height: 60px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="42333538" data-review-reference-id="42333538">\
         <div class="stencil-wrapper" style="width: 435px; height: 60px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline12"><p><span style="font-size: 18px;"><span class="bold">Món đặc sắc</span> : Bánh xèo, lẩu hải sản, bún bò Huế, phở Hà Nội, bánh\
                     tôm Hồ Tây, bánh hỏi chạo tôm, hải sản nướng</span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page310606381-layer-996597469" style="position: absolute; left: 900px; top: 600px; width: 390px; height: 20px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="996597469" data-review-reference-id="996597469">\
         <div class="stencil-wrapper" style="width: 390px; height: 20px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline12"><p><span style="font-size: 18px;"><span class="bold">Giá trung bình</span> : 100.000 - 150.000 vnđ/người</span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page310606381-layer-2014622778" style="position: absolute; left: 900px; top: 655px; width: 451px; height: 40px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="2014622778" data-review-reference-id="2014622778">\
         <div class="stencil-wrapper" style="width: 451px; height: 40px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline12"><p><span style="font-size: 18px;"><span class="bold">Không gian</span> : Phong cách đường phố Việt truyền thống của 3 miền\
                     độc đáo. Sức chứa: 800 khách</span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page310606381-layer-iphoneButton414354944" style="position: absolute; left: 1250px; top: 760px; width: 92px; height: 30px" data-interactive-element-type="default.iphoneButton" class="iphoneButton stencil mobile-interaction-potential-trigger " data-stencil-id="iphoneButton414354944" data-review-reference-id="iphoneButton414354944">\
         <div class="stencil-wrapper" style="width: 92px; height: 30px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" title="" style="height: 30px;width:92px;">\
               <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" width="92" height="30" viewBox="0 0 92 30">\
                  <svg:a>\
                     <svg:path fill-rule="evenodd" clip-rule="evenodd" fill="#808080" stroke="#666666" d="M5,29.5 l-2,-0.5 -1,-1 -1,-1.5 -0.5,-1.5 0,-20 0.5,-2 1,-1 1,-1 2,-0.5 74,0 0.5,0.5 1,0 1,1 1.5,1.5 8.5,11 -7.5,11 -2,2.5 -1.5,1 -0.5,0.5 z"></svg:path>\
                     <svg:text x="43" y="15" dy="0.3em" fill="#FFFFFF" style="font-size:1em;stroke-width:0pt;" font-family="\'HelveticaNeue-Bold\'" text-anchor="middle" xml:space="preserve">Đạt chỗ ngay</svg:text>\
                  </svg:a>\
               </svg:svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page310606381-layer-image660004996" style="position: absolute; left: 20px; top: 860px; width: 830px; height: 580px" data-interactive-element-type="default.image" class="image stencil mobile-interaction-potential-trigger " data-stencil-id="image660004996" data-review-reference-id="image660004996">\
         <div class="stencil-wrapper" style="width: 830px; height: 580px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" title="">\
               <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" class="image-cropper" style="height: 580px;width:830px;" width="830" height="580" viewBox="0 0 830 580">\
                  <svg:g width="830" height="580">\
                     <svg:svg x="0" y="0" width="830" height="580">\
                        <svg:image width="80" height="60" xlink:href="../repoimages/508410.PNG" preserveAspectRatio="none" transform="scale(10.375,9.666666666666666) translate(-0,-0)  "></svg:image>\
                     </svg:svg>\
                  </svg:g>\
               </svg:svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page310606381-layer-image743413727" style="position: absolute; left: 20px; top: 900px; width: 830px; height: 580px" data-interactive-element-type="default.image" class="image stencil mobile-interaction-potential-trigger " data-stencil-id="image743413727" data-review-reference-id="image743413727">\
         <div class="stencil-wrapper" style="width: 830px; height: 580px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" title="">\
               <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" class="image-cropper" style="height: 580px;width:830px;" width="830" height="580" viewBox="0 0 830 580">\
                  <svg:g width="830" height="580">\
                     <svg:svg x="0" y="0" width="830" height="580">\
                        <svg:image width="80" height="60" xlink:href="../repoimages/508410.PNG" preserveAspectRatio="none" transform="scale(10.375,9.666666666666666) translate(-0,-0)  "></svg:image>\
                     </svg:svg>\
                  </svg:g>\
               </svg:svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page310606381-layer-image529488340" style="position: absolute; left: 20px; top: 1480px; width: 860px; height: 278px" data-interactive-element-type="default.image" class="image stencil mobile-interaction-potential-trigger " data-stencil-id="image529488340" data-review-reference-id="image529488340">\
         <div class="stencil-wrapper" style="width: 860px; height: 278px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" title="">\
               <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" class="image-cropper" style="height: 278px;width:860px;" width="860" height="278" viewBox="0 0 860 278">\
                  <svg:g width="860" height="278">\
                     <svg:svg x="0" y="0" width="860" height="278">\
                        <svg:image width="80" height="60" xlink:href="../repoimages/508411.PNG" preserveAspectRatio="none" transform="scale(10.75,4.633333333333334) translate(-0,-0)  "></svg:image>\
                     </svg:svg>\
                  </svg:g>\
               </svg:svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page310606381-layer-map379231884" style="position: absolute; left: 50px; top: 1765px; width: 820px; height: 430px" data-interactive-element-type="static.map" class="map stencil mobile-interaction-potential-trigger " data-stencil-id="map379231884" data-review-reference-id="map379231884">\
         <div class="stencil-wrapper" style="width: 820px; height: 430px">\
            <div style="background:white;width:820px; height:430px;border:2px solid" title=""><img src="../resources/icons/map_default.png" style="position:relative;left:0px;top:0px;;width:820px;height:430px;overflow:auto;" width="820" height="430" preserveAspectRatio="none" /></div>\
         </div>\
      </div>\
      <div id="__containerId__-page310606381-layer-image761310260" style="position: absolute; left: 45px; top: 2210px; width: 820px; height: 300px" data-interactive-element-type="default.image" class="image stencil mobile-interaction-potential-trigger " data-stencil-id="image761310260" data-review-reference-id="image761310260">\
         <div class="stencil-wrapper" style="width: 820px; height: 300px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" title="">\
               <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" class="image-cropper" style="height: 300px;width:820px;" width="820" height="300" viewBox="0 0 820 300">\
                  <svg:g width="820" height="300">\
                     <svg:svg x="0" y="0" width="820" height="300">\
                        <svg:image width="80" height="60" xlink:href="../repoimages/508412.PNG" preserveAspectRatio="none" transform="scale(10.25,5) translate(-0,-0)  "></svg:image>\
                     </svg:svg>\
                  </svg:g>\
               </svg:svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page310606381-layer-434730018" style="position: absolute; left: 900px; top: 710px; width: 425px; height: 20px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="434730018" data-review-reference-id="434730018">\
         <div class="stencil-wrapper" style="width: 425px; height: 20px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline12"><p><span style="font-size: 18px;"><span class="bold">Giờ mở cửa</span> : 7h sáng - 10h đêm / làm cả ngày lễ</span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page310606381-layer-icon742604360" style="position: absolute; left: 320px; top: 105px; width: 32px; height: 32px" data-interactive-element-type="fonticon.icon" class="icon pidoco-clickable-element stencil mobile-interaction-potential-trigger " data-stencil-id="icon742604360" data-review-reference-id="icon742604360">\
         <div class="stencil-wrapper" style="width: 32px; height: 32px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" style="width:32px;height:32px;" title="">\
               <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" class="fill-green">\
                  <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#icon-glyph-e210"></use>\
               </svg>\
            </div>\
         </div><script type="text/javascript">\
			$(document).ready(function(){\
				rabbit.interaction.manager.registerInteraction(\'__containerId__-page310606381-layer-icon742604360\', \'interaction524586502\', \
		{\
		\
			\'button\': \'left\'\
			\
				,\
			\
			\'id\': \'action702678278\'\
			\
				,\
			\
			\'numberOfFinger\': \'1\'\
			\
				,\
			\
			\'type\': \'click\'\
			\
		}\
	,  \
					[\
						\
		{\
		\
			\'delay\': \'0\'\
			\
				,\
			\
			\'id\': \'reaction792968331\'\
			\
				,\
			\
			\'options\': \'withoutReloadOnly\'\
			\
				,\
			\
			\'target\': \'page584926941\'\
			\
				,\
			\
			\'transition\': \'none\'\
			\
				,\
			\
			\'type\': \'showPage\'\
			\
		}\
	\
					]\
				);\
			});\
		</script></div>\
   </div>\
</div>');