rabbit.data.layerStore.addLayerFromHtml('<div xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:fn="http://www.w3.org/2005/xpath-functions" id="result">\
   <div xmlns:xs="http://www.w3.org/2001/XMLSchema" xmlns="http://www.w3.org/1999/xhtml" id="__containerId__page660359406-layer" class="layer" name="__containerId__pageLayer" data-layer-id="page660359406" data-layer-type="pageLayer" style="position:absolute;left:0px;top:0px;">\
      <div id="__containerId__-page660359406-layer-image406635204" style="position: absolute; left: 0px; top: 0px; width: 1366px; height: 2000px" data-interactive-element-type="default.image" class="image stencil mobile-interaction-potential-trigger " data-stencil-id="image406635204" data-review-reference-id="image406635204">\
         <div class="stencil-wrapper" style="width: 1366px; height: 2000px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" title="">\
               <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" class="image-cropper" style="height: 2000px;width:1366px;" width="1366" height="2000">\
                  <svg:g width="1366" height="2000">\
                     <svg:svg x="1" y="1" width="1364" height="1998">\
                        <svg:image width="432" height="253" xlink:href="../repoimages/506332.PNG" preserveAspectRatio="none" transform="scale(3.162037037037037,7.905138339920948) translate(-0,-0)  "></svg:image>\
                     </svg:svg>\
                  </svg:g>\
               </svg:svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page660359406-layer-image460387506" style="position: absolute; left: 0px; top: 50px; width: 1366px; height: 2000px" data-interactive-element-type="default.image" class="image stencil mobile-interaction-potential-trigger " data-stencil-id="image460387506" data-review-reference-id="image460387506">\
         <div class="stencil-wrapper" style="width: 1366px; height: 2000px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" title="">\
               <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" class="image-cropper" style="height: 2000px;width:1366px;" width="1366" height="2000">\
                  <svg:g width="1366" height="2000">\
                     <svg:svg x="1" y="1" width="1364" height="1998">\
                        <svg:image width="432" height="253" xlink:href="../repoimages/506332.PNG" preserveAspectRatio="none" transform="scale(3.162037037037037,7.905138339920948) translate(-0,-0)  "></svg:image>\
                     </svg:svg>\
                  </svg:g>\
               </svg:svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page660359406-layer-image837760300" style="position: absolute; left: 0px; top: 5px; width: 1366px; height: 340px" data-interactive-element-type="default.image" class="image stencil mobile-interaction-potential-trigger " data-stencil-id="image837760300" data-review-reference-id="image837760300">\
         <div class="stencil-wrapper" style="width: 1366px; height: 340px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" title="">\
               <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" class="image-cropper" style="height: 340px;width:1366px;" width="1366" height="340">\
                  <svg:g width="1366" height="340">\
                     <svg:svg x="1" y="1" width="1364" height="338">\
                        <svg:image width="2400" height="742" xlink:href="../repoimages/508378.jpg" preserveAspectRatio="none" transform="scale(0.5691666666666667,0.4582210242587601) translate(-0,-0)  "></svg:image>\
                     </svg:svg>\
                  </svg:g>\
               </svg:svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page660359406-layer-text741231440" style="position: absolute; left: 820px; top: 20px; width: 490px; height: 28px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text741231440" data-review-reference-id="text741231440">\
         <div class="stencil-wrapper" style="width: 490px; height: 28px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.text2"><p class="none" style="font-size: 14px;"><span class="bold" style="font-size: 24px; color: #b1c51a;">Khám phá hàng trăm nhà\
                     hàng khác nhau </span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page660359406-layer-icon982927271" style="position: absolute; left: 1310px; top: 150px; width: 48px; height: 48px" data-interactive-element-type="fonticon.icon" class="icon stencil mobile-interaction-potential-trigger " data-stencil-id="icon982927271" data-review-reference-id="icon982927271">\
         <div class="stencil-wrapper" style="width: 48px; height: 48px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" style="width:48px;height:48px;" title="">\
               <svg xmlns="http://www.w3.org/2000/svg" width="48" height="48" class="fill-black">\
                  <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#icon-glyph-e224"></use>\
               </svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page660359406-layer-icon380509444" style="position: absolute; left: 10px; top: 150px; width: 48px; height: 48px" data-interactive-element-type="fonticon.icon" class="icon stencil mobile-interaction-potential-trigger " data-stencil-id="icon380509444" data-review-reference-id="icon380509444">\
         <div class="stencil-wrapper" style="width: 48px; height: 48px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" style="width:48px;height:48px;" title="">\
               <svg xmlns="http://www.w3.org/2000/svg" width="48" height="48" class="fill-black">\
                  <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#icon-glyph-e225"></use>\
               </svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page660359406-layer-text423544196" style="position: absolute; left: 60px; top: 370px; width: 226px; height: 30px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text423544196" data-review-reference-id="text423544196">\
         <div class="stencil-wrapper" style="width: 226px; height: 30px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.text2"><p style="font-size: 14px;"><span style="color: #658cd9; font-size: 26px;">TOP PROMOTION</span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page660359406-layer-image949538592" style="position: absolute; left: 100px; top: 415px; width: 1162px; height: 324px" data-interactive-element-type="default.image" class="image stencil mobile-interaction-potential-trigger " data-stencil-id="image949538592" data-review-reference-id="image949538592">\
         <div class="stencil-wrapper" style="width: 1162px; height: 324px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" title="">\
               <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" class="image-cropper" style="height: 324px;width:1162px;" width="1162" height="324">\
                  <svg:g width="1162" height="324">\
                     <svg:svg x="1" y="1" width="1160" height="322">\
                        <svg:image width="80" height="60" xlink:href="../repoimages/508379.PNG" preserveAspectRatio="none" transform="scale(14.525,5.4) translate(-0,-0)  "></svg:image>\
                     </svg:svg>\
                  </svg:g>\
               </svg:svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page660359406-layer-1494601871" style="position: absolute; left: 60px; top: 775px; width: 165px; height: 30px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="1494601871" data-review-reference-id="1494601871">\
         <div class="stencil-wrapper" style="width: 165px; height: 30px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.text2"><p class="none" style="font-size: 14px;"><span style="color: #658cd9; font-size: 26px;">TOP ORDER</span></p>\
                     <p class="none" style="font-size: 14px;"> </p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page660359406-layer-text72631429" style="position: absolute; left: 1155px; top: 390px; width: 95px; height: 20px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text72631429" data-review-reference-id="text72631429">\
         <div class="stencil-wrapper" style="width: 95px; height: 20px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.link2"><p class="underline" style="font-size: 14px;"><span style="color: #658cd9; font-size: 18px;">Xem thêm </span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page660359406-layer-image408505614" style="position: absolute; left: 100px; top: 840px; width: 1175px; height: 316px" data-interactive-element-type="default.image" class="image stencil mobile-interaction-potential-trigger " data-stencil-id="image408505614" data-review-reference-id="image408505614">\
         <div class="stencil-wrapper" style="width: 1175px; height: 316px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" title="">\
               <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" class="image-cropper" style="height: 316px;width:1175px;" width="1175" height="316">\
                  <svg:g width="1175" height="316">\
                     <svg:svg x="1" y="1" width="1173" height="314">\
                        <svg:image width="80" height="60" xlink:href="../repoimages/508380.PNG" preserveAspectRatio="none" transform="scale(14.6875,5.266666666666667) translate(-0,-0)  "></svg:image>\
                     </svg:svg>\
                  </svg:g>\
               </svg:svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page660359406-layer-449336821" style="position: absolute; left: 1155px; top: 810px; width: 95px; height: 20px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="449336821" data-review-reference-id="449336821">\
         <div class="stencil-wrapper" style="width: 95px; height: 20px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.link2"><p class="underline" style="font-size: 14px;"><span style="color: #658cd9; font-size: 18px;">Xem thêm </span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page660359406-layer-1096420295" style="position: absolute; left: 60px; top: 1220px; width: 137px; height: 31px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="1096420295" data-review-reference-id="1096420295">\
         <div class="stencil-wrapper" style="width: 137px; height: 31px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.text2"><p class="none" style="font-size: 14px;"><span style="color: #658cd9; font-size: 26px;">TOP SALE</span></p>\
                     <p class="none" style="font-size: 14px;"> </p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page660359406-layer-1890738293" style="position: absolute; left: 1155px; top: 1250px; width: 95px; height: 20px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="1890738293" data-review-reference-id="1890738293">\
         <div class="stencil-wrapper" style="width: 95px; height: 20px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.link2"><p class="underline" style="font-size: 14px;"><span style="color: #658cd9; font-size: 18px;">Xem thêm </span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page660359406-layer-image726573445" style="position: absolute; left: 90px; top: 1280px; width: 1176px; height: 322px" data-interactive-element-type="default.image" class="image stencil mobile-interaction-potential-trigger " data-stencil-id="image726573445" data-review-reference-id="image726573445">\
         <div class="stencil-wrapper" style="width: 1176px; height: 322px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" title="">\
               <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" class="image-cropper" style="height: 322px;width:1176px;" width="1176" height="322">\
                  <svg:g width="1176" height="322">\
                     <svg:svg x="1" y="1" width="1174" height="320">\
                        <svg:image width="80" height="60" xlink:href="../repoimages/508382.PNG" preserveAspectRatio="none" transform="scale(14.7,5.366666666666666) translate(-0,-0)  "></svg:image>\
                     </svg:svg>\
                  </svg:g>\
               </svg:svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page660359406-layer-1786805590" style="position: absolute; left: 70px; top: 1625px; width: 122px; height: 30px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="1786805590" data-review-reference-id="1786805590">\
         <div class="stencil-wrapper" style="width: 122px; height: 30px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.text2"><p class="none" style="font-size: 14px;"><span style="color: #658cd9; font-size: 26px;">NEWEST</span></p>\
                     <p class="none" style="font-size: 14px;"> </p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page660359406-layer-1404225621" style="position: absolute; left: 1165px; top: 1660px; width: 95px; height: 20px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="1404225621" data-review-reference-id="1404225621">\
         <div class="stencil-wrapper" style="width: 95px; height: 20px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.link2"><p class="underline" style="font-size: 14px;"><span style="color: #658cd9; font-size: 18px;">Xem thêm </span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page660359406-layer-image106389150" style="position: absolute; left: 90px; top: 1685px; width: 1170px; height: 313px" data-interactive-element-type="default.image" class="image stencil mobile-interaction-potential-trigger " data-stencil-id="image106389150" data-review-reference-id="image106389150">\
         <div class="stencil-wrapper" style="width: 1170px; height: 313px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" title="">\
               <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" class="image-cropper" style="height: 313px;width:1170px;" width="1170" height="313">\
                  <svg:g width="1170" height="313">\
                     <svg:svg x="1" y="1" width="1168" height="311">\
                        <svg:image width="80" height="60" xlink:href="../repoimages/508384.PNG" preserveAspectRatio="none" transform="scale(14.625,5.216666666666667) translate(-0,-0)  "></svg:image>\
                     </svg:svg>\
                  </svg:g>\
               </svg:svg>\
            </div>\
         </div>\
      </div>\
   </div>\
</div>');