rabbit.data.layerStore.addLayerFromHtml('<div xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:fn="http://www.w3.org/2005/xpath-functions" id="result">\
   <div xmlns:xs="http://www.w3.org/2001/XMLSchema" xmlns="http://www.w3.org/1999/xhtml" id="__containerId__page735926670-layer" class="layer" name="__containerId__pageLayer" data-layer-id="page735926670" data-layer-type="pageLayer" style="position:absolute;left:0px;top:0px;">\
      <div id="__containerId__-page735926670-layer-image973037928" style="position: absolute; left: 0px; top: 0px; width: 1366px; height: 60px" data-interactive-element-type="default.image" class="image stencil mobile-interaction-potential-trigger " data-stencil-id="image973037928" data-review-reference-id="image973037928">\
         <div class="stencil-wrapper" style="width: 1366px; height: 60px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" title="">\
               <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" class="image-cropper" style="height: 60px;width:1366px;" width="1366" height="60" viewBox="0 0 1366 60">\
                  <svg:g width="1366" height="60">\
                     <svg:svg x="0" y="0" width="1366" height="60">\
                        <svg:image width="70" height="21" xlink:href="../repoimages/508386.PNG" preserveAspectRatio="none" transform="scale(19.514285714285716,2.857142857142857) translate(-0,-0)  "></svg:image>\
                     </svg:svg>\
                  </svg:g>\
               </svg:svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page735926670-layer-image564669680" style="position: absolute; left: 0px; top: 40px; width: 1366px; height: 50px" data-interactive-element-type="default.image" class="image stencil mobile-interaction-potential-trigger " data-stencil-id="image564669680" data-review-reference-id="image564669680">\
         <div class="stencil-wrapper" style="width: 1366px; height: 50px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" title="">\
               <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" class="image-cropper" style="height: 50px;width:1366px;" width="1366" height="50" viewBox="0 0 1366 50">\
                  <svg:g width="1366" height="50">\
                     <svg:svg x="0" y="0" width="1366" height="50">\
                        <svg:image width="70" height="21" xlink:href="../repoimages/508386.PNG" preserveAspectRatio="none" transform="scale(19.514285714285716,2.380952380952381) translate(-0,-0)  "></svg:image>\
                     </svg:svg>\
                  </svg:g>\
               </svg:svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page735926670-layer-image497667861" style="position: absolute; left: 0px; top: 80px; width: 1366px; height: 1300px" data-interactive-element-type="default.image" class="image stencil mobile-interaction-potential-trigger " data-stencil-id="image497667861" data-review-reference-id="image497667861">\
         <div class="stencil-wrapper" style="width: 1366px; height: 1300px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" title="">\
               <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" class="image-cropper" style="height: 1300px;width:1366px;" width="1366" height="1300" viewBox="0 0 1366 1300">\
                  <svg:g width="1366" height="1300">\
                     <svg:svg x="0" y="0" width="1366" height="1300">\
                        <svg:image width="80" height="60" xlink:href="../repoimages/506332.PNG" preserveAspectRatio="none" transform="scale(17.075,21.666666666666668) translate(-0,-0)  "></svg:image>\
                     </svg:svg>\
                  </svg:g>\
               </svg:svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page735926670-layer-image330320926" style="position: absolute; left: 0px; top: 120px; width: 1366px; height: 1300px" data-interactive-element-type="default.image" class="image stencil mobile-interaction-potential-trigger " data-stencil-id="image330320926" data-review-reference-id="image330320926">\
         <div class="stencil-wrapper" style="width: 1366px; height: 1300px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" title="">\
               <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" class="image-cropper" style="height: 1300px;width:1366px;" width="1366" height="1300" viewBox="0 0 1366 1300">\
                  <svg:g width="1366" height="1300">\
                     <svg:svg x="0" y="0" width="1366" height="1300">\
                        <svg:image width="80" height="60" xlink:href="../repoimages/506332.PNG" preserveAspectRatio="none" transform="scale(17.075,21.666666666666668) translate(-0,-0)  "></svg:image>\
                     </svg:svg>\
                  </svg:g>\
               </svg:svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page735926670-layer-image950603217" style="position: absolute; left: 0px; top: 0px; width: 120px; height: 55px" data-interactive-element-type="default.image" class="image stencil mobile-interaction-potential-trigger " data-stencil-id="image950603217" data-review-reference-id="image950603217">\
         <div class="stencil-wrapper" style="width: 120px; height: 55px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" title="">\
               <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" class="image-cropper" style="height: 55px;width:120px;" width="120" height="55" viewBox="0 0 120 55">\
                  <svg:g width="120" height="55">\
                     <svg:svg x="0" y="0" width="120" height="55">\
                        <svg:image width="80" height="60" xlink:href="../repoimages/506334.png" preserveAspectRatio="none" transform="scale(1.5,0.9166666666666666) translate(-0,-0)  "></svg:image>\
                     </svg:svg>\
                  </svg:g>\
               </svg:svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page735926670-layer-text445899147" style="position: absolute; left: 140px; top: 5px; width: 103px; height: 28px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text445899147" data-review-reference-id="text445899147">\
         <div class="stencil-wrapper" style="width: 103px; height: 28px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline22"><p class="none" style="font-size: 24px;"><span style="color: white;">Ẩm thực </span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page735926670-layer-1313036361" style="position: absolute; left: 270px; top: 5px; width: 122px; height: 28px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="1313036361" data-review-reference-id="1313036361">\
         <div class="stencil-wrapper" style="width: 122px; height: 28px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline22"><p class="none" style="font-size: 24px;"><span style="color: white;">Thẻ ưu đãi</span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page735926670-layer-1018362389" style="position: absolute; left: 430px; top: 5px; width: 79px; height: 28px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="1018362389" data-review-reference-id="1018362389">\
         <div class="stencil-wrapper" style="width: 79px; height: 28px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline22"><p class="none" style="font-size: 24px;"><span style="color: white;">Tin tức</span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page735926670-layer-871043117" style="position: absolute; left: 570px; top: 5px; width: 54px; height: 28px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="871043117" data-review-reference-id="871043117">\
         <div class="stencil-wrapper" style="width: 54px; height: 28px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline22"><p class="none" style="font-size: 24px;"><span style="color: white;">Blog</span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page735926670-layer-44672541" style="position: absolute; left: 855px; top: 5px; width: 110px; height: 28px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="44672541" data-review-reference-id="44672541">\
         <div class="stencil-wrapper" style="width: 110px; height: 28px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline22"><p class="none" style="font-size: 24px;"><span style="color: white;">Giới thiệu</span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page735926670-layer-867557644" style="position: absolute; left: 680px; top: 5px; width: 129px; height: 28px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="867557644" data-review-reference-id="867557644">\
         <div class="stencil-wrapper" style="width: 129px; height: 28px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline22"><p class="none" style="font-size: 24px;"><span style="color: white;">Hướng dẫn</span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page735926670-layer-1827375608" style="position: absolute; left: 1005px; top: 5px; width: 113px; height: 28px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="1827375608" data-review-reference-id="1827375608">\
         <div class="stencil-wrapper" style="width: 113px; height: 28px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline22"><p class="none" style="font-size: 24px;"><span style="color: white;">Ngôn ngữ</span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page735926670-layer-icon264923266" style="position: absolute; left: 1325px; top: 5px; width: 32px; height: 32px" data-interactive-element-type="fonticon.icon" class="icon stencil mobile-interaction-potential-trigger " data-stencil-id="icon264923266" data-review-reference-id="icon264923266">\
         <div class="stencil-wrapper" style="width: 32px; height: 32px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" style="width:32px;height:32px;" title="">\
               <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" class="fill-white">\
                  <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#icon-glyph-e004"></use>\
               </svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page735926670-layer-456376681" style="position: absolute; left: 1190px; top: 5px; width: 128px; height: 28px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="456376681" data-review-reference-id="456376681">\
         <div class="stencil-wrapper" style="width: 128px; height: 28px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline22"><p class="none" style="font-size: 24px;"><span style="color: white;">Người dùng</span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page735926670-layer-image473404083" style="position: absolute; left: 0px; top: 55px; width: 1366px; height: 85px" data-interactive-element-type="default.image" class="image stencil mobile-interaction-potential-trigger " data-stencil-id="image473404083" data-review-reference-id="image473404083">\
         <div class="stencil-wrapper" style="width: 1366px; height: 85px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" title="">\
               <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" class="image-cropper" style="height: 85px;width:1366px;" width="1366" height="85" viewBox="0 0 1366 85">\
                  <svg:g width="1366" height="85">\
                     <svg:svg x="0" y="0" width="1366" height="85">\
                        <svg:image width="432" height="253" xlink:href="../repoimages/506338.PNG" preserveAspectRatio="none" transform="scale(3.162037037037037,0.3359683794466403) translate(-0,-0)  "></svg:image>\
                     </svg:svg>\
                  </svg:g>\
               </svg:svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page735926670-layer-combobox90962004" style="position: absolute; left: 45px; top: 80px; width: 180px; height: 45px" data-interactive-element-type="default.combobox" class="combobox stencil mobile-interaction-potential-trigger " data-stencil-id="combobox90962004" data-review-reference-id="combobox90962004">\
         <div class="stencil-wrapper" style="width: 180px; height: 45px">\
            <div title=""><select id="__containerId__-page735926670-layer-combobox90962004select" style="width:180px;height:45px;" title="">\
                  <option title="">Hà Nội</option>\
                  <option title="">HCM </option>\
                  <option title="">Đà Nẵng</option></select></div>\
         </div>\
      </div>\
      <div id="__containerId__-page735926670-layer-icon874521084" style="position: absolute; left: -5px; top: 80px; width: 48px; height: 48px" data-interactive-element-type="fonticon.icon" class="icon stencil mobile-interaction-potential-trigger " data-stencil-id="icon874521084" data-review-reference-id="icon874521084">\
         <div class="stencil-wrapper" style="width: 48px; height: 48px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" style="width:48px;height:48px;" title="">\
               <svg xmlns="http://www.w3.org/2000/svg" width="48" height="48" class="fill-blue">\
                  <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#icon-glyph-e243"></use>\
               </svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page735926670-layer-textinput817849469" style="position: absolute; left: 250px; top: 80px; width: 780px; height: 45px" data-interactive-element-type="default.textinput" class="textinput stencil mobile-interaction-potential-trigger " data-stencil-id="textinput817849469" data-review-reference-id="textinput817849469">\
         <div class="stencil-wrapper" style="width: 780px; height: 45px">\
            <div title=""><textarea id="__containerId__-page735926670-layer-textinput817849469input" rows="" cols="" style="width:778px;height:41px;padding: 0px;border-width:1px;"></textarea></div>\
         </div>\
      </div>\
      <div id="__containerId__-page735926670-layer-icon423281343" style="position: absolute; left: 970px; top: 80px; width: 48px; height: 48px" data-interactive-element-type="fonticon.icon" class="icon stencil mobile-interaction-potential-trigger " data-stencil-id="icon423281343" data-review-reference-id="icon423281343">\
         <div class="stencil-wrapper" style="width: 48px; height: 48px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" style="width:48px;height:48px;" title="">\
               <svg xmlns="http://www.w3.org/2000/svg" width="48" height="48" class="fill-blue">\
                  <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#icon-glyph-e028"></use>\
               </svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page735926670-layer-2017814572" style="position: absolute; left: 1055px; top: 80px; width: 48px; height: 48px" data-interactive-element-type="fonticon.icon" class="icon stencil mobile-interaction-potential-trigger " data-stencil-id="2017814572" data-review-reference-id="2017814572">\
         <div class="stencil-wrapper" style="width: 48px; height: 48px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" style="width:48px;height:48px;" title="">\
               <svg xmlns="http://www.w3.org/2000/svg" width="48" height="48" class="fill-blue">\
                  <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#icon-android-e091"></use>\
               </svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page735926670-layer-text922663467" style="position: absolute; left: 1120px; top: 85px; width: 183px; height: 37px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text922663467" data-review-reference-id="text922663467">\
         <div class="stencil-wrapper" style="width: 183px; height: 37px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline12"><p><span style="font-size: 32px; color: white;">0169321456</span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page735926670-layer-1381528993" style="position: absolute; left: 455px; top: 905px; width: 285px; height: 37px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="1381528993" data-review-reference-id="1381528993">\
         <div class="stencil-wrapper" style="width: 285px; height: 37px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline12"><p><span style="font-size: 32px; color: white;">Hướng dẫn đặt bàn</span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page735926670-layer-image585050781" style="position: absolute; left: 0px; top: 870px; width: 1366px; height: 450px" data-interactive-element-type="default.image" class="image stencil mobile-interaction-potential-trigger " data-stencil-id="image585050781" data-review-reference-id="image585050781">\
         <div class="stencil-wrapper" style="width: 1366px; height: 450px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" title="">\
               <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" class="image-cropper" style="height: 450px;width:1366px;" width="1366" height="450" viewBox="0 0 1366 450">\
                  <svg:g width="1366" height="450">\
                     <svg:svg x="0" y="0" width="1366" height="450">\
                        <svg:image width="432" height="253" xlink:href="../repoimages/506340.PNG" preserveAspectRatio="none" transform="scale(3.162037037037037,1.7786561264822134) translate(-0,-0)  "></svg:image>\
                     </svg:svg>\
                  </svg:g>\
               </svg:svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page735926670-layer-icon25482507" style="position: absolute; left: 425px; top: 885px; width: 48px; height: 48px" data-interactive-element-type="fonticon.icon" class="icon stencil mobile-interaction-potential-trigger " data-stencil-id="icon25482507" data-review-reference-id="icon25482507">\
         <div class="stencil-wrapper" style="width: 48px; height: 48px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" style="width:48px;height:48px;" title="">\
               <svg xmlns="http://www.w3.org/2000/svg" width="48" height="48" class="fill-green">\
                  <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#icon-glyph-e196"></use>\
               </svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page735926670-layer-text777883387" style="position: absolute; left: 480px; top: 900px; width: 365px; height: 23px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text777883387" data-review-reference-id="text777883387">\
         <div class="stencil-wrapper" style="width: 365px; height: 23px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline22"><p><span style="font-size: 20px;">HƯỚNG DẪN ĐẶT BÀN NHẬN ƯU ĐÃI</span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page735926670-layer-653023696" style="position: absolute; left: 140px; top: 935px; width: 95px; height: 95px" data-interactive-element-type="fonticon.icon" class="icon stencil mobile-interaction-potential-trigger " data-stencil-id="653023696" data-review-reference-id="653023696">\
         <div class="stencil-wrapper" style="width: 95px; height: 95px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" style="width:95px;height:95px;" title="">\
               <svg xmlns="http://www.w3.org/2000/svg" width="95" height="95" class="fill-blue">\
                  <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#icon-glyph-e021"></use>\
               </svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page735926670-layer-1445656429" style="position: absolute; left: 265px; top: 960px; width: 48px; height: 48px" data-interactive-element-type="fonticon.icon" class="icon stencil mobile-interaction-potential-trigger " data-stencil-id="1445656429" data-review-reference-id="1445656429">\
         <div class="stencil-wrapper" style="width: 48px; height: 48px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" style="width:48px;height:48px;" title="">\
               <svg xmlns="http://www.w3.org/2000/svg" width="48" height="48" class="fill-black">\
                  <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#icon-glyph-e218"></use>\
               </svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page735926670-layer-220731268" style="position: absolute; left: 360px; top: 935px; width: 95px; height: 95px" data-interactive-element-type="fonticon.icon" class="icon stencil mobile-interaction-potential-trigger " data-stencil-id="220731268" data-review-reference-id="220731268">\
         <div class="stencil-wrapper" style="width: 95px; height: 95px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" style="width:95px;height:95px;" title="">\
               <svg xmlns="http://www.w3.org/2000/svg" width="95" height="95" class="fill-blue">\
                  <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#icon-android-e090"></use>\
               </svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page735926670-layer-1261497061" style="position: absolute; left: 350px; top: 1035px; width: 129px; height: 56px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="1261497061" data-review-reference-id="1261497061">\
         <div class="stencil-wrapper" style="width: 129px; height: 56px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline22"><p><span style="font-size: 24px;">Gọi đặt chỗ<br /><br /></span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page735926670-layer-740653891" style="position: absolute; left: 740px; top: 960px; width: 48px; height: 48px" data-interactive-element-type="fonticon.icon" class="icon stencil mobile-interaction-potential-trigger " data-stencil-id="740653891" data-review-reference-id="740653891">\
         <div class="stencil-wrapper" style="width: 48px; height: 48px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" style="width:48px;height:48px;" title="">\
               <svg xmlns="http://www.w3.org/2000/svg" width="48" height="48" class="fill-black">\
                  <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#icon-glyph-e218"></use>\
               </svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page735926670-layer-844100078" style="position: absolute; left: 495px; top: 970px; width: 77px; height: 28px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="844100078" data-review-reference-id="844100078">\
         <div class="stencil-wrapper" style="width: 77px; height: 28px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline22"><span class="bold" style="font-size: 24px;">HOẶC</span></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page735926670-layer-1946624304" style="position: absolute; left: 605px; top: 935px; width: 95px; height: 95px" data-interactive-element-type="fonticon.icon" class="icon stencil mobile-interaction-potential-trigger " data-stencil-id="1946624304" data-review-reference-id="1946624304">\
         <div class="stencil-wrapper" style="width: 95px; height: 95px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" style="width:95px;height:95px;" title="">\
               <svg xmlns="http://www.w3.org/2000/svg" width="95" height="95" class="fill-blue">\
                  <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#icon-glyph-e074"></use>\
               </svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page735926670-layer-927178842" style="position: absolute; left: 580px; top: 1035px; width: 173px; height: 28px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="927178842" data-review-reference-id="927178842">\
         <div class="stencil-wrapper" style="width: 173px; height: 28px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline22"><p class="none" style="font-size: 24px;">Đặt bàn Online </p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page735926670-layer-1409345585" style="position: absolute; left: 845px; top: 1035px; width: 107px; height: 28px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="1409345585" data-review-reference-id="1409345585">\
         <div class="stencil-wrapper" style="width: 107px; height: 28px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline22"><p class="none" style="font-size: 24px;">Xác nhận</p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page735926670-layer-1007868033" style="position: absolute; left: 965px; top: 960px; width: 48px; height: 48px" data-interactive-element-type="fonticon.icon" class="icon stencil mobile-interaction-potential-trigger " data-stencil-id="1007868033" data-review-reference-id="1007868033">\
         <div class="stencil-wrapper" style="width: 48px; height: 48px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" style="width:48px;height:48px;" title="">\
               <svg xmlns="http://www.w3.org/2000/svg" width="48" height="48" class="fill-black">\
                  <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#icon-glyph-e218"></use>\
               </svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page735926670-layer-173847591" style="position: absolute; left: 850px; top: 935px; width: 95px; height: 95px" data-interactive-element-type="fonticon.icon" class="icon stencil mobile-interaction-potential-trigger " data-stencil-id="173847591" data-review-reference-id="173847591">\
         <div class="stencil-wrapper" style="width: 95px; height: 95px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" style="width:95px;height:95px;" title="">\
               <svg xmlns="http://www.w3.org/2000/svg" width="95" height="95" class="fill-blue">\
                  <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#icon-glyph-e078"></use>\
               </svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page735926670-layer-414030016" style="position: absolute; left: 1080px; top: 935px; width: 95px; height: 95px" data-interactive-element-type="fonticon.icon" class="icon stencil mobile-interaction-potential-trigger " data-stencil-id="414030016" data-review-reference-id="414030016">\
         <div class="stencil-wrapper" style="width: 95px; height: 95px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" style="width:95px;height:95px;" title="">\
               <svg xmlns="http://www.w3.org/2000/svg" width="95" height="95" class="fill-blue">\
                  <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#icon-glyph-e344"></use>\
               </svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page735926670-layer-1240214398" style="position: absolute; left: 1070px; top: 1035px; width: 147px; height: 28px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="1240214398" data-review-reference-id="1240214398">\
         <div class="stencil-wrapper" style="width: 147px; height: 28px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline22"><p class="none" style="font-size: 24px;">Thưởng thức</p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page735926670-layer-1029912587" style="position: absolute; left: 150px; top: 1070px; width: 117px; height: 23px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="1029912587" data-review-reference-id="1029912587">\
         <div class="stencil-wrapper" style="width: 117px; height: 23px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline22"><p><span style="font-size: 20px; color: #658cd9;">Nhiều ưu đãi</span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page735926670-layer-1289859578" style="position: absolute; left: 355px; top: 1070px; width: 113px; height: 23px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="1289859578" data-review-reference-id="1289859578">\
         <div class="stencil-wrapper" style="width: 113px; height: 23px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline22"><p><span style="font-size: 20px; color: #658cd9;">0169321456</span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page735926670-layer-217928491" style="position: absolute; left: 565px; top: 1070px; width: 201px; height: 23px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="217928491" data-review-reference-id="217928491">\
         <div class="stencil-wrapper" style="width: 201px; height: 23px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline22"><p><span style="font-size: 20px; color: #658cd9;">Qua app hoặc website</span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page735926670-layer-108155705" style="position: absolute; left: 830px; top: 1070px; width: 158px; height: 23px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="108155705" data-review-reference-id="108155705">\
         <div class="stencil-wrapper" style="width: 158px; height: 23px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline22"><p><span style="font-size: 20px; color: #658cd9;">Qua tổng đài viên</span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page735926670-layer-909419338" style="position: absolute; left: 1065px; top: 1065px; width: 169px; height: 28px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="909419338" data-review-reference-id="909419338">\
         <div class="stencil-wrapper" style="width: 169px; height: 28px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline22"><p class="none" style="font-size: 24px;"><span style="font-size: 20px;"><span style="color: #658cd9;">Đến nhà hàng thôi</span> </span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page735926670-layer-1928496892" style="position: absolute; left: 125px; top: 1040px; width: 170px; height: 28px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="1928496892" data-review-reference-id="1928496892">\
         <div class="stencil-wrapper" style="width: 170px; height: 28px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline22"><p><span style="font-size: 24px;">Chọn nhà hàng</span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page735926670-layer-image692818024" style="position: absolute; left: 0px; top: 1095px; width: 1366px; height: 225px" data-interactive-element-type="default.image" class="image stencil mobile-interaction-potential-trigger " data-stencil-id="image692818024" data-review-reference-id="image692818024">\
         <div class="stencil-wrapper" style="width: 1366px; height: 225px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" title="">\
               <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" class="image-cropper" style="height: 225px;width:1366px;" width="1366" height="225" viewBox="0 0 1366 225">\
                  <svg:g width="1366" height="225">\
                     <svg:svg x="0" y="0" width="1366" height="225">\
                        <svg:image width="432" height="253" xlink:href="../repoimages/506342.PNG" preserveAspectRatio="none" transform="scale(3.162037037037037,0.8893280632411067) translate(-0,-0)  "></svg:image>\
                     </svg:svg>\
                  </svg:g>\
               </svg:svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page735926670-layer-image65779106" style="position: absolute; left: 50px; top: 1105px; width: 115px; height: 50px" data-interactive-element-type="default.image" class="image stencil mobile-interaction-potential-trigger " data-stencil-id="image65779106" data-review-reference-id="image65779106">\
         <div class="stencil-wrapper" style="width: 115px; height: 50px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" title="">\
               <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" class="image-cropper" style="height: 50px;width:115px;" width="115" height="50" viewBox="0 0 115 50">\
                  <svg:g width="115" height="50">\
                     <svg:svg x="0" y="0" width="115" height="50">\
                        <svg:image width="287" height="276" xlink:href="../repoimages/506334.png" preserveAspectRatio="none" transform="scale(0.40069686411149824,0.18115942028985507) translate(-0,-0)  "></svg:image>\
                     </svg:svg>\
                  </svg:g>\
               </svg:svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page735926670-layer-text232541355" style="position: absolute; left: 50px; top: 1165px; width: 270px; height: 65px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text232541355" data-review-reference-id="text232541355">\
         <div class="stencil-wrapper" style="width: 270px; height: 65px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline32"><p><span style="color: #658cd9;">Giải pháp giúp người dùng tìm kiếm Điểm đến gần nhất và đặt chỗ trực tuyến một cách nhanh\
                     chóng, tiện lợi.</span><br /><br /></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page735926670-layer-text857925194" style="position: absolute; left: 405px; top: 1105px; width: 111px; height: 20px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text857925194" data-review-reference-id="text857925194">\
         <div class="stencil-wrapper" style="width: 111px; height: 20px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.link2"><p style="font-size: 14px;"><span class="underline" style="font-size: 18px; color: #658cd9;">Về chúng tôi</span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page735926670-layer-2144072547" style="position: absolute; left: 405px; top: 1240px; width: 69px; height: 20px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="2144072547" data-review-reference-id="2144072547">\
         <div class="stencil-wrapper" style="width: 69px; height: 20px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.link2"><p class="underline" style="font-size: 14px;"><span style="color: #658cd9; font-size: 18px;">Đối tác</span></p>\
                     <p class="underline" style="font-size: 14px;"> </p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page735926670-layer-484876472" style="position: absolute; left: 405px; top: 1205px; width: 154px; height: 20px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="484876472" data-review-reference-id="484876472">\
         <div class="stencil-wrapper" style="width: 154px; height: 20px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.link2"><p style="font-size: 14px;"><span class="underline" style="font-size: 18px; color: #ffffcc;"><span style="color: #658cd9;">Cơ\
                     chế giải quyết</span><br /></span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page735926670-layer-828291916" style="position: absolute; left: 405px; top: 1170px; width: 175px; height: 20px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="828291916" data-review-reference-id="828291916">\
         <div class="stencil-wrapper" style="width: 175px; height: 20px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.link2"><p style="font-size: 14px;"><span class="underline" style="font-size: 18px; color: #658cd9;">Chính sách bảo mât</span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page735926670-layer-2022753913" style="position: absolute; left: 405px; top: 1135px; width: 167px; height: 20px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="2022753913" data-review-reference-id="2022753913">\
         <div class="stencil-wrapper" style="width: 167px; height: 20px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.link2"><p style="font-size: 14px;"><span class="underline" style="font-size: 18px; color: #658cd9;">Quy chế hoạt động</span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page735926670-layer-1391060915" style="position: absolute; left: 815px; top: 1105px; width: 43px; height: 20px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="1391060915" data-review-reference-id="1391060915">\
         <div class="stencil-wrapper" style="width: 43px; height: 20px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.link2"><p style="font-size: 14px;"><span class="underline" style="font-size: 18px; color: #658cd9;">Blog</span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page735926670-layer-805627153" style="position: absolute; left: 675px; top: 1105px; width: 63px; height: 20px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="805627153" data-review-reference-id="805627153">\
         <div class="stencil-wrapper" style="width: 63px; height: 20px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.link2"><p style="font-size: 14px;"><span class="underline" style="font-size: 18px; color: #658cd9;">Tin tức</span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page735926670-layer-1150200441" style="position: absolute; left: 675px; top: 1135px; width: 97px; height: 20px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="1150200441" data-review-reference-id="1150200441">\
         <div class="stencil-wrapper" style="width: 97px; height: 20px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.link2"><p style="font-size: 14px;"><span class="underline" style="font-size: 18px; color: #658cd9;">Thẻ ưu đãi</span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page735926670-layer-1179732517" style="position: absolute; left: 675px; top: 1165px; width: 109px; height: 20px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="1179732517" data-review-reference-id="1179732517">\
         <div class="stencil-wrapper" style="width: 109px; height: 20px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.link2"><p style="font-size: 14px;"><span class="underline" style="font-size: 18px; color: #ffffcc;"><span style="color: #658cd9;">Mạng\
                     xã hội</span><br /></span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page735926670-layer-icon640553417" style="position: absolute; left: 820px; top: 1205px; width: 48px; height: 48px" data-interactive-element-type="fonticon.icon" class="icon stencil mobile-interaction-potential-trigger " data-stencil-id="icon640553417" data-review-reference-id="icon640553417">\
         <div class="stencil-wrapper" style="width: 48px; height: 48px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" style="width:48px;height:48px;" title="">\
               <svg xmlns="http://www.w3.org/2000/svg" width="48" height="48" class="fill-red">\
                  <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#icon-glyph-e383"></use>\
               </svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page735926670-layer-638354470" style="position: absolute; left: 750px; top: 1205px; width: 48px; height: 48px" data-interactive-element-type="fonticon.icon" class="icon stencil mobile-interaction-potential-trigger " data-stencil-id="638354470" data-review-reference-id="638354470">\
         <div class="stencil-wrapper" style="width: 48px; height: 48px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" style="width:48px;height:48px;" title="">\
               <svg xmlns="http://www.w3.org/2000/svg" width="48" height="48" class="fill-blue">\
                  <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#icon-glyph-e411"></use>\
               </svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page735926670-layer-797206375" style="position: absolute; left: 675px; top: 1205px; width: 48px; height: 48px" data-interactive-element-type="fonticon.icon" class="icon stencil mobile-interaction-potential-trigger " data-stencil-id="797206375" data-review-reference-id="797206375">\
         <div class="stencil-wrapper" style="width: 48px; height: 48px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" style="width:48px;height:48px;" title="">\
               <svg xmlns="http://www.w3.org/2000/svg" width="48" height="48" class="fill-orange">\
                  <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#icon-glyph-e418"></use>\
               </svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page735926670-layer-text923089768" style="position: absolute; left: 940px; top: 1130px; width: 39px; height: 87px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text923089768" data-review-reference-id="text923089768">\
         <div class="stencil-wrapper" style="width: 39px; height: 87px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline12"><p class="none" style="font-size: 32px;"><span style="color: #d9d9d9; font-size: 18px;">Địa điểm nổi bật  </span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page735926670-layer-arrow768490168" style="position: absolute; left: 890px; top: 1105px; width: 33px; height: 165px" data-interactive-element-type="static.line" class="line stencil mobile-interaction-potential-trigger " data-stencil-id="arrow768490168" data-review-reference-id="arrow768490168">\
         <div class="stencil-wrapper" style="width: 33px; height: 165px">\
            <div title="">\
               <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" style="position: absolute; left: -5px; top: -5px; height: 175px;width:43px;" viewBox="-5 -5 43 175" width="43" height="175">\
                  <svg:path d="M 16.5,0 L 16.5,165" marker-start="" marker-end="" style="fill:none; stroke-width:2px;stroke:black;"></svg:path>\
               </svg:svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page735926670-layer-1410987044" style="position: absolute; left: 350px; top: 1100px; width: 33px; height: 165px" data-interactive-element-type="static.line" class="line stencil mobile-interaction-potential-trigger " data-stencil-id="1410987044" data-review-reference-id="1410987044">\
         <div class="stencil-wrapper" style="width: 33px; height: 165px">\
            <div title="">\
               <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" style="position: absolute; left: -5px; top: -5px; height: 175px;width:43px;" viewBox="-5 -5 43 175" width="43" height="175">\
                  <svg:path d="M 16.5,0 L 16.5,165" marker-start="" marker-end="" style="fill:none; stroke-width:2px;stroke:black;"></svg:path>\
               </svg:svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page735926670-layer-image434272841" style="position: absolute; left: 1005px; top: 1110px; width: 70px; height: 70px" data-interactive-element-type="default.image" class="image stencil mobile-interaction-potential-trigger " data-stencil-id="image434272841" data-review-reference-id="image434272841">\
         <div class="stencil-wrapper" style="width: 70px; height: 70px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" title="">\
               <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" class="image-cropper" style="height: 70px;width:70px;" width="70" height="70" viewBox="0 0 70 70">\
                  <svg:g width="70" height="70">\
                     <svg:svg x="0" y="0" width="70" height="70">\
                        <svg:image width="80" height="60" xlink:href="../repoimages/506343.JPG" preserveAspectRatio="none" transform="scale(0.875,1.1666666666666667) translate(-0,-0)  "></svg:image>\
                     </svg:svg>\
                  </svg:g>\
               </svg:svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page735926670-layer-1080545475" style="position: absolute; left: 1085px; top: 1110px; width: 70px; height: 70px" data-interactive-element-type="default.image" class="image stencil mobile-interaction-potential-trigger " data-stencil-id="1080545475" data-review-reference-id="1080545475">\
         <div class="stencil-wrapper" style="width: 70px; height: 70px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" title="">\
               <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" class="image-cropper" style="height: 70px;width:70px;" width="70" height="70" viewBox="0 0 70 70">\
                  <svg:g width="70" height="70">\
                     <svg:svg x="0" y="0" width="70" height="70">\
                        <svg:image width="80" height="60" xlink:href="../repoimages/506343.JPG" preserveAspectRatio="none" transform="scale(0.875,1.1666666666666667) translate(-0,-0)  "></svg:image>\
                     </svg:svg>\
                  </svg:g>\
               </svg:svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page735926670-layer-1826970549" style="position: absolute; left: 1005px; top: 1190px; width: 70px; height: 70px" data-interactive-element-type="default.image" class="image stencil mobile-interaction-potential-trigger " data-stencil-id="1826970549" data-review-reference-id="1826970549">\
         <div class="stencil-wrapper" style="width: 70px; height: 70px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" title="">\
               <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" class="image-cropper" style="height: 70px;width:70px;" width="70" height="70" viewBox="0 0 70 70">\
                  <svg:g width="70" height="70">\
                     <svg:svg x="0" y="0" width="70" height="70">\
                        <svg:image width="80" height="60" xlink:href="../repoimages/506343.JPG" preserveAspectRatio="none" transform="scale(0.875,1.1666666666666667) translate(-0,-0)  "></svg:image>\
                     </svg:svg>\
                  </svg:g>\
               </svg:svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page735926670-layer-1650460350" style="position: absolute; left: 1085px; top: 1190px; width: 70px; height: 70px" data-interactive-element-type="default.image" class="image stencil mobile-interaction-potential-trigger " data-stencil-id="1650460350" data-review-reference-id="1650460350">\
         <div class="stencil-wrapper" style="width: 70px; height: 70px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" title="">\
               <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" class="image-cropper" style="height: 70px;width:70px;" width="70" height="70" viewBox="0 0 70 70">\
                  <svg:g width="70" height="70">\
                     <svg:svg x="0" y="0" width="70" height="70">\
                        <svg:image width="80" height="60" xlink:href="../repoimages/506343.JPG" preserveAspectRatio="none" transform="scale(0.875,1.1666666666666667) translate(-0,-0)  "></svg:image>\
                     </svg:svg>\
                  </svg:g>\
               </svg:svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page735926670-layer-1779754897" style="position: absolute; left: 1165px; top: 1110px; width: 70px; height: 70px" data-interactive-element-type="default.image" class="image stencil mobile-interaction-potential-trigger " data-stencil-id="1779754897" data-review-reference-id="1779754897">\
         <div class="stencil-wrapper" style="width: 70px; height: 70px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" title="">\
               <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" class="image-cropper" style="height: 70px;width:70px;" width="70" height="70" viewBox="0 0 70 70">\
                  <svg:g width="70" height="70">\
                     <svg:svg x="0" y="0" width="70" height="70">\
                        <svg:image width="80" height="60" xlink:href="../repoimages/506343.JPG" preserveAspectRatio="none" transform="scale(0.875,1.1666666666666667) translate(-0,-0)  "></svg:image>\
                     </svg:svg>\
                  </svg:g>\
               </svg:svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page735926670-layer-1326299265" style="position: absolute; left: 1165px; top: 1190px; width: 70px; height: 70px" data-interactive-element-type="default.image" class="image stencil mobile-interaction-potential-trigger " data-stencil-id="1326299265" data-review-reference-id="1326299265">\
         <div class="stencil-wrapper" style="width: 70px; height: 70px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" title="">\
               <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" class="image-cropper" style="height: 70px;width:70px;" width="70" height="70" viewBox="0 0 70 70">\
                  <svg:g width="70" height="70">\
                     <svg:svg x="0" y="0" width="70" height="70">\
                        <svg:image width="80" height="60" xlink:href="../repoimages/506343.JPG" preserveAspectRatio="none" transform="scale(0.875,1.1666666666666667) translate(-0,-0)  "></svg:image>\
                     </svg:svg>\
                  </svg:g>\
               </svg:svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page735926670-layer-image266654245" style="position: absolute; left: 360px; top: 1280px; width: 1000px; height: 40px" data-interactive-element-type="default.image" class="image stencil mobile-interaction-potential-trigger " data-stencil-id="image266654245" data-review-reference-id="image266654245">\
         <div class="stencil-wrapper" style="width: 1000px; height: 40px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" title="">\
               <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" class="image-cropper" style="height: 40px;width:1000px;" width="1000" height="40" viewBox="0 0 1000 40">\
                  <svg:g width="1000" height="40">\
                     <svg:svg x="0" y="0" width="1000" height="40">\
                        <svg:image width="80" height="60" xlink:href="../repoimages/506344.PNG" preserveAspectRatio="none" transform="scale(12.5,0.6666666666666666) translate(-0,-0)  "></svg:image>\
                     </svg:svg>\
                  </svg:g>\
               </svg:svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page735926670-layer-text266830145" style="position: absolute; left: 70px; top: 1275px; width: 169px; height: 18px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text266830145" data-review-reference-id="text266830145">\
         <div class="stencil-wrapper" style="width: 169px; height: 18px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.link2"><p class="underline" style="font-size: 14px;"><span style="color: #ffffcc; font-size: 16px;">Bản quyền thuộc về ... </span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page735926670-layer-text134826375" style="position: absolute; left: 495px; top: 160px; width: 222px; height: 37px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text134826375" data-review-reference-id="text134826375">\
         <div class="stencil-wrapper" style="width: 222px; height: 37px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline12"><p><span style="font-size: 32px;">Content Holder</span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page735926670-layer-image487827429" style="position: absolute; left: 5px; top: 580px; width: 1361px; height: 287px" data-interactive-element-type="default.image" class="image stencil mobile-interaction-potential-trigger " data-stencil-id="image487827429" data-review-reference-id="image487827429">\
         <div class="stencil-wrapper" style="width: 1361px; height: 287px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" title="">\
               <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" class="image-cropper" style="height: 287px;width:1361px;" width="1361" height="287" viewBox="0 0 1361 287">\
                  <svg:g width="1361" height="287">\
                     <svg:svg x="0" y="0" width="1361" height="287">\
                        <svg:image width="1350" height="287" xlink:href="../repoimages/508373.PNG" preserveAspectRatio="none" transform="scale(1.0081481481481482,1) translate(-0,-0)  "></svg:image>\
                     </svg:svg>\
                  </svg:g>\
               </svg:svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page735926670-layer-image813988845" style="position: absolute; left: 0px; top: 260px; width: 1366px; height: 320px" data-interactive-element-type="default.image" class="image stencil mobile-interaction-potential-trigger " data-stencil-id="image813988845" data-review-reference-id="image813988845">\
         <div class="stencil-wrapper" style="width: 1366px; height: 320px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" title="">\
               <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" class="image-cropper" style="height: 320px;width:1366px;" width="1366" height="320" viewBox="0 0 1366 320">\
                  <svg:g width="1366" height="320">\
                     <svg:svg x="0" y="0" width="1366" height="320">\
                        <svg:image width="1336" height="320" xlink:href="../repoimages/508374.PNG" preserveAspectRatio="none" transform="scale(1.0224550898203593,1) translate(-0,-0)  "></svg:image>\
                     </svg:svg>\
                  </svg:g>\
               </svg:svg>\
            </div>\
         </div>\
      </div>\
   </div>\
</div>');