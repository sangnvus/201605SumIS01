rabbit.data.layerStore.addLayerFromHtml('<div xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:fn="http://www.w3.org/2005/xpath-functions" id="result">\
   <div xmlns:xs="http://www.w3.org/2001/XMLSchema" xmlns="http://www.w3.org/1999/xhtml" id="__containerId__page735926670-layer" class="layer" name="__containerId__pageLayer" data-layer-id="page735926670" data-layer-type="pageLayer" style="position:absolute;left:0px;top:0px;">\
      <div id="__containerId__-page735926670-layer-image973037928" style="position: absolute; left: 0px; top: 0px; width: 1366px; height: 60px" data-interactive-element-type="default.image" class="image stencil mobile-interaction-potential-trigger " data-stencil-id="image973037928" data-review-reference-id="image973037928">\
         <div class="stencil-wrapper" style="width: 1366px; height: 60px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" title="">\
               <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" class="image-cropper" style="height: 60px;width:1366px;" width="1366" height="60">\
                  <svg:g width="1366" height="60">\
                     <svg:svg x="1" y="1" width="1364" height="58">\
                        <svg:image width="70" height="21" xlink:href="../repoimages/508386.PNG" preserveAspectRatio="none" transform="scale(19.514285714285716,2.857142857142857) translate(-0,-0)  "></svg:image>\
                     </svg:svg>\
                  </svg:g>\
               </svg:svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page735926670-layer-image564669680" style="position: absolute; left: 0px; top: 40px; width: 1366px; height: 50px" data-interactive-element-type="default.image" class="image stencil mobile-interaction-potential-trigger " data-stencil-id="image564669680" data-review-reference-id="image564669680">\
         <div class="stencil-wrapper" style="width: 1366px; height: 50px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" title="">\
               <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" class="image-cropper" style="height: 50px;width:1366px;" width="1366" height="50">\
                  <svg:g width="1366" height="50">\
                     <svg:svg x="1" y="1" width="1364" height="48">\
                        <svg:image width="70" height="21" xlink:href="../repoimages/508386.PNG" preserveAspectRatio="none" transform="scale(19.514285714285716,2.380952380952381) translate(-0,-0)  "></svg:image>\
                     </svg:svg>\
                  </svg:g>\
               </svg:svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page735926670-layer-image497667861" style="position: absolute; left: 0px; top: 80px; width: 1366px; height: 1300px" data-interactive-element-type="default.image" class="image stencil mobile-interaction-potential-trigger " data-stencil-id="image497667861" data-review-reference-id="image497667861">\
         <div class="stencil-wrapper" style="width: 1366px; height: 1300px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" title="">\
               <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" class="image-cropper" style="height: 1300px;width:1366px;" width="1366" height="1300">\
                  <svg:g width="1366" height="1300">\
                     <svg:svg x="1" y="1" width="1364" height="1298">\
                        <svg:image width="80" height="60" xlink:href="../repoimages/506332.PNG" preserveAspectRatio="none" transform="scale(17.075,21.666666666666668) translate(-0,-0)  "></svg:image>\
                     </svg:svg>\
                  </svg:g>\
               </svg:svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page735926670-layer-image330320926" style="position: absolute; left: 0px; top: 120px; width: 1366px; height: 1300px" data-interactive-element-type="default.image" class="image stencil mobile-interaction-potential-trigger " data-stencil-id="image330320926" data-review-reference-id="image330320926">\
         <div class="stencil-wrapper" style="width: 1366px; height: 1300px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" title="">\
               <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" class="image-cropper" style="height: 1300px;width:1366px;" width="1366" height="1300">\
                  <svg:g width="1366" height="1300">\
                     <svg:svg x="1" y="1" width="1364" height="1298">\
                        <svg:image width="80" height="60" xlink:href="../repoimages/506332.PNG" preserveAspectRatio="none" transform="scale(17.075,21.666666666666668) translate(-0,-0)  "></svg:image>\
                     </svg:svg>\
                  </svg:g>\
               </svg:svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page735926670-layer-image950603217" style="position: absolute; left: 0px; top: 0px; width: 120px; height: 55px" data-interactive-element-type="default.image" class="image stencil mobile-interaction-potential-trigger " data-stencil-id="image950603217" data-review-reference-id="image950603217">\
         <div class="stencil-wrapper" style="width: 120px; height: 55px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" title="">\
               <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" class="image-cropper" style="height: 55px;width:120px;" width="120" height="55">\
                  <svg:g width="120" height="55">\
                     <svg:svg x="1" y="1" width="118" height="53">\
                        <svg:image width="80" height="60" xlink:href="../repoimages/506334.png" preserveAspectRatio="none" transform="scale(1.5,0.9166666666666666) translate(-0,-0)  "></svg:image>\
                     </svg:svg>\
                  </svg:g>\
               </svg:svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page735926670-layer-text445899147" style="position: absolute; left: 140px; top: 5px; width: 103px; height: 28px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text445899147" data-review-reference-id="text445899147">\
         <div class="stencil-wrapper" style="width: 103px; height: 28px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline22"><p class="none" style="font-size: 24px;"><span style="color: white;">Ẩm thực </span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page735926670-layer-1313036361" style="position: absolute; left: 270px; top: 5px; width: 122px; height: 28px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="1313036361" data-review-reference-id="1313036361">\
         <div class="stencil-wrapper" style="width: 122px; height: 28px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline22"><p class="none" style="font-size: 24px;"><span style="color: white;">Thẻ ưu đãi</span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page735926670-layer-1018362389" style="position: absolute; left: 430px; top: 5px; width: 79px; height: 28px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="1018362389" data-review-reference-id="1018362389">\
         <div class="stencil-wrapper" style="width: 79px; height: 28px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline22"><p class="none" style="font-size: 24px;"><span style="color: white;">Tin tức</span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page735926670-layer-871043117" style="position: absolute; left: 570px; top: 5px; width: 54px; height: 28px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="871043117" data-review-reference-id="871043117">\
         <div class="stencil-wrapper" style="width: 54px; height: 28px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline22"><p class="none" style="font-size: 24px;"><span style="color: white;">Blog</span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page735926670-layer-44672541" style="position: absolute; left: 855px; top: 5px; width: 110px; height: 28px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="44672541" data-review-reference-id="44672541">\
         <div class="stencil-wrapper" style="width: 110px; height: 28px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline22"><p class="none" style="font-size: 24px;"><span style="color: white;">Giới thiệu</span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page735926670-layer-867557644" style="position: absolute; left: 680px; top: 5px; width: 129px; height: 28px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="867557644" data-review-reference-id="867557644">\
         <div class="stencil-wrapper" style="width: 129px; height: 28px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline22"><p class="none" style="font-size: 24px;"><span style="color: white;">Hướng dẫn</span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page735926670-layer-1827375608" style="position: absolute; left: 1005px; top: 5px; width: 113px; height: 28px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="1827375608" data-review-reference-id="1827375608">\
         <div class="stencil-wrapper" style="width: 113px; height: 28px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline22"><p class="none" style="font-size: 24px;"><span style="color: white;">Ngôn ngữ</span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page735926670-layer-icon264923266" style="position: absolute; left: 1325px; top: 5px; width: 32px; height: 32px" data-interactive-element-type="fonticon.icon" class="icon stencil mobile-interaction-potential-trigger " data-stencil-id="icon264923266" data-review-reference-id="icon264923266">\
         <div class="stencil-wrapper" style="width: 32px; height: 32px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" style="width:32px;height:32px;" title="">\
               <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" class="fill-white">\
                  <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#icon-glyph-e004"></use>\
               </svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page735926670-layer-456376681" style="position: absolute; left: 1190px; top: 5px; width: 128px; height: 28px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="456376681" data-review-reference-id="456376681">\
         <div class="stencil-wrapper" style="width: 128px; height: 28px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline22"><p class="none" style="font-size: 24px;"><span style="color: white;">Người dùng</span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page735926670-layer-image473404083" style="position: absolute; left: 0px; top: 55px; width: 1366px; height: 85px" data-interactive-element-type="default.image" class="image stencil mobile-interaction-potential-trigger " data-stencil-id="image473404083" data-review-reference-id="image473404083">\
         <div class="stencil-wrapper" style="width: 1366px; height: 85px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" title="">\
               <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" class="image-cropper" style="height: 85px;width:1366px;" width="1366" height="85">\
                  <svg:g width="1366" height="85">\
                     <svg:svg x="1" y="1" width="1364" height="83">\
                        <svg:image width="432" height="253" xlink:href="../repoimages/506338.PNG" preserveAspectRatio="none" transform="scale(3.162037037037037,0.3359683794466403) translate(-0,-0)  "></svg:image>\
                     </svg:svg>\
                  </svg:g>\
               </svg:svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page735926670-layer-combobox90962004" style="position: absolute; left: 45px; top: 80px; width: 180px; height: 45px" data-interactive-element-type="default.combobox" class="combobox stencil mobile-interaction-potential-trigger " data-stencil-id="combobox90962004" data-review-reference-id="combobox90962004">\
         <div class="stencil-wrapper" style="width: 180px; height: 45px">\
            <div style="position:absolute;left:2px;top:0px;">\
               <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" style="position: absolute; height: 45px;width:180px;" width="180" height="45">\
                  <svg:g id="__containerId__-page735926670-layer-combobox90962004" width="180" height="45"><svg:path id="__containerId__-page735926670-layer-combobox90962004_input_svg_border" d="M 2.00, 2.00 Q 13.00, 1.50, 24.00,\
                     1.34 Q 35.00, 1.49, 46.00, 1.18 Q 57.00, 1.36, 68.00, 1.53 Q 79.00, 1.61, 90.00, 1.83 Q 101.00, 1.37, 112.00, 1.30 Q 123.00,\
                     1.62, 134.00, 1.45 Q 145.00, 2.34, 156.00, 1.66 Q 167.00, 2.13, 177.79, 2.21 Q 178.26, 12.16, 178.31, 22.46 Q 177.92, 32.76,\
                     178.04, 43.04 Q 166.99, 42.96, 156.01, 43.09 Q 145.02, 43.30, 134.03, 43.85 Q 123.01, 43.54, 112.00, 42.80 Q 101.00, 44.19,\
                     90.00, 43.07 Q 79.00, 41.86, 68.00, 42.34 Q 57.00, 41.51, 46.00, 42.04 Q 35.00, 42.46, 24.00, 43.13 Q 13.00, 43.71, 2.01,\
                     42.99 Q 1.60, 32.88, 2.51, 22.43 Q 2.00, 12.25, 2.00, 2.00" style=" fill:white;" class="svg_unselected_element"/>\
                  </svg:g>\
               </svg:svg>\
               <div title="" style="position:absolute"><select id="__containerId__-page735926670-layer-combobox90962004select" onblur="rabbit.facade.raiseEvent(rabbit.events.svgBlur, \'__containerId__-page735926670-layer-combobox90962004_input_svg_border\')" onfocus="rabbit.facade.raiseEvent(rabbit.events.svgFocus, \'__containerId__-page735926670-layer-combobox90962004_input_svg_border\')" style="width:176px; height:41px;" title="">\
                     <option title="">Hà Nội</option>\
                     <option title="">HCM </option>\
                     <option title="">Đà Nẵng</option></select></div>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page735926670-layer-icon874521084" style="position: absolute; left: -5px; top: 80px; width: 48px; height: 48px" data-interactive-element-type="fonticon.icon" class="icon stencil mobile-interaction-potential-trigger " data-stencil-id="icon874521084" data-review-reference-id="icon874521084">\
         <div class="stencil-wrapper" style="width: 48px; height: 48px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" style="width:48px;height:48px;" title="">\
               <svg xmlns="http://www.w3.org/2000/svg" width="48" height="48" class="fill-blue">\
                  <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#icon-glyph-e243"></use>\
               </svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page735926670-layer-textinput817849469" style="position: absolute; left: 250px; top: 80px; width: 780px; height: 45px" data-interactive-element-type="default.textinput" class="textinput stencil mobile-interaction-potential-trigger " data-stencil-id="textinput817849469" data-review-reference-id="textinput817849469">\
         <div class="stencil-wrapper" style="width: 780px; height: 45px">\
            <div>\
               <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" style="height: 45px;width:780px;" width="780" height="45">\
                  <svg:g id="__containerId__-page735926670-layer-textinput817849469svg" width="780" height="45"><svg:path id="__containerId__-page735926670-layer-textinput817849469_input_svg_border" d="M 2.00, 2.00 Q 12.21, -0.67, 22.42,\
                     0.09 Q 32.63, 0.44, 42.84, 0.74 Q 53.05, 0.54, 63.26, 1.00 Q 73.47, 1.28, 83.68, 1.60 Q 93.89, 1.33, 104.11, 0.86 Q 114.32,\
                     0.74, 124.53, 0.72 Q 134.74, 1.25, 144.95, 0.89 Q 155.16, 1.07, 165.37, 0.87 Q 175.58, 1.11, 185.79, 1.08 Q 196.00, 1.00,\
                     206.21, 0.80 Q 216.42, 0.70, 226.63, 0.66 Q 236.84, 1.23, 247.05, 0.55 Q 257.26, 1.23, 267.47, 1.61 Q 277.68, 0.76, 287.89,\
                     0.91 Q 298.11, 1.45, 308.32, 1.85 Q 318.53, 2.11, 328.74, 1.61 Q 338.95, 1.91, 349.16, 1.36 Q 359.37, 1.75, 369.58, 1.29 Q\
                     379.79, 1.60, 390.00, 1.75 Q 400.21, 1.36, 410.42, 1.19 Q 420.63, 0.97, 430.84, 0.97 Q 441.05, 0.94, 451.26, 1.37 Q 461.47,\
                     1.70, 471.68, 1.83 Q 481.90, 1.12, 492.11, 1.01 Q 502.32, 1.41, 512.53, 1.78 Q 522.74, 2.55, 532.95, 2.86 Q 543.16, 2.80,\
                     553.37, 1.80 Q 563.58, 1.83, 573.79, 1.54 Q 584.00, 2.52, 594.21, 1.90 Q 604.42, 1.52, 614.63, 1.88 Q 624.84, 2.84, 635.05,\
                     2.42 Q 645.26, 1.61, 655.47, 1.75 Q 665.68, 1.37, 675.89, 1.56 Q 686.11, 1.21, 696.32, 0.82 Q 706.53, 1.04, 716.74, 1.33 Q\
                     726.95, 2.43, 737.16, 1.58 Q 747.37, 2.70, 757.58, 1.32 Q 767.79, 1.64, 778.28, 1.72 Q 778.90, 11.95, 779.06, 22.35 Q 779.11,\
                     32.68, 778.24, 43.24 Q 767.88, 43.29, 757.66, 43.60 Q 747.41, 43.61, 737.20, 44.37 Q 726.97, 44.55, 716.75, 44.68 Q 706.53,\
                     43.99, 696.32, 43.99 Q 686.11, 42.67, 675.89, 43.12 Q 665.68, 43.32, 655.47, 42.98 Q 645.26, 43.28, 635.05, 44.08 Q 624.84,\
                     44.08, 614.63, 43.97 Q 604.42, 43.88, 594.21, 43.93 Q 584.00, 43.86, 573.79, 44.54 Q 563.58, 43.76, 553.37, 43.83 Q 543.16,\
                     43.45, 532.95, 43.50 Q 522.74, 42.89, 512.53, 42.75 Q 502.32, 42.90, 492.11, 43.07 Q 481.90, 43.33, 471.68, 42.22 Q 461.47,\
                     43.45, 451.26, 44.00 Q 441.05, 43.39, 430.84, 42.78 Q 420.63, 42.50, 410.42, 42.46 Q 400.21, 43.32, 390.00, 42.50 Q 379.79,\
                     42.99, 369.58, 42.97 Q 359.37, 42.14, 349.16, 42.02 Q 338.95, 42.14, 328.74, 42.15 Q 318.53, 42.50, 308.32, 41.98 Q 298.11,\
                     42.77, 287.89, 41.64 Q 277.68, 42.91, 267.47, 42.87 Q 257.26, 43.16, 247.05, 42.84 Q 236.84, 42.94, 226.63, 43.10 Q 216.42,\
                     44.15, 206.21, 44.11 Q 196.00, 43.64, 185.79, 44.12 Q 175.58, 44.13, 165.37, 43.92 Q 155.16, 42.48, 144.95, 42.16 Q 134.74,\
                     43.18, 124.53, 42.57 Q 114.32, 43.45, 104.11, 41.53 Q 93.89, 42.79, 83.68, 43.67 Q 73.47, 43.42, 63.26, 43.05 Q 53.05, 43.52,\
                     42.84, 43.74 Q 32.63, 44.37, 22.42, 44.68 Q 12.21, 44.38, 1.35, 43.65 Q 0.93, 33.11, 0.74, 22.68 Q 2.00, 12.25, 2.00, 2.00"\
                     style=" fill:white;" class="svg_unselected_element"/><svg:path id="__containerId__-page735926670-layer-textinput817849469_line1" d="M 3.00, 3.00 Q 13.18, 2.80, 23.37, 2.70 Q 33.55,\
                     2.61, 43.74, 2.43 Q 53.92, 2.29, 64.11, 2.59 Q 74.29, 2.75, 84.47, 1.95 Q 94.66, 2.61, 104.84, 1.95 Q 115.03, 2.39, 125.21,\
                     2.96 Q 135.39, 2.49, 145.58, 3.19 Q 155.76, 2.01, 165.95, 1.42 Q 176.13, 1.89, 186.32, 2.37 Q 196.50, 2.38, 206.68, 1.71 Q\
                     216.87, 1.74, 227.05, 2.38 Q 237.24, 3.37, 247.42, 3.04 Q 257.61, 2.33, 267.79, 2.71 Q 277.97, 3.26, 288.16, 3.83 Q 298.34,\
                     3.12, 308.53, 2.18 Q 318.71, 2.15, 328.89, 1.76 Q 339.08, 1.86, 349.26, 2.24 Q 359.45, 2.17, 369.63, 2.97 Q 379.82, 3.23,\
                     390.00, 3.08 Q 400.18, 2.45, 410.37, 1.68 Q 420.55, 1.79, 430.74, 2.14 Q 440.92, 1.92, 451.11, 2.66 Q 461.29, 3.32, 471.47,\
                     3.94 Q 481.66, 3.53, 491.84, 3.30 Q 502.03, 2.68, 512.21, 2.32 Q 522.39, 2.79, 532.58, 2.34 Q 542.76, 2.80, 552.95, 3.24 Q\
                     563.13, 3.13, 573.32, 3.35 Q 583.50, 3.30, 593.68, 3.35 Q 603.87, 3.00, 614.05, 2.71 Q 624.24, 2.56, 634.42, 2.63 Q 644.60,\
                     2.61, 654.79, 2.82 Q 664.97, 1.89, 675.16, 2.81 Q 685.34, 2.19, 695.53, 1.77 Q 705.71, 2.94, 715.89, 0.90 Q 726.08, 1.49,\
                     736.26, 1.55 Q 746.45, 1.48, 756.63, 1.33 Q 766.82, 3.00, 777.00, 3.00" style=" fill:none;" class="svg_unselected_element"/><svg:path id="__containerId__-page735926670-layer-textinput817849469_line2" d="M 3.00, 3.00 Q 3.00, 22.50, 3.00, 42.00" style="\
                     fill:none;" class="svg_unselected_element"/><svg:path id="__containerId__-page735926670-layer-textinput817849469_line3" d="M 3.00, 3.00 Q 13.18, 2.66, 23.37, 2.62 Q 33.55,\
                     2.48, 43.74, 2.39 Q 53.92, 2.19, 64.11, 2.78 Q 74.29, 2.80, 84.47, 2.84 Q 94.66, 2.24, 104.84, 2.01 Q 115.03, 2.15, 125.21,\
                     2.83 Q 135.39, 2.18, 145.58, 2.71 Q 155.76, 2.62, 165.95, 3.53 Q 176.13, 2.88, 186.32, 2.22 Q 196.50, 2.37, 206.68, 2.00 Q\
                     216.87, 1.65, 227.05, 2.24 Q 237.24, 3.05, 247.42, 3.65 Q 257.61, 2.95, 267.79, 2.92 Q 277.97, 3.30, 288.16, 3.61 Q 298.34,\
                     2.94, 308.53, 3.13 Q 318.71, 3.09, 328.89, 4.44 Q 339.08, 4.24, 349.26, 4.01 Q 359.45, 3.02, 369.63, 3.14 Q 379.82, 3.06,\
                     390.00, 2.87 Q 400.18, 2.32, 410.37, 2.30 Q 420.55, 2.62, 430.74, 2.22 Q 440.92, 2.56, 451.11, 2.38 Q 461.29, 2.95, 471.47,\
                     1.93 Q 481.66, 1.80, 491.84, 2.44 Q 502.03, 1.89, 512.21, 2.58 Q 522.39, 2.18, 532.58, 2.89 Q 542.76, 2.73, 552.95, 2.68 Q\
                     563.13, 2.78, 573.32, 2.81 Q 583.50, 3.00, 593.68, 2.38 Q 603.87, 2.68, 614.05, 2.56 Q 624.24, 1.68, 634.42, 1.75 Q 644.60,\
                     2.78, 654.79, 3.75 Q 664.97, 3.74, 675.16, 3.84 Q 685.34, 2.28, 695.53, 3.03 Q 705.71, 2.67, 715.89, 2.64 Q 726.08, 2.56,\
                     736.26, 3.35 Q 746.45, 3.03, 756.63, 3.45 Q 766.82, 3.00, 777.00, 3.00" style=" fill:none;" class="svg_unselected_element"/><svg:path id="__containerId__-page735926670-layer-textinput817849469_line4" d="M 3.00, 3.00 Q 3.00, 22.50, 3.00, 42.00" style="\
                     fill:none;" class="svg_unselected_element"/>\
                  </svg:g>\
               </svg:svg>\
               <div style="position:absolute;left: 6px; top: 1px;" title=""><textarea id="__containerId__-page735926670-layer-textinput817849469input" onblur="rabbit.facade.raiseEvent(rabbit.events.svgBlur, new Array(\'__containerId__-page735926670-layer-textinput817849469_input_svg_border\',\'__containerId__-page735926670-layer-textinput817849469_line1\',\'__containerId__-page735926670-layer-textinput817849469_line2\',\'__containerId__-page735926670-layer-textinput817849469_line3\',\'__containerId__-page735926670-layer-textinput817849469_line4\'))" onfocus="rabbit.facade.raiseEvent(rabbit.events.svgFocus, new Array(\'__containerId__-page735926670-layer-textinput817849469_input_svg_border\',\'__containerId__-page735926670-layer-textinput817849469_line1\',\'__containerId__-page735926670-layer-textinput817849469_line2\',\'__containerId__-page735926670-layer-textinput817849469_line3\',\'__containerId__-page735926670-layer-textinput817849469_line4\'))" rows="" cols="" style="width:773px;height:39px;"></textarea></div>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page735926670-layer-icon423281343" style="position: absolute; left: 970px; top: 80px; width: 48px; height: 48px" data-interactive-element-type="fonticon.icon" class="icon stencil mobile-interaction-potential-trigger " data-stencil-id="icon423281343" data-review-reference-id="icon423281343">\
         <div class="stencil-wrapper" style="width: 48px; height: 48px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" style="width:48px;height:48px;" title="">\
               <svg xmlns="http://www.w3.org/2000/svg" width="48" height="48" class="fill-blue">\
                  <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#icon-glyph-e028"></use>\
               </svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page735926670-layer-2017814572" style="position: absolute; left: 1055px; top: 80px; width: 48px; height: 48px" data-interactive-element-type="fonticon.icon" class="icon stencil mobile-interaction-potential-trigger " data-stencil-id="2017814572" data-review-reference-id="2017814572">\
         <div class="stencil-wrapper" style="width: 48px; height: 48px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" style="width:48px;height:48px;" title="">\
               <svg xmlns="http://www.w3.org/2000/svg" width="48" height="48" class="fill-blue">\
                  <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#icon-android-e091"></use>\
               </svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page735926670-layer-text922663467" style="position: absolute; left: 1120px; top: 85px; width: 183px; height: 37px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text922663467" data-review-reference-id="text922663467">\
         <div class="stencil-wrapper" style="width: 183px; height: 37px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline12"><p><span style="font-size: 32px; color: white;">0169321456</span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page735926670-layer-1381528993" style="position: absolute; left: 455px; top: 905px; width: 285px; height: 37px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="1381528993" data-review-reference-id="1381528993">\
         <div class="stencil-wrapper" style="width: 285px; height: 37px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline12"><p><span style="font-size: 32px; color: white;">Hướng dẫn đặt bàn</span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page735926670-layer-image585050781" style="position: absolute; left: 0px; top: 870px; width: 1366px; height: 450px" data-interactive-element-type="default.image" class="image stencil mobile-interaction-potential-trigger " data-stencil-id="image585050781" data-review-reference-id="image585050781">\
         <div class="stencil-wrapper" style="width: 1366px; height: 450px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" title="">\
               <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" class="image-cropper" style="height: 450px;width:1366px;" width="1366" height="450">\
                  <svg:g width="1366" height="450">\
                     <svg:svg x="1" y="1" width="1364" height="448">\
                        <svg:image width="432" height="253" xlink:href="../repoimages/506340.PNG" preserveAspectRatio="none" transform="scale(3.162037037037037,1.7786561264822134) translate(-0,-0)  "></svg:image>\
                     </svg:svg>\
                  </svg:g>\
               </svg:svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page735926670-layer-icon25482507" style="position: absolute; left: 425px; top: 885px; width: 48px; height: 48px" data-interactive-element-type="fonticon.icon" class="icon stencil mobile-interaction-potential-trigger " data-stencil-id="icon25482507" data-review-reference-id="icon25482507">\
         <div class="stencil-wrapper" style="width: 48px; height: 48px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" style="width:48px;height:48px;" title="">\
               <svg xmlns="http://www.w3.org/2000/svg" width="48" height="48" class="fill-green">\
                  <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#icon-glyph-e196"></use>\
               </svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page735926670-layer-text777883387" style="position: absolute; left: 480px; top: 900px; width: 365px; height: 23px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text777883387" data-review-reference-id="text777883387">\
         <div class="stencil-wrapper" style="width: 365px; height: 23px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline22"><p><span style="font-size: 20px;">HƯỚNG DẪN ĐẶT BÀN NHẬN ƯU ĐÃI</span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page735926670-layer-653023696" style="position: absolute; left: 140px; top: 935px; width: 95px; height: 95px" data-interactive-element-type="fonticon.icon" class="icon stencil mobile-interaction-potential-trigger " data-stencil-id="653023696" data-review-reference-id="653023696">\
         <div class="stencil-wrapper" style="width: 95px; height: 95px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" style="width:95px;height:95px;" title="">\
               <svg xmlns="http://www.w3.org/2000/svg" width="95" height="95" class="fill-blue">\
                  <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#icon-glyph-e021"></use>\
               </svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page735926670-layer-1445656429" style="position: absolute; left: 265px; top: 960px; width: 48px; height: 48px" data-interactive-element-type="fonticon.icon" class="icon stencil mobile-interaction-potential-trigger " data-stencil-id="1445656429" data-review-reference-id="1445656429">\
         <div class="stencil-wrapper" style="width: 48px; height: 48px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" style="width:48px;height:48px;" title="">\
               <svg xmlns="http://www.w3.org/2000/svg" width="48" height="48" class="fill-black">\
                  <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#icon-glyph-e218"></use>\
               </svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page735926670-layer-220731268" style="position: absolute; left: 360px; top: 935px; width: 95px; height: 95px" data-interactive-element-type="fonticon.icon" class="icon stencil mobile-interaction-potential-trigger " data-stencil-id="220731268" data-review-reference-id="220731268">\
         <div class="stencil-wrapper" style="width: 95px; height: 95px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" style="width:95px;height:95px;" title="">\
               <svg xmlns="http://www.w3.org/2000/svg" width="95" height="95" class="fill-blue">\
                  <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#icon-android-e090"></use>\
               </svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page735926670-layer-1261497061" style="position: absolute; left: 350px; top: 1035px; width: 129px; height: 56px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="1261497061" data-review-reference-id="1261497061">\
         <div class="stencil-wrapper" style="width: 129px; height: 56px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline22"><p><span style="font-size: 24px;">Gọi đặt chỗ<br /><br /></span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page735926670-layer-740653891" style="position: absolute; left: 740px; top: 960px; width: 48px; height: 48px" data-interactive-element-type="fonticon.icon" class="icon stencil mobile-interaction-potential-trigger " data-stencil-id="740653891" data-review-reference-id="740653891">\
         <div class="stencil-wrapper" style="width: 48px; height: 48px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" style="width:48px;height:48px;" title="">\
               <svg xmlns="http://www.w3.org/2000/svg" width="48" height="48" class="fill-black">\
                  <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#icon-glyph-e218"></use>\
               </svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page735926670-layer-844100078" style="position: absolute; left: 495px; top: 970px; width: 77px; height: 28px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="844100078" data-review-reference-id="844100078">\
         <div class="stencil-wrapper" style="width: 77px; height: 28px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline22"><span class="bold" style="font-size: 24px;">HOẶC</span></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page735926670-layer-1946624304" style="position: absolute; left: 605px; top: 935px; width: 95px; height: 95px" data-interactive-element-type="fonticon.icon" class="icon stencil mobile-interaction-potential-trigger " data-stencil-id="1946624304" data-review-reference-id="1946624304">\
         <div class="stencil-wrapper" style="width: 95px; height: 95px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" style="width:95px;height:95px;" title="">\
               <svg xmlns="http://www.w3.org/2000/svg" width="95" height="95" class="fill-blue">\
                  <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#icon-glyph-e074"></use>\
               </svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page735926670-layer-927178842" style="position: absolute; left: 580px; top: 1035px; width: 173px; height: 28px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="927178842" data-review-reference-id="927178842">\
         <div class="stencil-wrapper" style="width: 173px; height: 28px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline22"><p class="none" style="font-size: 24px;">Đặt bàn Online </p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page735926670-layer-1409345585" style="position: absolute; left: 845px; top: 1035px; width: 107px; height: 28px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="1409345585" data-review-reference-id="1409345585">\
         <div class="stencil-wrapper" style="width: 107px; height: 28px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline22"><p class="none" style="font-size: 24px;">Xác nhận</p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page735926670-layer-1007868033" style="position: absolute; left: 965px; top: 960px; width: 48px; height: 48px" data-interactive-element-type="fonticon.icon" class="icon stencil mobile-interaction-potential-trigger " data-stencil-id="1007868033" data-review-reference-id="1007868033">\
         <div class="stencil-wrapper" style="width: 48px; height: 48px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" style="width:48px;height:48px;" title="">\
               <svg xmlns="http://www.w3.org/2000/svg" width="48" height="48" class="fill-black">\
                  <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#icon-glyph-e218"></use>\
               </svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page735926670-layer-173847591" style="position: absolute; left: 850px; top: 935px; width: 95px; height: 95px" data-interactive-element-type="fonticon.icon" class="icon stencil mobile-interaction-potential-trigger " data-stencil-id="173847591" data-review-reference-id="173847591">\
         <div class="stencil-wrapper" style="width: 95px; height: 95px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" style="width:95px;height:95px;" title="">\
               <svg xmlns="http://www.w3.org/2000/svg" width="95" height="95" class="fill-blue">\
                  <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#icon-glyph-e078"></use>\
               </svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page735926670-layer-414030016" style="position: absolute; left: 1080px; top: 935px; width: 95px; height: 95px" data-interactive-element-type="fonticon.icon" class="icon stencil mobile-interaction-potential-trigger " data-stencil-id="414030016" data-review-reference-id="414030016">\
         <div class="stencil-wrapper" style="width: 95px; height: 95px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" style="width:95px;height:95px;" title="">\
               <svg xmlns="http://www.w3.org/2000/svg" width="95" height="95" class="fill-blue">\
                  <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#icon-glyph-e344"></use>\
               </svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page735926670-layer-1240214398" style="position: absolute; left: 1070px; top: 1035px; width: 147px; height: 28px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="1240214398" data-review-reference-id="1240214398">\
         <div class="stencil-wrapper" style="width: 147px; height: 28px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline22"><p class="none" style="font-size: 24px;">Thưởng thức</p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page735926670-layer-1029912587" style="position: absolute; left: 150px; top: 1070px; width: 117px; height: 23px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="1029912587" data-review-reference-id="1029912587">\
         <div class="stencil-wrapper" style="width: 117px; height: 23px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline22"><p><span style="font-size: 20px; color: #658cd9;">Nhiều ưu đãi</span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page735926670-layer-1289859578" style="position: absolute; left: 355px; top: 1070px; width: 113px; height: 23px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="1289859578" data-review-reference-id="1289859578">\
         <div class="stencil-wrapper" style="width: 113px; height: 23px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline22"><p><span style="font-size: 20px; color: #658cd9;">0169321456</span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page735926670-layer-217928491" style="position: absolute; left: 565px; top: 1070px; width: 201px; height: 23px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="217928491" data-review-reference-id="217928491">\
         <div class="stencil-wrapper" style="width: 201px; height: 23px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline22"><p><span style="font-size: 20px; color: #658cd9;">Qua app hoặc website</span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page735926670-layer-108155705" style="position: absolute; left: 830px; top: 1070px; width: 158px; height: 23px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="108155705" data-review-reference-id="108155705">\
         <div class="stencil-wrapper" style="width: 158px; height: 23px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline22"><p><span style="font-size: 20px; color: #658cd9;">Qua tổng đài viên</span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page735926670-layer-909419338" style="position: absolute; left: 1065px; top: 1065px; width: 169px; height: 28px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="909419338" data-review-reference-id="909419338">\
         <div class="stencil-wrapper" style="width: 169px; height: 28px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline22"><p class="none" style="font-size: 24px;"><span style="font-size: 20px;"><span style="color: #658cd9;">Đến nhà hàng thôi</span> </span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page735926670-layer-1928496892" style="position: absolute; left: 125px; top: 1040px; width: 170px; height: 28px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="1928496892" data-review-reference-id="1928496892">\
         <div class="stencil-wrapper" style="width: 170px; height: 28px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline22"><p><span style="font-size: 24px;">Chọn nhà hàng</span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page735926670-layer-image692818024" style="position: absolute; left: 0px; top: 1095px; width: 1366px; height: 225px" data-interactive-element-type="default.image" class="image stencil mobile-interaction-potential-trigger " data-stencil-id="image692818024" data-review-reference-id="image692818024">\
         <div class="stencil-wrapper" style="width: 1366px; height: 225px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" title="">\
               <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" class="image-cropper" style="height: 225px;width:1366px;" width="1366" height="225">\
                  <svg:g width="1366" height="225">\
                     <svg:svg x="1" y="1" width="1364" height="223">\
                        <svg:image width="432" height="253" xlink:href="../repoimages/506342.PNG" preserveAspectRatio="none" transform="scale(3.162037037037037,0.8893280632411067) translate(-0,-0)  "></svg:image>\
                     </svg:svg>\
                  </svg:g>\
               </svg:svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page735926670-layer-image65779106" style="position: absolute; left: 50px; top: 1105px; width: 115px; height: 50px" data-interactive-element-type="default.image" class="image stencil mobile-interaction-potential-trigger " data-stencil-id="image65779106" data-review-reference-id="image65779106">\
         <div class="stencil-wrapper" style="width: 115px; height: 50px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" title="">\
               <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" class="image-cropper" style="height: 50px;width:115px;" width="115" height="50">\
                  <svg:g width="115" height="50">\
                     <svg:svg x="1" y="1" width="113" height="48">\
                        <svg:image width="287" height="276" xlink:href="../repoimages/506334.png" preserveAspectRatio="none" transform="scale(0.40069686411149824,0.18115942028985507) translate(-0,-0)  "></svg:image>\
                     </svg:svg>\
                  </svg:g>\
               </svg:svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page735926670-layer-text232541355" style="position: absolute; left: 50px; top: 1165px; width: 270px; height: 65px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text232541355" data-review-reference-id="text232541355">\
         <div class="stencil-wrapper" style="width: 270px; height: 65px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline32"><p><span style="color: #658cd9;">Giải pháp giúp người dùng tìm kiếm Điểm đến gần nhất và đặt chỗ trực tuyến một cách nhanh\
                     chóng, tiện lợi.</span><br /><br /></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page735926670-layer-text857925194" style="position: absolute; left: 405px; top: 1105px; width: 111px; height: 20px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text857925194" data-review-reference-id="text857925194">\
         <div class="stencil-wrapper" style="width: 111px; height: 20px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.link2"><p style="font-size: 14px;"><span class="underline" style="font-size: 18px; color: #658cd9;">Về chúng tôi</span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page735926670-layer-2144072547" style="position: absolute; left: 405px; top: 1240px; width: 69px; height: 20px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="2144072547" data-review-reference-id="2144072547">\
         <div class="stencil-wrapper" style="width: 69px; height: 20px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.link2"><p class="underline" style="font-size: 14px;"><span style="color: #658cd9; font-size: 18px;">Đối tác</span></p>\
                     <p class="underline" style="font-size: 14px;"> </p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page735926670-layer-484876472" style="position: absolute; left: 405px; top: 1205px; width: 154px; height: 20px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="484876472" data-review-reference-id="484876472">\
         <div class="stencil-wrapper" style="width: 154px; height: 20px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.link2"><p style="font-size: 14px;"><span class="underline" style="font-size: 18px; color: #ffffcc;"><span style="color: #658cd9;">Cơ\
                     chế giải quyết</span><br /></span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page735926670-layer-828291916" style="position: absolute; left: 405px; top: 1170px; width: 175px; height: 20px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="828291916" data-review-reference-id="828291916">\
         <div class="stencil-wrapper" style="width: 175px; height: 20px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.link2"><p style="font-size: 14px;"><span class="underline" style="font-size: 18px; color: #658cd9;">Chính sách bảo mât</span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page735926670-layer-2022753913" style="position: absolute; left: 405px; top: 1135px; width: 167px; height: 20px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="2022753913" data-review-reference-id="2022753913">\
         <div class="stencil-wrapper" style="width: 167px; height: 20px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.link2"><p style="font-size: 14px;"><span class="underline" style="font-size: 18px; color: #658cd9;">Quy chế hoạt động</span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page735926670-layer-1391060915" style="position: absolute; left: 815px; top: 1105px; width: 43px; height: 20px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="1391060915" data-review-reference-id="1391060915">\
         <div class="stencil-wrapper" style="width: 43px; height: 20px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.link2"><p style="font-size: 14px;"><span class="underline" style="font-size: 18px; color: #658cd9;">Blog</span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page735926670-layer-805627153" style="position: absolute; left: 675px; top: 1105px; width: 63px; height: 20px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="805627153" data-review-reference-id="805627153">\
         <div class="stencil-wrapper" style="width: 63px; height: 20px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.link2"><p style="font-size: 14px;"><span class="underline" style="font-size: 18px; color: #658cd9;">Tin tức</span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page735926670-layer-1150200441" style="position: absolute; left: 675px; top: 1135px; width: 97px; height: 20px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="1150200441" data-review-reference-id="1150200441">\
         <div class="stencil-wrapper" style="width: 97px; height: 20px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.link2"><p style="font-size: 14px;"><span class="underline" style="font-size: 18px; color: #658cd9;">Thẻ ưu đãi</span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page735926670-layer-1179732517" style="position: absolute; left: 675px; top: 1165px; width: 109px; height: 20px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="1179732517" data-review-reference-id="1179732517">\
         <div class="stencil-wrapper" style="width: 109px; height: 20px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.link2"><p style="font-size: 14px;"><span class="underline" style="font-size: 18px; color: #ffffcc;"><span style="color: #658cd9;">Mạng\
                     xã hội</span><br /></span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page735926670-layer-icon640553417" style="position: absolute; left: 820px; top: 1205px; width: 48px; height: 48px" data-interactive-element-type="fonticon.icon" class="icon stencil mobile-interaction-potential-trigger " data-stencil-id="icon640553417" data-review-reference-id="icon640553417">\
         <div class="stencil-wrapper" style="width: 48px; height: 48px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" style="width:48px;height:48px;" title="">\
               <svg xmlns="http://www.w3.org/2000/svg" width="48" height="48" class="fill-red">\
                  <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#icon-glyph-e383"></use>\
               </svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page735926670-layer-638354470" style="position: absolute; left: 750px; top: 1205px; width: 48px; height: 48px" data-interactive-element-type="fonticon.icon" class="icon stencil mobile-interaction-potential-trigger " data-stencil-id="638354470" data-review-reference-id="638354470">\
         <div class="stencil-wrapper" style="width: 48px; height: 48px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" style="width:48px;height:48px;" title="">\
               <svg xmlns="http://www.w3.org/2000/svg" width="48" height="48" class="fill-blue">\
                  <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#icon-glyph-e411"></use>\
               </svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page735926670-layer-797206375" style="position: absolute; left: 675px; top: 1205px; width: 48px; height: 48px" data-interactive-element-type="fonticon.icon" class="icon stencil mobile-interaction-potential-trigger " data-stencil-id="797206375" data-review-reference-id="797206375">\
         <div class="stencil-wrapper" style="width: 48px; height: 48px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" style="width:48px;height:48px;" title="">\
               <svg xmlns="http://www.w3.org/2000/svg" width="48" height="48" class="fill-orange">\
                  <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#icon-glyph-e418"></use>\
               </svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page735926670-layer-text923089768" style="position: absolute; left: 940px; top: 1130px; width: 39px; height: 87px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text923089768" data-review-reference-id="text923089768">\
         <div class="stencil-wrapper" style="width: 39px; height: 87px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline12"><p class="none" style="font-size: 32px;"><span style="color: #d9d9d9; font-size: 18px;">Địa điểm nổi bật  </span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page735926670-layer-arrow768490168" style="position: absolute; left: 890px; top: 1105px; width: 33px; height: 165px" data-interactive-element-type="static.line" class="line stencil mobile-interaction-potential-trigger " data-stencil-id="arrow768490168" data-review-reference-id="arrow768490168">\
         <div class="stencil-wrapper" style="width: 33px; height: 165px">\
            <div title="">\
               <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" style="position: absolute; left: -5px; top: -5px; height: 175px;width:43px;" viewBox="-5 -5 43 175" width="43" height="175"><svg:path d="M 16.00, 0.00 Q 18.49, 10.31, 18.54, 20.62 Q 18.26, 30.94, 18.31, 41.25 Q 17.42, 51.56, 17.94, 61.88 Q 18.36,\
                  72.19, 17.98, 82.50 Q 17.55, 92.81, 15.90, 103.12 Q 16.62, 113.44, 17.06, 123.75 Q 17.81, 134.06, 18.03, 144.38 Q 16.00, 154.69,\
                  16.00, 165.00" style="marker-start:;marker-end:" class="svg_unselected_element"/>\
               </svg:svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page735926670-layer-1410987044" style="position: absolute; left: 350px; top: 1100px; width: 33px; height: 165px" data-interactive-element-type="static.line" class="line stencil mobile-interaction-potential-trigger " data-stencil-id="1410987044" data-review-reference-id="1410987044">\
         <div class="stencil-wrapper" style="width: 33px; height: 165px">\
            <div title="">\
               <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" style="position: absolute; left: -5px; top: -5px; height: 175px;width:43px;" viewBox="-5 -5 43 175" width="43" height="175"><svg:path d="M 16.00, 0.00 Q 15.15, 10.31, 16.07, 20.62 Q 16.33, 30.94, 16.71, 41.25 Q 16.19, 51.56, 16.38, 61.88 Q 17.04,\
                  72.19, 16.71, 82.50 Q 16.76, 92.81, 16.84, 103.12 Q 16.78, 113.44, 16.88, 123.75 Q 17.33, 134.06, 17.29, 144.38 Q 16.00, 154.69,\
                  16.00, 165.00" style="marker-start:;marker-end:" class="svg_unselected_element"/>\
               </svg:svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page735926670-layer-image434272841" style="position: absolute; left: 1005px; top: 1110px; width: 70px; height: 70px" data-interactive-element-type="default.image" class="image stencil mobile-interaction-potential-trigger " data-stencil-id="image434272841" data-review-reference-id="image434272841">\
         <div class="stencil-wrapper" style="width: 70px; height: 70px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" title="">\
               <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" class="image-cropper" style="height: 70px;width:70px;" width="70" height="70">\
                  <svg:g width="70" height="70">\
                     <svg:svg x="1" y="1" width="68" height="68">\
                        <svg:image width="80" height="60" xlink:href="../repoimages/506343.JPG" preserveAspectRatio="none" transform="scale(0.875,1.1666666666666667) translate(-0,-0)  "></svg:image>\
                     </svg:svg>\
                  </svg:g>\
               </svg:svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page735926670-layer-1080545475" style="position: absolute; left: 1085px; top: 1110px; width: 70px; height: 70px" data-interactive-element-type="default.image" class="image stencil mobile-interaction-potential-trigger " data-stencil-id="1080545475" data-review-reference-id="1080545475">\
         <div class="stencil-wrapper" style="width: 70px; height: 70px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" title="">\
               <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" class="image-cropper" style="height: 70px;width:70px;" width="70" height="70">\
                  <svg:g width="70" height="70">\
                     <svg:svg x="1" y="1" width="68" height="68">\
                        <svg:image width="80" height="60" xlink:href="../repoimages/506343.JPG" preserveAspectRatio="none" transform="scale(0.875,1.1666666666666667) translate(-0,-0)  "></svg:image>\
                     </svg:svg>\
                  </svg:g>\
               </svg:svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page735926670-layer-1826970549" style="position: absolute; left: 1005px; top: 1190px; width: 70px; height: 70px" data-interactive-element-type="default.image" class="image stencil mobile-interaction-potential-trigger " data-stencil-id="1826970549" data-review-reference-id="1826970549">\
         <div class="stencil-wrapper" style="width: 70px; height: 70px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" title="">\
               <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" class="image-cropper" style="height: 70px;width:70px;" width="70" height="70">\
                  <svg:g width="70" height="70">\
                     <svg:svg x="1" y="1" width="68" height="68">\
                        <svg:image width="80" height="60" xlink:href="../repoimages/506343.JPG" preserveAspectRatio="none" transform="scale(0.875,1.1666666666666667) translate(-0,-0)  "></svg:image>\
                     </svg:svg>\
                  </svg:g>\
               </svg:svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page735926670-layer-1650460350" style="position: absolute; left: 1085px; top: 1190px; width: 70px; height: 70px" data-interactive-element-type="default.image" class="image stencil mobile-interaction-potential-trigger " data-stencil-id="1650460350" data-review-reference-id="1650460350">\
         <div class="stencil-wrapper" style="width: 70px; height: 70px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" title="">\
               <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" class="image-cropper" style="height: 70px;width:70px;" width="70" height="70">\
                  <svg:g width="70" height="70">\
                     <svg:svg x="1" y="1" width="68" height="68">\
                        <svg:image width="80" height="60" xlink:href="../repoimages/506343.JPG" preserveAspectRatio="none" transform="scale(0.875,1.1666666666666667) translate(-0,-0)  "></svg:image>\
                     </svg:svg>\
                  </svg:g>\
               </svg:svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page735926670-layer-1779754897" style="position: absolute; left: 1165px; top: 1110px; width: 70px; height: 70px" data-interactive-element-type="default.image" class="image stencil mobile-interaction-potential-trigger " data-stencil-id="1779754897" data-review-reference-id="1779754897">\
         <div class="stencil-wrapper" style="width: 70px; height: 70px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" title="">\
               <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" class="image-cropper" style="height: 70px;width:70px;" width="70" height="70">\
                  <svg:g width="70" height="70">\
                     <svg:svg x="1" y="1" width="68" height="68">\
                        <svg:image width="80" height="60" xlink:href="../repoimages/506343.JPG" preserveAspectRatio="none" transform="scale(0.875,1.1666666666666667) translate(-0,-0)  "></svg:image>\
                     </svg:svg>\
                  </svg:g>\
               </svg:svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page735926670-layer-1326299265" style="position: absolute; left: 1165px; top: 1190px; width: 70px; height: 70px" data-interactive-element-type="default.image" class="image stencil mobile-interaction-potential-trigger " data-stencil-id="1326299265" data-review-reference-id="1326299265">\
         <div class="stencil-wrapper" style="width: 70px; height: 70px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" title="">\
               <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" class="image-cropper" style="height: 70px;width:70px;" width="70" height="70">\
                  <svg:g width="70" height="70">\
                     <svg:svg x="1" y="1" width="68" height="68">\
                        <svg:image width="80" height="60" xlink:href="../repoimages/506343.JPG" preserveAspectRatio="none" transform="scale(0.875,1.1666666666666667) translate(-0,-0)  "></svg:image>\
                     </svg:svg>\
                  </svg:g>\
               </svg:svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page735926670-layer-image266654245" style="position: absolute; left: 360px; top: 1280px; width: 1000px; height: 40px" data-interactive-element-type="default.image" class="image stencil mobile-interaction-potential-trigger " data-stencil-id="image266654245" data-review-reference-id="image266654245">\
         <div class="stencil-wrapper" style="width: 1000px; height: 40px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" title="">\
               <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" class="image-cropper" style="height: 40px;width:1000px;" width="1000" height="40">\
                  <svg:g width="1000" height="40">\
                     <svg:svg x="1" y="1" width="998" height="38">\
                        <svg:image width="80" height="60" xlink:href="../repoimages/506344.PNG" preserveAspectRatio="none" transform="scale(12.5,0.6666666666666666) translate(-0,-0)  "></svg:image>\
                     </svg:svg>\
                  </svg:g>\
               </svg:svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page735926670-layer-text266830145" style="position: absolute; left: 70px; top: 1275px; width: 169px; height: 18px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text266830145" data-review-reference-id="text266830145">\
         <div class="stencil-wrapper" style="width: 169px; height: 18px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.link2"><p class="underline" style="font-size: 14px;"><span style="color: #ffffcc; font-size: 16px;">Bản quyền thuộc về ... </span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page735926670-layer-text134826375" style="position: absolute; left: 495px; top: 160px; width: 222px; height: 37px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text134826375" data-review-reference-id="text134826375">\
         <div class="stencil-wrapper" style="width: 222px; height: 37px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline12"><p><span style="font-size: 32px;">Content Holder</span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page735926670-layer-image487827429" style="position: absolute; left: 5px; top: 580px; width: 1361px; height: 287px" data-interactive-element-type="default.image" class="image stencil mobile-interaction-potential-trigger " data-stencil-id="image487827429" data-review-reference-id="image487827429">\
         <div class="stencil-wrapper" style="width: 1361px; height: 287px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" title="">\
               <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" class="image-cropper" style="height: 287px;width:1361px;" width="1361" height="287">\
                  <svg:g width="1361" height="287">\
                     <svg:svg x="1" y="1" width="1359" height="285">\
                        <svg:image width="1350" height="287" xlink:href="../repoimages/508373.PNG" preserveAspectRatio="none" transform="scale(1.0081481481481482,1) translate(-0,-0)  "></svg:image>\
                     </svg:svg>\
                  </svg:g>\
               </svg:svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page735926670-layer-image813988845" style="position: absolute; left: 0px; top: 260px; width: 1366px; height: 320px" data-interactive-element-type="default.image" class="image stencil mobile-interaction-potential-trigger " data-stencil-id="image813988845" data-review-reference-id="image813988845">\
         <div class="stencil-wrapper" style="width: 1366px; height: 320px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" title="">\
               <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" class="image-cropper" style="height: 320px;width:1366px;" width="1366" height="320">\
                  <svg:g width="1366" height="320">\
                     <svg:svg x="1" y="1" width="1364" height="318">\
                        <svg:image width="1336" height="320" xlink:href="../repoimages/508374.PNG" preserveAspectRatio="none" transform="scale(1.0224550898203593,1) translate(-0,-0)  "></svg:image>\
                     </svg:svg>\
                  </svg:g>\
               </svg:svg>\
            </div>\
         </div>\
      </div>\
   </div>\
</div>');