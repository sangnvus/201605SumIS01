rabbit.data.layerStore.addLayerFromHtml('<div xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:fn="http://www.w3.org/2005/xpath-functions" id="result">\
   <div xmlns:xs="http://www.w3.org/2001/XMLSchema" xmlns="http://www.w3.org/1999/xhtml" id="__containerId__page271612227-layer" class="layer" name="__containerId__pageLayer" data-layer-id="page271612227" data-layer-type="pageLayer" style="position:absolute;left:0px;top:0px;">\
      <div id="__containerId__-page271612227-layer-image273698272" style="position: absolute; left: 0px; top: 0px; width: 1366px; height: 6000px" data-interactive-element-type="default.image" class="image stencil mobile-interaction-potential-trigger " data-stencil-id="image273698272" data-review-reference-id="image273698272">\
         <div class="stencil-wrapper" style="width: 1366px; height: 6000px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" title="">\
               <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" class="image-cropper" style="height: 6000px;width:1366px;" width="1366" height="6000" viewBox="0 0 1366 6000">\
                  <svg:g width="1366" height="6000">\
                     <svg:svg x="0" y="0" width="1366" height="6000">\
                        <svg:image width="432" height="253" xlink:href="../repoimages/506332.PNG" preserveAspectRatio="none" transform="scale(3.162037037037037,23.715415019762847) translate(-0,-0)  "></svg:image>\
                     </svg:svg>\
                  </svg:g>\
               </svg:svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page271612227-layer-image498960770" style="position: absolute; left: 0px; top: 55px; width: 1366px; height: 6000px" data-interactive-element-type="default.image" class="image stencil mobile-interaction-potential-trigger " data-stencil-id="image498960770" data-review-reference-id="image498960770">\
         <div class="stencil-wrapper" style="width: 1366px; height: 6000px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" title="">\
               <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" class="image-cropper" style="height: 6000px;width:1366px;" width="1366" height="6000" viewBox="0 0 1366 6000">\
                  <svg:g width="1366" height="6000">\
                     <svg:svg x="0" y="0" width="1366" height="6000">\
                        <svg:image width="432" height="253" xlink:href="../repoimages/506332.PNG" preserveAspectRatio="none" transform="scale(3.162037037037037,23.715415019762847) translate(-0,-0)  "></svg:image>\
                     </svg:svg>\
                  </svg:g>\
               </svg:svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page271612227-layer-image519661798" style="position: absolute; left: 35px; top: 25px; width: 150px; height: 150px" data-interactive-element-type="default.image" class="image stencil mobile-interaction-potential-trigger " data-stencil-id="image519661798" data-review-reference-id="image519661798">\
         <div class="stencil-wrapper" style="width: 150px; height: 150px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" title="">\
               <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" class="image-cropper" style="height: 150px;width:150px;" width="150" height="150" viewBox="0 0 150 150">\
                  <svg:g width="150" height="150">\
                     <svg:svg x="0" y="0" width="150" height="150">\
                        <svg:image width="80" height="60" xlink:href="../repoimages/508705.png" preserveAspectRatio="none" transform="scale(1.875,2.5) translate(-0,-0)  "></svg:image>\
                     </svg:svg>\
                  </svg:g>\
               </svg:svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page271612227-layer-text479975646" style="position: absolute; left: 65px; top: 180px; width: 97px; height: 37px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text479975646" data-review-reference-id="text479975646">\
         <div class="stencil-wrapper" style="width: 97px; height: 37px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline12"><p><span style="font-size: 32px; color: #658cd9;">Admin</span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page271612227-layer-arrow535785819" style="position: absolute; left: 245px; top: 35px; width: 25px; height: 4415px" data-interactive-element-type="static.line" class="line stencil mobile-interaction-potential-trigger " data-stencil-id="arrow535785819" data-review-reference-id="arrow535785819">\
         <div class="stencil-wrapper" style="width: 25px; height: 4415px">\
            <div title="">\
               <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" style="position: absolute; left: -5px; top: -5px; height: 4425px;width:35px;" viewBox="-5 -5 35 4425" width="35" height="4425">\
                  <svg:path d="M 12.5,0 L 12.5,4415" marker-start="" marker-end="" style="fill:none; stroke-width:2px;stroke:black;"></svg:path>\
               </svg:svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page271612227-layer-text174357313" style="position: absolute; left: 70px; top: 240px; width: 89px; height: 23px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text174357313" data-review-reference-id="text174357313">\
         <div class="stencil-wrapper" style="width: 89px; height: 23px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline22"><p><span style="font-size: 20px; color: #658cd9;">Thông tin</span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page271612227-layer-1265587393" style="position: absolute; left: 5px; top: -1125px; width: 32px; height: 32px" data-interactive-element-type="fonticon.icon" class="icon stencil mobile-interaction-potential-trigger " data-stencil-id="1265587393" data-review-reference-id="1265587393">\
         <div class="stencil-wrapper" style="width: 32px; height: 32px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" style="width:32px;height:32px;" title="">\
               <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" class="fill-blue">\
                  <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#icon-glyph-e004"></use>\
               </svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page271612227-layer-1887757013" style="position: absolute; left: 50px; top: -1120px; width: 106px; height: 28px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="1887757013" data-review-reference-id="1887757013">\
         <div class="stencil-wrapper" style="width: 106px; height: 28px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline22"><p><span style="font-size: 24px; color: #658cd9;">Thông tin</span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page271612227-layer-1621736172" style="position: absolute; left: 25px; top: 235px; width: 32px; height: 32px" data-interactive-element-type="fonticon.icon" class="icon stencil mobile-interaction-potential-trigger " data-stencil-id="1621736172" data-review-reference-id="1621736172">\
         <div class="stencil-wrapper" style="width: 32px; height: 32px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" style="width:32px;height:32px;" title="">\
               <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" class="fill-blue">\
                  <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#icon-glyph-e004"></use>\
               </svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page271612227-layer-340966007" style="position: absolute; left: 70px; top: 575px; width: 165px; height: 28px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="340966007" data-review-reference-id="340966007">\
         <div class="stencil-wrapper" style="width: 165px; height: 28px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline22"><p class="none" style="font-size: 24px;"><span style="color: #658cd9; font-size: 20px;">Quản lí mật khẩu</span> </p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page271612227-layer-icon935926720" style="position: absolute; left: 25px; top: 570px; width: 32px; height: 32px" data-interactive-element-type="fonticon.icon" class="icon stencil mobile-interaction-potential-trigger " data-stencil-id="icon935926720" data-review-reference-id="icon935926720">\
         <div class="stencil-wrapper" style="width: 32px; height: 32px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" style="width:32px;height:32px;" title="">\
               <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" class="fill-blue">\
                  <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#icon-glyph-e205"></use>\
               </svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page271612227-layer-1222042112" style="position: absolute; left: 25px; top: 285px; width: 32px; height: 32px" data-interactive-element-type="fonticon.icon" class="icon stencil mobile-interaction-potential-trigger " data-stencil-id="1222042112" data-review-reference-id="1222042112">\
         <div class="stencil-wrapper" style="width: 32px; height: 32px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" style="width:32px;height:32px;" title="">\
               <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" class="fill-blue">\
                  <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#icon-glyph-e025"></use>\
               </svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page271612227-layer-1981890541" style="position: absolute; left: 70px; top: 290px; width: 165px; height: 28px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="1981890541" data-review-reference-id="1981890541">\
         <div class="stencil-wrapper" style="width: 165px; height: 28px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline22"><p class="none" style="font-size: 24px;"><span style="color: #658cd9;">Chủ cửa hàng</span> </p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page271612227-layer-1528972458" style="position: absolute; left: 25px; top: 335px; width: 32px; height: 32px" data-interactive-element-type="fonticon.icon" class="icon stencil mobile-interaction-potential-trigger " data-stencil-id="1528972458" data-review-reference-id="1528972458">\
         <div class="stencil-wrapper" style="width: 32px; height: 32px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" style="width:32px;height:32px;" title="">\
               <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" class="fill-blue">\
                  <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#icon-glyph-e044"></use>\
               </svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page271612227-layer-737490597" style="position: absolute; left: 70px; top: 340px; width: 141px; height: 28px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="737490597" data-review-reference-id="737490597">\
         <div class="stencil-wrapper" style="width: 141px; height: 28px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline22"><p class="none" style="font-size: 24px;"><span style="color: #658cd9;">Khách hàng</span> </p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page271612227-layer-1412662593" style="position: absolute; left: 70px; top: 390px; width: 119px; height: 27px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="1412662593" data-review-reference-id="1412662593">\
         <div class="stencil-wrapper" style="width: 119px; height: 27px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline22"><p class="none" style="font-size: 24px;"><span style="color: #658cd9;">Đơn hàng</span> </p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page271612227-layer-icon911435795" style="position: absolute; left: 25px; top: 385px; width: 32px; height: 32px" data-interactive-element-type="fonticon.icon" class="icon stencil mobile-interaction-potential-trigger " data-stencil-id="icon911435795" data-review-reference-id="icon911435795">\
         <div class="stencil-wrapper" style="width: 32px; height: 32px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" style="width:32px;height:32px;" title="">\
               <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" class="fill-blue">\
                  <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#icon-glyph-e319"></use>\
               </svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page271612227-layer-2087309316" style="position: absolute; left: 65px; top: 515px; width: 89px; height: 23px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="2087309316" data-review-reference-id="2087309316">\
         <div class="stencil-wrapper" style="width: 89px; height: 23px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline22"><p><span style="font-size: 20px; color: #658cd9;">Thống kê</span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page271612227-layer-686516014" style="position: absolute; left: 20px; top: 505px; width: 32px; height: 32px" data-interactive-element-type="fonticon.icon" class="icon stencil mobile-interaction-potential-trigger " data-stencil-id="686516014" data-review-reference-id="686516014">\
         <div class="stencil-wrapper" style="width: 32px; height: 32px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" style="width:32px;height:32px;" title="">\
               <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" class="fill-blue">\
                  <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#icon-glyph-e041"></use>\
               </svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page271612227-layer-text566932881" style="position: absolute; left: 325px; top: 35px; width: 139px; height: 37px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text566932881" data-review-reference-id="text566932881">\
         <div class="stencil-wrapper" style="width: 139px; height: 37px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline12"><p><span style="font-size: 32px; color: #658cd9;">Thông tin</span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page271612227-layer-arrow577384147" style="position: absolute; left: 300px; top: 490px; width: 1020px; height: 33px" data-interactive-element-type="static.line" class="line stencil mobile-interaction-potential-trigger " data-stencil-id="arrow577384147" data-review-reference-id="arrow577384147">\
         <div class="stencil-wrapper" style="width: 1020px; height: 33px">\
            <div title="">\
               <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" style="position: absolute; left: -5px; top: -5px; height: 43px;width:1030px;" viewBox="-5 -5 1030 43" width="1030" height="43">\
                  <svg:path d="M 0,16.5 L 1020,16.5" marker-start="" marker-end="" style="fill:none; stroke-width:2px;stroke:black;"></svg:path>\
               </svg:svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page271612227-layer-text98494574" style="position: absolute; left: 330px; top: 530px; width: 209px; height: 37px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text98494574" data-review-reference-id="text98494574">\
         <div class="stencil-wrapper" style="width: 209px; height: 37px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline12"><p><span style="font-size: 32px; color: #658cd9;">Chủ cửa hàng</span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page271612227-layer-text27852196" style="position: absolute; left: 1150px; top: 530px; width: 123px; height: 37px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text27852196" data-review-reference-id="text27852196">\
         <div class="stencil-wrapper" style="width: 123px; height: 37px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline12"><p><span style="font-size: 32px; color: #000000;"><span style="color: #658cd9;">4</span> Người</span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page271612227-layer-text725678959" style="position: absolute; left: 340px; top: 580px; width: 62px; height: 23px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text725678959" data-review-reference-id="text725678959">\
         <div class="stencil-wrapper" style="width: 62px; height: 23px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline32"><p><span style="font-size: 20px; color: #658cd9;">Bộ lọc</span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page271612227-layer-textinput704298858" style="position: absolute; left: 395px; top: 625px; width: 150px; height: 30px" data-interactive-element-type="default.textinput" class="textinput stencil mobile-interaction-potential-trigger " data-stencil-id="textinput704298858" data-review-reference-id="textinput704298858">\
         <div class="stencil-wrapper" style="width: 150px; height: 30px">\
            <div title=""><input id="__containerId__-page271612227-layer-textinput704298858input" value="" style="width:148px;height:28px;padding: 0px;border-width:1px;" type="text" /></div>\
         </div>\
      </div>\
      <div id="__containerId__-page271612227-layer-text608299457" style="position: absolute; left: 350px; top: 630px; width: 37px; height: 21px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text608299457" data-review-reference-id="text608299457">\
         <div class="stencil-wrapper" style="width: 37px; height: 21px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline32"><p><span style="font-size: 18px; color: #658cd9;">Tên</span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page271612227-layer-combobox385567715" style="position: absolute; left: 600px; top: 625px; width: 150px; height: 30px" data-interactive-element-type="default.combobox" class="combobox stencil mobile-interaction-potential-trigger " data-stencil-id="combobox385567715" data-review-reference-id="combobox385567715">\
         <div class="stencil-wrapper" style="width: 150px; height: 30px">\
            <div title=""><select id="__containerId__-page271612227-layer-combobox385567715select" style="width:150px;height:30px;" title="">\
                  <option title="">Trạng thái</option>\
                  <option title="">Active</option>\
                  <option title="">Deactive</option></select></div>\
         </div>\
      </div>\
      <div id="__containerId__-page271612227-layer-iphoneButton485347976" style="position: absolute; left: 1180px; top: 880px; width: 88px; height: 30px" data-interactive-element-type="default.iphoneButton" class="iphoneButton stencil mobile-interaction-potential-trigger " data-stencil-id="iphoneButton485347976" data-review-reference-id="iphoneButton485347976">\
         <div class="stencil-wrapper" style="width: 88px; height: 30px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" title="" style="height: 30px;width:88px;">\
               <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" width="88" height="30" viewBox="0 0 88 30">\
                  <svg:a>\
                     <svg:path fill-rule="evenodd" clip-rule="evenodd" fill="#808080" stroke="#666666" d="M5,29.5 l-2,-0.5 -1,-1 -1,-1.5 -0.5,-1.5 0,-20 0.5,-2 1,-1 1,-1 2,-0.5 78,0 1.5,0.5 1.5,1 1,1.5 0.5,1.5 0,20 -0.5,1.5 -1,1.5 -1.5,1 -1.5,0.5 z"></svg:path>\
                     <svg:text x="44" y="15" dy="0.3em" fill="#FFFFFF" style="font-size:1em;stroke-width:0pt;" font-family="\'HelveticaNeue-Bold\'" text-anchor="middle" xml:space="preserve">Lưu thay đổi</svg:text>\
                  </svg:a>\
               </svg:svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page271612227-layer-857703320" style="position: absolute; left: 315px; top: 125px; width: 67px; height: 20px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="857703320" data-review-reference-id="857703320">\
         <div class="stencil-wrapper" style="width: 67px; height: 20px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline32"><p><span style="font-size: 18px;">Họ tên:</span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page271612227-layer-542178574" style="position: absolute; left: 475px; top: 110px; width: 275px; height: 30px" data-interactive-element-type="default.textinput" class="textinput stencil mobile-interaction-potential-trigger " data-stencil-id="542178574" data-review-reference-id="542178574">\
         <div class="stencil-wrapper" style="width: 275px; height: 30px">\
            <div title=""><input id="__containerId__-page271612227-layer-542178574input" value="" style="width:273px;height:28px;padding: 0px;border-width:1px;" type="text" /></div>\
         </div>\
      </div>\
      <div id="__containerId__-page271612227-layer-1722534564" style="position: absolute; left: 475px; top: 170px; width: 275px; height: 30px" data-interactive-element-type="default.textinput" class="textinput stencil mobile-interaction-potential-trigger " data-stencil-id="1722534564" data-review-reference-id="1722534564">\
         <div class="stencil-wrapper" style="width: 275px; height: 30px">\
            <div title=""><input id="__containerId__-page271612227-layer-1722534564input" value="" style="width:273px;height:28px;padding: 0px;border-width:1px;" type="text" /></div>\
         </div>\
      </div>\
      <div id="__containerId__-page271612227-layer-239335217" style="position: absolute; left: 315px; top: 185px; width: 56px; height: 21px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="239335217" data-review-reference-id="239335217">\
         <div class="stencil-wrapper" style="width: 56px; height: 21px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline32"><p><span style="font-size: 18px;">Email:</span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page271612227-layer-2135516536" style="position: absolute; left: 315px; top: 245px; width: 91px; height: 21px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="2135516536" data-review-reference-id="2135516536">\
         <div class="stencil-wrapper" style="width: 91px; height: 21px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline32"><p><span style="font-size: 18px;">Ngày sinh:</span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page271612227-layer-694368928" style="position: absolute; left: 475px; top: 235px; width: 150px; height: 30px" data-interactive-element-type="default.datepicker" class="datepicker stencil mobile-interaction-potential-trigger " data-stencil-id="694368928" data-review-reference-id="694368928">\
         <div class="stencil-wrapper" style="width: 150px; height: 30px">\
            <div>\
               <div style="position:absolute; white-space: nowrap;" title=""><input type="text" style="width:114px; height:28px;padding: 0px;border-width:1px;" id="__containerId__-page271612227-layer-694368928_input" /><button type="button" style="width:34px; height:28px; vertical-align: top; padding: 0px;border-width:1px;" id="__containerId__-page271612227-layer-694368928_button"><img src="../resources/icons/date.png" /></button></div>\
               <div id="__containerId__-page271612227-layer-694368928_ov" class="yui-skin-sam" style="position: absolute; width: 16em;visibility:visible;">\
                  <div id="__containerId__-page271612227-layer-694368928_cal"></div>\
               </div><script type="text/javascript">\
				rabbit.stencils.datepicker.setupDatepicker("__containerId__-page271612227-layer-694368928");\
			</script></div>\
         </div>\
      </div>\
      <div id="__containerId__-page271612227-layer-520739904" style="position: absolute; left: 825px; top: 125px; width: 45px; height: 21px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="520739904" data-review-reference-id="520739904">\
         <div class="stencil-wrapper" style="width: 45px; height: 21px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline32"><p><span style="font-size: 18px;">SĐT:</span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page271612227-layer-898593973" style="position: absolute; left: 875px; top: 120px; width: 275px; height: 30px" data-interactive-element-type="default.textinput" class="textinput stencil mobile-interaction-potential-trigger " data-stencil-id="898593973" data-review-reference-id="898593973">\
         <div class="stencil-wrapper" style="width: 275px; height: 30px">\
            <div title=""><input id="__containerId__-page271612227-layer-898593973input" value="" style="width:273px;height:28px;padding: 0px;border-width:1px;" type="text" /></div>\
         </div>\
      </div>\
      <div id="__containerId__-page271612227-layer-1725358062" style="position: absolute; left: 1150px; top: 120px; width: 32px; height: 32px" data-interactive-element-type="fonticon.icon" class="icon stencil mobile-interaction-potential-trigger " data-stencil-id="1725358062" data-review-reference-id="1725358062">\
         <div class="stencil-wrapper" style="width: 32px; height: 32px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" style="width:32px;height:32px;" title="">\
               <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" class="fill-blue">\
                  <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#icon-glyph-e337"></use>\
               </svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page271612227-layer-715721669" style="position: absolute; left: 310px; top: 320px; width: 111px; height: 21px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="715721669" data-review-reference-id="715721669">\
         <div class="stencil-wrapper" style="width: 111px; height: 21px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline32"><p><span style="font-size: 18px;">Số tài khoản:</span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page271612227-layer-656986165" style="position: absolute; left: 475px; top: 310px; width: 275px; height: 30px" data-interactive-element-type="default.textinput" class="textinput stencil mobile-interaction-potential-trigger " data-stencil-id="656986165" data-review-reference-id="656986165">\
         <div class="stencil-wrapper" style="width: 275px; height: 30px">\
            <div title=""><input id="__containerId__-page271612227-layer-656986165input" value="" style="width:273px;height:28px;padding: 0px;border-width:1px;" type="text" /></div>\
         </div>\
      </div>\
      <div id="__containerId__-page271612227-layer-445581969" style="position: absolute; left: 315px; top: 390px; width: 74px; height: 20px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="445581969" data-review-reference-id="445581969">\
         <div class="stencil-wrapper" style="width: 74px; height: 20px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline32"><p class="none" style="font-size: 18px;">Địa chỉ: </p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page271612227-layer-411085646" style="position: absolute; left: 475px; top: 385px; width: 275px; height: 30px" data-interactive-element-type="default.textinput" class="textinput stencil mobile-interaction-potential-trigger " data-stencil-id="411085646" data-review-reference-id="411085646">\
         <div class="stencil-wrapper" style="width: 275px; height: 30px">\
            <div title=""><input id="__containerId__-page271612227-layer-411085646input" value="" style="width:273px;height:28px;padding: 0px;border-width:1px;" type="text" /></div>\
         </div>\
      </div>\
      <div id="__containerId__-page271612227-layer-383946518" style="position: absolute; left: 300px; top: 490px; width: 1020px; height: 33px" data-interactive-element-type="static.line" class="line stencil mobile-interaction-potential-trigger " data-stencil-id="383946518" data-review-reference-id="383946518">\
         <div class="stencil-wrapper" style="width: 1020px; height: 33px">\
            <div title="">\
               <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" style="position: absolute; left: -5px; top: -5px; height: 43px;width:1030px;" viewBox="-5 -5 1030 43" width="1030" height="43">\
                  <svg:path d="M 0,16.5 L 1020,16.5" marker-start="" marker-end="" style="fill:none; stroke-width:2px;stroke:black;"></svg:path>\
               </svg:svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page271612227-layer-1813156342" style="position: absolute; left: 285px; top: 925px; width: 1020px; height: 33px" data-interactive-element-type="static.line" class="line stencil mobile-interaction-potential-trigger " data-stencil-id="1813156342" data-review-reference-id="1813156342">\
         <div class="stencil-wrapper" style="width: 1020px; height: 33px">\
            <div title="">\
               <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" style="position: absolute; left: -5px; top: -5px; height: 43px;width:1030px;" viewBox="-5 -5 1030 43" width="1030" height="43">\
                  <svg:path d="M 0,16.5 L 1020,16.5" marker-start="" marker-end="" style="fill:none; stroke-width:2px;stroke:black;"></svg:path>\
               </svg:svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page271612227-layer-1196557919" style="position: absolute; left: 315px; top: 965px; width: 177px; height: 37px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="1196557919" data-review-reference-id="1196557919">\
         <div class="stencil-wrapper" style="width: 177px; height: 37px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline12"><p><span style="font-size: 32px; color: #658cd9;">Khách hàng</span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page271612227-layer-1535468065" style="position: absolute; left: 1135px; top: 965px; width: 123px; height: 37px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="1535468065" data-review-reference-id="1535468065">\
         <div class="stencil-wrapper" style="width: 123px; height: 37px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline12"><p><span style="font-size: 32px; color: #000000;"><span style="color: #658cd9;">4</span> Người</span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page271612227-layer-220910507" style="position: absolute; left: 315px; top: 1135px; width: 952px; height: 150px" data-interactive-element-type="default.table" class="table stencil mobile-interaction-potential-trigger " data-stencil-id="220910507" data-review-reference-id="220910507">\
         <div class="stencil-wrapper" style="width: 952px; height: 150px">\
            <div title=""><table width=\'942.0\' height=\'150.0\' cellspacing=\'0\' class=\'tableStyle\'><tr style=\'height: 30px\'><td style=\'width:110px;\' class=\'tableCells\'><span\
               style=\'\'>Mã số</span><br /></td><td style=\'width:156px;\' class=\'tableCells\'><span style=\'\'>Họ tên</span><br /></td><td style=\'width:179px;\'\
               class=\'tableCells\'><span style=\'\'>SĐT</span><br /></td><td style=\'width:198px;\' class=\'tableCells\'><span style=\'\'>Số đơn hàng</span><br\
               /></td><td style=\'width:159px;\' class=\'tableCells\'><span style=\'\'>Trạng thái</span><br /></td></tr><tr style=\'height: 30px\'><td\
               style=\'width:110px;\' class=\'tableCells\'><span style=\'\'>1</span><br /></td><td style=\'width:156px;\' class=\'tableCells\'><span\
               style=\'\'>Nguyễn A</span><br /></td><td style=\'width:179px;\' class=\'tableCells\'><span style=\'\'>012153452</span><br /></td><td\
               style=\'width:198px;\' class=\'tableCells\'><span style=\'\'>3</span><br /></td><td style=\'width:159px;\' class=\'tableCells\'><span\
               style=\'\'>Active</span><br /></td></tr><tr style=\'height: 30px\'><td style=\'width:110px;\' class=\'tableCells\'><span style=\'\'>2</span><br\
               /></td><td style=\'width:156px;\' class=\'tableCells\'><span style=\'\'>TRần B</span><br /></td><td style=\'width:179px;\' class=\'tableCells\'><span\
               style=\'\'>016844245</span><br /></td><td style=\'width:198px;\' class=\'tableCells\'><span style=\'\'>4</span><br /></td><td style=\'width:159px;\'\
               class=\'tableCells\'><span style=\'\'>Active</span><br /></td></tr><tr style=\'height: 30px\'><td style=\'width:110px;\' class=\'tableCells\'><span\
               style=\'\'>3</span><br /></td><td style=\'width:156px;\' class=\'tableCells\'><span style=\'\'>Nguyễn C</span><br /></td><td style=\'width:179px;\'\
               class=\'tableCells\'><span style=\'\'>016844245</span><br /></td><td style=\'width:198px;\' class=\'tableCells\'><span style=\'\'>2</span><br\
               /></td><td style=\'width:159px;\' class=\'tableCells\'><span style=\'\'>Deactive</span><br /></td></tr><tr style=\'height: 30px\'><td\
               style=\'width:110px;\' class=\'tableCells\'><span style=\'\'>4</span><br /></td><td style=\'width:156px;\' class=\'tableCells\'><span\
               style=\'\'>Ngô A</span><br /></td><td style=\'width:179px;\' class=\'tableCells\'><span style=\'\'>016844245</span><br /></td><td\
               style=\'width:198px;\' class=\'tableCells\'><span style=\'\'>5</span><br /></td><td style=\'width:159px;\' class=\'tableCells\'><span\
               style=\'\'>Active</span><br /></td></tr></table>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page271612227-layer-1333927778" style="position: absolute; left: 315px; top: 1010px; width: 955px; height: 100px" data-interactive-element-type="static.rect" class="rect stencil mobile-interaction-potential-trigger " data-stencil-id="1333927778" data-review-reference-id="1333927778">\
         <div class="stencil-wrapper" style="width: 955px; height: 100px">\
            <div title="">\
               <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" style="height: 100px; width:955px;" width="955" height="100" viewBox="0 0 955 100">\
                  <svg:g width="955" height="100">\
                     <svg:rect x="0" y="0" width="955" height="100" style="stroke-width:1;stroke:black;fill:white;"></svg:rect>\
                  </svg:g>\
               </svg:svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page271612227-layer-1452645800" style="position: absolute; left: 325px; top: 1015px; width: 62px; height: 23px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="1452645800" data-review-reference-id="1452645800">\
         <div class="stencil-wrapper" style="width: 62px; height: 23px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline32"><p><span style="font-size: 20px; color: #658cd9;">Bộ lọc</span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page271612227-layer-1742869886" style="position: absolute; left: 380px; top: 1060px; width: 150px; height: 30px" data-interactive-element-type="default.textinput" class="textinput stencil mobile-interaction-potential-trigger " data-stencil-id="1742869886" data-review-reference-id="1742869886">\
         <div class="stencil-wrapper" style="width: 150px; height: 30px">\
            <div title=""><input id="__containerId__-page271612227-layer-1742869886input" value="" style="width:148px;height:28px;padding: 0px;border-width:1px;" type="text" /></div>\
         </div>\
      </div>\
      <div id="__containerId__-page271612227-layer-1037648139" style="position: absolute; left: 335px; top: 1065px; width: 37px; height: 21px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="1037648139" data-review-reference-id="1037648139">\
         <div class="stencil-wrapper" style="width: 37px; height: 21px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline32"><p><span style="font-size: 18px; color: #658cd9;">Tên</span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page271612227-layer-2068706232" style="position: absolute; left: 590px; top: 1065px; width: 82px; height: 20px" data-interactive-element-type="default.checkbox" class="checkbox stencil mobile-interaction-potential-trigger " data-stencil-id="2068706232" data-review-reference-id="2068706232">\
         <div class="stencil-wrapper" style="width: 82px; height: 20px">\
            <div class="" style="font-size:1.17em;" xml:space="preserve" title="">\
               			\
               <nobr>\
                  				<label>\
                     					<input id="__containerId__-page271612227-layer-2068706232input" xml:space="default" style="padding-right:9px" type="checkbox" checked="true" />\
                     					\
                     						\
                     						Ngày lập \
                     						\
                     					\
                     				</label>\
                  			\
               </nobr>\
               		\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page271612227-layer-2004676189" style="position: absolute; left: 710px; top: 1065px; width: 104px; height: 20px" data-interactive-element-type="default.checkbox" class="checkbox stencil mobile-interaction-potential-trigger " data-stencil-id="2004676189" data-review-reference-id="2004676189">\
         <div class="stencil-wrapper" style="width: 104px; height: 20px">\
            <div class="" style="font-size:1.17em;" xml:space="preserve" title="">\
               			\
               <nobr>\
                  				<label>\
                     					<input id="__containerId__-page271612227-layer-2004676189input" xml:space="default" style="padding-right:9px" type="checkbox" checked="true" />\
                     					\
                     						\
                     						Số đơn hàng\
                     						\
                     					\
                     				</label>\
                  			\
               </nobr>\
               		\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page271612227-layer-132386789" style="position: absolute; left: 845px; top: 1060px; width: 150px; height: 30px" data-interactive-element-type="default.combobox" class="combobox stencil mobile-interaction-potential-trigger " data-stencil-id="132386789" data-review-reference-id="132386789">\
         <div class="stencil-wrapper" style="width: 150px; height: 30px">\
            <div title=""><select id="__containerId__-page271612227-layer-132386789select" style="width:150px;height:30px;" title="">\
                  <option title="">Trạng thái</option>\
                  <option title="">Active</option>\
                  <option title="">Deactive</option></select></div>\
         </div>\
      </div>\
      <div id="__containerId__-page271612227-layer-1661348270" style="position: absolute; left: 1165px; top: 1050px; width: 80px; height: 30px" data-interactive-element-type="default.iphoneButton" class="iphoneButton stencil mobile-interaction-potential-trigger " data-stencil-id="1661348270" data-review-reference-id="1661348270">\
         <div class="stencil-wrapper" style="width: 80px; height: 30px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" title="" style="height: 30px;width:80px;">\
               <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" width="80" height="30" viewBox="0 0 80 30">\
                  <svg:a>\
                     <svg:path fill-rule="evenodd" clip-rule="evenodd" fill="#808080" stroke="#666666" d="M5,29.5 l-2,-0.5 -1,-1 -1,-1.5 -0.5,-1.5 0,-20 0.5,-2 1,-1 1,-1 2,-0.5 62,0 0.5,0.5 1,0 1,1 1.5,1.5 8.5,11 -7.5,11 -2,2.5 -1.5,1 -0.5,0.5 z"></svg:path>\
                     <svg:text x="37" y="15" dy="0.3em" fill="#FFFFFF" style="font-size:1em;stroke-width:0pt;" font-family="\'HelveticaNeue-Bold\'" text-anchor="middle" xml:space="preserve">Lọc</svg:text>\
                  </svg:a>\
               </svg:svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page271612227-layer-1089734820" style="position: absolute; left: 1165px; top: 1315px; width: 88px; height: 30px" data-interactive-element-type="default.iphoneButton" class="iphoneButton stencil mobile-interaction-potential-trigger " data-stencil-id="1089734820" data-review-reference-id="1089734820">\
         <div class="stencil-wrapper" style="width: 88px; height: 30px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" title="" style="height: 30px;width:88px;">\
               <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" width="88" height="30" viewBox="0 0 88 30">\
                  <svg:a>\
                     <svg:path fill-rule="evenodd" clip-rule="evenodd" fill="#808080" stroke="#666666" d="M5,29.5 l-2,-0.5 -1,-1 -1,-1.5 -0.5,-1.5 0,-20 0.5,-2 1,-1 1,-1 2,-0.5 78,0 1.5,0.5 1.5,1 1,1.5 0.5,1.5 0,20 -0.5,1.5 -1,1.5 -1.5,1 -1.5,0.5 z"></svg:path>\
                     <svg:text x="44" y="15" dy="0.3em" fill="#FFFFFF" style="font-size:1em;stroke-width:0pt;" font-family="\'HelveticaNeue-Bold\'" text-anchor="middle" xml:space="preserve">Lưu thay đổi</svg:text>\
                  </svg:a>\
               </svg:svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page271612227-layer-1618779882" style="position: absolute; left: 285px; top: 1390px; width: 1020px; height: 33px" data-interactive-element-type="static.line" class="line stencil mobile-interaction-potential-trigger " data-stencil-id="1618779882" data-review-reference-id="1618779882">\
         <div class="stencil-wrapper" style="width: 1020px; height: 33px">\
            <div title="">\
               <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" style="position: absolute; left: -5px; top: -5px; height: 43px;width:1030px;" viewBox="-5 -5 1030 43" width="1030" height="43">\
                  <svg:path d="M 0,16.5 L 1020,16.5" marker-start="" marker-end="" style="fill:none; stroke-width:2px;stroke:black;"></svg:path>\
               </svg:svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page271612227-layer-1924773091" style="position: absolute; left: 25px; top: 628px; width: 32px; height: 32px" data-interactive-element-type="fonticon.icon" class="icon stencil mobile-interaction-potential-trigger " data-stencil-id="1924773091" data-review-reference-id="1924773091">\
         <div class="stencil-wrapper" style="width: 32px; height: 32px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" style="width:32px;height:32px;" title="">\
               <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" class="fill-blue">\
                  <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#icon-glyph-e064"></use>\
               </svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page271612227-layer-1260812243" style="position: absolute; left: 70px; top: 632px; width: 115px; height: 28px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="1260812243" data-review-reference-id="1260812243">\
         <div class="stencil-wrapper" style="width: 115px; height: 28px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline22"><p class="none" style="font-size: 24px;"><span style="color: #658cd9;">Đăng xuất</span></p>\
                     <p class="none" style="font-size: 24px;"> </p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page271612227-layer-text292740648" style="position: absolute; left: 315px; top: 1440px; width: 139px; height: 37px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text292740648" data-review-reference-id="text292740648">\
         <div class="stencil-wrapper" style="width: 139px; height: 37px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline12"><p><span style="font-size: 32px; color: #658cd9;">Thống kê</span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page271612227-layer-icon463696794" style="position: absolute; left: 340px; top: 1565px; width: 32px; height: 32px" data-interactive-element-type="fonticon.icon" class="icon stencil mobile-interaction-potential-trigger " data-stencil-id="icon463696794" data-review-reference-id="icon463696794">\
         <div class="stencil-wrapper" style="width: 32px; height: 32px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" style="width:32px;height:32px;" title="">\
               <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" class="fill-blue">\
                  <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#icon-glyph-e052"></use>\
               </svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page271612227-layer-text11504227" style="position: absolute; left: 390px; top: 1570px; width: 55px; height: 20px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text11504227" data-review-reference-id="text11504227">\
         <div class="stencil-wrapper" style="width: 55px; height: 20px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline32"><p><span style="font-size: 18px;">Views</span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page271612227-layer-icon356173002" style="position: absolute; left: 485px; top: 1565px; width: 32px; height: 32px" data-interactive-element-type="fonticon.icon" class="icon stencil mobile-interaction-potential-trigger " data-stencil-id="icon356173002" data-review-reference-id="icon356173002">\
         <div class="stencil-wrapper" style="width: 32px; height: 32px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" style="width:32px;height:32px;" title="">\
               <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" class="fill-blue">\
                  <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#icon-glyph-e044"></use>\
               </svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page271612227-layer-text154822595" style="position: absolute; left: 535px; top: 1570px; width: 66px; height: 20px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text154822595" data-review-reference-id="text154822595">\
         <div class="stencil-wrapper" style="width: 66px; height: 20px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline32"><p><span style="font-size: 18px;">Visitors</span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page271612227-layer-icon380171137" style="position: absolute; left: 615px; top: 1565px; width: 32px; height: 32px" data-interactive-element-type="fonticon.icon" class="icon stencil mobile-interaction-potential-trigger " data-stencil-id="icon380171137" data-review-reference-id="icon380171137">\
         <div class="stencil-wrapper" style="width: 32px; height: 32px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" style="width:32px;height:32px;" title="">\
               <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" class="fill-blue">\
                  <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#icon-glyph-e007"></use>\
               </svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page271612227-layer-text608930030" style="position: absolute; left: 655px; top: 1570px; width: 113px; height: 20px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text608930030" data-review-reference-id="text608930030">\
         <div class="stencil-wrapper" style="width: 113px; height: 20px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline32"><p class="none" style="font-size: 18px;">Đăng kí mới </p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page271612227-layer-text289762378" style="position: absolute; left: 305px; top: 1515px; width: 226px; height: 28px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text289762378" data-review-reference-id="text289762378">\
         <div class="stencil-wrapper" style="width: 226px; height: 28px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline22"><p><span style="font-size: 24px; color: #658cd9;">Thống kê trong ngày</span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page271612227-layer-icon297474552" style="position: absolute; left: 980px; top: 1565px; width: 32px; height: 32px" data-interactive-element-type="fonticon.icon" class="icon stencil mobile-interaction-potential-trigger " data-stencil-id="icon297474552" data-review-reference-id="icon297474552">\
         <div class="stencil-wrapper" style="width: 32px; height: 32px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" style="width:32px;height:32px;" title="">\
               <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" class="fill-blue">\
                  <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#icon-glyph-e310"></use>\
               </svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page271612227-layer-text244109582" style="position: absolute; left: 1020px; top: 1570px; width: 118px; height: 20px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text244109582" data-review-reference-id="text244109582">\
         <div class="stencil-wrapper" style="width: 118px; height: 20px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline32"><p><span style="font-size: 18px;">Nhận xét mới</span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page271612227-layer-text673474919" style="position: absolute; left: 360px; top: 1605px; width: 77px; height: 37px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text673474919" data-review-reference-id="text673474919">\
         <div class="stencil-wrapper" style="width: 77px; height: 37px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline12"><p><span style="font-size: 32px;">2563</span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page271612227-layer-text628782145" style="position: absolute; left: 495px; top: 1605px; width: 59px; height: 37px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text628782145" data-review-reference-id="text628782145">\
         <div class="stencil-wrapper" style="width: 59px; height: 37px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline12"><p><span style="font-size: 32px;">142</span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page271612227-layer-text80495280" style="position: absolute; left: 665px; top: 1605px; width: 42px; height: 37px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text80495280" data-review-reference-id="text80495280">\
         <div class="stencil-wrapper" style="width: 42px; height: 37px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline12"><p><span style="font-size: 32px;">12</span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page271612227-layer-text748817498" style="position: absolute; left: 1040px; top: 1605px; width: 42px; height: 37px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text748817498" data-review-reference-id="text748817498">\
         <div class="stencil-wrapper" style="width: 42px; height: 37px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline12"><p><span style="font-size: 32px;">12</span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page271612227-layer-icon216596433" style="position: absolute; left: 1150px; top: 1565px; width: 32px; height: 32px" data-interactive-element-type="fonticon.icon" class="icon stencil mobile-interaction-potential-trigger " data-stencil-id="icon216596433" data-review-reference-id="icon216596433">\
         <div class="stencil-wrapper" style="width: 32px; height: 32px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" style="width:32px;height:32px;" title="">\
               <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" class="fill-blue">\
                  <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#icon-glyph-e203"></use>\
               </svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page271612227-layer-text164821205" style="position: absolute; left: 1185px; top: 1570px; width: 89px; height: 20px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text164821205" data-review-reference-id="text164821205">\
         <div class="stencil-wrapper" style="width: 89px; height: 20px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline32"><p class="none" style="font-size: 18px;">Đơn hàng </p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page271612227-layer-text988426186" style="position: absolute; left: 1205px; top: 1605px; width: 42px; height: 37px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text988426186" data-review-reference-id="text988426186">\
         <div class="stencil-wrapper" style="width: 42px; height: 37px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline12"><p><span style="font-size: 32px;">26</span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page271612227-layer-text955728268" style="position: absolute; left: 310px; top: 1680px; width: 166px; height: 28px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text955728268" data-review-reference-id="text955728268">\
         <div class="stencil-wrapper" style="width: 166px; height: 28px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline22"><p class="none" style="font-size: 24px;"><span style="color: #658cd9;">Thống kê tổng </span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page271612227-layer-icon866859006" style="position: absolute; left: 345px; top: 1740px; width: 32px; height: 32px" data-interactive-element-type="fonticon.icon" class="icon stencil mobile-interaction-potential-trigger " data-stencil-id="icon866859006" data-review-reference-id="icon866859006">\
         <div class="stencil-wrapper" style="width: 32px; height: 32px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" style="width:32px;height:32px;" title="">\
               <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" class="fill-blue">\
                  <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#icon-glyph-e021"></use>\
               </svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page271612227-layer-text14344760" style="position: absolute; left: 390px; top: 1745px; width: 131px; height: 20px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text14344760" data-review-reference-id="text14344760">\
         <div class="stencil-wrapper" style="width: 131px; height: 20px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline32"><p class="none" style="font-size: 18px;">Chủ cửa hàng </p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page271612227-layer-icon660216018" style="position: absolute; left: 535px; top: 1740px; width: 32px; height: 32px" data-interactive-element-type="fonticon.icon" class="icon stencil mobile-interaction-potential-trigger " data-stencil-id="icon660216018" data-review-reference-id="icon660216018">\
         <div class="stencil-wrapper" style="width: 32px; height: 32px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" style="width:32px;height:32px;" title="">\
               <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" class="fill-blue">\
                  <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#icon-glyph-e004"></use>\
               </svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page271612227-layer-text845570909" style="position: absolute; left: 580px; top: 1750px; width: 105px; height: 20px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text845570909" data-review-reference-id="text845570909">\
         <div class="stencil-wrapper" style="width: 105px; height: 20px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline32"><p class="none" style="font-size: 18px;">Thực khách</p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page271612227-layer-text638612662" style="position: absolute; left: 755px; top: 1745px; width: 137px; height: 20px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text638612662" data-review-reference-id="text638612662">\
         <div class="stencil-wrapper" style="width: 137px; height: 20px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline32"><p><span style="font-size: 18px;">Giá trị giao dịch</span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page271612227-layer-icon521107790" style="position: absolute; left: 710px; top: 1740px; width: 32px; height: 32px" data-interactive-element-type="fonticon.icon" class="icon stencil mobile-interaction-potential-trigger " data-stencil-id="icon521107790" data-review-reference-id="icon521107790">\
         <div class="stencil-wrapper" style="width: 32px; height: 32px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" style="width:32px;height:32px;" title="">\
               <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" class="fill-blue">\
                  <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#icon-glyph-e228"></use>\
               </svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page271612227-layer-icon77868297" style="position: absolute; left: 935px; top: 1740px; width: 32px; height: 32px" data-interactive-element-type="fonticon.icon" class="icon stencil mobile-interaction-potential-trigger " data-stencil-id="icon77868297" data-review-reference-id="icon77868297">\
         <div class="stencil-wrapper" style="width: 32px; height: 32px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" style="width:32px;height:32px;" title="">\
               <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" class="fill-blue">\
                  <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#icon-glyph-e203"></use>\
               </svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page271612227-layer-text892191880" style="position: absolute; left: 980px; top: 1745px; width: 95px; height: 20px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text892191880" data-review-reference-id="text892191880">\
         <div class="stencil-wrapper" style="width: 95px; height: 20px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline32"><p class="none" style="font-size: 18px;">Đơn hàng </p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page271612227-layer-icon868419500" style="position: absolute; left: 1100px; top: 1740px; width: 32px; height: 32px" data-interactive-element-type="fonticon.icon" class="icon stencil mobile-interaction-potential-trigger " data-stencil-id="icon868419500" data-review-reference-id="icon868419500">\
         <div class="stencil-wrapper" style="width: 32px; height: 32px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" style="width:32px;height:32px;" title="">\
               <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" class="fill-blue">\
                  <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#icon-glyph-e050"></use>\
               </svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page271612227-layer-text472859988" style="position: absolute; left: 1155px; top: 1745px; width: 178px; height: 20px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text472859988" data-review-reference-id="text472859988">\
         <div class="stencil-wrapper" style="width: 178px; height: 20px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline32"><p class="none" style="font-size: 18px;">Đánh giá trung bình </p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page271612227-layer-text568304008" style="position: absolute; left: 400px; top: 1800px; width: 69px; height: 37px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text568304008" data-review-reference-id="text568304008">\
         <div class="stencil-wrapper" style="width: 69px; height: 37px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline12"><p class="none" style="font-size: 32px;">210 </p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page271612227-layer-text415412555" style="position: absolute; left: 570px; top: 1800px; width: 59px; height: 37px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text415412555" data-review-reference-id="text415412555">\
         <div class="stencil-wrapper" style="width: 59px; height: 37px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline12"><p><span style="font-size: 32px;">489</span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page271612227-layer-text213620098" style="position: absolute; left: 740px; top: 1805px; width: 137px; height: 31px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text213620098" data-review-reference-id="text213620098">\
         <div class="stencil-wrapper" style="width: 137px; height: 31px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline12"><p><span style="font-size: 26px;">23.246.000</span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page271612227-layer-text116651954" style="position: absolute; left: 990px; top: 1800px; width: 59px; height: 37px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text116651954" data-review-reference-id="text116651954">\
         <div class="stencil-wrapper" style="width: 59px; height: 37px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline12"><p class="none" style="font-size: 32px;">568</p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page271612227-layer-text548221057" style="position: absolute; left: 1190px; top: 1800px; width: 50px; height: 37px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text548221057" data-review-reference-id="text548221057">\
         <div class="stencil-wrapper" style="width: 50px; height: 37px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline12"><p><span style="font-size: 32px;">3.5</span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page271612227-layer-text589256156" style="position: absolute; left: 315px; top: 1860px; width: 215px; height: 28px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text589256156" data-review-reference-id="text589256156">\
         <div class="stencil-wrapper" style="width: 215px; height: 28px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline22"><p><span style="font-size: 24px; color: #658cd9;">Thống kê đơn hàng</span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page271612227-layer-837931805" style="position: absolute; left: 1160px; top: 2050px; width: 176px; height: 23px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="837931805" data-review-reference-id="837931805">\
         <div class="stencil-wrapper" style="width: 176px; height: 23px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline32"><p class="none" style="font-size: 18px;"><span style="color: #b1c51a; font-size: 20px;">Đã thanh toán: 374</span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page271612227-layer-910786443" style="position: absolute; left: 1160px; top: 2080px; width: 108px; height: 23px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="910786443" data-review-reference-id="910786443">\
         <div class="stencil-wrapper" style="width: 108px; height: 23px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline32"><p class="none" style="font-size: 18px;"><span style="color: #f2a63f; font-size: 20px;">Đã hủy: 59 </span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page271612227-layer-815507455" style="position: absolute; left: 1160px; top: 1990px; width: 189px; height: 23px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="815507455" data-review-reference-id="815507455">\
         <div class="stencil-wrapper" style="width: 189px; height: 23px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline32"><p><span style="font-size: 20px; color: #658cd9;">Chờ thanh toán: 124</span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page271612227-layer-682707788" style="position: absolute; left: 1160px; top: 2020px; width: 178px; height: 23px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="682707788" data-review-reference-id="682707788">\
         <div class="stencil-wrapper" style="width: 178px; height: 23px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline32"><p class="none" style="font-size: 18px;"><span style="font-size: 20px; color: #d96666;">Chưa xác nhận : 34</span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page271612227-layer-1560535390" style="position: absolute; left: 790px; top: 1890px; width: 360px; height: 360px" data-interactive-element-type="fonticon.icon" class="icon stencil mobile-interaction-potential-trigger " data-stencil-id="1560535390" data-review-reference-id="1560535390">\
         <div class="stencil-wrapper" style="width: 360px; height: 360px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" style="width:360px;height:360px;" title="">\
               <svg xmlns="http://www.w3.org/2000/svg" width="360" height="360" class="fill-black">\
                  <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#icon-glyph-e043"></use>\
               </svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page271612227-layer-1563436380" style="position: absolute; left: 600px; top: 2050px; width: 94px; height: 23px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="1563436380" data-review-reference-id="1563436380">\
         <div class="stencil-wrapper" style="width: 94px; height: 23px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline32"><p class="none" style="font-size: 18px;"><span style="color: #b1c51a; font-size: 20px;">Bufet: 374</span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page271612227-layer-1059445969" style="position: absolute; left: 600px; top: 2080px; width: 125px; height: 23px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="1059445969" data-review-reference-id="1059445969">\
         <div class="stencil-wrapper" style="width: 125px; height: 23px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline32"><p class="none" style="font-size: 18px;"><span style="color: #f2a63f; font-size: 20px;">Tùy chọn: 59 </span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page271612227-layer-931132211" style="position: absolute; left: 600px; top: 1990px; width: 81px; height: 23px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="931132211" data-review-reference-id="931132211">\
         <div class="stencil-wrapper" style="width: 81px; height: 23px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline32"><p><span style="font-size: 20px; color: #658cd9;">Lẩu: 124</span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page271612227-layer-344698266" style="position: absolute; left: 600px; top: 2020px; width: 101px; height: 23px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="344698266" data-review-reference-id="344698266">\
         <div class="stencil-wrapper" style="width: 101px; height: 23px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline32"><p class="none" style="font-size: 18px;"><span style="font-size: 20px; color: #d96666;">Nướng: 34</span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page271612227-layer-1262139680" style="position: absolute; left: 230px; top: 1890px; width: 360px; height: 360px" data-interactive-element-type="fonticon.icon" class="icon stencil mobile-interaction-potential-trigger " data-stencil-id="1262139680" data-review-reference-id="1262139680">\
         <div class="stencil-wrapper" style="width: 360px; height: 360px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" style="width:360px;height:360px;" title="">\
               <svg xmlns="http://www.w3.org/2000/svg" width="360" height="360" class="fill-black">\
                  <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#icon-glyph-e043"></use>\
               </svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page271612227-layer-text986626586" style="position: absolute; left: 565px; top: 1900px; width: 321px; height: 28px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text986626586" data-review-reference-id="text986626586">\
         <div class="stencil-wrapper" style="width: 321px; height: 28px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline22"><p class="none" style="font-size: 24px;">Đơn hàng từ 350 thực khách </p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page271612227-layer-text814209321" style="position: absolute; left: 600px; top: 2115px; width: 82px; height: 20px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text814209321" data-review-reference-id="text814209321">\
         <div class="stencil-wrapper" style="width: 82px; height: 20px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline32"><p><span style="font-size: 18px; color: #d9d9d9;">Chay: 56</span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page271612227-layer-chart57168250" style="position: absolute; left: 285px; top: 2305px; width: 955px; height: 450px" data-interactive-element-type="static.chart" class="chart stencil mobile-interaction-potential-trigger " data-stencil-id="chart57168250" data-review-reference-id="chart57168250">\
         <div class="stencil-wrapper" style="width: 955px; height: 450px">\
            <div title="">\
               <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" style="height: 450px;width:955px;" viewBox="0 0 955 450" width="955" height="450">\
                  <svg:g width="955" height="450">\
                     <svg:g xmlns:xi="http://www.w3.org/2001/XInclude" transform="scale(5.305555555555555, 3)">\
                        <svg:rect x="0" y="0" width="180" height="150" style="fill:white;stroke:none;"></svg:rect>\
                        <svg:g name="line" style="fill:none;stroke:black;stroke-width:1px;">\
                           <svg:path d="M 9,3 L 9,140 L 168,140 L 176,140"></svg:path>\
                           <svg:path d="M 167,135 L 177,140 L 167,145"></svg:path>\
                           <svg:path d="M 4,13 L 9,3 L 14,13"></svg:path>\
                           <svg:path d="M 9,140 L 30,112 L 46,98 L 54,106 L 68,89 L 74,82 L 76,74 L 82,67 L 92,96 L 97,76 L 106,66 L 111,50 L 122,37 L 127,45 L 129,51 L 139,51 L 151,29 L 159,26 L 161,16 L 166,12"></svg:path>\
                           <svg:path d="M 10,140 L 18,107 L 29,91 L 34,73 L 44,80 L 51,55 L 62,52 L 74,34 L 86,51 L 99,43 L 111,59 L 121,70 L 128,98 L 139,119 L 147,103 L 154,125 L 165,136"></svg:path>\
                        </svg:g>\
                     </svg:g>\
                  </svg:g>\
               </svg:svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page271612227-layer-text374185035" style="position: absolute; left: 325px; top: 2245px; width: 259px; height: 28px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text374185035" data-review-reference-id="text374185035">\
         <div class="stencil-wrapper" style="width: 259px; height: 28px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline22"><p><span style="font-size: 24px; color: #658cd9;">Thống kê theo thời gian</span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page271612227-layer-icon873397376" style="position: absolute; left: 400px; top: 2755px; width: 32px; height: 32px" data-interactive-element-type="fonticon.icon" class="icon stencil mobile-interaction-potential-trigger " data-stencil-id="icon873397376" data-review-reference-id="icon873397376">\
         <div class="stencil-wrapper" style="width: 32px; height: 32px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" style="width:32px;height:32px;" title="">\
               <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" class="fill-blue">\
                  <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#icon-glyph-e052"></use>\
               </svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page271612227-layer-icon161794730" style="position: absolute; left: 515px; top: 2755px; width: 32px; height: 32px" data-interactive-element-type="fonticon.icon" class="icon stencil mobile-interaction-potential-trigger " data-stencil-id="icon161794730" data-review-reference-id="icon161794730">\
         <div class="stencil-wrapper" style="width: 32px; height: 32px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" style="width:32px;height:32px;" title="">\
               <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" class="fill-blue">\
                  <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#icon-glyph-e004"></use>\
               </svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page271612227-layer-icon584919311" style="position: absolute; left: 630px; top: 2755px; width: 32px; height: 32px" data-interactive-element-type="fonticon.icon" class="icon stencil mobile-interaction-potential-trigger " data-stencil-id="icon584919311" data-review-reference-id="icon584919311">\
         <div class="stencil-wrapper" style="width: 32px; height: 32px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" style="width:32px;height:32px;" title="">\
               <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" class="fill-blue">\
                  <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#icon-glyph-e203"></use>\
               </svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page271612227-layer-icon778384437" style="position: absolute; left: 735px; top: 2755px; width: 32px; height: 32px" data-interactive-element-type="fonticon.icon" class="icon stencil mobile-interaction-potential-trigger " data-stencil-id="icon778384437" data-review-reference-id="icon778384437">\
         <div class="stencil-wrapper" style="width: 32px; height: 32px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" style="width:32px;height:32px;" title="">\
               <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" class="fill-blue">\
                  <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#icon-glyph-e007"></use>\
               </svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page271612227-layer-icon520909763" style="position: absolute; left: 840px; top: 2755px; width: 32px; height: 32px" data-interactive-element-type="fonticon.icon" class="icon stencil mobile-interaction-potential-trigger " data-stencil-id="icon520909763" data-review-reference-id="icon520909763">\
         <div class="stencil-wrapper" style="width: 32px; height: 32px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" style="width:32px;height:32px;" title="">\
               <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" class="fill-blue">\
                  <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#icon-glyph-e228"></use>\
               </svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page271612227-layer-datepicker142658128" style="position: absolute; left: 815px; top: 2245px; width: 150px; height: 30px" data-interactive-element-type="default.datepicker" class="datepicker stencil mobile-interaction-potential-trigger " data-stencil-id="datepicker142658128" data-review-reference-id="datepicker142658128">\
         <div class="stencil-wrapper" style="width: 150px; height: 30px">\
            <div>\
               <div style="position:absolute; white-space: nowrap;" title=""><input type="text" style="width:114px; height:28px;padding: 0px;border-width:1px;" id="__containerId__-page271612227-layer-datepicker142658128_input" /><button type="button" style="width:34px; height:28px; vertical-align: top; padding: 0px;border-width:1px;" id="__containerId__-page271612227-layer-datepicker142658128_button"><img src="../resources/icons/date.png" /></button></div>\
               <div id="__containerId__-page271612227-layer-datepicker142658128_ov" class="yui-skin-sam" style="position: absolute; width: 16em;visibility:visible;">\
                  <div id="__containerId__-page271612227-layer-datepicker142658128_cal"></div>\
               </div><script type="text/javascript">\
				rabbit.stencils.datepicker.setupDatepicker("__containerId__-page271612227-layer-datepicker142658128");\
			</script></div>\
         </div>\
      </div>\
      <div id="__containerId__-page271612227-layer-datepicker318945540" style="position: absolute; left: 1035px; top: 2245px; width: 150px; height: 30px" data-interactive-element-type="default.datepicker" class="datepicker stencil mobile-interaction-potential-trigger " data-stencil-id="datepicker318945540" data-review-reference-id="datepicker318945540">\
         <div class="stencil-wrapper" style="width: 150px; height: 30px">\
            <div>\
               <div style="position:absolute; white-space: nowrap;" title=""><input type="text" style="width:114px; height:28px;padding: 0px;border-width:1px;" id="__containerId__-page271612227-layer-datepicker318945540_input" /><button type="button" style="width:34px; height:28px; vertical-align: top; padding: 0px;border-width:1px;" id="__containerId__-page271612227-layer-datepicker318945540_button"><img src="../resources/icons/date.png" /></button></div>\
               <div id="__containerId__-page271612227-layer-datepicker318945540_ov" class="yui-skin-sam" style="position: absolute; width: 16em;visibility:visible;">\
                  <div id="__containerId__-page271612227-layer-datepicker318945540_cal"></div>\
               </div><script type="text/javascript">\
				rabbit.stencils.datepicker.setupDatepicker("__containerId__-page271612227-layer-datepicker318945540");\
			</script></div>\
         </div>\
      </div>\
      <div id="__containerId__-page271612227-layer-icon521035252" style="position: absolute; left: 975px; top: 2245px; width: 32px; height: 32px" data-interactive-element-type="fonticon.icon" class="icon stencil mobile-interaction-potential-trigger " data-stencil-id="icon521035252" data-review-reference-id="icon521035252">\
         <div class="stencil-wrapper" style="width: 32px; height: 32px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" style="width:32px;height:32px;" title="">\
               <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" class="fill-black">\
                  <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#icon-glyph-e212"></use>\
               </svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page271612227-layer-1078109739" style="position: absolute; left: 70px; top: 445px; width: 146px; height: 28px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="1078109739" data-review-reference-id="1078109739">\
         <div class="stencil-wrapper" style="width: 146px; height: 28px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline22"><p class="none" style="font-size: 24px;"><span style="color: #658cd9;">Quản lí Web</span> </p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page271612227-layer-936737504" style="position: absolute; left: 25px; top: 440px; width: 32px; height: 32px" data-interactive-element-type="fonticon.icon" class="icon stencil mobile-interaction-potential-trigger " data-stencil-id="936737504" data-review-reference-id="936737504">\
         <div class="stencil-wrapper" style="width: 32px; height: 32px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" style="width:32px;height:32px;" title="">\
               <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" class="fill-blue">\
                  <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#icon-glyph-e281"></use>\
               </svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page271612227-layer-icon638930188" style="position: absolute; left: 780px; top: 1565px; width: 32px; height: 32px" data-interactive-element-type="fonticon.icon" class="icon stencil mobile-interaction-potential-trigger " data-stencil-id="icon638930188" data-review-reference-id="icon638930188">\
         <div class="stencil-wrapper" style="width: 32px; height: 32px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" style="width:32px;height:32px;" title="">\
               <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" class="fill-blue">\
                  <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#icon-glyph-e021"></use>\
               </svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page271612227-layer-text702135114" style="position: absolute; left: 815px; top: 1575px; width: 95px; height: 17px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text702135114" data-review-reference-id="text702135114">\
         <div class="stencil-wrapper" style="width: 95px; height: 17px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.text2"><p style="font-size: 14px;">Nhà hàng mới</p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page271612227-layer-arrow53562341" style="position: absolute; left: 265px; top: 2810px; width: 965px; height: 33px" data-interactive-element-type="static.line" class="line stencil mobile-interaction-potential-trigger " data-stencil-id="arrow53562341" data-review-reference-id="arrow53562341">\
         <div class="stencil-wrapper" style="width: 965px; height: 33px">\
            <div title="">\
               <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" style="position: absolute; left: -5px; top: -5px; height: 43px;width:975px;" viewBox="-5 -5 975 43" width="975" height="43">\
                  <svg:path d="M 0,16.5 L 965,16.5" marker-start="" marker-end="" style="fill:none; stroke-width:2px;stroke:black;"></svg:path>\
               </svg:svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page271612227-layer-table566536323" style="position: absolute; left: 330px; top: 765px; width: 682px; height: 148px" data-interactive-element-type="default.table" class="table stencil mobile-interaction-potential-trigger " data-stencil-id="table566536323" data-review-reference-id="table566536323">\
         <div class="stencil-wrapper" style="width: 682px; height: 148px">\
            <div title=""><table width=\'672.0\' height=\'148.0\' cellspacing=\'0\' class=\'tableStyle\'><tr style=\'height: 37px\'><td style=\'width:34px;\' class=\'tableCells\'><span\
               style=\'\'>Mã số</span><br /></td><td style=\'width:55px;\' class=\'tableCells\'><span style=\'\'>Họ tên</span><br /></td><td style=\'width:66px;\'\
               class=\'tableCells\'><span style=\'\'>SĐT</span><br /></td><td style=\'width:74px;\' class=\'tableCells\'><span style=\'\'>Số đơn hàng</span><br\
               /></td><td style=\'width:56px;\' class=\'tableCells\'><span style=\'\'>Trạng thái</span><br /></td><td style=\'width:57px;\' class=\'tableCells\'><span\
               style=\'\'>Nhà Hàng</span><br /></td><td style=\'width:36px;\' class=\'tableCells\'><span style=\'\'>Uy Tín</span><br /></td><td style=\'width:64px;\'\
               class=\'tableCells\'><span style=\'\'>Phí phải trả</span><br /></td></tr><tr style=\'height: 37px\'><td style=\'width:34px;\' class=\'tableCells\'><span\
               style=\'\'>1</span><br /></td><td style=\'width:55px;\' class=\'tableCells\'><span style=\'\'>Nguyễn A</span><br /></td><td style=\'width:66px;\'\
               class=\'tableCells\'><span style=\'\'>012153452</span><br /></td><td style=\'width:74px;\' class=\'tableCells\'><span style=\'\'>23</span><br\
               /></td><td style=\'width:56px;\' class=\'tableCells\'><span style=\'\'>Active</span><br /></td><td style=\'width:57px;\' class=\'tableCells\'><span\
               style=\'\'>Nhà A</span><br /></td><td style=\'width:36px;\' class=\'tableCells\'><span style=\'\'>3</span><br /></td><td style=\'width:64px;\'\
               class=\'tableCells\'><span style=\'\'>0</span><br /></td></tr><tr style=\'height: 37px\'><td style=\'width:34px;\' class=\'tableCells\'><span\
               style=\'\'>2</span><br /></td><td style=\'width:55px;\' class=\'tableCells\'><span style=\'\'>TRần B</span><br /></td><td style=\'width:66px;\'\
               class=\'tableCells\'><span style=\'\'>016844245</span><br /></td><td style=\'width:74px;\' class=\'tableCells\'><span style=\'\'>47</span><br\
               /></td><td style=\'width:56px;\' class=\'tableCells\'><span style=\'\'>Active</span><br /></td><td style=\'width:57px;\' class=\'tableCells\'><span\
               style=\'\'>Nhà B</span><br /></td><td style=\'width:36px;\' class=\'tableCells\'><span style=\'\'>2</span><br /></td><td style=\'width:64px;\'\
               class=\'tableCells\'><span style=\'\'>0</span><br /></td></tr><tr style=\'height: 37px\'><td style=\'width:34px;\' class=\'tableCells\'><span\
               style=\'\'>3</span><br /></td><td style=\'width:55px;\' class=\'tableCells\'><span style=\'\'>Nguyễn C</span><br /></td><td style=\'width:66px;\'\
               class=\'tableCells\'><span style=\'\'>016844245</span><br /></td><td style=\'width:74px;\' class=\'tableCells\'><span style=\'\'>112</span><br\
               /></td><td style=\'width:56px;\' class=\'tableCells\'><span style=\'\'>Deactive</span><br /></td><td style=\'width:57px;\' class=\'tableCells\'><span\
               style=\'\'>Nhà C</span><br /></td><td style=\'width:36px;\' class=\'tableCells\'><span style=\'\'>4</span><br /></td><td style=\'width:64px;\'\
               class=\'tableCells\'><span style=\'\'>10.000</span><br /></td></tr></table>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page271612227-layer-datepicker381481445" style="position: absolute; left: 400px; top: 690px; width: 150px; height: 30px" data-interactive-element-type="default.datepicker" class="datepicker stencil mobile-interaction-potential-trigger " data-stencil-id="datepicker381481445" data-review-reference-id="datepicker381481445">\
         <div class="stencil-wrapper" style="width: 150px; height: 30px">\
            <div>\
               <div style="position:absolute; white-space: nowrap;" title=""><input type="text" style="width:114px; height:28px;padding: 0px;border-width:1px;" id="__containerId__-page271612227-layer-datepicker381481445_input" /><button type="button" style="width:34px; height:28px; vertical-align: top; padding: 0px;border-width:1px;" id="__containerId__-page271612227-layer-datepicker381481445_button"><img src="../resources/icons/date.png" /></button></div>\
               <div id="__containerId__-page271612227-layer-datepicker381481445_ov" class="yui-skin-sam" style="position: absolute; width: 16em;visibility:visible;">\
                  <div id="__containerId__-page271612227-layer-datepicker381481445_cal"></div>\
               </div><script type="text/javascript">\
				rabbit.stencils.datepicker.setupDatepicker("__containerId__-page271612227-layer-datepicker381481445");\
			</script></div>\
         </div>\
      </div>\
      <div id="__containerId__-page271612227-layer-datepicker148793522" style="position: absolute; left: 665px; top: 690px; width: 150px; height: 30px" data-interactive-element-type="default.datepicker" class="datepicker stencil mobile-interaction-potential-trigger " data-stencil-id="datepicker148793522" data-review-reference-id="datepicker148793522">\
         <div class="stencil-wrapper" style="width: 150px; height: 30px">\
            <div>\
               <div style="position:absolute; white-space: nowrap;" title=""><input type="text" style="width:114px; height:28px;padding: 0px;border-width:1px;" id="__containerId__-page271612227-layer-datepicker148793522_input" /><button type="button" style="width:34px; height:28px; vertical-align: top; padding: 0px;border-width:1px;" id="__containerId__-page271612227-layer-datepicker148793522_button"><img src="../resources/icons/date.png" /></button></div>\
               <div id="__containerId__-page271612227-layer-datepicker148793522_ov" class="yui-skin-sam" style="position: absolute; width: 16em;visibility:visible;">\
                  <div id="__containerId__-page271612227-layer-datepicker148793522_cal"></div>\
               </div><script type="text/javascript">\
				rabbit.stencils.datepicker.setupDatepicker("__containerId__-page271612227-layer-datepicker148793522");\
			</script></div>\
         </div>\
      </div>\
      <div id="__containerId__-page271612227-layer-text592765247" style="position: absolute; left: 355px; top: 695px; width: 29px; height: 20px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text592765247" data-review-reference-id="text592765247">\
         <div class="stencil-wrapper" style="width: 29px; height: 20px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline32"><p><span style="font-size: 18px;">Từ</span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page271612227-layer-text45589307" style="position: absolute; left: 620px; top: 695px; width: 46px; height: 20px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text45589307" data-review-reference-id="text45589307">\
         <div class="stencil-wrapper" style="width: 46px; height: 20px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline32"><p class="none" style="font-size: 18px;">Đến </p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page271612227-layer-text229832826" style="position: absolute; left: 290px; top: 2845px; width: 177px; height: 37px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text229832826" data-review-reference-id="text229832826">\
         <div class="stencil-wrapper" style="width: 177px; height: 37px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline12"><p><span style="font-size: 32px; color: #658cd9;">Quản lí web</span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page271612227-layer-text964548013" style="position: absolute; left: 295px; top: 2910px; width: 146px; height: 28px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text964548013" data-review-reference-id="text964548013">\
         <div class="stencil-wrapper" style="width: 146px; height: 28px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline22"><p><span style="font-size: 24px;">Số điện thoại</span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page271612227-layer-textinput920362722" style="position: absolute; left: 490px; top: 2910px; width: 325px; height: 30px" data-interactive-element-type="default.textinput" class="textinput stencil mobile-interaction-potential-trigger " data-stencil-id="textinput920362722" data-review-reference-id="textinput920362722">\
         <div class="stencil-wrapper" style="width: 325px; height: 30px">\
            <div title=""><input id="__containerId__-page271612227-layer-textinput920362722input" value="" style="width:323px;height:28px;padding: 0px;border-width:1px;" type="text" /></div>\
         </div>\
      </div>\
      <div id="__containerId__-page271612227-layer-text707230980" style="position: absolute; left: 295px; top: 2970px; width: 155px; height: 28px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text707230980" data-review-reference-id="text707230980">\
         <div class="stencil-wrapper" style="width: 155px; height: 28px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline22"><p class="none" style="font-size: 24px;">Địa chỉ trụ sở </p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page271612227-layer-textinput374163465" style="position: absolute; left: 490px; top: 2970px; width: 330px; height: 30px" data-interactive-element-type="default.textinput" class="textinput stencil mobile-interaction-potential-trigger " data-stencil-id="textinput374163465" data-review-reference-id="textinput374163465">\
         <div class="stencil-wrapper" style="width: 330px; height: 30px">\
            <div title=""><input id="__containerId__-page271612227-layer-textinput374163465input" value="" style="width:328px;height:28px;padding: 0px;border-width:1px;" type="text" /></div>\
         </div>\
      </div>\
      <div id="__containerId__-page271612227-layer-text649843400" style="position: absolute; left: 295px; top: 3030px; width: 202px; height: 28px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text649843400" data-review-reference-id="text649843400">\
         <div class="stencil-wrapper" style="width: 202px; height: 28px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline22"><p><span style="font-size: 24px;">Banner quảng cáo</span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page271612227-layer-image48855182" style="position: absolute; left: 530px; top: 3025px; width: 130px; height: 130px" data-interactive-element-type="default.image" class="image stencil mobile-interaction-potential-trigger " data-stencil-id="image48855182" data-review-reference-id="image48855182">\
         <div class="stencil-wrapper" style="width: 130px; height: 130px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" title="">\
               <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" class="image-cropper" style="height: 130px;width:130px;" width="130" height="130" viewBox="0 0 130 130">\
                  <svg:g width="130" height="130">\
                     <svg:svg x="0" y="0" width="130" height="130">\
                        <svg:image width="432" height="253" xlink:href="../repoimages/506339.PNG" preserveAspectRatio="none" transform="scale(0.30092592592592593,0.5138339920948617) translate(-0,-0)  "></svg:image>\
                     </svg:svg>\
                  </svg:g>\
               </svg:svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page271612227-layer-text207434747" style="position: absolute; left: 300px; top: 3215px; width: 161px; height: 28px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text207434747" data-review-reference-id="text207434747">\
         <div class="stencil-wrapper" style="width: 161px; height: 28px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline22"><p><span style="font-size: 24px;">Banner đối tác</span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page271612227-layer-image401667591" style="position: absolute; left: 530px; top: 3210px; width: 130px; height: 130px" data-interactive-element-type="default.image" class="image stencil mobile-interaction-potential-trigger " data-stencil-id="image401667591" data-review-reference-id="image401667591">\
         <div class="stencil-wrapper" style="width: 130px; height: 130px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" title="">\
               <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" class="image-cropper" style="height: 130px;width:130px;" width="130" height="130" viewBox="0 0 130 130">\
                  <svg:g width="130" height="130">\
                     <svg:svg x="0" y="0" width="130" height="130">\
                        <svg:image width="432" height="253" xlink:href="../repoimages/506339.PNG" preserveAspectRatio="none" transform="scale(0.30092592592592593,0.5138339920948617) translate(-0,-0)  "></svg:image>\
                     </svg:svg>\
                  </svg:g>\
               </svg:svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page271612227-layer-icon109801539" style="position: absolute; left: 715px; top: 3245px; width: 64px; height: 64px" data-interactive-element-type="fonticon.icon" class="icon stencil mobile-interaction-potential-trigger " data-stencil-id="icon109801539" data-review-reference-id="icon109801539">\
         <div class="stencil-wrapper" style="width: 64px; height: 64px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" style="width:64px;height:64px;" title="">\
               <svg xmlns="http://www.w3.org/2000/svg" width="64" height="64" class="fill-black">\
                  <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#icon-glyph-e191"></use>\
               </svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page271612227-layer-icon885109286" style="position: absolute; left: 710px; top: 3060px; width: 64px; height: 64px" data-interactive-element-type="fonticon.icon" class="icon stencil mobile-interaction-potential-trigger " data-stencil-id="icon885109286" data-review-reference-id="icon885109286">\
         <div class="stencil-wrapper" style="width: 64px; height: 64px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" style="width:64px;height:64px;" title="">\
               <svg xmlns="http://www.w3.org/2000/svg" width="64" height="64" class="fill-black">\
                  <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#icon-glyph-e191"></use>\
               </svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page271612227-layer-text128644248" style="position: absolute; left: 880px; top: 2915px; width: 59px; height: 28px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text128644248" data-review-reference-id="text128644248">\
         <div class="stencil-wrapper" style="width: 59px; height: 28px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline22"><p><span style="font-size: 24px;">Logo</span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page271612227-layer-image628768360" style="position: absolute; left: 965px; top: 2875px; width: 130px; height: 130px" data-interactive-element-type="default.image" class="image stencil mobile-interaction-potential-trigger " data-stencil-id="image628768360" data-review-reference-id="image628768360">\
         <div class="stencil-wrapper" style="width: 130px; height: 130px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" title="">\
               <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" class="image-cropper" style="height: 130px;width:130px;" width="130" height="130" viewBox="0 0 130 130">\
                  <svg:g width="130" height="130">\
                     <svg:svg x="0" y="0" width="130" height="130">\
                        <svg:image width="432" height="253" xlink:href="../repoimages/506339.PNG" preserveAspectRatio="none" transform="scale(0.30092592592592593,0.5138339920948617) translate(-0,-0)  "></svg:image>\
                     </svg:svg>\
                  </svg:g>\
               </svg:svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page271612227-layer-image77752952" style="position: absolute; left: 965px; top: 2900px; width: 130px; height: 130px" data-interactive-element-type="default.image" class="image stencil mobile-interaction-potential-trigger " data-stencil-id="image77752952" data-review-reference-id="image77752952">\
         <div class="stencil-wrapper" style="width: 130px; height: 130px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" title="">\
               <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" class="image-cropper" style="height: 130px;width:130px;" width="130" height="130" viewBox="0 0 130 130">\
                  <svg:g width="130" height="130">\
                     <svg:svg x="0" y="0" width="130" height="130">\
                        <svg:image width="432" height="253" xlink:href="../repoimages/506339.PNG" preserveAspectRatio="none" transform="scale(0.30092592592592593,0.5138339920948617) translate(-0,-0)  "></svg:image>\
                     </svg:svg>\
                  </svg:g>\
               </svg:svg>\
            </div>\
         </div>\
      </div>\
   </div>\
</div>');