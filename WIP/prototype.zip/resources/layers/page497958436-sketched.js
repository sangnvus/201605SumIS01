rabbit.data.layerStore.addLayerFromHtml('<div xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:fn="http://www.w3.org/2005/xpath-functions" id="result">\
   <div xmlns:xs="http://www.w3.org/2001/XMLSchema" xmlns="http://www.w3.org/1999/xhtml" id="__containerId__page497958436-layer" class="layer" name="__containerId__pageLayer" data-layer-id="page497958436" data-layer-type="pageLayer" style="position:absolute;left:0px;top:0px;">\
      <div id="__containerId__-page497958436-layer-image513716695" style="position: absolute; left: 0px; top: 0px; width: 1366px; height: 1300px" data-interactive-element-type="default.image" class="image stencil mobile-interaction-potential-trigger " data-stencil-id="image513716695" data-review-reference-id="image513716695">\
         <div class="stencil-wrapper" style="width: 1366px; height: 1300px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" title="">\
               <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" class="image-cropper" style="height: 1300px;width:1366px;" width="1366" height="1300">\
                  <svg:g width="1366" height="1300">\
                     <svg:svg x="1" y="1" width="1364" height="1298">\
                        <svg:image width="432" height="253" xlink:href="../repoimages/506332.PNG" preserveAspectRatio="none" transform="scale(3.162037037037037,5.138339920948616) translate(-0,-0)  "></svg:image>\
                     </svg:svg>\
                  </svg:g>\
               </svg:svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page497958436-layer-image296305840" style="position: absolute; left: 0px; top: 35px; width: 1366px; height: 1300px" data-interactive-element-type="default.image" class="image stencil mobile-interaction-potential-trigger " data-stencil-id="image296305840" data-review-reference-id="image296305840">\
         <div class="stencil-wrapper" style="width: 1366px; height: 1300px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" title="">\
               <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" class="image-cropper" style="height: 1300px;width:1366px;" width="1366" height="1300">\
                  <svg:g width="1366" height="1300">\
                     <svg:svg x="1" y="1" width="1364" height="1298">\
                        <svg:image width="432" height="253" xlink:href="../repoimages/506332.PNG" preserveAspectRatio="none" transform="scale(3.162037037037037,5.138339920948616) translate(-0,-0)  "></svg:image>\
                     </svg:svg>\
                  </svg:g>\
               </svg:svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page497958436-layer-image598229695" style="position: absolute; left: 45px; top: 5px; width: 150px; height: 150px" data-interactive-element-type="default.image" class="image stencil mobile-interaction-potential-trigger " data-stencil-id="image598229695" data-review-reference-id="image598229695">\
         <div class="stencil-wrapper" style="width: 150px; height: 150px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" title="">\
               <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" class="image-cropper" style="height: 150px;width:150px;" width="150" height="150">\
                  <svg:g width="150" height="150">\
                     <svg:svg x="1" y="1" width="148" height="148">\
                        <svg:image width="80" height="60" xlink:href="../repoimages/506350.png" preserveAspectRatio="none" transform="scale(1.875,2.5) translate(-0,-0)  "></svg:image>\
                     </svg:svg>\
                  </svg:g>\
               </svg:svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page497958436-layer-icon879519200" style="position: absolute; left: 20px; top: 170px; width: 32px; height: 32px" data-interactive-element-type="fonticon.icon" class="icon stencil mobile-interaction-potential-trigger " data-stencil-id="icon879519200" data-review-reference-id="icon879519200">\
         <div class="stencil-wrapper" style="width: 32px; height: 32px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" style="width:32px;height:32px;" title="">\
               <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" class="fill-blue">\
                  <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#icon-glyph-e004"></use>\
               </svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page497958436-layer-1824273119" style="position: absolute; left: 20px; top: 215px; width: 32px; height: 32px" data-interactive-element-type="fonticon.icon" class="icon stencil mobile-interaction-potential-trigger " data-stencil-id="1824273119" data-review-reference-id="1824273119">\
         <div class="stencil-wrapper" style="width: 32px; height: 32px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" style="width:32px;height:32px;" title="">\
               <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" class="fill-blue">\
                  <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#icon-glyph-e205"></use>\
               </svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page497958436-layer-1443885442" style="position: absolute; left: 20px; top: 260px; width: 32px; height: 32px" data-interactive-element-type="fonticon.icon" class="icon stencil mobile-interaction-potential-trigger " data-stencil-id="1443885442" data-review-reference-id="1443885442">\
         <div class="stencil-wrapper" style="width: 32px; height: 32px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" style="width:32px;height:32px;" title="">\
               <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" class="fill-blue">\
                  <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#icon-glyph-e056"></use>\
               </svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page497958436-layer-535877150" style="position: absolute; left: 20px; top: 310px; width: 32px; height: 32px" data-interactive-element-type="fonticon.icon" class="icon stencil mobile-interaction-potential-trigger " data-stencil-id="535877150" data-review-reference-id="535877150">\
         <div class="stencil-wrapper" style="width: 32px; height: 32px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" style="width:32px;height:32px;" title="">\
               <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" class="fill-blue">\
                  <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#icon-glyph-e064"></use>\
               </svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page497958436-layer-text347065447" style="position: absolute; left: 60px; top: 180px; width: 179px; height: 23px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text347065447" data-review-reference-id="text347065447">\
         <div class="stencil-wrapper" style="width: 179px; height: 23px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline22"><p><span style="font-size: 20px; color: #658cd9;">Thông tin tài Khoản</span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page497958436-layer-863393734" style="position: absolute; left: 60px; top: 225px; width: 158px; height: 23px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="863393734" data-review-reference-id="863393734">\
         <div class="stencil-wrapper" style="width: 158px; height: 23px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline22"><p><span style="font-size: 20px; color: #658cd9;">Quản lí mật khẩu</span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page497958436-layer-322332929" style="position: absolute; left: 60px; top: 270px; width: 143px; height: 23px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="322332929" data-review-reference-id="322332929">\
         <div class="stencil-wrapper" style="width: 143px; height: 23px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline22"><p><span style="font-size: 20px; color: #658cd9;">Lịch sử đặt chỗ</span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page497958436-layer-1544584988" style="position: absolute; left: 60px; top: 310px; width: 104px; height: 28px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="1544584988" data-review-reference-id="1544584988">\
         <div class="stencil-wrapper" style="width: 104px; height: 28px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline22"><p class="none" style="font-size: 24px;"><span style="font-size: 20px; color: #658cd9;">Đăng xuất</span></p>\
                     <p class="none" style="font-size: 24px;"> </p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page497958436-layer-12249313" style="position: absolute; left: 305px; top: 45px; width: 284px; height: 37px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="12249313" data-review-reference-id="12249313">\
         <div class="stencil-wrapper" style="width: 284px; height: 37px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline22"><p><span style="font-size: 32px; color: #658cd9;">Thông tin tài Khoản</span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page497958436-layer-arrow45765632" style="position: absolute; left: 235px; top: 40px; width: 33px; height: 365px" data-interactive-element-type="static.line" class="line stencil mobile-interaction-potential-trigger " data-stencil-id="arrow45765632" data-review-reference-id="arrow45765632">\
         <div class="stencil-wrapper" style="width: 33px; height: 365px">\
            <div title="">\
               <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" style="position: absolute; left: -5px; top: -5px; height: 375px;width:43px;" viewBox="-5 -5 43 375" width="43" height="375"><svg:path d="M 16.00, 0.00 Q 18.26, 10.14, 17.87, 20.28 Q 17.74, 30.42, 17.29, 40.56 Q 17.27, 50.69, 17.26, 60.83 Q 16.64,\
                  70.97, 16.33, 81.11 Q 15.99, 91.25, 16.20, 101.39 Q 16.58, 111.53, 16.85, 121.67 Q 16.85, 131.81, 16.61, 141.94 Q 16.19, 152.08,\
                  16.61, 162.22 Q 15.89, 172.36, 15.61, 182.50 Q 16.02, 192.64, 16.21, 202.78 Q 16.71, 212.92, 16.72, 223.06 Q 16.77, 233.19,\
                  16.88, 243.33 Q 16.85, 253.47, 16.73, 263.61 Q 16.31, 273.75, 16.23, 283.89 Q 15.79, 294.03, 15.63, 304.17 Q 15.93, 314.31,\
                  16.61, 324.44 Q 16.03, 334.58, 15.46, 344.72 Q 16.00, 354.86, 16.00, 365.00" style="marker-start:;marker-end:" class="svg_unselected_element"/>\
               </svg:svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page497958436-layer-text626355810" style="position: absolute; left: 305px; top: 160px; width: 64px; height: 21px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text626355810" data-review-reference-id="text626355810">\
         <div class="stencil-wrapper" style="width: 64px; height: 21px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline32"><p><span style="font-size: 18px;">Họ tên:</span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page497958436-layer-textinput584172794" style="position: absolute; left: 405px; top: 150px; width: 275px; height: 30px" data-interactive-element-type="default.textinput" class="textinput stencil mobile-interaction-potential-trigger " data-stencil-id="textinput584172794" data-review-reference-id="textinput584172794">\
         <div class="stencil-wrapper" style="width: 275px; height: 30px">\
            <div>\
               <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" style="height: 30px;width:275px;" width="275" height="30">\
                  <svg:g id="__containerId__-page497958436-layer-textinput584172794svg" width="275" height="30"><svg:path id="__containerId__-page497958436-layer-textinput584172794_input_svg_border" d="M 2.00, 2.00 Q 12.42, 3.49, 22.85,\
                     2.72 Q 33.27, 1.86, 43.69, 1.72 Q 54.12, 1.77, 64.54, 1.21 Q 74.96, 0.98, 85.38, 2.11 Q 95.81, 2.41, 106.23, 2.94 Q 116.65,\
                     2.69, 127.08, 2.13 Q 137.50, 2.44, 147.92, 1.35 Q 158.35, 2.10, 168.77, 2.01 Q 179.19, 1.85, 189.62, 1.02 Q 200.04, 0.51,\
                     210.46, 1.87 Q 220.88, 2.33, 231.31, 1.40 Q 241.73, 1.28, 252.15, 0.76 Q 262.58, 1.97, 272.79, 2.21 Q 273.71, 14.76, 273.34,\
                     28.34 Q 262.64, 28.22, 252.15, 27.99 Q 241.71, 27.57, 231.31, 28.26 Q 220.88, 28.02, 210.47, 28.61 Q 200.04, 29.53, 189.62,\
                     29.72 Q 179.19, 30.17, 168.77, 30.04 Q 158.35, 29.34, 147.92, 28.14 Q 137.50, 27.75, 127.08, 27.68 Q 116.65, 28.38, 106.23,\
                     29.00 Q 95.81, 28.75, 85.38, 28.34 Q 74.96, 29.57, 64.54, 29.67 Q 54.12, 28.49, 43.69, 27.97 Q 33.27, 27.85, 22.85, 27.50\
                     Q 12.42, 28.40, 1.46, 28.54 Q 2.00, 15.00, 2.00, 2.00" style=" fill:white;" class="svg_unselected_element"/><svg:path id="__containerId__-page497958436-layer-textinput584172794_line1" d="M 3.00, 3.00 Q 13.35, 2.86, 23.69, 2.08 Q 34.04,\
                     1.91, 44.38, 1.64 Q 54.73, 2.46, 65.08, 2.34 Q 75.42, 2.47, 85.77, 1.74 Q 96.12, 2.76, 106.46, 1.86 Q 116.81, 2.14, 127.15,\
                     2.07 Q 137.50, 2.96, 147.85, 3.36 Q 158.19, 3.33, 168.54, 2.74 Q 178.88, 3.02, 189.23, 4.11 Q 199.58, 3.53, 209.92, 1.92 Q\
                     220.27, 1.87, 230.62, 2.18 Q 240.96, 2.62, 251.31, 2.54 Q 261.65, 3.00, 272.00, 3.00" style=" fill:none;" class="svg_unselected_element"/><svg:path id="__containerId__-page497958436-layer-textinput584172794_line2" d="M 3.00, 3.00 Q 3.00, 15.00, 3.00, 27.00" style="\
                     fill:none;" class="svg_unselected_element"/><svg:path id="__containerId__-page497958436-layer-textinput584172794_line3" d="M 3.00, 3.00 Q 13.35, 2.43, 23.69, 2.89 Q 34.04,\
                     1.85, 44.38, 2.75 Q 54.73, 1.89, 65.08, 1.28 Q 75.42, 1.88, 85.77, 2.48 Q 96.12, 2.20, 106.46, 1.87 Q 116.81, 1.47, 127.15,\
                     1.74 Q 137.50, 2.41, 147.85, 2.12 Q 158.19, 1.68, 168.54, 1.54 Q 178.88, 1.33, 189.23, 0.85 Q 199.58, 0.83, 209.92, 1.75 Q\
                     220.27, 1.81, 230.62, 1.75 Q 240.96, 1.12, 251.31, 2.54 Q 261.65, 3.00, 272.00, 3.00" style=" fill:none;" class="svg_unselected_element"/><svg:path id="__containerId__-page497958436-layer-textinput584172794_line4" d="M 3.00, 3.00 Q 3.00, 15.00, 3.00, 27.00" style="\
                     fill:none;" class="svg_unselected_element"/>\
                  </svg:g>\
               </svg:svg>\
               <div style="position:absolute;left: 6px; top: 1px;" title=""><input id="__containerId__-page497958436-layer-textinput584172794input" onblur="rabbit.facade.raiseEvent(rabbit.events.svgBlur, new Array(\'__containerId__-page497958436-layer-textinput584172794_input_svg_border\',\'__containerId__-page497958436-layer-textinput584172794_line1\',\'__containerId__-page497958436-layer-textinput584172794_line2\',\'__containerId__-page497958436-layer-textinput584172794_line3\',\'__containerId__-page497958436-layer-textinput584172794_line4\'))" onfocus="rabbit.facade.raiseEvent(rabbit.events.svgFocus, new Array(\'__containerId__-page497958436-layer-textinput584172794_input_svg_border\',\'__containerId__-page497958436-layer-textinput584172794_line1\',\'__containerId__-page497958436-layer-textinput584172794_line2\',\'__containerId__-page497958436-layer-textinput584172794_line3\',\'__containerId__-page497958436-layer-textinput584172794_line4\'))" value="" style="width:268px;height:28px;padding: 0px;" type="text" /></div>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page497958436-layer-2047370980" style="position: absolute; left: 405px; top: 210px; width: 275px; height: 30px" data-interactive-element-type="default.textinput" class="textinput stencil mobile-interaction-potential-trigger " data-stencil-id="2047370980" data-review-reference-id="2047370980">\
         <div class="stencil-wrapper" style="width: 275px; height: 30px">\
            <div>\
               <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" style="height: 30px;width:275px;" width="275" height="30">\
                  <svg:g id="__containerId__-page497958436-layer-2047370980svg" width="275" height="30"><svg:path id="__containerId__-page497958436-layer-2047370980_input_svg_border" d="M 2.00, 2.00 Q 12.42, 1.02, 22.85, 1.51\
                     Q 33.27, 2.18, 43.69, 1.22 Q 54.12, 1.29, 64.54, 1.99 Q 74.96, 2.04, 85.38, 1.53 Q 95.81, 0.85, 106.23, 2.27 Q 116.65, 2.26,\
                     127.08, 2.10 Q 137.50, 2.02, 147.92, 1.88 Q 158.35, 1.94, 168.77, 1.31 Q 179.19, 0.92, 189.62, 0.42 Q 200.04, 0.69, 210.46,\
                     2.16 Q 220.88, 2.46, 231.31, 1.84 Q 241.73, 1.87, 252.15, 1.57 Q 262.58, 1.28, 273.07, 1.93 Q 273.37, 14.88, 273.09, 28.09\
                     Q 262.75, 28.63, 252.18, 28.24 Q 241.73, 27.94, 231.33, 28.96 Q 220.89, 28.85, 210.47, 29.68 Q 200.04, 29.85, 189.62, 30.15\
                     Q 179.19, 29.09, 168.77, 29.76 Q 158.35, 28.00, 147.92, 27.17 Q 137.50, 27.22, 127.08, 27.37 Q 116.65, 27.87, 106.23, 28.34\
                     Q 95.81, 29.22, 85.38, 28.05 Q 74.96, 28.38, 64.54, 27.84 Q 54.12, 27.83, 43.69, 28.04 Q 33.27, 28.85, 22.85, 27.94 Q 12.42,\
                     28.42, 1.84, 28.16 Q 2.00, 15.00, 2.00, 2.00" style=" fill:white;" class="svg_unselected_element"/><svg:path id="__containerId__-page497958436-layer-2047370980_line1" d="M 3.00, 3.00 Q 13.35, 2.91, 23.69, 3.20 Q 34.04, 2.88,\
                     44.38, 3.75 Q 54.73, 2.16, 65.08, 1.91 Q 75.42, 3.02, 85.77, 3.78 Q 96.12, 3.52, 106.46, 2.10 Q 116.81, 1.21, 127.15, 1.55\
                     Q 137.50, 2.50, 147.85, 3.66 Q 158.19, 3.00, 168.54, 4.27 Q 178.88, 4.21, 189.23, 3.79 Q 199.58, 3.07, 209.92, 2.25 Q 220.27,\
                     1.25, 230.62, 1.61 Q 240.96, 1.76, 251.31, 2.01 Q 261.65, 3.00, 272.00, 3.00" style=" fill:none;" class="svg_unselected_element"/><svg:path id="__containerId__-page497958436-layer-2047370980_line2" d="M 3.00, 3.00 Q 3.00, 15.00, 3.00, 27.00" style=" fill:none;"\
                     class="svg_unselected_element"/><svg:path id="__containerId__-page497958436-layer-2047370980_line3" d="M 3.00, 3.00 Q 13.35, 2.71, 23.69, 2.86 Q 34.04, 2.75,\
                     44.38, 3.17 Q 54.73, 3.59, 65.08, 2.81 Q 75.42, 2.81, 85.77, 3.27 Q 96.12, 3.85, 106.46, 3.81 Q 116.81, 2.20, 127.15, 2.74\
                     Q 137.50, 2.28, 147.85, 2.82 Q 158.19, 3.69, 168.54, 3.24 Q 178.88, 3.82, 189.23, 3.27 Q 199.58, 3.92, 209.92, 3.55 Q 220.27,\
                     2.42, 230.62, 1.20 Q 240.96, 1.94, 251.31, 2.32 Q 261.65, 3.00, 272.00, 3.00" style=" fill:none;" class="svg_unselected_element"/><svg:path id="__containerId__-page497958436-layer-2047370980_line4" d="M 3.00, 3.00 Q 3.00, 15.00, 3.00, 27.00" style=" fill:none;"\
                     class="svg_unselected_element"/>\
                  </svg:g>\
               </svg:svg>\
               <div style="position:absolute;left: 6px; top: 1px;" title=""><input id="__containerId__-page497958436-layer-2047370980input" onblur="rabbit.facade.raiseEvent(rabbit.events.svgBlur, new Array(\'__containerId__-page497958436-layer-2047370980_input_svg_border\',\'__containerId__-page497958436-layer-2047370980_line1\',\'__containerId__-page497958436-layer-2047370980_line2\',\'__containerId__-page497958436-layer-2047370980_line3\',\'__containerId__-page497958436-layer-2047370980_line4\'))" onfocus="rabbit.facade.raiseEvent(rabbit.events.svgFocus, new Array(\'__containerId__-page497958436-layer-2047370980_input_svg_border\',\'__containerId__-page497958436-layer-2047370980_line1\',\'__containerId__-page497958436-layer-2047370980_line2\',\'__containerId__-page497958436-layer-2047370980_line3\',\'__containerId__-page497958436-layer-2047370980_line4\'))" value="" style="width:268px;height:28px;padding: 0px;" type="text" /></div>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page497958436-layer-1388442516" style="position: absolute; left: 305px; top: 220px; width: 51px; height: 21px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="1388442516" data-review-reference-id="1388442516">\
         <div class="stencil-wrapper" style="width: 51px; height: 21px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline32"><p><span style="font-size: 18px;">Email</span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page497958436-layer-1362012371" style="position: absolute; left: 305px; top: 285px; width: 91px; height: 21px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="1362012371" data-review-reference-id="1362012371">\
         <div class="stencil-wrapper" style="width: 91px; height: 21px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline32"><p><span style="font-size: 18px;">Ngày sinh:</span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page497958436-layer-59597839" style="position: absolute; left: 305px; top: 345px; width: 81px; height: 21px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="59597839" data-review-reference-id="59597839">\
         <div class="stencil-wrapper" style="width: 81px; height: 21px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline32"><p><span style="font-size: 18px;">Giới Tính</span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page497958436-layer-datepicker278696836" style="position: absolute; left: 405px; top: 275px; width: 150px; height: 30px" data-interactive-element-type="default.datepicker" class="datepicker stencil mobile-interaction-potential-trigger " data-stencil-id="datepicker278696836" data-review-reference-id="datepicker278696836">\
         <div class="stencil-wrapper" style="width: 150px; height: 30px">\
            <div>\
               <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" style="position: absolute; height: 30px;width:150px;" width="150" height="30">\
                  <svg:g width="150px" height="30px"><svg:path id="__containerId__-page497958436-layer-datepicker278696836_input_svg_border" d="M 2.00, 2.00 Q 13.20, 0.56, 24.40,\
                     0.51 Q 35.60, 1.18, 46.80, 0.82 Q 58.00, 1.54, 69.20, 2.43 Q 80.40, 1.86, 91.60, 1.46 Q 102.80, 1.34, 114.17, 1.83 Q 114.22,\
                     14.93, 114.07, 28.08 Q 102.92, 28.45, 91.62, 28.14 Q 80.40, 27.93, 69.20, 28.00 Q 58.01, 28.85, 46.81, 28.93 Q 35.60, 29.02,\
                     24.40, 28.97 Q 13.20, 28.85, 1.79, 28.21 Q 2.00, 15.00, 2.00, 2.00" style=" fill:white;" class="svg_unselected_element"/><svg:path id="__containerId__-page497958436-layer-datepicker278696836_line1" d="M 3.00, 3.00 Q 14.90, 3.48, 26.80, 3.83 Q\
                     38.70, 4.02, 50.60, 3.50 Q 62.50, 3.07, 74.40, 2.69 Q 86.30, 1.99, 98.20, 2.08 Q 110.10, 3.00, 122.00, 3.00" style=" fill:none;"\
                     class="svg_unselected_element"/><svg:path id="__containerId__-page497958436-layer-datepicker278696836_line2" d="M 3.00, 3.00 Q 3.00, 15.00, 3.00, 27.00" style="\
                     fill:none;" class="svg_unselected_element"/><svg:path id="__containerId__-page497958436-layer-datepicker278696836_line3" d="M 3.00, 3.00 Q 14.90, 2.87, 26.80, 3.37 Q\
                     38.70, 3.01, 50.60, 2.81 Q 62.50, 1.52, 74.40, 1.68 Q 86.30, 1.65, 98.20, 1.92 Q 110.10, 3.00, 122.00, 3.00" style=" fill:none;"\
                     class="svg_unselected_element"/><svg:path id="__containerId__-page497958436-layer-datepicker278696836_line4" d="M 3.00, 3.00 Q 3.00, 15.00, 3.00, 27.00" style="\
                     fill:none;" class="svg_unselected_element"/>\
                  </svg:g>\
                  <svg:g width="150px" height="30px"><svg:path id="__containerId__-page497958436-layer-datepicker278696836_input_svg_border2" d="M 118.00, 2.00 Q 133.00, 0.25,\
                     148.67, 1.33 Q 148.76, 14.75, 148.26, 28.26 Q 133.15, 28.55, 117.80, 28.17 Q 118.00, 15.00, 118.00, 2.00" style=" fill:white;"\
                     class="svg_unselected_element"/>\
                  </svg:g>\
               </svg:svg>\
               <div style="white-space: nowrap;" title=""><input type="text" onblur="rabbit.facade.raiseEvent(rabbit.events.svgBlur, new Array(\'__containerId__-page497958436-layer-datepicker278696836_input_svg_border\',\'__containerId__-page497958436-layer-datepicker278696836_line1\',\'__containerId__-page497958436-layer-datepicker278696836_line2\',\'__containerId__-page497958436-layer-datepicker278696836_line3\',\'__containerId__-page497958436-layer-datepicker278696836_line4\'))" onfocus="rabbit.facade.raiseEvent(rabbit.events.svgFocus, new Array(\'__containerId__-page497958436-layer-datepicker278696836_input_svg_border\',\'__containerId__-page497958436-layer-datepicker278696836_line1\',\'__containerId__-page497958436-layer-datepicker278696836_line2\',\'__containerId__-page497958436-layer-datepicker278696836_line3\',\'__containerId__-page497958436-layer-datepicker278696836_line4\'))" style="width:116px; height:30px;padding: 0px;border-width:1px; position: absolute;" id="__containerId__-page497958436-layer-datepicker278696836_input" /><button type="button" onblur="rabbit.facade.raiseEvent(rabbit.events.svgBlur, \'__containerId__-page497958436-layer-datepicker278696836_input_svg_border2\')" onfocus="rabbit.facade.raiseEvent(rabbit.events.svgFocus, \'__containerId__-page497958436-layer-datepicker278696836_input_svg_border2\')" style="position:absolute; left:116px; top:0px; width:34px; height:30px; vertical-align: top; padding: 0px;border-width:1px; cursor:pointer;" id="__containerId__-page497958436-layer-datepicker278696836_button"><img src="../resources/icons/date.png" /></button></div>\
               <div id="__containerId__-page497958436-layer-datepicker278696836_ov" class="yui-skin-sam" style="position: absolute; width: 16em;visibility:visible;">\
                  <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" style="position: absolute; left: -6px; top: -4px; height: 204px;width:200px;display:none" id="__containerId__-page497958436-layer-datepicker278696836_open_calendar" width="150" height="204"><svg:path id="__containerId__-page497958436-layer-datepicker278696836_open_calendar_border" d="M 2.00, 2.00 Q 12.89, 0.03,\
                     23.78, 0.53 Q 34.67, 0.88, 45.56, 1.36 Q 56.44, 0.92, 67.33, 1.97 Q 78.22, 1.19, 89.11, 1.94 Q 100.00, 1.68, 110.89, 0.86\
                     Q 121.78, 1.67, 132.67, 2.88 Q 143.56, 2.60, 154.44, 1.39 Q 165.33, 1.72, 176.22, 1.88 Q 187.11, 2.29, 197.94, 2.06 Q 198.06,\
                     11.98, 198.30, 21.96 Q 198.86, 31.94, 198.22, 41.99 Q 198.40, 51.99, 197.12, 62.01 Q 198.03, 72.00, 198.10, 82.00 Q 198.05,\
                     92.00, 199.06, 102.00 Q 198.59, 112.00, 197.83, 122.00 Q 198.24, 132.00, 198.25, 142.00 Q 197.65, 152.00, 198.30, 162.00 Q\
                     198.51, 172.00, 198.92, 182.00 Q 199.30, 192.00, 198.55, 202.55 Q 187.42, 202.93, 176.41, 203.33 Q 165.45, 203.82, 154.51,\
                     203.99 Q 143.58, 203.72, 132.68, 203.25 Q 121.78, 203.53, 110.89, 204.16 Q 100.00, 204.01, 89.11, 202.45 Q 78.22, 202.19,\
                     67.33, 202.41 Q 56.44, 202.50, 45.56, 202.62 Q 34.67, 202.30, 23.78, 202.43 Q 12.89, 203.04, 1.57, 202.43 Q 1.63, 192.12,\
                     2.08, 181.99 Q 1.88, 172.01, 2.48, 161.98 Q 2.21, 152.00, 1.49, 142.00 Q 1.76, 132.00, 1.47, 122.00 Q 1.66, 112.00, 2.80,\
                     102.00 Q 2.54, 92.00, 1.46, 82.00 Q 1.49, 72.00, 1.23, 62.00 Q 1.10, 52.00, 0.97, 42.00 Q 0.61, 32.00, 0.34, 22.00 Q 2.00,\
                     12.00, 2.00, 2.00" style=" fill:white;" class="svg_unselected_element"/>\
                  </svg:svg>\
                  <div id="__containerId__-page497958436-layer-datepicker278696836_cal"></div>\
               </div><script type="text/javascript">\
				rabbit.stencils.datepicker.setupDatepicker("__containerId__-page497958436-layer-datepicker278696836");\
			</script></div>\
         </div>\
      </div>\
      <div id="__containerId__-page497958436-layer-radiobutton285398877" style="position: absolute; left: 405px; top: 345px; width: 52px; height: 20px" data-interactive-element-type="default.radiobutton" class="radiobutton stencil mobile-interaction-potential-trigger " data-stencil-id="radiobutton285398877" data-review-reference-id="radiobutton285398877">\
         <div class="stencil-wrapper" style="width: 52px; height: 20px">\
            <div class="">\
               <div style="font-size:1.17em;" xml:space="preserve" title="" onclick="rabbit.facade.fireMouseOn(\'__containerId__-page497958436-layer-radiobutton285398877_input\');">\
                  				<input id="__containerId__-page497958436-layer-radiobutton285398877_input" xml:space="default" type="radio" style="padding-right:8px" class="hidden_class" onblur="rabbit.facade.raiseEvent(rabbit.events.svgBlur, \'__containerId__-page497958436-layer-radiobutton285398877_input_svg_border\')" onfocus="rabbit.facade.raiseEvent(rabbit.events.svgFocus, \'__containerId__-page497958436-layer-radiobutton285398877_input_svg_border\')" onclick="rabbit.facade.raiseEvent(rabbit.events.radioButtonClicked, \'__containerId__-page497958436-layer-radiobutton285398877_input\', \'__containerId__-page497958436-layer-radiobutton285398877_input_svgChecked\');" name="group1" value="__containerId__-page497958436-layer-radiobutton285398877" />\
                  				\
                  				\
                  				\
                  					Nam\
                  					\
                  				\
                  			\
               </div>\
               <div title="">\
                  <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" style="position: absolute;  top: 1.0199999999999996px; height: 20px;width:52px;cursor: pointer;" width="52" height="20" onclick="rabbit.facade.fireMouseOn(\'__containerId__-page497958436-layer-radiobutton285398877_input\');">\
                     <svg:g id="__containerId__-page497958436-layer-radiobutton285398877_input_svg" x="0" y="1.0199999999999996" width="52" height="20" onclick="rabbit.facade.fireMouseOn(\'__containerId__-page497958436-layer-radiobutton285398877_input\');"><svg:path id="__containerId__-page497958436-layer-radiobutton285398877_input_svg_border" d="M 17.00, 10.00 Q 16.57, 9.96,\
                        14.98, 13.00 Q 12.17, 14.51, 9.17, 14.82 Q 6.40, 13.12, 5.56, 9.81 Q 6.13, 6.35, 9.35, 4.48 Q 12.94, 4.40, 16.25, 6.25 Q 17.00,\
                        10.10, 15.79, 13.61" style=" fill:white;" class="svg_unselected_element"/>\
                     </svg:g>\
                     <svg:g id="__containerId__-page497958436-layer-radiobutton285398877_input_svgChecked" x="0" y="1.0199999999999996" width="52" height="20" onclick="rabbit.facade.fireMouseOn(\'__containerId__-page497958436-layer-radiobutton285398877_input\');" visibility="hidden"><svg:path d="M 13.00, 10.00 Q 13.96, 10.37, 13.23, 11.68 Q 11.65, 12.04, 10.39, 11.61 Q 9.51, 11.00, 10.03, 9.81 Q 10.36,\
                        9.31, 10.73, 8.76 Q 11.56, 8.60, 12.54, 8.94 Q 13.00, 10.03, 12.60, 11.20" style="" class="svg_unselected_element"/>\
                     </svg:g>\
                  </svg:svg>\
               </div>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page497958436-layer-1625352149" style="position: absolute; left: 490px; top: 345px; width: 41px; height: 20px" data-interactive-element-type="default.radiobutton" class="radiobutton stencil mobile-interaction-potential-trigger " data-stencil-id="1625352149" data-review-reference-id="1625352149">\
         <div class="stencil-wrapper" style="width: 41px; height: 20px">\
            <div class="">\
               <div style="font-size:1.17em;" xml:space="preserve" title="" onclick="rabbit.facade.fireMouseOn(\'__containerId__-page497958436-layer-1625352149_input\');">\
                  				<input id="__containerId__-page497958436-layer-1625352149_input" xml:space="default" type="radio" style="padding-right:8px" class="hidden_class" onblur="rabbit.facade.raiseEvent(rabbit.events.svgBlur, \'__containerId__-page497958436-layer-1625352149_input_svg_border\')" onfocus="rabbit.facade.raiseEvent(rabbit.events.svgFocus, \'__containerId__-page497958436-layer-1625352149_input_svg_border\')" onclick="rabbit.facade.raiseEvent(rabbit.events.radioButtonClicked, \'__containerId__-page497958436-layer-1625352149_input\', \'__containerId__-page497958436-layer-1625352149_input_svgChecked\');" name="group1" value="__containerId__-page497958436-layer-1625352149" />\
                  				\
                  				\
                  				\
                  					Nữ\
                  					\
                  				\
                  			\
               </div>\
               <div title="">\
                  <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" style="position: absolute;  top: 1.0199999999999996px; height: 20px;width:41px;cursor: pointer;" width="41" height="20" onclick="rabbit.facade.fireMouseOn(\'__containerId__-page497958436-layer-1625352149_input\');">\
                     <svg:g id="__containerId__-page497958436-layer-1625352149_input_svg" x="0" y="1.0199999999999996" width="41" height="20" onclick="rabbit.facade.fireMouseOn(\'__containerId__-page497958436-layer-1625352149_input\');"><svg:path id="__containerId__-page497958436-layer-1625352149_input_svg_border" d="M 17.00, 10.00 Q 17.56, 10.30, 15.54, 13.42\
                        Q 12.52, 15.24, 9.04, 15.69 Q 5.52, 14.01, 4.98, 9.90 Q 6.10, 6.33, 9.11, 3.98 Q 13.08, 3.67, 16.23, 6.27 Q 17.00, 10.10,\
                        15.79, 13.61" style=" fill:white;" class="svg_unselected_element"/>\
                     </svg:g>\
                     <svg:g id="__containerId__-page497958436-layer-1625352149_input_svgChecked" x="0" y="1.0199999999999996" width="41" height="20" onclick="rabbit.facade.fireMouseOn(\'__containerId__-page497958436-layer-1625352149_input\');" visibility="hidden"><svg:path d="M 13.00, 10.00 Q 13.87, 10.34, 13.44, 11.84 Q 12.06, 12.92, 10.24, 12.61 Q 8.94, 11.58, 8.80, 10.00 Q 9.68, 8.95,\
                        10.49, 8.24 Q 11.61, 8.31, 12.97, 8.54 Q 13.00, 10.03, 12.60, 11.20" style="" class="svg_unselected_element"/>\
                     </svg:g>\
                  </svg:svg>\
               </div>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page497958436-layer-iphoneButton869462933" style="position: absolute; left: 490px; top: 485px; width: 100px; height: 30px" data-interactive-element-type="default.iphoneButton" class="iphoneButton stencil mobile-interaction-potential-trigger " data-stencil-id="iphoneButton869462933" data-review-reference-id="iphoneButton869462933">\
         <div class="stencil-wrapper" style="width: 100px; height: 30px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" title="" style="position: absolute; left: -2px; top: -2px;height: 34px;width:104px;">\
               <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" class="helvetica-font" width="104" height="34" viewBox="-2 -2 104 34">\
                  <svg:a><svg:path d="M 4.00, 29.00 Q 2.40, 29.71, 1.02, 28.98 Q 0.29, 27.87, -0.02, 26.32 Q -0.36, 14.20, -0.32, 1.78 Q 0.59, 0.70,\
                     1.49, -0.45 Q 2.41, -1.28, 3.61, -2.23 Q 15.56, -2.29, 27.39, -2.45 Q 39.20, -2.36, 50.99, -1.55 Q 62.75, -1.50, 74.50, -1.20\
                     Q 86.25, -1.20, 98.14, -1.59 Q 99.19, -1.03, 100.24, -0.27 Q 101.25, 0.44, 101.66, 1.79 Q 101.87, 13.87, 101.72, 26.12 Q 101.52,\
                     27.34, 100.74, 28.66 Q 99.42, 29.06, 98.14, 29.44 Q 86.35, 29.66, 74.53, 29.40 Q 62.78, 29.74, 51.01, 29.78 Q 39.26, 30.02,\
                     27.50, 30.04 Q 15.75, 29.00, 4.00, 29.00" style="fill-rule:evenodd;clip-rule:evenodd;fill:#808080;stroke:#666666;" class="svg_unselected_element"/>\
                     <svg:text x="50" y="15" dy="0.3em" fill="#FFFFFF" style="font-size:1em;stroke-width:0pt;" font-family="\'HelveticaNeue-Bold\'" text-anchor="middle" xml:space="preserve">Cập nhật</svg:text>\
                  </svg:a>\
               </svg:svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page497958436-layer-1552259828" style="position: absolute; left: 305px; top: 395px; width: 161px; height: 21px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="1552259828" data-review-reference-id="1552259828">\
         <div class="stencil-wrapper" style="width: 161px; height: 21px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline32"><p><span style="font-size: 18px;">Lĩnh vực quan tâm:</span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page497958436-layer-checkbox519710206" style="position: absolute; left: 305px; top: 430px; width: 76px; height: 20px" data-interactive-element-type="default.checkbox" class="checkbox stencil mobile-interaction-potential-trigger " data-stencil-id="checkbox519710206" data-review-reference-id="checkbox519710206">\
         <div class="stencil-wrapper" style="width: 76px; height: 20px">\
            <div class="" style="font-size:1.17em;">\
               <div xml:space="preserve" title="" style="position:absolute" onclick="rabbit.facade.fireMouseOn(\'__containerId__-page497958436-layer-checkbox519710206_input\');">\
                  				\
                  <nobr>\
                     					<input id="__containerId__-page497958436-layer-checkbox519710206_input" xml:space="default" class="hidden_class" style="padding-right:9px" type="checkbox" onpropertychange="rabbit.facade.raiseEvent(rabbit.events.propertyChange, \'__containerId__-page497958436-layer-checkbox519710206_input\', \'__containerId__-page497958436-layer-checkbox519710206_input_svgChecked\');" onblur="rabbit.facade.raiseEvent(rabbit.events.svgBlur, \'__containerId__-page497958436-layer-checkbox519710206_input_svg_border\')" onfocus="rabbit.facade.raiseEvent(rabbit.events.svgFocus, \'__containerId__-page497958436-layer-checkbox519710206_input_svg_border\')" onclick="rabbit.facade.raiseEvent(rabbit.events.checkBoxClicked, \'__containerId__-page497958436-layer-checkbox519710206_input\', \'__containerId__-page497958436-layer-checkbox519710206_input_svgChecked\')" />\
                     				\
                     					\
                     					\
                     						Bar-cafe\
                     						\
                     					\
                     				\
                  </nobr>\
                  			\
               </div>\
               <div title="">\
                  <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" style="position: absolute; height: 20px;width:76px;" width="76" height="20" onclick="rabbit.facade.fireMouseOn(\'__containerId__-page497958436-layer-checkbox519710206_input\');">\
                     <svg:g id="__containerId__-page497958436-layer-checkbox519710206_input_svg" x="0" y="1.0199999999999996" width="76" height="20"><svg:path id="__containerId__-page497958436-layer-checkbox519710206_input_svg_border" d="M 5.00, 5.00 Q 10.00, 4.19, 15.36,\
                        4.64 Q 15.48, 9.84, 15.23, 15.23 Q 10.03, 15.11, 4.76, 15.21 Q 5.00, 10.00, 5.00, 5.00" style=" fill:white;" class="svg_unselected_element"/>\
                     </svg:g>\
                     <svg:g id="__containerId__-page497958436-layer-checkbox519710206_input_svgChecked" x="0" y="1.0199999999999996" width="76" height="20" visibility="hidden"><svg:path d="M 5.00, 9.00 Q 8.00, 12.00, 11.00, 15.00" style=" fill:none;" class="svg_unselected_element"/><svg:path d="M 11.00, 15.00 Q 15.50, 7.00, 20.00, -1.00" style=" fill:none;" class="svg_unselected_element"/></svg:g>\
                  </svg:svg>\
               </div>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page497958436-layer-1419803245" style="position: absolute; left: 425px; top: 430px; width: 89px; height: 20px" data-interactive-element-type="default.checkbox" class="checkbox stencil mobile-interaction-potential-trigger " data-stencil-id="1419803245" data-review-reference-id="1419803245">\
         <div class="stencil-wrapper" style="width: 89px; height: 20px">\
            <div class="" style="font-size:1.17em;">\
               <div xml:space="preserve" title="" style="position:absolute" onclick="rabbit.facade.fireMouseOn(\'__containerId__-page497958436-layer-1419803245_input\');">\
                  				\
                  <nobr>\
                     					<input id="__containerId__-page497958436-layer-1419803245_input" xml:space="default" class="hidden_class" style="padding-right:9px" type="checkbox" onpropertychange="rabbit.facade.raiseEvent(rabbit.events.propertyChange, \'__containerId__-page497958436-layer-1419803245_input\', \'__containerId__-page497958436-layer-1419803245_input_svgChecked\');" onblur="rabbit.facade.raiseEvent(rabbit.events.svgBlur, \'__containerId__-page497958436-layer-1419803245_input_svg_border\')" onfocus="rabbit.facade.raiseEvent(rabbit.events.svgFocus, \'__containerId__-page497958436-layer-1419803245_input_svg_border\')" onclick="rabbit.facade.raiseEvent(rabbit.events.checkBoxClicked, \'__containerId__-page497958436-layer-1419803245_input\', \'__containerId__-page497958436-layer-1419803245_input_svgChecked\')" />\
                     				\
                     					\
                     					\
                     						Khách sạn\
                     						\
                     					\
                     				\
                  </nobr>\
                  			\
               </div>\
               <div title="">\
                  <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" style="position: absolute; height: 20px;width:89px;" width="89" height="20" onclick="rabbit.facade.fireMouseOn(\'__containerId__-page497958436-layer-1419803245_input\');">\
                     <svg:g id="__containerId__-page497958436-layer-1419803245_input_svg" x="0" y="1.0199999999999996" width="89" height="20"><svg:path id="__containerId__-page497958436-layer-1419803245_input_svg_border" d="M 5.00, 5.00 Q 10.00, 2.97, 15.78, 4.22\
                        Q 15.96, 9.68, 15.54, 15.54 Q 10.35, 16.27, 4.22, 15.66 Q 5.00, 10.00, 5.00, 5.00" style=" fill:white;" class="svg_unselected_element"/>\
                     </svg:g>\
                     <svg:g id="__containerId__-page497958436-layer-1419803245_input_svgChecked" x="0" y="1.0199999999999996" width="89" height="20" visibility="hidden"><svg:path d="M 5.00, 9.00 Q 8.00, 12.00, 11.00, 15.00" style=" fill:none;" class="svg_unselected_element"/><svg:path d="M 11.00, 15.00 Q 15.50, 7.00, 20.00, -1.00" style=" fill:none;" class="svg_unselected_element"/></svg:g>\
                  </svg:svg>\
               </div>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page497958436-layer-1787666778" style="position: absolute; left: 545px; top: 430px; width: 64px; height: 20px" data-interactive-element-type="default.checkbox" class="checkbox stencil mobile-interaction-potential-trigger " data-stencil-id="1787666778" data-review-reference-id="1787666778">\
         <div class="stencil-wrapper" style="width: 64px; height: 20px">\
            <div class="" style="font-size:1.17em;">\
               <div xml:space="preserve" title="" style="position:absolute" onclick="rabbit.facade.fireMouseOn(\'__containerId__-page497958436-layer-1787666778_input\');">\
                  				\
                  <nobr>\
                     					<input id="__containerId__-page497958436-layer-1787666778_input" xml:space="default" class="hidden_class" style="padding-right:9px" type="checkbox" onpropertychange="rabbit.facade.raiseEvent(rabbit.events.propertyChange, \'__containerId__-page497958436-layer-1787666778_input\', \'__containerId__-page497958436-layer-1787666778_input_svgChecked\');" onblur="rabbit.facade.raiseEvent(rabbit.events.svgBlur, \'__containerId__-page497958436-layer-1787666778_input_svg_border\')" onfocus="rabbit.facade.raiseEvent(rabbit.events.svgFocus, \'__containerId__-page497958436-layer-1787666778_input_svg_border\')" onclick="rabbit.facade.raiseEvent(rabbit.events.checkBoxClicked, \'__containerId__-page497958436-layer-1787666778_input\', \'__containerId__-page497958436-layer-1787666778_input_svgChecked\')" />\
                     				\
                     					\
                     					\
                     						Giải trí\
                     						\
                     					\
                     				\
                  </nobr>\
                  			\
               </div>\
               <div title="">\
                  <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" style="position: absolute; height: 20px;width:64px;" width="64" height="20" onclick="rabbit.facade.fireMouseOn(\'__containerId__-page497958436-layer-1787666778_input\');">\
                     <svg:g id="__containerId__-page497958436-layer-1787666778_input_svg" x="0" y="1.0199999999999996" width="64" height="20"><svg:path id="__containerId__-page497958436-layer-1787666778_input_svg_border" d="M 5.00, 5.00 Q 10.00, 3.62, 15.44, 4.56\
                        Q 15.54, 9.82, 15.31, 15.31 Q 10.15, 15.56, 4.54, 15.39 Q 5.00, 10.00, 5.00, 5.00" style=" fill:white;" class="svg_unselected_element"/>\
                     </svg:g>\
                     <svg:g id="__containerId__-page497958436-layer-1787666778_input_svgChecked" x="0" y="1.0199999999999996" width="64" height="20" visibility="hidden"><svg:path d="M 5.00, 9.00 Q 8.00, 12.00, 11.00, 15.00" style=" fill:none;" class="svg_unselected_element"/><svg:path d="M 11.00, 15.00 Q 15.50, 7.00, 20.00, -1.00" style=" fill:none;" class="svg_unselected_element"/></svg:g>\
                  </svg:svg>\
               </div>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page497958436-layer-1500199881" style="position: absolute; left: 675px; top: 430px; width: 82px; height: 20px" data-interactive-element-type="default.checkbox" class="checkbox stencil mobile-interaction-potential-trigger " data-stencil-id="1500199881" data-review-reference-id="1500199881">\
         <div class="stencil-wrapper" style="width: 82px; height: 20px">\
            <div class="" style="font-size:1.17em;">\
               <div xml:space="preserve" title="" style="position:absolute" onclick="rabbit.facade.fireMouseOn(\'__containerId__-page497958436-layer-1500199881_input\');">\
                  				\
                  <nobr>\
                     					<input id="__containerId__-page497958436-layer-1500199881_input" xml:space="default" class="hidden_class" style="padding-right:9px" type="checkbox" onpropertychange="rabbit.facade.raiseEvent(rabbit.events.propertyChange, \'__containerId__-page497958436-layer-1500199881_input\', \'__containerId__-page497958436-layer-1500199881_input_svgChecked\');" onblur="rabbit.facade.raiseEvent(rabbit.events.svgBlur, \'__containerId__-page497958436-layer-1500199881_input_svg_border\')" onfocus="rabbit.facade.raiseEvent(rabbit.events.svgFocus, \'__containerId__-page497958436-layer-1500199881_input_svg_border\')" onclick="rabbit.facade.raiseEvent(rabbit.events.checkBoxClicked, \'__containerId__-page497958436-layer-1500199881_input\', \'__containerId__-page497958436-layer-1500199881_input_svgChecked\')" />\
                     				\
                     					\
                     					\
                     						Sức khỏe\
                     						\
                     					\
                     				\
                  </nobr>\
                  			\
               </div>\
               <div title="">\
                  <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" style="position: absolute; height: 20px;width:82px;" width="82" height="20" onclick="rabbit.facade.fireMouseOn(\'__containerId__-page497958436-layer-1500199881_input\');">\
                     <svg:g id="__containerId__-page497958436-layer-1500199881_input_svg" x="0" y="1.0199999999999996" width="82" height="20"><svg:path id="__containerId__-page497958436-layer-1500199881_input_svg_border" d="M 5.00, 5.00 Q 10.00, 6.33, 14.41, 5.59\
                        Q 14.29, 10.24, 14.65, 14.65 Q 9.88, 14.55, 5.24, 14.79 Q 5.00, 10.00, 5.00, 5.00" style=" fill:white;" class="svg_unselected_element"/>\
                     </svg:g>\
                     <svg:g id="__containerId__-page497958436-layer-1500199881_input_svgChecked" x="0" y="1.0199999999999996" width="82" height="20" visibility="hidden"><svg:path d="M 5.00, 9.00 Q 8.00, 12.00, 11.00, 15.00" style=" fill:none;" class="svg_unselected_element"/><svg:path d="M 11.00, 15.00 Q 15.50, 7.00, 20.00, -1.00" style=" fill:none;" class="svg_unselected_element"/></svg:g>\
                  </svg:svg>\
               </div>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page497958436-layer-964031897" style="position: absolute; left: 290px; top: 560px; width: 225px; height: 37px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="964031897" data-review-reference-id="964031897">\
         <div class="stencil-wrapper" style="width: 225px; height: 37px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline22"><p><span style="font-size: 32px; color: #658cd9;">Lịch sử đặt chỗ</span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page497958436-layer-arrow243142665" style="position: absolute; left: 285px; top: 520px; width: 735px; height: 33px" data-interactive-element-type="static.line" class="line stencil mobile-interaction-potential-trigger " data-stencil-id="arrow243142665" data-review-reference-id="arrow243142665">\
         <div class="stencil-wrapper" style="width: 735px; height: 33px">\
            <div title="">\
               <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" style="position: absolute; left: -5px; top: -5px; height: 43px;width:745px;" viewBox="-5 -5 745 43" width="745" height="43"><svg:path d="M 0.00, 16.00 Q 10.21, 15.69, 20.42, 16.34 Q 30.62, 16.30, 40.83, 16.39 Q 51.04, 15.84, 61.25, 15.25 Q 71.46,\
                  15.24, 81.67, 15.28 Q 91.88, 15.22, 102.08, 15.20 Q 112.29, 15.34, 122.50, 15.14 Q 132.71, 15.10, 142.92, 14.97 Q 153.12,\
                  14.94, 163.33, 15.12 Q 173.54, 15.13, 183.75, 15.38 Q 193.96, 15.05, 204.17, 14.88 Q 214.37, 15.17, 224.58, 15.09 Q 234.79,\
                  15.10, 245.00, 15.14 Q 255.21, 14.79, 265.42, 15.15 Q 275.62, 15.04, 285.83, 14.74 Q 296.04, 14.60, 306.25, 14.54 Q 316.46,\
                  14.64, 326.67, 15.09 Q 336.88, 15.47, 347.08, 15.23 Q 357.29, 15.90, 367.50, 16.11 Q 377.71, 15.22, 387.92, 15.19 Q 398.13,\
                  15.09, 408.33, 14.47 Q 418.54, 14.67, 428.75, 14.82 Q 438.96, 15.26, 449.17, 15.60 Q 459.38, 15.76, 469.58, 15.94 Q 479.79,\
                  15.92, 490.00, 15.75 Q 500.21, 15.93, 510.42, 15.16 Q 520.63, 15.91, 530.83, 16.11 Q 541.04, 15.66, 551.25, 15.61 Q 561.46,\
                  15.31, 571.67, 15.48 Q 581.88, 15.04, 592.08, 15.48 Q 602.29, 15.69, 612.50, 15.48 Q 622.71, 15.45, 632.92, 14.67 Q 643.12,\
                  15.07, 653.33, 15.43 Q 663.54, 16.06, 673.75, 16.85 Q 683.96, 17.09, 694.17, 16.77 Q 704.37, 17.47, 714.58, 17.50 Q 724.79,\
                  16.00, 735.00, 16.00" style="marker-start:;marker-end:" class="svg_unselected_element"/>\
               </svg:svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page497958436-layer-image115759317" style="position: absolute; left: 275px; top: 645px; width: 980px; height: 342px" data-interactive-element-type="default.image" class="image stencil mobile-interaction-potential-trigger " data-stencil-id="image115759317" data-review-reference-id="image115759317">\
         <div class="stencil-wrapper" style="width: 980px; height: 342px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" title="">\
               <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" class="image-cropper" style="height: 342px;width:980px;" width="980" height="342">\
                  <svg:g width="980" height="342">\
                     <svg:svg x="1" y="1" width="978" height="340">\
                        <svg:image width="80" height="60" xlink:href="../repoimages/506362.PNG" preserveAspectRatio="none" transform="scale(12.25,5.7) translate(-0,-0)  "></svg:image>\
                     </svg:svg>\
                  </svg:g>\
               </svg:svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page497958436-layer-453722338" style="position: absolute; left: 70px; top: 160px; width: 108px; height: 17px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="453722338" data-review-reference-id="453722338">\
         <div class="stencil-wrapper" style="width: 108px; height: 17px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline22"><p><span style="font-size: 14px; color: #658cd9;">SĐT 016325483</span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page497958436-layer-text904756561" style="position: absolute; left: 1135px; top: 770px; width: 50px; height: 17px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text904756561" data-review-reference-id="text904756561">\
         <div class="stencil-wrapper" style="width: 50px; height: 17px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.link2"><p style="font-size: 14px;"><span class="underline" style="color: #658cd9;">Chi tiết</span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page497958436-layer-1427091192" style="position: absolute; left: 1135px; top: 940px; width: 50px; height: 17px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="1427091192" data-review-reference-id="1427091192">\
         <div class="stencil-wrapper" style="width: 50px; height: 17px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.link2"><p style="font-size: 14px;"><span class="underline" style="color: #658cd9;">Chi tiết</span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page497958436-layer-1098393805" style="position: absolute; left: 305px; top: 100px; width: 87px; height: 21px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="1098393805" data-review-reference-id="1098393805">\
         <div class="stencil-wrapper" style="width: 87px; height: 21px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline32"><p class="none" style="font-size: 18px;">Ngày lập: </p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page497958436-layer-text591097359" style="position: absolute; left: 410px; top: 100px; width: 96px; height: 21px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text591097359" data-review-reference-id="text591097359">\
         <div class="stencil-wrapper" style="width: 96px; height: 21px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline32"><p><span style="font-size: 18px;">23/07/2016</span></p></span></span></div>\
         </div>\
      </div>\
   </div>\
</div>');