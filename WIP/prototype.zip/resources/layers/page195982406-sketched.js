rabbit.data.layerStore.addLayerFromHtml('<div xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:fn="http://www.w3.org/2005/xpath-functions" id="result">\
   <div xmlns:xs="http://www.w3.org/2001/XMLSchema" xmlns="http://www.w3.org/1999/xhtml" id="__containerId__page195982406-layer" class="layer" name="__containerId__pageLayer" data-layer-id="page195982406" data-layer-type="pageLayer" style="position:absolute;left:0px;top:0px;">\
      <div id="__containerId__-page195982406-layer-image40232402" style="position: absolute; left: 5px; top: 0px; width: 1366px; height: 2000px" data-interactive-element-type="default.image" class="image stencil mobile-interaction-potential-trigger " data-stencil-id="image40232402" data-review-reference-id="image40232402">\
         <div class="stencil-wrapper" style="width: 1366px; height: 2000px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" title="">\
               <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" class="image-cropper" style="height: 2000px;width:1366px;" width="1366" height="2000">\
                  <svg:g width="1366" height="2000">\
                     <svg:svg x="1" y="1" width="1364" height="1998">\
                        <svg:image width="432" height="253" xlink:href="../repoimages/506332.PNG" preserveAspectRatio="none" transform="scale(3.162037037037037,7.905138339920948) translate(-0,-0)  "></svg:image>\
                     </svg:svg>\
                  </svg:g>\
               </svg:svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page195982406-layer-text964319955" style="position: absolute; left: 490px; top: 40px; width: 299px; height: 37px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text964319955" data-review-reference-id="text964319955">\
         <div class="stencil-wrapper" style="width: 299px; height: 37px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline12"><p class="none" style="font-size: 32px;"><span class="bold" style="color: #658cd9;">Đăng kí thành viên </span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page195982406-layer-text983126157" style="position: absolute; left: 170px; top: 145px; width: 83px; height: 28px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text983126157" data-review-reference-id="text983126157">\
         <div class="stencil-wrapper" style="width: 83px; height: 28px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline22"><p><span style="font-size: 24px; color: #658cd9;">Họ tên:</span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page195982406-layer-textinput797440193" style="position: absolute; left: 395px; top: 145px; width: 400px; height: 30px" data-interactive-element-type="default.textinput" class="textinput stencil mobile-interaction-potential-trigger " data-stencil-id="textinput797440193" data-review-reference-id="textinput797440193">\
         <div class="stencil-wrapper" style="width: 400px; height: 30px">\
            <div>\
               <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" style="height: 30px;width:400px;" width="400" height="30">\
                  <svg:g id="__containerId__-page195982406-layer-textinput797440193svg" width="400" height="30"><svg:path id="__containerId__-page195982406-layer-textinput797440193_input_svg_border" d="M 2.00, 2.00 Q 12.42, 2.15, 22.84,\
                     2.08 Q 33.26, 2.03, 43.68, 1.23 Q 54.11, 1.09, 64.53, 2.13 Q 74.95, 2.57, 85.37, 1.86 Q 95.79, 0.75, 106.21, 1.30 Q 116.63,\
                     1.35, 127.05, 2.05 Q 137.47, 1.87, 147.89, 2.36 Q 158.32, 2.35, 168.74, 1.68 Q 179.16, 1.37, 189.58, 1.00 Q 200.00, 2.13,\
                     210.42, 2.09 Q 220.84, 2.36, 231.26, 1.74 Q 241.68, 1.61, 252.11, 2.21 Q 262.53, 1.98, 272.95, 1.75 Q 283.37, 1.43, 293.79,\
                     2.80 Q 304.21, 3.03, 314.63, 3.03 Q 325.05, 2.99, 335.47, 2.40 Q 345.89, 2.34, 356.32, 2.17 Q 366.74, 1.80, 377.16, 1.36 Q\
                     387.58, 2.23, 397.61, 2.39 Q 397.75, 15.08, 397.96, 27.96 Q 387.65, 28.24, 377.12, 27.64 Q 366.69, 27.14, 356.31, 27.81 Q\
                     345.90, 28.63, 335.48, 28.67 Q 325.05, 28.36, 314.63, 28.00 Q 304.21, 27.96, 293.79, 29.02 Q 283.37, 28.91, 272.95, 29.00\
                     Q 262.53, 29.24, 252.11, 29.18 Q 241.68, 28.86, 231.26, 27.38 Q 220.84, 28.17, 210.42, 27.75 Q 200.00, 27.43, 189.58, 28.02\
                     Q 179.16, 28.25, 168.74, 28.23 Q 158.32, 28.23, 147.89, 28.80 Q 137.47, 28.38, 127.05, 28.63 Q 116.63, 28.14, 106.21, 28.97\
                     Q 95.79, 29.07, 85.37, 29.07 Q 74.95, 28.88, 64.53, 29.12 Q 54.11, 29.34, 43.68, 28.67 Q 33.26, 29.19, 22.84, 28.77 Q 12.42,\
                     28.99, 1.55, 28.45 Q 2.00, 15.00, 2.00, 2.00" style=" fill:white;" class="svg_unselected_element"/><svg:path id="__containerId__-page195982406-layer-textinput797440193_line1" d="M 3.00, 3.00 Q 13.37, 3.24, 23.74, 3.10 Q 34.11,\
                     3.53, 44.47, 3.45 Q 54.84, 2.75, 65.21, 2.22 Q 75.58, 2.10, 85.95, 1.84 Q 96.32, 3.02, 106.68, 1.78 Q 117.05, 1.94, 127.42,\
                     1.81 Q 137.79, 2.15, 148.16, 2.29 Q 158.53, 2.02, 168.89, 2.65 Q 179.26, 4.15, 189.63, 3.63 Q 200.00, 2.91, 210.37, 2.06 Q\
                     220.74, 1.57, 231.11, 1.56 Q 241.47, 1.20, 251.84, 1.03 Q 262.21, 1.22, 272.58, 1.26 Q 282.95, 1.85, 293.32, 1.61 Q 303.68,\
                     1.84, 314.05, 1.30 Q 324.42, 2.18, 334.79, 1.60 Q 345.16, 2.53, 355.53, 3.95 Q 365.89, 4.92, 376.26, 3.61 Q 386.63, 3.00,\
                     397.00, 3.00" style=" fill:none;" class="svg_unselected_element"/><svg:path id="__containerId__-page195982406-layer-textinput797440193_line2" d="M 3.00, 3.00 Q 3.00, 15.00, 3.00, 27.00" style="\
                     fill:none;" class="svg_unselected_element"/><svg:path id="__containerId__-page195982406-layer-textinput797440193_line3" d="M 3.00, 3.00 Q 13.37, 2.62, 23.74, 2.58 Q 34.11,\
                     2.46, 44.47, 2.33 Q 54.84, 2.02, 65.21, 1.99 Q 75.58, 1.96, 85.95, 1.84 Q 96.32, 1.74, 106.68, 1.72 Q 117.05, 1.76, 127.42,\
                     1.73 Q 137.79, 1.58, 148.16, 1.50 Q 158.53, 1.48, 168.89, 1.30 Q 179.26, 1.67, 189.63, 1.51 Q 200.00, 1.38, 210.37, 1.52 Q\
                     220.74, 1.92, 231.11, 1.85 Q 241.47, 1.97, 251.84, 1.61 Q 262.21, 1.48, 272.58, 1.39 Q 282.95, 1.36, 293.32, 1.23 Q 303.68,\
                     1.19, 314.05, 1.28 Q 324.42, 2.26, 334.79, 1.30 Q 345.16, 1.84, 355.53, 1.52 Q 365.89, 1.68, 376.26, 1.35 Q 386.63, 3.00,\
                     397.00, 3.00" style=" fill:none;" class="svg_unselected_element"/><svg:path id="__containerId__-page195982406-layer-textinput797440193_line4" d="M 3.00, 3.00 Q 3.00, 15.00, 3.00, 27.00" style="\
                     fill:none;" class="svg_unselected_element"/>\
                  </svg:g>\
               </svg:svg>\
               <div style="position:absolute;left: 6px; top: 1px;" title=""><input id="__containerId__-page195982406-layer-textinput797440193input" onblur="rabbit.facade.raiseEvent(rabbit.events.svgBlur, new Array(\'__containerId__-page195982406-layer-textinput797440193_input_svg_border\',\'__containerId__-page195982406-layer-textinput797440193_line1\',\'__containerId__-page195982406-layer-textinput797440193_line2\',\'__containerId__-page195982406-layer-textinput797440193_line3\',\'__containerId__-page195982406-layer-textinput797440193_line4\'))" onfocus="rabbit.facade.raiseEvent(rabbit.events.svgFocus, new Array(\'__containerId__-page195982406-layer-textinput797440193_input_svg_border\',\'__containerId__-page195982406-layer-textinput797440193_line1\',\'__containerId__-page195982406-layer-textinput797440193_line2\',\'__containerId__-page195982406-layer-textinput797440193_line3\',\'__containerId__-page195982406-layer-textinput797440193_line4\'))" value="" style="width:393px;height:28px;padding: 0px;" type="text" /></div>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page195982406-layer-1600488173" style="position: absolute; left: 395px; top: 220px; width: 400px; height: 30px" data-interactive-element-type="default.textinput" class="textinput stencil mobile-interaction-potential-trigger " data-stencil-id="1600488173" data-review-reference-id="1600488173">\
         <div class="stencil-wrapper" style="width: 400px; height: 30px">\
            <div>\
               <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" style="height: 30px;width:400px;" width="400" height="30">\
                  <svg:g id="__containerId__-page195982406-layer-1600488173svg" width="400" height="30"><svg:path id="__containerId__-page195982406-layer-1600488173_input_svg_border" d="M 2.00, 2.00 Q 12.42, 2.80, 22.84, 2.65\
                     Q 33.26, 2.40, 43.68, 1.99 Q 54.11, 2.17, 64.53, 1.41 Q 74.95, 1.51, 85.37, 1.26 Q 95.79, 1.86, 106.21, 1.35 Q 116.63, 1.06,\
                     127.05, 0.37 Q 137.47, 1.00, 147.89, 1.22 Q 158.32, 0.87, 168.74, 0.75 Q 179.16, 0.64, 189.58, 1.49 Q 200.00, 0.97, 210.42,\
                     0.36 Q 220.84, 0.49, 231.26, 0.68 Q 241.68, 0.43, 252.11, -0.22 Q 262.53, 0.41, 272.95, -0.04 Q 283.37, 0.39, 293.79, 0.16\
                     Q 304.21, 0.27, 314.63, 0.62 Q 325.05, 1.47, 335.47, 1.20 Q 345.89, 0.68, 356.32, 1.33 Q 366.74, 2.14, 377.16, 2.61 Q 387.58,\
                     1.88, 398.12, 1.88 Q 398.41, 14.86, 398.40, 28.40 Q 387.70, 28.44, 377.22, 28.55 Q 366.77, 28.57, 356.33, 28.56 Q 345.90,\
                     28.71, 335.48, 28.32 Q 325.06, 28.90, 314.63, 29.63 Q 304.21, 29.11, 293.79, 28.67 Q 283.37, 29.14, 272.95, 29.49 Q 262.53,\
                     29.37, 252.11, 29.09 Q 241.68, 29.66, 231.26, 29.68 Q 220.84, 29.82, 210.42, 29.83 Q 200.00, 29.58, 189.58, 29.70 Q 179.16,\
                     29.62, 168.74, 29.05 Q 158.32, 27.74, 147.89, 28.95 Q 137.47, 29.19, 127.05, 28.87 Q 116.63, 27.97, 106.21, 28.37 Q 95.79,\
                     28.60, 85.37, 28.32 Q 74.95, 28.88, 64.53, 28.50 Q 54.11, 28.89, 43.68, 29.16 Q 33.26, 28.79, 22.84, 28.42 Q 12.42, 27.81,\
                     1.70, 28.30 Q 2.00, 15.00, 2.00, 2.00" style=" fill:white;" class="svg_unselected_element"/><svg:path id="__containerId__-page195982406-layer-1600488173_line1" d="M 3.00, 3.00 Q 13.37, 0.27, 23.74, 1.13 Q 34.11, 1.41,\
                     44.47, 2.16 Q 54.84, 1.53, 65.21, 2.03 Q 75.58, 3.56, 85.95, 3.20 Q 96.32, 3.18, 106.68, 2.74 Q 117.05, 2.87, 127.42, 2.73\
                     Q 137.79, 2.75, 148.16, 3.06 Q 158.53, 2.60, 168.89, 1.99 Q 179.26, 2.10, 189.63, 2.61 Q 200.00, 2.25, 210.37, 3.05 Q 220.74,\
                     2.74, 231.11, 2.66 Q 241.47, 1.97, 251.84, 1.93 Q 262.21, 1.38, 272.58, 1.85 Q 282.95, 2.89, 293.32, 3.30 Q 303.68, 2.41,\
                     314.05, 2.33 Q 324.42, 2.07, 334.79, 1.10 Q 345.16, 0.84, 355.53, 0.92 Q 365.89, 1.77, 376.26, 1.65 Q 386.63, 3.00, 397.00,\
                     3.00" style=" fill:none;" class="svg_unselected_element"/><svg:path id="__containerId__-page195982406-layer-1600488173_line2" d="M 3.00, 3.00 Q 3.00, 15.00, 3.00, 27.00" style=" fill:none;"\
                     class="svg_unselected_element"/><svg:path id="__containerId__-page195982406-layer-1600488173_line3" d="M 3.00, 3.00 Q 13.37, 0.37, 23.74, 0.37 Q 34.11, 1.75,\
                     44.47, 0.96 Q 54.84, 2.11, 65.21, 2.36 Q 75.58, 2.19, 85.95, 1.24 Q 96.32, 1.48, 106.68, 2.20 Q 117.05, 2.50, 127.42, 2.82\
                     Q 137.79, 2.21, 148.16, 2.65 Q 158.53, 2.30, 168.89, 1.86 Q 179.26, 2.19, 189.63, 2.05 Q 200.00, 3.26, 210.37, 2.95 Q 220.74,\
                     2.73, 231.11, 2.12 Q 241.47, 2.06, 251.84, 1.92 Q 262.21, 0.84, 272.58, 1.02 Q 282.95, 1.47, 293.32, 2.64 Q 303.68, 3.50,\
                     314.05, 2.35 Q 324.42, 1.33, 334.79, 0.95 Q 345.16, 1.12, 355.53, 1.48 Q 365.89, 1.93, 376.26, 1.85 Q 386.63, 3.00, 397.00,\
                     3.00" style=" fill:none;" class="svg_unselected_element"/><svg:path id="__containerId__-page195982406-layer-1600488173_line4" d="M 3.00, 3.00 Q 3.00, 15.00, 3.00, 27.00" style=" fill:none;"\
                     class="svg_unselected_element"/>\
                  </svg:g>\
               </svg:svg>\
               <div style="position:absolute;left: 6px; top: 1px;" title=""><input id="__containerId__-page195982406-layer-1600488173input" onblur="rabbit.facade.raiseEvent(rabbit.events.svgBlur, new Array(\'__containerId__-page195982406-layer-1600488173_input_svg_border\',\'__containerId__-page195982406-layer-1600488173_line1\',\'__containerId__-page195982406-layer-1600488173_line2\',\'__containerId__-page195982406-layer-1600488173_line3\',\'__containerId__-page195982406-layer-1600488173_line4\'))" onfocus="rabbit.facade.raiseEvent(rabbit.events.svgFocus, new Array(\'__containerId__-page195982406-layer-1600488173_input_svg_border\',\'__containerId__-page195982406-layer-1600488173_line1\',\'__containerId__-page195982406-layer-1600488173_line2\',\'__containerId__-page195982406-layer-1600488173_line3\',\'__containerId__-page195982406-layer-1600488173_line4\'))" value="" style="width:393px;height:28px;padding: 0px;" type="text" /></div>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page195982406-layer-1786337216" style="position: absolute; left: 170px; top: 220px; width: 153px; height: 28px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="1786337216" data-review-reference-id="1786337216">\
         <div class="stencil-wrapper" style="width: 153px; height: 28px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline22"><p><span style="font-size: 24px; color: #658cd9;">Số điện thoại:</span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page195982406-layer-2146370051" style="position: absolute; left: 170px; top: 300px; width: 113px; height: 28px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="2146370051" data-review-reference-id="2146370051">\
         <div class="stencil-wrapper" style="width: 113px; height: 28px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline22"><p><span style="font-size: 24px; color: #658cd9;">Ngày sinh</span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page195982406-layer-875716220" style="position: absolute; left: 395px; top: 380px; width: 400px; height: 30px" data-interactive-element-type="default.textinput" class="textinput stencil mobile-interaction-potential-trigger " data-stencil-id="875716220" data-review-reference-id="875716220">\
         <div class="stencil-wrapper" style="width: 400px; height: 30px">\
            <div>\
               <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" style="height: 30px;width:400px;" width="400" height="30">\
                  <svg:g id="__containerId__-page195982406-layer-875716220svg" width="400" height="30"><svg:path id="__containerId__-page195982406-layer-875716220_input_svg_border" d="M 2.00, 2.00 Q 12.42, 3.16, 22.84, 3.22 Q\
                     33.26, 3.16, 43.68, 2.64 Q 54.11, 1.80, 64.53, 2.70 Q 74.95, 2.67, 85.37, 2.09 Q 95.79, 1.24, 106.21, 1.00 Q 116.63, 1.84,\
                     127.05, 2.16 Q 137.47, 1.46, 147.89, 1.51 Q 158.32, 1.56, 168.74, 1.33 Q 179.16, 1.22, 189.58, 1.61 Q 200.00, 1.27, 210.42,\
                     1.70 Q 220.84, 2.73, 231.26, 2.36 Q 241.68, 1.68, 252.11, 2.26 Q 262.53, 1.38, 272.95, 1.42 Q 283.37, 1.73, 293.79, 1.87 Q\
                     304.21, 1.96, 314.63, 1.99 Q 325.05, 2.24, 335.47, 1.48 Q 345.89, 2.01, 356.32, 1.69 Q 366.74, 2.46, 377.16, 2.51 Q 387.58,\
                     1.53, 398.41, 1.59 Q 397.82, 15.06, 397.98, 27.98 Q 387.68, 28.36, 377.12, 27.66 Q 366.77, 28.57, 356.32, 28.09 Q 345.91,\
                     28.97, 335.48, 28.71 Q 325.05, 27.38, 314.63, 27.11 Q 304.21, 27.93, 293.79, 28.89 Q 283.37, 28.84, 272.95, 29.06 Q 262.53,\
                     28.71, 252.11, 28.61 Q 241.68, 28.28, 231.26, 28.42 Q 220.84, 27.85, 210.42, 27.97 Q 200.00, 28.52, 189.58, 27.98 Q 179.16,\
                     28.34, 168.74, 27.01 Q 158.32, 28.12, 147.89, 28.50 Q 137.47, 28.01, 127.05, 27.57 Q 116.63, 27.87, 106.21, 28.22 Q 95.79,\
                     27.11, 85.37, 27.26 Q 74.95, 26.69, 64.53, 26.91 Q 54.11, 28.02, 43.68, 28.14 Q 33.26, 28.39, 22.84, 28.72 Q 12.42, 28.32,\
                     2.68, 27.32 Q 2.00, 15.00, 2.00, 2.00" style=" fill:white;" class="svg_unselected_element"/><svg:path id="__containerId__-page195982406-layer-875716220_line1" d="M 3.00, 3.00 Q 13.37, 3.48, 23.74, 3.29 Q 34.11, 3.02,\
                     44.47, 3.39 Q 54.84, 2.69, 65.21, 2.55 Q 75.58, 2.32, 85.95, 3.15 Q 96.32, 2.61, 106.68, 2.74 Q 117.05, 2.55, 127.42, 2.86\
                     Q 137.79, 2.81, 148.16, 1.94 Q 158.53, 2.89, 168.89, 2.78 Q 179.26, 3.04, 189.63, 2.07 Q 200.00, 2.94, 210.37, 3.19 Q 220.74,\
                     2.89, 231.11, 2.91 Q 241.47, 2.31, 251.84, 2.91 Q 262.21, 2.07, 272.58, 2.87 Q 282.95, 2.40, 293.32, 2.30 Q 303.68, 2.23,\
                     314.05, 2.32 Q 324.42, 2.16, 334.79, 1.43 Q 345.16, 1.44, 355.53, 2.04 Q 365.89, 2.36, 376.26, 2.20 Q 386.63, 3.00, 397.00,\
                     3.00" style=" fill:none;" class="svg_unselected_element"/><svg:path id="__containerId__-page195982406-layer-875716220_line2" d="M 3.00, 3.00 Q 3.00, 15.00, 3.00, 27.00" style=" fill:none;"\
                     class="svg_unselected_element"/><svg:path id="__containerId__-page195982406-layer-875716220_line3" d="M 3.00, 3.00 Q 13.37, 1.06, 23.74, 1.01 Q 34.11, 0.87,\
                     44.47, 1.27 Q 54.84, 1.07, 65.21, 1.02 Q 75.58, 1.13, 85.95, 1.49 Q 96.32, 1.37, 106.68, 1.13 Q 117.05, 1.00, 127.42, 0.99\
                     Q 137.79, 1.22, 148.16, 1.45 Q 158.53, 1.88, 168.89, 1.94 Q 179.26, 1.91, 189.63, 1.67 Q 200.00, 1.69, 210.37, 1.77 Q 220.74,\
                     1.69, 231.11, 1.65 Q 241.47, 1.57, 251.84, 1.54 Q 262.21, 2.17, 272.58, 2.13 Q 282.95, 2.08, 293.32, 2.00 Q 303.68, 2.07,\
                     314.05, 1.62 Q 324.42, 1.34, 334.79, 1.32 Q 345.16, 1.52, 355.53, 2.01 Q 365.89, 1.51, 376.26, 1.11 Q 386.63, 3.00, 397.00,\
                     3.00" style=" fill:none;" class="svg_unselected_element"/><svg:path id="__containerId__-page195982406-layer-875716220_line4" d="M 3.00, 3.00 Q 3.00, 15.00, 3.00, 27.00" style=" fill:none;"\
                     class="svg_unselected_element"/>\
                  </svg:g>\
               </svg:svg>\
               <div style="position:absolute;left: 6px; top: 1px;" title=""><input id="__containerId__-page195982406-layer-875716220input" onblur="rabbit.facade.raiseEvent(rabbit.events.svgBlur, new Array(\'__containerId__-page195982406-layer-875716220_input_svg_border\',\'__containerId__-page195982406-layer-875716220_line1\',\'__containerId__-page195982406-layer-875716220_line2\',\'__containerId__-page195982406-layer-875716220_line3\',\'__containerId__-page195982406-layer-875716220_line4\'))" onfocus="rabbit.facade.raiseEvent(rabbit.events.svgFocus, new Array(\'__containerId__-page195982406-layer-875716220_input_svg_border\',\'__containerId__-page195982406-layer-875716220_line1\',\'__containerId__-page195982406-layer-875716220_line2\',\'__containerId__-page195982406-layer-875716220_line3\',\'__containerId__-page195982406-layer-875716220_line4\'))" value="" style="width:393px;height:28px;padding: 0px;" type="text" /></div>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page195982406-layer-1573620076" style="position: absolute; left: 170px; top: 380px; width: 93px; height: 28px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="1573620076" data-review-reference-id="1573620076">\
         <div class="stencil-wrapper" style="width: 93px; height: 28px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline22"><p class="none" style="font-size: 24px;"><span style="color: #658cd9;">Địa chỉ:</span> </p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page195982406-layer-1916668307" style="position: absolute; left: 170px; top: 540px; width: 118px; height: 28px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="1916668307" data-review-reference-id="1916668307">\
         <div class="stencil-wrapper" style="width: 118px; height: 28px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline22"><p class="none" style="font-size: 24px;"><span style="color: #658cd9;">Mật khẩu:</span> </p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page195982406-layer-1255023614" style="position: absolute; left: 395px; top: 540px; width: 400px; height: 30px" data-interactive-element-type="default.textinput" class="textinput stencil mobile-interaction-potential-trigger " data-stencil-id="1255023614" data-review-reference-id="1255023614">\
         <div class="stencil-wrapper" style="width: 400px; height: 30px">\
            <div>\
               <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" style="height: 30px;width:400px;" width="400" height="30">\
                  <svg:g id="__containerId__-page195982406-layer-1255023614svg" width="400" height="30"><svg:path id="__containerId__-page195982406-layer-1255023614_input_svg_border" d="M 2.00, 2.00 Q 12.42, 1.52, 22.84, 1.02\
                     Q 33.26, 1.88, 43.68, 0.51 Q 54.11, 0.96, 64.53, 2.24 Q 74.95, 1.83, 85.37, 1.07 Q 95.79, 0.54, 106.21, 0.99 Q 116.63, 1.61,\
                     127.05, 1.96 Q 137.47, 1.50, 147.89, 1.99 Q 158.32, 2.13, 168.74, 1.91 Q 179.16, 2.11, 189.58, 1.42 Q 200.00, 1.90, 210.42,\
                     1.61 Q 220.84, 1.48, 231.26, 0.52 Q 241.68, 1.25, 252.11, 1.61 Q 262.53, 1.61, 272.95, 0.96 Q 283.37, 0.80, 293.79, 2.06 Q\
                     304.21, 2.01, 314.63, 2.56 Q 325.05, 2.21, 335.47, 1.85 Q 345.89, 1.84, 356.32, 1.87 Q 366.74, 1.66, 377.16, 1.04 Q 387.58,\
                     2.15, 398.11, 1.89 Q 398.01, 15.00, 398.31, 28.31 Q 387.84, 28.95, 377.23, 28.68 Q 366.79, 29.03, 356.35, 29.36 Q 345.91,\
                     29.29, 335.48, 28.52 Q 325.06, 28.84, 314.63, 28.89 Q 304.21, 29.47, 293.79, 29.21 Q 283.37, 28.77, 272.95, 29.28 Q 262.53,\
                     29.64, 252.11, 29.35 Q 241.68, 27.94, 231.26, 28.38 Q 220.84, 28.31, 210.42, 29.30 Q 200.00, 29.19, 189.58, 28.44 Q 179.16,\
                     28.45, 168.74, 28.48 Q 158.32, 29.10, 147.89, 28.93 Q 137.47, 28.83, 127.05, 28.96 Q 116.63, 28.83, 106.21, 28.28 Q 95.79,\
                     27.86, 85.37, 28.40 Q 74.95, 28.95, 64.53, 28.73 Q 54.11, 27.76, 43.68, 28.18 Q 33.26, 28.03, 22.84, 29.50 Q 12.42, 29.24,\
                     1.90, 28.10 Q 2.00, 15.00, 2.00, 2.00" style=" fill:white;" class="svg_unselected_element"/><svg:path id="__containerId__-page195982406-layer-1255023614_line1" d="M 3.00, 3.00 Q 13.37, 2.15, 23.74, 2.13 Q 34.11, 1.86,\
                     44.47, 1.78 Q 54.84, 1.39, 65.21, 1.29 Q 75.58, 1.26, 85.95, 1.61 Q 96.32, 1.43, 106.68, 1.08 Q 117.05, 0.99, 127.42, 0.93\
                     Q 137.79, 0.91, 148.16, 1.21 Q 158.53, 1.52, 168.89, 1.60 Q 179.26, 1.55, 189.63, 1.86 Q 200.00, 1.54, 210.37, 1.21 Q 220.74,\
                     0.83, 231.11, 1.00 Q 241.47, 1.26, 251.84, 1.21 Q 262.21, 1.45, 272.58, 1.07 Q 282.95, 1.69, 293.32, 1.84 Q 303.68, 1.82,\
                     314.05, 1.83 Q 324.42, 2.13, 334.79, 2.43 Q 345.16, 2.26, 355.53, 2.66 Q 365.89, 2.57, 376.26, 3.08 Q 386.63, 3.00, 397.00,\
                     3.00" style=" fill:none;" class="svg_unselected_element"/><svg:path id="__containerId__-page195982406-layer-1255023614_line2" d="M 3.00, 3.00 Q 3.00, 15.00, 3.00, 27.00" style=" fill:none;"\
                     class="svg_unselected_element"/><svg:path id="__containerId__-page195982406-layer-1255023614_line3" d="M 3.00, 3.00 Q 13.37, 2.41, 23.74, 1.26 Q 34.11, 1.29,\
                     44.47, 1.42 Q 54.84, 1.34, 65.21, 1.95 Q 75.58, 2.42, 85.95, 2.07 Q 96.32, 2.82, 106.68, 1.82 Q 117.05, 2.20, 127.42, 3.41\
                     Q 137.79, 3.51, 148.16, 3.30 Q 158.53, 3.03, 168.89, 1.84 Q 179.26, 1.46, 189.63, 2.35 Q 200.00, 2.45, 210.37, 1.80 Q 220.74,\
                     1.71, 231.11, 2.62 Q 241.47, 2.50, 251.84, 2.64 Q 262.21, 2.59, 272.58, 2.37 Q 282.95, 2.64, 293.32, 2.13 Q 303.68, 2.59,\
                     314.05, 1.87 Q 324.42, 1.63, 334.79, 1.73 Q 345.16, 1.57, 355.53, 1.66 Q 365.89, 1.68, 376.26, 1.23 Q 386.63, 3.00, 397.00,\
                     3.00" style=" fill:none;" class="svg_unselected_element"/><svg:path id="__containerId__-page195982406-layer-1255023614_line4" d="M 3.00, 3.00 Q 3.00, 15.00, 3.00, 27.00" style=" fill:none;"\
                     class="svg_unselected_element"/>\
                  </svg:g>\
               </svg:svg>\
               <div style="position:absolute;left: 6px; top: 1px;" title=""><input id="__containerId__-page195982406-layer-1255023614input" onblur="rabbit.facade.raiseEvent(rabbit.events.svgBlur, new Array(\'__containerId__-page195982406-layer-1255023614_input_svg_border\',\'__containerId__-page195982406-layer-1255023614_line1\',\'__containerId__-page195982406-layer-1255023614_line2\',\'__containerId__-page195982406-layer-1255023614_line3\',\'__containerId__-page195982406-layer-1255023614_line4\'))" onfocus="rabbit.facade.raiseEvent(rabbit.events.svgFocus, new Array(\'__containerId__-page195982406-layer-1255023614_input_svg_border\',\'__containerId__-page195982406-layer-1255023614_line1\',\'__containerId__-page195982406-layer-1255023614_line2\',\'__containerId__-page195982406-layer-1255023614_line3\',\'__containerId__-page195982406-layer-1255023614_line4\'))" value="" style="width:393px;height:28px;padding: 0px;" type="text" /></div>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page195982406-layer-1987119085" style="position: absolute; left: 170px; top: 625px; width: 226px; height: 28px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="1987119085" data-review-reference-id="1987119085">\
         <div class="stencil-wrapper" style="width: 226px; height: 28px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline22"><p class="none" style="font-size: 24px;"><span style="color: #658cd9;">Xác nhận mật khẩu:</span> </p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page195982406-layer-1874987766" style="position: absolute; left: 395px; top: 625px; width: 400px; height: 30px" data-interactive-element-type="default.textinput" class="textinput stencil mobile-interaction-potential-trigger " data-stencil-id="1874987766" data-review-reference-id="1874987766">\
         <div class="stencil-wrapper" style="width: 400px; height: 30px">\
            <div>\
               <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" style="height: 30px;width:400px;" width="400" height="30">\
                  <svg:g id="__containerId__-page195982406-layer-1874987766svg" width="400" height="30"><svg:path id="__containerId__-page195982406-layer-1874987766_input_svg_border" d="M 2.00, 2.00 Q 12.42, 1.57, 22.84, 1.41\
                     Q 33.26, 1.33, 43.68, 1.16 Q 54.11, 1.57, 64.53, 1.75 Q 74.95, 0.99, 85.37, 0.98 Q 95.79, 1.28, 106.21, 1.26 Q 116.63, 1.03,\
                     127.05, 1.55 Q 137.47, 1.19, 147.89, 1.43 Q 158.32, 0.87, 168.74, 0.73 Q 179.16, 0.79, 189.58, 1.16 Q 200.00, 1.69, 210.42,\
                     1.35 Q 220.84, 1.31, 231.26, 1.06 Q 241.68, 1.37, 252.11, 1.70 Q 262.53, 2.11, 272.95, 1.12 Q 283.37, 0.92, 293.79, 1.40 Q\
                     304.21, 0.94, 314.63, 0.66 Q 325.05, 0.83, 335.47, 0.68 Q 345.89, 0.42, 356.32, 0.25 Q 366.74, 0.37, 377.16, 0.46 Q 387.58,\
                     0.79, 398.52, 1.48 Q 399.10, 14.63, 398.57, 28.57 Q 387.70, 28.45, 377.33, 29.53 Q 366.78, 28.87, 356.35, 29.47 Q 345.91,\
                     29.61, 335.48, 29.60 Q 325.06, 29.68, 314.63, 29.60 Q 304.21, 28.87, 293.79, 28.48 Q 283.37, 27.64, 272.95, 28.15 Q 262.53,\
                     29.07, 252.11, 28.33 Q 241.68, 27.87, 231.26, 27.88 Q 220.84, 28.24, 210.42, 29.58 Q 200.00, 28.98, 189.58, 30.01 Q 179.16,\
                     28.53, 168.74, 28.95 Q 158.32, 29.06, 147.89, 28.96 Q 137.47, 29.19, 127.05, 29.37 Q 116.63, 28.86, 106.21, 28.95 Q 95.79,\
                     28.86, 85.37, 28.79 Q 74.95, 28.75, 64.53, 28.87 Q 54.11, 28.97, 43.68, 28.84 Q 33.26, 28.47, 22.84, 29.76 Q 12.42, 29.65,\
                     1.14, 28.86 Q 2.00, 15.00, 2.00, 2.00" style=" fill:white;" class="svg_unselected_element"/><svg:path id="__containerId__-page195982406-layer-1874987766_line1" d="M 3.00, 3.00 Q 13.37, 0.70, 23.74, 0.66 Q 34.11, 0.98,\
                     44.47, 0.95 Q 54.84, 1.27, 65.21, 1.34 Q 75.58, 1.32, 85.95, 1.36 Q 96.32, 1.33, 106.68, 2.16 Q 117.05, 2.25, 127.42, 2.23\
                     Q 137.79, 1.96, 148.16, 1.96 Q 158.53, 2.09, 168.89, 1.90 Q 179.26, 1.55, 189.63, 1.79 Q 200.00, 1.80, 210.37, 2.47 Q 220.74,\
                     2.25, 231.11, 2.19 Q 241.47, 2.44, 251.84, 2.33 Q 262.21, 1.99, 272.58, 1.69 Q 282.95, 1.72, 293.32, 1.80 Q 303.68, 1.94,\
                     314.05, 2.36 Q 324.42, 2.38, 334.79, 2.41 Q 345.16, 1.67, 355.53, 1.27 Q 365.89, 1.07, 376.26, 1.63 Q 386.63, 3.00, 397.00,\
                     3.00" style=" fill:none;" class="svg_unselected_element"/><svg:path id="__containerId__-page195982406-layer-1874987766_line2" d="M 3.00, 3.00 Q 3.00, 15.00, 3.00, 27.00" style=" fill:none;"\
                     class="svg_unselected_element"/><svg:path id="__containerId__-page195982406-layer-1874987766_line3" d="M 3.00, 3.00 Q 13.37, 2.15, 23.74, 1.93 Q 34.11, 1.65,\
                     44.47, 1.56 Q 54.84, 1.45, 65.21, 1.10 Q 75.58, 1.41, 85.95, 1.29 Q 96.32, 1.28, 106.68, 1.22 Q 117.05, 0.96, 127.42, 1.29\
                     Q 137.79, 1.70, 148.16, 1.68 Q 158.53, 1.88, 168.89, 1.61 Q 179.26, 1.37, 189.63, 1.53 Q 200.00, 1.79, 210.37, 1.70 Q 220.74,\
                     1.60, 231.11, 1.40 Q 241.47, 1.31, 251.84, 1.78 Q 262.21, 1.85, 272.58, 2.22 Q 282.95, 2.52, 293.32, 2.43 Q 303.68, 2.78,\
                     314.05, 2.75 Q 324.42, 2.68, 334.79, 2.31 Q 345.16, 2.27, 355.53, 1.93 Q 365.89, 2.07, 376.26, 2.02 Q 386.63, 3.00, 397.00,\
                     3.00" style=" fill:none;" class="svg_unselected_element"/><svg:path id="__containerId__-page195982406-layer-1874987766_line4" d="M 3.00, 3.00 Q 3.00, 15.00, 3.00, 27.00" style=" fill:none;"\
                     class="svg_unselected_element"/>\
                  </svg:g>\
               </svg:svg>\
               <div style="position:absolute;left: 6px; top: 1px;" title=""><input id="__containerId__-page195982406-layer-1874987766input" onblur="rabbit.facade.raiseEvent(rabbit.events.svgBlur, new Array(\'__containerId__-page195982406-layer-1874987766_input_svg_border\',\'__containerId__-page195982406-layer-1874987766_line1\',\'__containerId__-page195982406-layer-1874987766_line2\',\'__containerId__-page195982406-layer-1874987766_line3\',\'__containerId__-page195982406-layer-1874987766_line4\'))" onfocus="rabbit.facade.raiseEvent(rabbit.events.svgFocus, new Array(\'__containerId__-page195982406-layer-1874987766_input_svg_border\',\'__containerId__-page195982406-layer-1874987766_line1\',\'__containerId__-page195982406-layer-1874987766_line2\',\'__containerId__-page195982406-layer-1874987766_line3\',\'__containerId__-page195982406-layer-1874987766_line4\'))" value="" style="width:393px;height:28px;padding: 0px;" type="text" /></div>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page195982406-layer-1223754287" style="position: absolute; left: 170px; top: 455px; width: 79px; height: 28px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="1223754287" data-review-reference-id="1223754287">\
         <div class="stencil-wrapper" style="width: 79px; height: 28px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline22"><p class="none" style="font-size: 24px;"><span style="color: #658cd9;">Email:</span> </p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page195982406-layer-501165204" style="position: absolute; left: 395px; top: 455px; width: 400px; height: 30px" data-interactive-element-type="default.textinput" class="textinput stencil mobile-interaction-potential-trigger " data-stencil-id="501165204" data-review-reference-id="501165204">\
         <div class="stencil-wrapper" style="width: 400px; height: 30px">\
            <div>\
               <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" style="height: 30px;width:400px;" width="400" height="30">\
                  <svg:g id="__containerId__-page195982406-layer-501165204svg" width="400" height="30"><svg:path id="__containerId__-page195982406-layer-501165204_input_svg_border" d="M 2.00, 2.00 Q 12.42, 1.59, 22.84, 1.96 Q\
                     33.26, 2.39, 43.68, 2.28 Q 54.11, 2.04, 64.53, 1.93 Q 74.95, 2.01, 85.37, 1.33 Q 95.79, 2.44, 106.21, 1.49 Q 116.63, 1.17,\
                     127.05, 0.89 Q 137.47, 1.27, 147.89, 1.18 Q 158.32, 0.33, 168.74, 0.19 Q 179.16, 1.24, 189.58, 2.29 Q 200.00, 1.46, 210.42,\
                     1.55 Q 220.84, 0.96, 231.26, 0.74 Q 241.68, 0.29, 252.11, -0.23 Q 262.53, -0.22, 272.95, -0.03 Q 283.37, 0.13, 293.79, 0.26\
                     Q 304.21, 0.01, 314.63, 0.19 Q 325.05, 0.80, 335.47, 0.56 Q 345.89, 0.28, 356.32, 0.87 Q 366.74, 1.59, 377.16, 2.06 Q 387.58,\
                     0.74, 398.30, 1.70 Q 398.46, 14.85, 398.03, 28.03 Q 387.60, 28.09, 377.25, 28.84 Q 366.81, 29.53, 356.36, 29.91 Q 345.92,\
                     30.01, 335.49, 30.01 Q 325.05, 28.48, 314.63, 29.63 Q 304.21, 29.83, 293.79, 29.44 Q 283.37, 29.35, 272.95, 29.52 Q 262.53,\
                     29.62, 252.11, 29.31 Q 241.68, 29.65, 231.26, 29.13 Q 220.84, 29.82, 210.42, 29.98 Q 200.00, 30.02, 189.58, 30.15 Q 179.16,\
                     30.18, 168.74, 29.76 Q 158.32, 29.16, 147.89, 28.78 Q 137.47, 28.81, 127.05, 29.01 Q 116.63, 27.99, 106.21, 28.77 Q 95.79,\
                     29.09, 85.37, 29.17 Q 74.95, 28.44, 64.53, 28.46 Q 54.11, 29.83, 43.68, 28.85 Q 33.26, 28.98, 22.84, 27.85 Q 12.42, 28.46,\
                     1.49, 28.51 Q 2.00, 15.00, 2.00, 2.00" style=" fill:white;" class="svg_unselected_element"/><svg:path id="__containerId__-page195982406-layer-501165204_line1" d="M 3.00, 3.00 Q 13.37, 4.45, 23.74, 3.94 Q 34.11, 3.05,\
                     44.47, 2.72 Q 54.84, 4.32, 65.21, 2.43 Q 75.58, 1.27, 85.95, 2.68 Q 96.32, 3.75, 106.68, 4.08 Q 117.05, 2.78, 127.42, 2.54\
                     Q 137.79, 1.91, 148.16, 1.12 Q 158.53, 1.69, 168.89, 2.26 Q 179.26, 2.62, 189.63, 2.60 Q 200.00, 2.76, 210.37, 2.49 Q 220.74,\
                     1.19, 231.11, 0.42 Q 241.47, 1.53, 251.84, 1.01 Q 262.21, 1.84, 272.58, 1.94 Q 282.95, 1.70, 293.32, 1.66 Q 303.68, 1.87,\
                     314.05, 2.53 Q 324.42, 3.02, 334.79, 3.10 Q 345.16, 3.12, 355.53, 2.76 Q 365.89, 2.52, 376.26, 2.43 Q 386.63, 3.00, 397.00,\
                     3.00" style=" fill:none;" class="svg_unselected_element"/><svg:path id="__containerId__-page195982406-layer-501165204_line2" d="M 3.00, 3.00 Q 3.00, 15.00, 3.00, 27.00" style=" fill:none;"\
                     class="svg_unselected_element"/><svg:path id="__containerId__-page195982406-layer-501165204_line3" d="M 3.00, 3.00 Q 13.37, 2.50, 23.74, 2.33 Q 34.11, 2.35,\
                     44.47, 2.00 Q 54.84, 2.94, 65.21, 2.11 Q 75.58, 2.89, 85.95, 2.05 Q 96.32, 2.25, 106.68, 3.50 Q 117.05, 3.03, 127.42, 2.21\
                     Q 137.79, 1.80, 148.16, 2.77 Q 158.53, 3.83, 168.89, 2.29 Q 179.26, 1.36, 189.63, 2.45 Q 200.00, 2.97, 210.37, 4.50 Q 220.74,\
                     4.11, 231.11, 3.31 Q 241.47, 3.10, 251.84, 1.97 Q 262.21, 2.09, 272.58, 1.73 Q 282.95, 2.26, 293.32, 2.92 Q 303.68, 3.91,\
                     314.05, 4.13 Q 324.42, 3.97, 334.79, 2.61 Q 345.16, 1.90, 355.53, 1.33 Q 365.89, 1.98, 376.26, 2.82 Q 386.63, 3.00, 397.00,\
                     3.00" style=" fill:none;" class="svg_unselected_element"/><svg:path id="__containerId__-page195982406-layer-501165204_line4" d="M 3.00, 3.00 Q 3.00, 15.00, 3.00, 27.00" style=" fill:none;"\
                     class="svg_unselected_element"/>\
                  </svg:g>\
               </svg:svg>\
               <div style="position:absolute;left: 6px; top: 1px;" title=""><input id="__containerId__-page195982406-layer-501165204input" onblur="rabbit.facade.raiseEvent(rabbit.events.svgBlur, new Array(\'__containerId__-page195982406-layer-501165204_input_svg_border\',\'__containerId__-page195982406-layer-501165204_line1\',\'__containerId__-page195982406-layer-501165204_line2\',\'__containerId__-page195982406-layer-501165204_line3\',\'__containerId__-page195982406-layer-501165204_line4\'))" onfocus="rabbit.facade.raiseEvent(rabbit.events.svgFocus, new Array(\'__containerId__-page195982406-layer-501165204_input_svg_border\',\'__containerId__-page195982406-layer-501165204_line1\',\'__containerId__-page195982406-layer-501165204_line2\',\'__containerId__-page195982406-layer-501165204_line3\',\'__containerId__-page195982406-layer-501165204_line4\'))" value="" style="width:393px;height:28px;padding: 0px;" type="text" /></div>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page195982406-layer-icon934293370" style="position: absolute; left: 115px; top: 145px; width: 32px; height: 32px" data-interactive-element-type="fonticon.icon" class="icon stencil mobile-interaction-potential-trigger " data-stencil-id="icon934293370" data-review-reference-id="icon934293370">\
         <div class="stencil-wrapper" style="width: 32px; height: 32px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" style="width:32px;height:32px;" title="">\
               <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" class="fill-red">\
                  <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#icon-glyph-e196"></use>\
               </svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page195982406-layer-532913823" style="position: absolute; left: 115px; top: 220px; width: 32px; height: 32px" data-interactive-element-type="fonticon.icon" class="icon stencil mobile-interaction-potential-trigger " data-stencil-id="532913823" data-review-reference-id="532913823">\
         <div class="stencil-wrapper" style="width: 32px; height: 32px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" style="width:32px;height:32px;" title="">\
               <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" class="fill-red">\
                  <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#icon-glyph-e196"></use>\
               </svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page195982406-layer-1151361062" style="position: absolute; left: 110px; top: 455px; width: 32px; height: 32px" data-interactive-element-type="fonticon.icon" class="icon stencil mobile-interaction-potential-trigger " data-stencil-id="1151361062" data-review-reference-id="1151361062">\
         <div class="stencil-wrapper" style="width: 32px; height: 32px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" style="width:32px;height:32px;" title="">\
               <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" class="fill-red">\
                  <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#icon-glyph-e196"></use>\
               </svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page195982406-layer-932295922" style="position: absolute; left: 110px; top: 540px; width: 32px; height: 32px" data-interactive-element-type="fonticon.icon" class="icon stencil mobile-interaction-potential-trigger " data-stencil-id="932295922" data-review-reference-id="932295922">\
         <div class="stencil-wrapper" style="width: 32px; height: 32px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" style="width:32px;height:32px;" title="">\
               <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" class="fill-red">\
                  <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#icon-glyph-e196"></use>\
               </svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page195982406-layer-1963586773" style="position: absolute; left: 115px; top: 620px; width: 32px; height: 32px" data-interactive-element-type="fonticon.icon" class="icon stencil mobile-interaction-potential-trigger " data-stencil-id="1963586773" data-review-reference-id="1963586773">\
         <div class="stencil-wrapper" style="width: 32px; height: 32px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" style="width:32px;height:32px;" title="">\
               <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" class="fill-red">\
                  <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#icon-glyph-e196"></use>\
               </svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page195982406-layer-datepicker303767136" style="position: absolute; left: 395px; top: 300px; width: 150px; height: 30px" data-interactive-element-type="default.datepicker" class="datepicker stencil mobile-interaction-potential-trigger " data-stencil-id="datepicker303767136" data-review-reference-id="datepicker303767136">\
         <div class="stencil-wrapper" style="width: 150px; height: 30px">\
            <div>\
               <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" style="position: absolute; height: 30px;width:150px;" width="150" height="30">\
                  <svg:g width="150px" height="30px"><svg:path id="__containerId__-page195982406-layer-datepicker303767136_input_svg_border" d="M 2.00, 2.00 Q 13.20, 1.96, 24.40,\
                     1.88 Q 35.60, 2.17, 46.80, 1.59 Q 58.00, 1.92, 69.20, 1.86 Q 80.40, 1.62, 91.60, 1.00 Q 102.80, 2.07, 114.09, 1.91 Q 113.49,\
                     15.17, 113.98, 27.98 Q 102.81, 28.04, 91.68, 28.68 Q 80.46, 29.24, 69.24, 29.65 Q 58.01, 28.76, 46.80, 27.78 Q 35.60, 28.31,\
                     24.40, 28.26 Q 13.20, 28.13, 2.17, 27.83 Q 2.00, 15.00, 2.00, 2.00" style=" fill:white;" class="svg_unselected_element"/><svg:path id="__containerId__-page195982406-layer-datepicker303767136_line1" d="M 3.00, 3.00 Q 14.90, 2.12, 26.80, 1.95 Q\
                     38.70, 2.52, 50.60, 2.01 Q 62.50, 2.08, 74.40, 2.71 Q 86.30, 2.31, 98.20, 2.08 Q 110.10, 3.00, 122.00, 3.00" style=" fill:none;"\
                     class="svg_unselected_element"/><svg:path id="__containerId__-page195982406-layer-datepicker303767136_line2" d="M 3.00, 3.00 Q 3.00, 15.00, 3.00, 27.00" style="\
                     fill:none;" class="svg_unselected_element"/><svg:path id="__containerId__-page195982406-layer-datepicker303767136_line3" d="M 3.00, 3.00 Q 14.90, 3.44, 26.80, 3.81 Q\
                     38.70, 4.31, 50.60, 2.92 Q 62.50, 2.85, 74.40, 3.17 Q 86.30, 3.73, 98.20, 1.92 Q 110.10, 3.00, 122.00, 3.00" style=" fill:none;"\
                     class="svg_unselected_element"/><svg:path id="__containerId__-page195982406-layer-datepicker303767136_line4" d="M 3.00, 3.00 Q 3.00, 15.00, 3.00, 27.00" style="\
                     fill:none;" class="svg_unselected_element"/>\
                  </svg:g>\
                  <svg:g width="150px" height="30px"><svg:path id="__containerId__-page195982406-layer-datepicker303767136_input_svg_border2" d="M 118.00, 2.00 Q 133.00, 1.42,\
                     148.01, 1.99 Q 148.15, 14.95, 148.21, 28.21 Q 133.11, 28.41, 117.74, 28.22 Q 118.00, 15.00, 118.00, 2.00" style=" fill:white;"\
                     class="svg_unselected_element"/>\
                  </svg:g>\
               </svg:svg>\
               <div style="white-space: nowrap;" title=""><input type="text" onblur="rabbit.facade.raiseEvent(rabbit.events.svgBlur, new Array(\'__containerId__-page195982406-layer-datepicker303767136_input_svg_border\',\'__containerId__-page195982406-layer-datepicker303767136_line1\',\'__containerId__-page195982406-layer-datepicker303767136_line2\',\'__containerId__-page195982406-layer-datepicker303767136_line3\',\'__containerId__-page195982406-layer-datepicker303767136_line4\'))" onfocus="rabbit.facade.raiseEvent(rabbit.events.svgFocus, new Array(\'__containerId__-page195982406-layer-datepicker303767136_input_svg_border\',\'__containerId__-page195982406-layer-datepicker303767136_line1\',\'__containerId__-page195982406-layer-datepicker303767136_line2\',\'__containerId__-page195982406-layer-datepicker303767136_line3\',\'__containerId__-page195982406-layer-datepicker303767136_line4\'))" style="width:116px; height:30px;padding: 0px;border-width:1px; position: absolute;" id="__containerId__-page195982406-layer-datepicker303767136_input" /><button type="button" onblur="rabbit.facade.raiseEvent(rabbit.events.svgBlur, \'__containerId__-page195982406-layer-datepicker303767136_input_svg_border2\')" onfocus="rabbit.facade.raiseEvent(rabbit.events.svgFocus, \'__containerId__-page195982406-layer-datepicker303767136_input_svg_border2\')" style="position:absolute; left:116px; top:0px; width:34px; height:30px; vertical-align: top; padding: 0px;border-width:1px; cursor:pointer;" id="__containerId__-page195982406-layer-datepicker303767136_button"><img src="../resources/icons/date.png" /></button></div>\
               <div id="__containerId__-page195982406-layer-datepicker303767136_ov" class="yui-skin-sam" style="position: absolute; width: 16em;visibility:visible;">\
                  <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" style="position: absolute; left: -6px; top: -4px; height: 204px;width:200px;display:none" id="__containerId__-page195982406-layer-datepicker303767136_open_calendar" width="150" height="204"><svg:path id="__containerId__-page195982406-layer-datepicker303767136_open_calendar_border" d="M 2.00, 2.00 Q 12.89, -0.52,\
                     23.78, 0.52 Q 34.67, 0.54, 45.56, 1.33 Q 56.44, 1.39, 67.33, 0.92 Q 78.22, 0.64, 89.11, 1.67 Q 100.00, 2.56, 110.89, 2.41\
                     Q 121.78, 2.44, 132.67, 1.97 Q 143.56, 1.16, 154.44, 0.35 Q 165.33, 0.06, 176.22, 0.09 Q 187.11, 0.49, 198.58, 1.42 Q 198.86,\
                     11.71, 199.15, 21.84 Q 199.18, 31.92, 199.29, 41.96 Q 199.51, 51.98, 199.24, 61.99 Q 199.31, 71.99, 199.32, 82.00 Q 199.45,\
                     92.00, 199.77, 102.00 Q 199.68, 112.00, 200.18, 122.00 Q 200.10, 132.00, 200.04, 142.00 Q 199.83, 152.00, 199.14, 162.00 Q\
                     199.04, 172.00, 199.17, 182.00 Q 199.49, 192.00, 198.58, 202.58 Q 187.39, 202.84, 176.34, 202.83 Q 165.40, 202.95, 154.48,\
                     203.01 Q 143.57, 203.10, 132.68, 203.15 Q 121.78, 203.29, 110.89, 203.06 Q 100.00, 203.03, 89.11, 202.60 Q 78.22, 202.49,\
                     67.33, 202.52 Q 56.44, 202.68, 45.56, 202.65 Q 34.67, 203.08, 23.78, 203.01 Q 12.89, 203.13, 1.32, 202.68 Q 1.01, 192.33,\
                     0.98, 182.15 Q 0.31, 172.11, 0.77, 162.04 Q -0.03, 152.03, 0.05, 142.02 Q 0.31, 132.01, 0.50, 122.00 Q 0.84, 112.00, 0.76,\
                     102.00 Q 1.24, 92.00, 1.06, 82.00 Q 0.58, 72.00, 0.82, 62.00 Q 0.25, 52.00, 0.43, 42.00 Q 0.01, 32.00, -0.08, 22.00 Q 2.00,\
                     12.00, 2.00, 2.00" style=" fill:white;" class="svg_unselected_element"/>\
                  </svg:svg>\
                  <div id="__containerId__-page195982406-layer-datepicker303767136_cal"></div>\
               </div><script type="text/javascript">\
				rabbit.stencils.datepicker.setupDatepicker("__containerId__-page195982406-layer-datepicker303767136");\
			</script></div>\
         </div>\
      </div>\
      <div id="__containerId__-page195982406-layer-radiobutton384608409" style="position: absolute; left: 610px; top: 305px; width: 52px; height: 20px" data-interactive-element-type="default.radiobutton" class="radiobutton stencil mobile-interaction-potential-trigger " data-stencil-id="radiobutton384608409" data-review-reference-id="radiobutton384608409">\
         <div class="stencil-wrapper" style="width: 52px; height: 20px">\
            <div class="">\
               <div style="font-size:1.17em;" xml:space="preserve" title="" onclick="rabbit.facade.fireMouseOn(\'__containerId__-page195982406-layer-radiobutton384608409_input\');">\
                  				<input id="__containerId__-page195982406-layer-radiobutton384608409_input" xml:space="default" type="radio" style="padding-right:8px" class="hidden_class" onblur="rabbit.facade.raiseEvent(rabbit.events.svgBlur, \'__containerId__-page195982406-layer-radiobutton384608409_input_svg_border\')" onfocus="rabbit.facade.raiseEvent(rabbit.events.svgFocus, \'__containerId__-page195982406-layer-radiobutton384608409_input_svg_border\')" onclick="rabbit.facade.raiseEvent(rabbit.events.radioButtonClicked, \'__containerId__-page195982406-layer-radiobutton384608409_input\', \'__containerId__-page195982406-layer-radiobutton384608409_input_svgChecked\');" name="group1" value="__containerId__-page195982406-layer-radiobutton384608409" />\
                  				\
                  				\
                  				\
                  					Nam\
                  					\
                  				\
                  			\
               </div>\
               <div title="">\
                  <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" style="position: absolute;  top: 1.0199999999999996px; height: 20px;width:52px;cursor: pointer;" width="52" height="20" onclick="rabbit.facade.fireMouseOn(\'__containerId__-page195982406-layer-radiobutton384608409_input\');">\
                     <svg:g id="__containerId__-page195982406-layer-radiobutton384608409_input_svg" x="0" y="1.0199999999999996" width="52" height="20" onclick="rabbit.facade.fireMouseOn(\'__containerId__-page195982406-layer-radiobutton384608409_input\');"><svg:path id="__containerId__-page195982406-layer-radiobutton384608409_input_svg_border" d="M 17.00, 10.00 Q 16.45, 9.91,\
                        15.16, 13.14 Q 12.02, 14.17, 9.12, 15.15 Q 6.03, 13.50, 6.36, 9.70 Q 7.06, 6.85, 9.02, 3.78 Q 13.28, 2.62, 17.12, 5.43 Q 17.00,\
                        10.10, 15.79, 13.61" style=" fill:white;" class="svg_unselected_element"/>\
                     </svg:g>\
                     <svg:g id="__containerId__-page195982406-layer-radiobutton384608409_input_svgChecked" x="0" y="1.0199999999999996" width="52" height="20" onclick="rabbit.facade.fireMouseOn(\'__containerId__-page195982406-layer-radiobutton384608409_input\');" visibility="hidden"><svg:path d="M 13.00, 10.00 Q 11.86, 9.64, 11.83, 10.63 Q 11.34, 11.40, 10.39, 11.63 Q 9.09, 11.42, 8.74, 10.00 Q 9.19, 8.68,\
                        10.27, 7.77 Q 11.76, 7.52, 12.94, 8.57 Q 13.00, 10.03, 12.60, 11.20" style="" class="svg_unselected_element"/>\
                     </svg:g>\
                  </svg:svg>\
               </div>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page195982406-layer-823983834" style="position: absolute; left: 705px; top: 305px; width: 41px; height: 20px" data-interactive-element-type="default.radiobutton" class="radiobutton stencil mobile-interaction-potential-trigger " data-stencil-id="823983834" data-review-reference-id="823983834">\
         <div class="stencil-wrapper" style="width: 41px; height: 20px">\
            <div class="">\
               <div style="font-size:1.17em;" xml:space="preserve" title="" onclick="rabbit.facade.fireMouseOn(\'__containerId__-page195982406-layer-823983834_input\');">\
                  				<input id="__containerId__-page195982406-layer-823983834_input" xml:space="default" type="radio" style="padding-right:8px" class="hidden_class" onblur="rabbit.facade.raiseEvent(rabbit.events.svgBlur, \'__containerId__-page195982406-layer-823983834_input_svg_border\')" onfocus="rabbit.facade.raiseEvent(rabbit.events.svgFocus, \'__containerId__-page195982406-layer-823983834_input_svg_border\')" onclick="rabbit.facade.raiseEvent(rabbit.events.radioButtonClicked, \'__containerId__-page195982406-layer-823983834_input\', \'__containerId__-page195982406-layer-823983834_input_svgChecked\');" name="group1" value="__containerId__-page195982406-layer-823983834" />\
                  				\
                  				\
                  				\
                  					Nữ\
                  					\
                  				\
                  			\
               </div>\
               <div title="">\
                  <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" style="position: absolute;  top: 1.0199999999999996px; height: 20px;width:41px;cursor: pointer;" width="41" height="20" onclick="rabbit.facade.fireMouseOn(\'__containerId__-page195982406-layer-823983834_input\');">\
                     <svg:g id="__containerId__-page195982406-layer-823983834_input_svg" x="0" y="1.0199999999999996" width="41" height="20" onclick="rabbit.facade.fireMouseOn(\'__containerId__-page195982406-layer-823983834_input\');"><svg:path id="__containerId__-page195982406-layer-823983834_input_svg_border" d="M 17.00, 10.00 Q 18.45, 10.60, 16.99, 14.51\
                        Q 13.40, 17.10, 8.89, 16.74 Q 5.26, 14.28, 3.83, 10.07 Q 5.24, 5.87, 8.89, 3.50 Q 13.12, 3.43, 16.52, 5.99 Q 17.00, 10.10,\
                        15.79, 13.61" style=" fill:white;" class="svg_unselected_element"/>\
                     </svg:g>\
                     <svg:g id="__containerId__-page195982406-layer-823983834_input_svgChecked" x="0" y="1.0199999999999996" width="41" height="20" onclick="rabbit.facade.fireMouseOn(\'__containerId__-page195982406-layer-823983834_input\');" visibility="hidden"><svg:path d="M 13.00, 10.00 Q 14.04, 10.39, 13.05, 11.54 Q 11.68, 12.11, 10.31, 12.15 Q 9.37, 11.14, 9.06, 9.96 Q 9.83, 9.03,\
                        10.35, 7.95 Q 11.66, 8.07, 12.39, 9.09 Q 13.00, 10.03, 12.60, 11.20" style="" class="svg_unselected_element"/>\
                     </svg:g>\
                  </svg:svg>\
               </div>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page195982406-layer-iphoneButton620649085" style="position: absolute; left: 875px; top: 745px; width: 120px; height: 55px" data-interactive-element-type="default.iphoneButton" class="iphoneButton stencil mobile-interaction-potential-trigger " data-stencil-id="iphoneButton620649085" data-review-reference-id="iphoneButton620649085">\
         <div class="stencil-wrapper" style="width: 120px; height: 55px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" title="" style="position: absolute; left: -2px; top: -2px;height: 59px;width:124px;">\
               <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" class="helvetica-font" width="124" height="59" viewBox="-2 -2 124 59">\
                  <svg:a><svg:path d="M 4.00, 54.00 Q 4.51, 52.49, 3.68, 52.72 Q 3.75, 40.11, 2.85, 27.51 Q 3.33, 14.74, 3.49, 2.19 Q 3.78, 1.69, 3.75,\
                     0.51 Q 14.42, 0.16, 25.19, 0.91 Q 35.78, 0.55, 46.40, 1.10 Q 56.99, -0.13, 67.60, 0.62 Q 78.20, 0.34, 88.80, -0.14 Q 99.40,\
                     -0.46, 110.33, -0.40 Q 111.37, 0.47, 112.51, 1.50 Q 117.42, 14.45, 122.36, 27.88 Q 116.88, 41.05, 112.00, 54.00 Q 111.31,\
                     54.89, 110.33, 56.00 Q 99.55, 55.98, 88.82, 55.30 Q 78.21, 55.34, 67.62, 56.32 Q 57.02, 56.95, 46.41, 56.97 Q 35.80, 56.93,\
                     25.20, 57.11 Q 14.60, 55.00, 4.00, 55.00" style="fill-rule:evenodd;clip-rule:evenodd;fill:#808080;stroke:#666666;" class="svg_unselected_element"/>\
                     <svg:text x="57" y="27.5" dy="0.3em" fill="#FFFFFF" style="font-size:1em;stroke-width:0pt;" font-family="\'HelveticaNeue-Bold\'" text-anchor="middle" xml:space="preserve">Đăng ký</svg:text>\
                  </svg:a>\
               </svg:svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page195982406-layer-checkbox5875495" style="position: absolute; left: 185px; top: 680px; width: 238px; height: 20px" data-interactive-element-type="default.checkbox" class="checkbox stencil mobile-interaction-potential-trigger " data-stencil-id="checkbox5875495" data-review-reference-id="checkbox5875495">\
         <div class="stencil-wrapper" style="width: 238px; height: 20px">\
            <div class="" style="font-size:1.17em;">\
               <div xml:space="preserve" title="" style="position:absolute" onclick="rabbit.facade.fireMouseOn(\'__containerId__-page195982406-layer-checkbox5875495_input\');">\
                  				\
                  <nobr>\
                     					<input id="__containerId__-page195982406-layer-checkbox5875495_input" xml:space="default" class="hidden_class" style="padding-right:9px" type="checkbox" onpropertychange="rabbit.facade.raiseEvent(rabbit.events.propertyChange, \'__containerId__-page195982406-layer-checkbox5875495_input\', \'__containerId__-page195982406-layer-checkbox5875495_input_svgChecked\');" onblur="rabbit.facade.raiseEvent(rabbit.events.svgBlur, \'__containerId__-page195982406-layer-checkbox5875495_input_svg_border\')" onfocus="rabbit.facade.raiseEvent(rabbit.events.svgFocus, \'__containerId__-page195982406-layer-checkbox5875495_input_svg_border\')" onclick="rabbit.facade.raiseEvent(rabbit.events.checkBoxClicked, \'__containerId__-page195982406-layer-checkbox5875495_input\', \'__containerId__-page195982406-layer-checkbox5875495_input_svgChecked\')" />\
                     				\
                     					\
                     					\
                     						Đăng ký với tư cách chủ cửa hàng\
                     						\
                     					\
                     				\
                  </nobr>\
                  			\
               </div>\
               <div title="">\
                  <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" style="position: absolute; height: 20px;width:238px;" width="238" height="20" onclick="rabbit.facade.fireMouseOn(\'__containerId__-page195982406-layer-checkbox5875495_input\');">\
                     <svg:g id="__containerId__-page195982406-layer-checkbox5875495_input_svg" x="0" y="1.0199999999999996" width="238" height="20"><svg:path id="__containerId__-page195982406-layer-checkbox5875495_input_svg_border" d="M 5.00, 5.00 Q 10.00, 5.52, 14.56,\
                        5.44 Q 14.19, 10.27, 14.66, 14.66 Q 9.88, 14.57, 5.26, 14.78 Q 5.00, 10.00, 5.00, 5.00" style=" fill:white;" class="svg_unselected_element"/>\
                     </svg:g>\
                     <svg:g id="__containerId__-page195982406-layer-checkbox5875495_input_svgChecked" x="0" y="1.0199999999999996" width="238" height="20" visibility="hidden"><svg:path d="M 5.00, 9.00 Q 8.00, 12.00, 11.00, 15.00" style=" fill:none;" class="svg_unselected_element"/><svg:path d="M 11.00, 15.00 Q 15.50, 7.00, 20.00, -1.00" style=" fill:none;" class="svg_unselected_element"/></svg:g>\
                  </svg:svg>\
               </div>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page195982406-layer-361062599" style="position: absolute; left: 185px; top: 720px; width: 268px; height: 20px" data-interactive-element-type="default.checkbox" class="checkbox stencil mobile-interaction-potential-trigger " data-stencil-id="361062599" data-review-reference-id="361062599">\
         <div class="stencil-wrapper" style="width: 268px; height: 20px">\
            <div class="" style="font-size:1.17em;">\
               <div xml:space="preserve" title="" style="position:absolute" onclick="rabbit.facade.fireMouseOn(\'__containerId__-page195982406-layer-361062599_input\');">\
                  				\
                  <nobr>\
                     					<input id="__containerId__-page195982406-layer-361062599_input" xml:space="default" class="hidden_class" style="padding-right:9px" type="checkbox" onpropertychange="rabbit.facade.raiseEvent(rabbit.events.propertyChange, \'__containerId__-page195982406-layer-361062599_input\', \'__containerId__-page195982406-layer-361062599_input_svgChecked\');" onblur="rabbit.facade.raiseEvent(rabbit.events.svgBlur, \'__containerId__-page195982406-layer-361062599_input_svg_border\')" onfocus="rabbit.facade.raiseEvent(rabbit.events.svgFocus, \'__containerId__-page195982406-layer-361062599_input_svg_border\')" onclick="rabbit.facade.raiseEvent(rabbit.events.checkBoxClicked, \'__containerId__-page195982406-layer-361062599_input\', \'__containerId__-page195982406-layer-361062599_input_svgChecked\')" checked="true" />\
                     				\
                     					\
                     					\
                     						Tôi đồng ý với các điều khoản sử dụng\
                     						\
                     					\
                     				\
                  </nobr>\
                  			\
               </div>\
               <div title="">\
                  <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" style="position: absolute; height: 20px;width:268px;" width="268" height="20" onclick="rabbit.facade.fireMouseOn(\'__containerId__-page195982406-layer-361062599_input\');">\
                     <svg:g id="__containerId__-page195982406-layer-361062599_input_svg" x="0" y="1.0199999999999996" width="268" height="20"><svg:path id="__containerId__-page195982406-layer-361062599_input_svg_border" d="M 5.00, 5.00 Q 10.00, 3.80, 15.18, 4.82 Q\
                        15.31, 9.90, 14.81, 14.81 Q 10.27, 15.99, 4.57, 15.36 Q 5.00, 10.00, 5.00, 5.00" style=" fill:white;" class="svg_unselected_element"/>\
                     </svg:g>\
                     <svg:g id="__containerId__-page195982406-layer-361062599_input_svgChecked" x="0" y="1.0199999999999996" width="268" height="20" visibility="inherit"><svg:path d="M 5.00, 9.00 Q 8.00, 12.00, 11.00, 15.00" style=" fill:none;" class="svg_unselected_element"/><svg:path d="M 11.00, 15.00 Q 15.50, 7.00, 20.00, -1.00" style=" fill:none;" class="svg_unselected_element"/></svg:g>\
                  </svg:svg>\
               </div>\
            </div>\
         </div>\
      </div>\
   </div>\
</div>');