rabbit.data.layerStore.addLayerFromHtml('<div xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:fn="http://www.w3.org/2005/xpath-functions" id="result">\
   <div xmlns:xs="http://www.w3.org/2001/XMLSchema" xmlns="http://www.w3.org/1999/xhtml" id="__containerId__page310606381-layer" class="layer" name="__containerId__pageLayer" data-layer-id="page310606381" data-layer-type="pageLayer" style="position:absolute;left:0px;top:0px;">\
      <div id="__containerId__-page310606381-layer-image377306962" style="position: absolute; left: 0px; top: 0px; width: 1366px; height: 2000px" data-interactive-element-type="default.image" class="image stencil mobile-interaction-potential-trigger " data-stencil-id="image377306962" data-review-reference-id="image377306962">\
         <div class="stencil-wrapper" style="width: 1366px; height: 2000px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" title="">\
               <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" class="image-cropper" style="height: 2000px;width:1366px;" width="1366" height="2000">\
                  <svg:g width="1366" height="2000">\
                     <svg:svg x="1" y="1" width="1364" height="1998">\
                        <svg:image width="432" height="253" xlink:href="../repoimages/508372.PNG" preserveAspectRatio="none" transform="scale(3.162037037037037,7.905138339920948) translate(-0,-0)  "></svg:image>\
                     </svg:svg>\
                  </svg:g>\
               </svg:svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page310606381-layer-image290283686" style="position: absolute; left: 0px; top: 40px; width: 1366px; height: 2500px" data-interactive-element-type="default.image" class="image stencil mobile-interaction-potential-trigger " data-stencil-id="image290283686" data-review-reference-id="image290283686">\
         <div class="stencil-wrapper" style="width: 1366px; height: 2500px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" title="">\
               <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" class="image-cropper" style="height: 2500px;width:1366px;" width="1366" height="2500">\
                  <svg:g width="1366" height="2500">\
                     <svg:svg x="1" y="1" width="1364" height="2498">\
                        <svg:image width="432" height="253" xlink:href="../repoimages/508372.PNG" preserveAspectRatio="none" transform="scale(3.162037037037037,9.881422924901186) translate(-0,-0)  "></svg:image>\
                     </svg:svg>\
                  </svg:g>\
               </svg:svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page310606381-layer-image48482458" style="position: absolute; left: 0px; top: 75px; width: 1366px; height: 2500px" data-interactive-element-type="default.image" class="image stencil mobile-interaction-potential-trigger " data-stencil-id="image48482458" data-review-reference-id="image48482458">\
         <div class="stencil-wrapper" style="width: 1366px; height: 2500px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" title="">\
               <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" class="image-cropper" style="height: 2500px;width:1366px;" width="1366" height="2500">\
                  <svg:g width="1366" height="2500">\
                     <svg:svg x="1" y="1" width="1364" height="2498">\
                        <svg:image width="432" height="253" xlink:href="../repoimages/508372.PNG" preserveAspectRatio="none" transform="scale(3.162037037037037,9.881422924901186) translate(-0,-0)  "></svg:image>\
                     </svg:svg>\
                  </svg:g>\
               </svg:svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page310606381-layer-image422146603" style="position: absolute; left: 0px; top: 0px; width: 1366px; height: 145px" data-interactive-element-type="default.image" class="image stencil mobile-interaction-potential-trigger " data-stencil-id="image422146603" data-review-reference-id="image422146603">\
         <div class="stencil-wrapper" style="width: 1366px; height: 145px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" title="">\
               <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" class="image-cropper" style="height: 145px;width:1366px;" width="1366" height="145">\
                  <svg:g width="1366" height="145">\
                     <svg:svg x="1" y="1" width="1364" height="143">\
                        <svg:image width="80" height="60" xlink:href="../repoimages/508394.PNG" preserveAspectRatio="none" transform="scale(17.075,2.4166666666666665) translate(-0,-0)  "></svg:image>\
                     </svg:svg>\
                  </svg:g>\
               </svg:svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page310606381-layer-image229590994" style="position: absolute; left: 10px; top: 155px; width: 866px; height: 577px" data-interactive-element-type="default.image" class="image stencil mobile-interaction-potential-trigger " data-stencil-id="image229590994" data-review-reference-id="image229590994">\
         <div class="stencil-wrapper" style="width: 866px; height: 577px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" title="">\
               <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" class="image-cropper" style="height: 577px;width:866px;" width="866" height="577">\
                  <svg:g width="866" height="577">\
                     <svg:svg x="1" y="1" width="864" height="575">\
                        <svg:image width="80" height="60" xlink:href="../repoimages/508395.JPG" preserveAspectRatio="none" transform="scale(10.825,9.616666666666667) translate(-0,-0)  "></svg:image>\
                     </svg:svg>\
                  </svg:g>\
               </svg:svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page310606381-layer-image732056455" style="position: absolute; left: 295px; top: 740px; width: 100px; height: 100px" data-interactive-element-type="default.image" class="image stencil mobile-interaction-potential-trigger " data-stencil-id="image732056455" data-review-reference-id="image732056455">\
         <div class="stencil-wrapper" style="width: 100px; height: 100px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" title="">\
               <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" class="image-cropper" style="height: 100px;width:100px;" width="100" height="100">\
                  <svg:g width="100" height="100">\
                     <svg:svg x="1" y="1" width="98" height="98">\
                        <svg:image width="80" height="60" xlink:href="../repoimages/508400.JPG" preserveAspectRatio="none" transform="scale(1.25,1.6666666666666667) translate(-0,-0)  "></svg:image>\
                     </svg:svg>\
                  </svg:g>\
               </svg:svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page310606381-layer-image159827258" style="position: absolute; left: 675px; top: 740px; width: 100px; height: 100px" data-interactive-element-type="default.image" class="image stencil mobile-interaction-potential-trigger " data-stencil-id="image159827258" data-review-reference-id="image159827258">\
         <div class="stencil-wrapper" style="width: 100px; height: 100px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" title="">\
               <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" class="image-cropper" style="height: 100px;width:100px;" width="100" height="100">\
                  <svg:g width="100" height="100">\
                     <svg:svg x="1" y="1" width="98" height="98">\
                        <svg:image width="80" height="60" xlink:href="../repoimages/508401.jpg" preserveAspectRatio="none" transform="scale(1.25,1.6666666666666667) translate(-0,-0)  "></svg:image>\
                     </svg:svg>\
                  </svg:g>\
               </svg:svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page310606381-layer-image798264162" style="position: absolute; left: 550px; top: 740px; width: 100px; height: 100px" data-interactive-element-type="default.image" class="image stencil mobile-interaction-potential-trigger " data-stencil-id="image798264162" data-review-reference-id="image798264162">\
         <div class="stencil-wrapper" style="width: 100px; height: 100px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" title="">\
               <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" class="image-cropper" style="height: 100px;width:100px;" width="100" height="100">\
                  <svg:g width="100" height="100">\
                     <svg:svg x="1" y="1" width="98" height="98">\
                        <svg:image width="80" height="60" xlink:href="../repoimages/508402.jpg" preserveAspectRatio="none" transform="scale(1.25,1.6666666666666667) translate(-0,-0)  "></svg:image>\
                     </svg:svg>\
                  </svg:g>\
               </svg:svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page310606381-layer-image351591010" style="position: absolute; left: 425px; top: 740px; width: 100px; height: 100px" data-interactive-element-type="default.image" class="image stencil mobile-interaction-potential-trigger " data-stencil-id="image351591010" data-review-reference-id="image351591010">\
         <div class="stencil-wrapper" style="width: 100px; height: 100px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" title="">\
               <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" class="image-cropper" style="height: 100px;width:100px;" width="100" height="100">\
                  <svg:g width="100" height="100">\
                     <svg:svg x="1" y="1" width="98" height="98">\
                        <svg:image width="80" height="60" xlink:href="../repoimages/508403.JPG" preserveAspectRatio="none" transform="scale(1.25,1.6666666666666667) translate(-0,-0)  "></svg:image>\
                     </svg:svg>\
                  </svg:g>\
               </svg:svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page310606381-layer-icon811601317" style="position: absolute; left: 5px; top: 400px; width: 48px; height: 48px" data-interactive-element-type="fonticon.icon" class="icon stencil mobile-interaction-potential-trigger " data-stencil-id="icon811601317" data-review-reference-id="icon811601317">\
         <div class="stencil-wrapper" style="width: 48px; height: 48px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" style="width:48px;height:48px;" title="">\
               <svg xmlns="http://www.w3.org/2000/svg" width="48" height="48" class="fill-black">\
                  <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#icon-glyph-e225"></use>\
               </svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page310606381-layer-icon191086089" style="position: absolute; left: 830px; top: 400px; width: 48px; height: 48px" data-interactive-element-type="fonticon.icon" class="icon stencil mobile-interaction-potential-trigger " data-stencil-id="icon191086089" data-review-reference-id="icon191086089">\
         <div class="stencil-wrapper" style="width: 48px; height: 48px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" style="width:48px;height:48px;" title="">\
               <svg xmlns="http://www.w3.org/2000/svg" width="48" height="48" class="fill-black">\
                  <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#icon-glyph-e224"></use>\
               </svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page310606381-layer-image40186489" style="position: absolute; left: 885px; top: 155px; width: 470px; height: 1330px" data-interactive-element-type="default.image" class="image stencil mobile-interaction-potential-trigger " data-stencil-id="image40186489" data-review-reference-id="image40186489">\
         <div class="stencil-wrapper" style="width: 470px; height: 1330px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" title="">\
               <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" class="image-cropper" style="height: 1330px;width:470px;" width="470" height="1330">\
                  <svg:g width="470" height="1330">\
                     <svg:svg x="1" y="1" width="468" height="1328">\
                        <svg:image width="93" height="25" xlink:href="../repoimages/508405.PNG" preserveAspectRatio="none" transform="scale(5.053763440860215,53.2) translate(-0,-0)  "></svg:image>\
                     </svg:svg>\
                  </svg:g>\
               </svg:svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page310606381-layer-icon890675694" style="position: absolute; left: 1320px; top: 145px; width: 32px; height: 32px" data-interactive-element-type="fonticon.icon" class="icon stencil mobile-interaction-potential-trigger " data-stencil-id="icon890675694" data-review-reference-id="icon890675694">\
         <div class="stencil-wrapper" style="width: 32px; height: 32px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" style="width:32px;height:32px;" title="">\
               <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" class="fill-black">\
                  <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#icon-glyph-e336"></use>\
               </svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page310606381-layer-text906924579" style="position: absolute; left: 900px; top: 425px; width: 235px; height: 37px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text906924579" data-review-reference-id="text906924579">\
         <div class="stencil-wrapper" style="width: 235px; height: 37px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline12"><p class="none" style="font-size: 32px;"><span style="color: #658cd9;">Điểm đặc trưng </span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page310606381-layer-rating586227224" style="position: absolute; left: 900px; top: 160px; width: 170px; height: 40px" data-interactive-element-type="default.rating" class="rating stencil mobile-interaction-potential-trigger " data-stencil-id="rating586227224" data-review-reference-id="rating586227224">\
         <div class="stencil-wrapper" style="width: 170px; height: 40px">\
            <div style="width:170px; height:40px" onmouseout="if(rabbit.stencils.rating.checkMouseOutDiv(\'__containerId__-page310606381-layer-rating586227224\', event)) rabbit.facade.raiseEvent(rabbit.events.ratingMouseOut, \'__containerId__-page310606381-layer-rating586227224\');" title=""><img id="__containerId__-page310606381-layer-rating586227224-1" src="../resources/icons/rating_black.png" width="34" height="40" style="position: absolute; left: 0px; cursor: pointer;" onmouseover="rabbit.facade.raiseEvent(rabbit.events.ratingMouseOver, \'__containerId__-page310606381-layer-rating586227224\', \'1\');" onclick="rabbit.facade.raiseEvent(rabbit.events.ratingResultChangedEvent, \'__containerId__-page310606381-layer-rating586227224\', \'1\');" /><img id="__containerId__-page310606381-layer-rating586227224-2" src="../resources/icons/rating_black.png" width="34" height="40" style="position: absolute; left: 34px; cursor: pointer;" onmouseover="rabbit.facade.raiseEvent(rabbit.events.ratingMouseOver, \'__containerId__-page310606381-layer-rating586227224\', \'2\');" onclick="rabbit.facade.raiseEvent(rabbit.events.ratingResultChangedEvent, \'__containerId__-page310606381-layer-rating586227224\', \'2\');" /><img id="__containerId__-page310606381-layer-rating586227224-3" src="../resources/icons/rating_black.png" width="34" height="40" style="position: absolute; left: 68px; cursor: pointer;" onmouseover="rabbit.facade.raiseEvent(rabbit.events.ratingMouseOver, \'__containerId__-page310606381-layer-rating586227224\', \'3\');" onclick="rabbit.facade.raiseEvent(rabbit.events.ratingResultChangedEvent, \'__containerId__-page310606381-layer-rating586227224\', \'3\');" /><img id="__containerId__-page310606381-layer-rating586227224-4" src="../resources/icons/rating_black.png" width="34" height="40" style="position: absolute; left: 102px; cursor: pointer;" onmouseover="rabbit.facade.raiseEvent(rabbit.events.ratingMouseOver, \'__containerId__-page310606381-layer-rating586227224\', \'4\');" onclick="rabbit.facade.raiseEvent(rabbit.events.ratingResultChangedEvent, \'__containerId__-page310606381-layer-rating586227224\', \'4\');" /><img id="__containerId__-page310606381-layer-rating586227224-5" src="../resources/icons/rating_white.png" width="34" height="40" style="position: absolute; left: 136px; cursor: pointer;" onmouseover="rabbit.facade.raiseEvent(rabbit.events.ratingMouseOver, \'__containerId__-page310606381-layer-rating586227224\', \'5\');" onclick="rabbit.facade.raiseEvent(rabbit.events.ratingResultChangedEvent, \'__containerId__-page310606381-layer-rating586227224\', \'5\');" /></div><script type="text/javascript">\
			rabbit.stencils.rating.onLoad("__containerId__-page310606381-layer-rating586227224", "4");\
		</script></div>\
      </div>\
      <div id="__containerId__-page310606381-layer-text184817720" style="position: absolute; left: 1090px; top: 170px; width: 111px; height: 23px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text184817720" data-review-reference-id="text184817720">\
         <div class="stencil-wrapper" style="width: 111px; height: 23px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.text2"><p class="none" style="font-size: 14px;"><span style="font-size: 20px;">13 đánh giá </span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page310606381-layer-text24658791" style="position: absolute; left: 1215px; top: 170px; width: 99px; height: 20px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text24658791" data-review-reference-id="text24658791">\
         <div class="stencil-wrapper" style="width: 99px; height: 20px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.link2"><p class="underline" style="font-size: 14px;"><span style="font-size: 18px;">1 nhận xét</span></p>\
                     <p class="underline" style="font-size: 14px;"> </p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page310606381-layer-text91490634" style="position: absolute; left: 900px; top: 265px; width: 403px; height: 20px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text91490634" data-review-reference-id="text91490634">\
         <div class="stencil-wrapper" style="width: 403px; height: 20px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline32"><span style="font-size: 18px;">AEON Mall Long Biên, Quận Long Biên, Hà Nội</span></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page310606381-layer-text790498912" style="position: absolute; left: 900px; top: 320px; width: 234px; height: 20px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text790498912" data-review-reference-id="text790498912">\
         <div class="stencil-wrapper" style="width: 234px; height: 20px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline32"><p><span class="bold" style="font-size: 18px; color: #658cd9;">Chương trình khuyến mại:</span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page310606381-layer-text4154276" style="position: absolute; left: 900px; top: 215px; width: 177px; height: 37px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text4154276" data-review-reference-id="text4154276">\
         <div class="stencil-wrapper" style="width: 177px; height: 37px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline12"><p><span style="font-size: 32px; color: #658cd9;">0121456756</span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page310606381-layer-text155070247" style="position: absolute; left: 895px; top: 355px; width: 295px; height: 76px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text155070247" data-review-reference-id="text155070247">\
         <div class="stencil-wrapper" style="width: 295px; height: 76px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textblock2"><p style="font-size: 14px;"><span style="font-size: 18px;">_ Giảm 30% cho khách mới</span><br /><span style="font-size: 18px;">_\
                     Giảm 10% cho đơn hàng trên 1 tr</span><br /><span style="font-size: 18px;"> </span><br /><br /></p>\
                     <p style="font-size: 14px;"> </p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page310606381-layer-text963000291" style="position: absolute; left: 900px; top: 475px; width: 370px; height: 20px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text963000291" data-review-reference-id="text963000291">\
         <div class="stencil-wrapper" style="width: 370px; height: 20px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline12"><p><span style="font-size: 18px;"><span class="bold">Loại hình ẩm thực</span> : Lẩu - Nướng - Ba miền</span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page310606381-layer-42333538" style="position: absolute; left: 900px; top: 515px; width: 435px; height: 60px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="42333538" data-review-reference-id="42333538">\
         <div class="stencil-wrapper" style="width: 435px; height: 60px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline12"><p><span style="font-size: 18px;"><span class="bold">Món đặc sắc</span> : Bánh xèo, lẩu hải sản, bún bò Huế, phở Hà Nội, bánh\
                     tôm Hồ Tây, bánh hỏi chạo tôm, hải sản nướng</span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page310606381-layer-996597469" style="position: absolute; left: 900px; top: 600px; width: 390px; height: 20px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="996597469" data-review-reference-id="996597469">\
         <div class="stencil-wrapper" style="width: 390px; height: 20px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline12"><p><span style="font-size: 18px;"><span class="bold">Giá trung bình</span> : 100.000 - 150.000 vnđ/người</span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page310606381-layer-2014622778" style="position: absolute; left: 900px; top: 655px; width: 451px; height: 40px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="2014622778" data-review-reference-id="2014622778">\
         <div class="stencil-wrapper" style="width: 451px; height: 40px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline12"><p><span style="font-size: 18px;"><span class="bold">Không gian</span> : Phong cách đường phố Việt truyền thống của 3 miền\
                     độc đáo. Sức chứa: 800 khách</span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page310606381-layer-iphoneButton414354944" style="position: absolute; left: 1250px; top: 760px; width: 92px; height: 30px" data-interactive-element-type="default.iphoneButton" class="iphoneButton stencil mobile-interaction-potential-trigger " data-stencil-id="iphoneButton414354944" data-review-reference-id="iphoneButton414354944">\
         <div class="stencil-wrapper" style="width: 92px; height: 30px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" title="" style="position: absolute; left: -2px; top: -2px;height: 34px;width:96px;">\
               <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" class="helvetica-font" width="96" height="34" viewBox="-2 -2 96 34">\
                  <svg:a><svg:path d="M 4.00, 29.00 Q 2.81, 29.19, 2.09, 28.38 Q 2.58, 15.08, 2.36, 1.79 Q 2.87, 1.10, 3.84, 0.69 Q 16.92, 0.61, 29.93,\
                     0.27 Q 42.99, 0.80, 56.00, 0.80 Q 69.01, 1.80, 81.88, 1.51 Q 82.81, 2.03, 83.92, 2.10 Q 88.69, 8.32, 93.43, 14.98 Q 88.42,\
                     21.47, 83.58, 27.61 Q 82.99, 28.49, 81.93, 28.78 Q 68.96, 28.71, 55.96, 28.47 Q 43.01, 29.18, 30.01, 29.72 Q 17.00, 29.00,\
                     4.00, 29.00" style="fill-rule:evenodd;clip-rule:evenodd;fill:#808080;stroke:#666666;" class="svg_unselected_element"/>\
                     <svg:text x="43" y="15" dy="0.3em" fill="#FFFFFF" style="font-size:1em;stroke-width:0pt;" font-family="\'HelveticaNeue-Bold\'" text-anchor="middle" xml:space="preserve">Đạt chỗ ngay</svg:text>\
                  </svg:a>\
               </svg:svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page310606381-layer-image660004996" style="position: absolute; left: 20px; top: 860px; width: 830px; height: 580px" data-interactive-element-type="default.image" class="image stencil mobile-interaction-potential-trigger " data-stencil-id="image660004996" data-review-reference-id="image660004996">\
         <div class="stencil-wrapper" style="width: 830px; height: 580px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" title="">\
               <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" class="image-cropper" style="height: 580px;width:830px;" width="830" height="580">\
                  <svg:g width="830" height="580">\
                     <svg:svg x="1" y="1" width="828" height="578">\
                        <svg:image width="80" height="60" xlink:href="../repoimages/508410.PNG" preserveAspectRatio="none" transform="scale(10.375,9.666666666666666) translate(-0,-0)  "></svg:image>\
                     </svg:svg>\
                  </svg:g>\
               </svg:svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page310606381-layer-image743413727" style="position: absolute; left: 20px; top: 900px; width: 830px; height: 580px" data-interactive-element-type="default.image" class="image stencil mobile-interaction-potential-trigger " data-stencil-id="image743413727" data-review-reference-id="image743413727">\
         <div class="stencil-wrapper" style="width: 830px; height: 580px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" title="">\
               <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" class="image-cropper" style="height: 580px;width:830px;" width="830" height="580">\
                  <svg:g width="830" height="580">\
                     <svg:svg x="1" y="1" width="828" height="578">\
                        <svg:image width="80" height="60" xlink:href="../repoimages/508410.PNG" preserveAspectRatio="none" transform="scale(10.375,9.666666666666666) translate(-0,-0)  "></svg:image>\
                     </svg:svg>\
                  </svg:g>\
               </svg:svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page310606381-layer-image529488340" style="position: absolute; left: 20px; top: 1480px; width: 860px; height: 278px" data-interactive-element-type="default.image" class="image stencil mobile-interaction-potential-trigger " data-stencil-id="image529488340" data-review-reference-id="image529488340">\
         <div class="stencil-wrapper" style="width: 860px; height: 278px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" title="">\
               <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" class="image-cropper" style="height: 278px;width:860px;" width="860" height="278">\
                  <svg:g width="860" height="278">\
                     <svg:svg x="1" y="1" width="858" height="276">\
                        <svg:image width="80" height="60" xlink:href="../repoimages/508411.PNG" preserveAspectRatio="none" transform="scale(10.75,4.633333333333334) translate(-0,-0)  "></svg:image>\
                     </svg:svg>\
                  </svg:g>\
               </svg:svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page310606381-layer-map379231884" style="position: absolute; left: 50px; top: 1765px; width: 820px; height: 430px" data-interactive-element-type="static.map" class="map stencil mobile-interaction-potential-trigger " data-stencil-id="map379231884" data-review-reference-id="map379231884">\
         <div class="stencil-wrapper" style="width: 820px; height: 430px">\
            <div style="background:white;width:814px; height:424px;border:none" title="">\
               <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" style="height: 430px;width:820px;" width="820" height="430">\
                  <svg:g id="__containerId__-page310606381-layer-map379231884svg" width="820" height="430"><svg:path d="M 2.00, 2.00 Q 12.20, 1.82, 22.40, 1.73 Q 32.60, 1.89, 42.80, 1.66 Q 53.00, 1.14, 63.20, 1.13 Q 73.40, 1.29,\
                     83.60, 1.18 Q 93.80, 1.97, 104.00, 0.93 Q 114.20, 1.47, 124.40, 1.34 Q 134.60, 2.06, 144.80, 1.76 Q 155.00, 1.50, 165.20,\
                     2.24 Q 175.40, 3.23, 185.60, 3.03 Q 195.80, 1.65, 206.00, 0.68 Q 216.20, 1.28, 226.40, 1.48 Q 236.60, 1.47, 246.80, 1.36 Q\
                     257.00, 2.04, 267.20, 1.86 Q 277.40, 1.84, 287.60, 1.91 Q 297.80, 1.36, 308.00, 1.97 Q 318.20, 2.91, 328.40, 2.55 Q 338.60,\
                     2.62, 348.80, 2.76 Q 359.00, 2.94, 369.20, 2.54 Q 379.40, 1.52, 389.60, 1.60 Q 399.80, 0.88, 410.00, 0.30 Q 420.20, -0.46,\
                     430.40, 0.48 Q 440.60, 0.55, 450.80, 0.12 Q 461.00, 0.48, 471.20, 0.47 Q 481.40, 1.06, 491.60, 0.53 Q 501.80, 1.11, 512.00,\
                     0.60 Q 522.20, 0.12, 532.40, 0.14 Q 542.60, 0.06, 552.80, 0.17 Q 563.00, 0.40, 573.20, 0.17 Q 583.40, -0.26, 593.60, -0.59\
                     Q 603.80, -0.49, 614.00, 1.04 Q 624.20, 1.76, 634.40, 2.14 Q 644.60, 1.92, 654.80, 1.89 Q 665.00, 2.03, 675.20, 2.21 Q 685.40,\
                     2.05, 695.60, 1.99 Q 705.80, 1.34, 716.00, 1.66 Q 726.20, 1.85, 736.40, 1.74 Q 746.60, 2.18, 756.80, 1.44 Q 767.00, 2.96,\
                     777.20, 2.87 Q 787.40, 2.08, 797.60, 1.48 Q 807.80, 1.24, 818.63, 1.37 Q 819.73, 11.57, 819.83, 22.02 Q 819.46, 32.33, 818.68,\
                     42.55 Q 819.82, 52.69, 818.74, 62.85 Q 819.66, 72.99, 818.88, 83.14 Q 819.08, 93.28, 818.77, 103.43 Q 817.90, 113.57, 818.68,\
                     123.71 Q 818.15, 133.86, 818.08, 144.00 Q 818.62, 154.14, 818.03, 164.29 Q 817.96, 174.43, 817.69, 184.57 Q 817.48, 194.71,\
                     818.41, 204.86 Q 818.78, 215.00, 818.96, 225.14 Q 819.17, 235.29, 818.51, 245.43 Q 819.47, 255.57, 818.99, 265.71 Q 819.69,\
                     275.86, 819.56, 286.00 Q 819.28, 296.14, 819.40, 306.29 Q 819.55, 316.43, 819.90, 326.57 Q 820.03, 336.71, 820.12, 346.86\
                     Q 820.30, 357.00, 820.41, 367.14 Q 820.39, 377.29, 820.14, 387.43 Q 819.39, 397.57, 818.74, 407.71 Q 819.35, 417.86, 818.32,\
                     428.32 Q 808.08, 428.85, 797.75, 429.03 Q 787.48, 429.25, 777.24, 429.16 Q 767.02, 428.93, 756.81, 429.20 Q 746.61, 429.24,\
                     736.40, 429.36 Q 726.20, 429.45, 716.00, 429.42 Q 705.80, 428.80, 695.60, 429.29 Q 685.40, 428.72, 675.20, 428.73 Q 665.00,\
                     428.94, 654.80, 429.25 Q 644.60, 429.23, 634.40, 429.30 Q 624.20, 429.43, 614.00, 429.61 Q 603.80, 429.21, 593.60, 428.86\
                     Q 583.40, 427.84, 573.20, 427.59 Q 563.00, 427.97, 552.80, 428.59 Q 542.60, 428.86, 532.40, 427.68 Q 522.20, 427.14, 512.00,\
                     427.56 Q 501.80, 427.75, 491.60, 427.18 Q 481.40, 427.15, 471.20, 427.37 Q 461.00, 427.52, 450.80, 428.09 Q 440.60, 427.95,\
                     430.40, 428.32 Q 420.20, 429.11, 410.00, 429.68 Q 399.80, 429.69, 389.60, 429.06 Q 379.40, 428.31, 369.20, 428.53 Q 359.00,\
                     427.32, 348.80, 427.65 Q 338.60, 428.57, 328.40, 429.76 Q 318.20, 428.72, 308.00, 427.67 Q 297.80, 428.62, 287.60, 429.78\
                     Q 277.40, 428.66, 267.20, 428.37 Q 257.00, 428.18, 246.80, 428.41 Q 236.60, 428.57, 226.40, 428.35 Q 216.20, 427.25, 206.00,\
                     427.22 Q 195.80, 427.62, 185.60, 428.86 Q 175.40, 429.65, 165.20, 429.10 Q 155.00, 428.30, 144.80, 429.28 Q 134.60, 429.79,\
                     124.40, 429.90 Q 114.20, 429.59, 104.00, 428.01 Q 93.80, 428.60, 83.60, 429.09 Q 73.40, 429.40, 63.20, 429.48 Q 53.00, 429.40,\
                     42.80, 429.29 Q 32.60, 429.28, 22.40, 428.92 Q 12.20, 429.24, 1.77, 428.23 Q 2.05, 417.84, 1.64, 407.77 Q 0.56, 397.67, 0.80,\
                     387.47 Q 1.52, 377.29, 1.71, 367.15 Q 0.80, 357.00, 0.69, 346.86 Q 1.01, 336.72, 1.39, 326.57 Q 1.25, 316.43, 0.37, 306.29\
                     Q 0.54, 296.14, 0.87, 286.00 Q 1.62, 275.86, 1.21, 265.71 Q 1.33, 255.57, 0.82, 245.43 Q 0.32, 235.29, 0.66, 225.14 Q 0.39,\
                     215.00, 0.09, 204.86 Q 0.23, 194.71, 0.30, 184.57 Q 0.20, 174.43, 0.06, 164.29 Q -0.12, 154.14, -0.05, 144.00 Q 0.45, 133.86,\
                     0.05, 123.71 Q -0.03, 113.57, 0.04, 103.43 Q 0.77, 93.29, 0.29, 83.14 Q 0.71, 73.00, 1.46, 62.86 Q 2.33, 52.71, 2.39, 42.57\
                     Q 0.63, 32.43, 0.60, 22.29 Q 2.00, 12.14, 2.00, 2.00" style=" fill:white;" class="svg_unselected_element"/>\
                  </svg:g>\
               </svg:svg><img src="../resources/icons/map_default.png" style="position:absolute;left:4px;top:4px;;width:814px;height:424px;overflow:auto;" width="814" height="424" preserveAspectRatio="none" /></div>\
         </div>\
      </div>\
      <div id="__containerId__-page310606381-layer-image761310260" style="position: absolute; left: 45px; top: 2210px; width: 820px; height: 300px" data-interactive-element-type="default.image" class="image stencil mobile-interaction-potential-trigger " data-stencil-id="image761310260" data-review-reference-id="image761310260">\
         <div class="stencil-wrapper" style="width: 820px; height: 300px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" title="">\
               <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" class="image-cropper" style="height: 300px;width:820px;" width="820" height="300">\
                  <svg:g width="820" height="300">\
                     <svg:svg x="1" y="1" width="818" height="298">\
                        <svg:image width="80" height="60" xlink:href="../repoimages/508412.PNG" preserveAspectRatio="none" transform="scale(10.25,5) translate(-0,-0)  "></svg:image>\
                     </svg:svg>\
                  </svg:g>\
               </svg:svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page310606381-layer-434730018" style="position: absolute; left: 900px; top: 710px; width: 425px; height: 20px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="434730018" data-review-reference-id="434730018">\
         <div class="stencil-wrapper" style="width: 425px; height: 20px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline12"><p><span style="font-size: 18px;"><span class="bold">Giờ mở cửa</span> : 7h sáng - 10h đêm / làm cả ngày lễ</span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page310606381-layer-icon742604360" style="position: absolute; left: 320px; top: 105px; width: 32px; height: 32px" data-interactive-element-type="fonticon.icon" class="icon pidoco-clickable-element stencil mobile-interaction-potential-trigger " data-stencil-id="icon742604360" data-review-reference-id="icon742604360">\
         <div class="stencil-wrapper" style="width: 32px; height: 32px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" style="width:32px;height:32px;" title="">\
               <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" class="fill-green">\
                  <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#icon-glyph-e210"></use>\
               </svg>\
            </div>\
         </div><script type="text/javascript">\
			$(document).ready(function(){\
				rabbit.interaction.manager.registerInteraction(\'__containerId__-page310606381-layer-icon742604360\', \'interaction524586502\', \
		{\
		\
			\'button\': \'left\'\
			\
				,\
			\
			\'id\': \'action702678278\'\
			\
				,\
			\
			\'numberOfFinger\': \'1\'\
			\
				,\
			\
			\'type\': \'click\'\
			\
		}\
	,  \
					[\
						\
		{\
		\
			\'delay\': \'0\'\
			\
				,\
			\
			\'id\': \'reaction792968331\'\
			\
				,\
			\
			\'options\': \'withoutReloadOnly\'\
			\
				,\
			\
			\'target\': \'page584926941\'\
			\
				,\
			\
			\'transition\': \'none\'\
			\
				,\
			\
			\'type\': \'showPage\'\
			\
		}\
	\
					]\
				);\
			});\
		</script></div>\
   </div>\
</div>');