rabbit.data.layerStore.addLayerFromHtml('<div xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:fn="http://www.w3.org/2005/xpath-functions" id="result">\
   <div xmlns:xs="http://www.w3.org/2001/XMLSchema" xmlns="http://www.w3.org/1999/xhtml" id="__containerId__page310606381-layer" class="layer" name="__containerId__pageLayer" data-layer-id="page310606381" data-layer-type="pageLayer" style="position:absolute;left:0px;top:0px;">\
      <div id="__containerId__-page310606381-layer-image377306962" style="position: absolute; left: 0px; top: 0px; width: 1366px; height: 2000px" data-interactive-element-type="default.image" class="image stencil mobile-interaction-potential-trigger " data-stencil-id="image377306962" data-review-reference-id="image377306962">\
         <div class="stencil-wrapper" style="width: 1366px; height: 2000px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" title="">\
               <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" class="image-cropper" style="height: 2000px;width:1366px;" width="1366" height="2000" viewBox="0 0 1366 2000">\
                  <svg:g width="1366" height="2000">\
                     <svg:svg x="0" y="0" width="1366" height="2000">\
                        <svg:image width="432" height="253" xlink:href="../repoimages/508372.PNG" preserveAspectRatio="none" transform="scale(3.162037037037037,7.905138339920948) translate(-0,-0)  "></svg:image>\
                     </svg:svg>\
                  </svg:g>\
               </svg:svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page310606381-layer-image290283686" style="position: absolute; left: 0px; top: 40px; width: 1366px; height: 2500px" data-interactive-element-type="default.image" class="image stencil mobile-interaction-potential-trigger " data-stencil-id="image290283686" data-review-reference-id="image290283686">\
         <div class="stencil-wrapper" style="width: 1366px; height: 2500px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" title="">\
               <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" class="image-cropper" style="height: 2500px;width:1366px;" width="1366" height="2500" viewBox="0 0 1366 2500">\
                  <svg:g width="1366" height="2500">\
                     <svg:svg x="0" y="0" width="1366" height="2500">\
                        <svg:image width="432" height="253" xlink:href="../repoimages/508372.PNG" preserveAspectRatio="none" transform="scale(3.162037037037037,9.881422924901186) translate(-0,-0)  "></svg:image>\
                     </svg:svg>\
                  </svg:g>\
               </svg:svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page310606381-layer-image48482458" style="position: absolute; left: 0px; top: 75px; width: 1366px; height: 2500px" data-interactive-element-type="default.image" class="image stencil mobile-interaction-potential-trigger " data-stencil-id="image48482458" data-review-reference-id="image48482458">\
         <div class="stencil-wrapper" style="width: 1366px; height: 2500px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" title="">\
               <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" class="image-cropper" style="height: 2500px;width:1366px;" width="1366" height="2500" viewBox="0 0 1366 2500">\
                  <svg:g width="1366" height="2500">\
                     <svg:svg x="0" y="0" width="1366" height="2500">\
                        <svg:image width="432" height="253" xlink:href="../repoimages/508372.PNG" preserveAspectRatio="none" transform="scale(3.162037037037037,9.881422924901186) translate(-0,-0)  "></svg:image>\
                     </svg:svg>\
                  </svg:g>\
               </svg:svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page310606381-layer-image422146603" style="position: absolute; left: 0px; top: 0px; width: 1366px; height: 145px" data-interactive-element-type="default.image" class="image stencil mobile-interaction-potential-trigger " data-stencil-id="image422146603" data-review-reference-id="image422146603">\
         <div class="stencil-wrapper" style="width: 1366px; height: 145px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" title="">\
               <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" class="image-cropper" style="height: 145px;width:1366px;" width="1366" height="145" viewBox="0 0 1366 145">\
                  <svg:g width="1366" height="145">\
                     <svg:svg x="0" y="0" width="1366" height="145">\
                        <svg:image width="80" height="60" xlink:href="../repoimages/508394.PNG" preserveAspectRatio="none" transform="scale(17.075,2.4166666666666665) translate(-0,-0)  "></svg:image>\
                     </svg:svg>\
                  </svg:g>\
               </svg:svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page310606381-layer-image229590994" style="position: absolute; left: 10px; top: 155px; width: 866px; height: 577px" data-interactive-element-type="default.image" class="image stencil mobile-interaction-potential-trigger " data-stencil-id="image229590994" data-review-reference-id="image229590994">\
         <div class="stencil-wrapper" style="width: 866px; height: 577px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" title="">\
               <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" class="image-cropper" style="height: 577px;width:866px;" width="866" height="577" viewBox="0 0 866 577">\
                  <svg:g width="866" height="577">\
                     <svg:svg x="0" y="0" width="866" height="577">\
                        <svg:image width="80" height="60" xlink:href="../repoimages/508395.JPG" preserveAspectRatio="none" transform="scale(10.825,9.616666666666667) translate(-0,-0)  "></svg:image>\
                     </svg:svg>\
                  </svg:g>\
               </svg:svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page310606381-layer-image732056455" style="position: absolute; left: 295px; top: 740px; width: 100px; height: 100px" data-interactive-element-type="default.image" class="image stencil mobile-interaction-potential-trigger " data-stencil-id="image732056455" data-review-reference-id="image732056455">\
         <div class="stencil-wrapper" style="width: 100px; height: 100px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" title="">\
               <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" class="image-cropper" style="height: 100px;width:100px;" width="100" height="100" viewBox="0 0 100 100">\
                  <svg:g width="100" height="100">\
                     <svg:svg x="0" y="0" width="100" height="100">\
                        <svg:image width="80" height="60" xlink:href="../repoimages/508400.JPG" preserveAspectRatio="none" transform="scale(1.25,1.6666666666666667) translate(-0,-0)  "></svg:image>\
                     </svg:svg>\
                  </svg:g>\
               </svg:svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page310606381-layer-image159827258" style="position: absolute; left: 675px; top: 740px; width: 100px; height: 100px" data-interactive-element-type="default.image" class="image stencil mobile-interaction-potential-trigger " data-stencil-id="image159827258" data-review-reference-id="image159827258">\
         <div class="stencil-wrapper" style="width: 100px; height: 100px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" title="">\
               <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" class="image-cropper" style="height: 100px;width:100px;" width="100" height="100" viewBox="0 0 100 100">\
                  <svg:g width="100" height="100">\
                     <svg:svg x="0" y="0" width="100" height="100">\
                        <svg:image width="80" height="60" xlink:href="../repoimages/508401.jpg" preserveAspectRatio="none" transform="scale(1.25,1.6666666666666667) translate(-0,-0)  "></svg:image>\
                     </svg:svg>\
                  </svg:g>\
               </svg:svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page310606381-layer-image798264162" style="position: absolute; left: 550px; top: 740px; width: 100px; height: 100px" data-interactive-element-type="default.image" class="image stencil mobile-interaction-potential-trigger " data-stencil-id="image798264162" data-review-reference-id="image798264162">\
         <div class="stencil-wrapper" style="width: 100px; height: 100px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" title="">\
               <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" class="image-cropper" style="height: 100px;width:100px;" width="100" height="100" viewBox="0 0 100 100">\
                  <svg:g width="100" height="100">\
                     <svg:svg x="0" y="0" width="100" height="100">\
                        <svg:image width="80" height="60" xlink:href="../repoimages/508402.jpg" preserveAspectRatio="none" transform="scale(1.25,1.6666666666666667) translate(-0,-0)  "></svg:image>\
                     </svg:svg>\
                  </svg:g>\
               </svg:svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page310606381-layer-image351591010" style="position: absolute; left: 425px; top: 740px; width: 100px; height: 100px" data-interactive-element-type="default.image" class="image stencil mobile-interaction-potential-trigger " data-stencil-id="image351591010" data-review-reference-id="image351591010">\
         <div class="stencil-wrapper" style="width: 100px; height: 100px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" title="">\
               <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" class="image-cropper" style="height: 100px;width:100px;" width="100" height="100" viewBox="0 0 100 100">\
                  <svg:g width="100" height="100">\
                     <svg:svg x="0" y="0" width="100" height="100">\
                        <svg:image width="80" height="60" xlink:href="../repoimages/508403.JPG" preserveAspectRatio="none" transform="scale(1.25,1.6666666666666667) translate(-0,-0)  "></svg:image>\
                     </svg:svg>\
                  </svg:g>\
               </svg:svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page310606381-layer-icon811601317" style="position: absolute; left: 5px; top: 400px; width: 48px; height: 48px" data-interactive-element-type="fonticon.icon" class="icon stencil mobile-interaction-potential-trigger " data-stencil-id="icon811601317" data-review-reference-id="icon811601317">\
         <div class="stencil-wrapper" style="width: 48px; height: 48px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" style="width:48px;height:48px;" title="">\
               <svg xmlns="http://www.w3.org/2000/svg" width="48" height="48" class="fill-black">\
                  <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#icon-glyph-e225"></use>\
               </svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page310606381-layer-icon191086089" style="position: absolute; left: 830px; top: 400px; width: 48px; height: 48px" data-interactive-element-type="fonticon.icon" class="icon stencil mobile-interaction-potential-trigger " data-stencil-id="icon191086089" data-review-reference-id="icon191086089">\
         <div class="stencil-wrapper" style="width: 48px; height: 48px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" style="width:48px;height:48px;" title="">\
               <svg xmlns="http://www.w3.org/2000/svg" width="48" height="48" class="fill-black">\
                  <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#icon-glyph-e224"></use>\
               </svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page310606381-layer-image40186489" style="position: absolute; left: 885px; top: 155px; width: 470px; height: 1330px" data-interactive-element-type="default.image" class="image stencil mobile-interaction-potential-trigger " data-stencil-id="image40186489" data-review-reference-id="image40186489">\
         <div class="stencil-wrapper" style="width: 470px; height: 1330px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" title="">\
               <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" class="image-cropper" style="height: 1330px;width:470px;" width="470" height="1330" viewBox="0 0 470 1330">\
                  <svg:g width="470" height="1330">\
                     <svg:svg x="0" y="0" width="470" height="1330">\
                        <svg:image width="93" height="25" xlink:href="../repoimages/508405.PNG" preserveAspectRatio="none" transform="scale(5.053763440860215,53.2) translate(-0,-0)  "></svg:image>\
                     </svg:svg>\
                  </svg:g>\
               </svg:svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page310606381-layer-icon890675694" style="position: absolute; left: 1320px; top: 145px; width: 32px; height: 32px" data-interactive-element-type="fonticon.icon" class="icon stencil mobile-interaction-potential-trigger " data-stencil-id="icon890675694" data-review-reference-id="icon890675694">\
         <div class="stencil-wrapper" style="width: 32px; height: 32px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" style="width:32px;height:32px;" title="">\
               <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" class="fill-black">\
                  <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#icon-glyph-e336"></use>\
               </svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page310606381-layer-text906924579" style="position: absolute; left: 900px; top: 425px; width: 235px; height: 37px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text906924579" data-review-reference-id="text906924579">\
         <div class="stencil-wrapper" style="width: 235px; height: 37px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline12"><p class="none" style="font-size: 32px;"><span style="color: #658cd9;">Điểm đặc trưng </span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page310606381-layer-rating586227224" style="position: absolute; left: 900px; top: 160px; width: 170px; height: 40px" data-interactive-element-type="default.rating" class="rating stencil mobile-interaction-potential-trigger " data-stencil-id="rating586227224" data-review-reference-id="rating586227224">\
         <div class="stencil-wrapper" style="width: 170px; height: 40px">\
            <div style="width:170px; height:40px" onmouseout="if(rabbit.stencils.rating.checkMouseOutDiv(\'__containerId__-page310606381-layer-rating586227224\', event)) rabbit.facade.raiseEvent(rabbit.events.ratingMouseOut, \'__containerId__-page310606381-layer-rating586227224\');" title=""><img id="__containerId__-page310606381-layer-rating586227224-1" src="../resources/icons/rating_black.png" width="34" height="40" style="position: absolute; left: 0px; cursor: pointer;" onmouseover="rabbit.facade.raiseEvent(rabbit.events.ratingMouseOver, \'__containerId__-page310606381-layer-rating586227224\', \'1\');" onclick="rabbit.facade.raiseEvent(rabbit.events.ratingResultChangedEvent, \'__containerId__-page310606381-layer-rating586227224\', \'1\');" /><img id="__containerId__-page310606381-layer-rating586227224-2" src="../resources/icons/rating_black.png" width="34" height="40" style="position: absolute; left: 34px; cursor: pointer;" onmouseover="rabbit.facade.raiseEvent(rabbit.events.ratingMouseOver, \'__containerId__-page310606381-layer-rating586227224\', \'2\');" onclick="rabbit.facade.raiseEvent(rabbit.events.ratingResultChangedEvent, \'__containerId__-page310606381-layer-rating586227224\', \'2\');" /><img id="__containerId__-page310606381-layer-rating586227224-3" src="../resources/icons/rating_black.png" width="34" height="40" style="position: absolute; left: 68px; cursor: pointer;" onmouseover="rabbit.facade.raiseEvent(rabbit.events.ratingMouseOver, \'__containerId__-page310606381-layer-rating586227224\', \'3\');" onclick="rabbit.facade.raiseEvent(rabbit.events.ratingResultChangedEvent, \'__containerId__-page310606381-layer-rating586227224\', \'3\');" /><img id="__containerId__-page310606381-layer-rating586227224-4" src="../resources/icons/rating_black.png" width="34" height="40" style="position: absolute; left: 102px; cursor: pointer;" onmouseover="rabbit.facade.raiseEvent(rabbit.events.ratingMouseOver, \'__containerId__-page310606381-layer-rating586227224\', \'4\');" onclick="rabbit.facade.raiseEvent(rabbit.events.ratingResultChangedEvent, \'__containerId__-page310606381-layer-rating586227224\', \'4\');" /><img id="__containerId__-page310606381-layer-rating586227224-5" src="../resources/icons/rating_white.png" width="34" height="40" style="position: absolute; left: 136px; cursor: pointer;" onmouseover="rabbit.facade.raiseEvent(rabbit.events.ratingMouseOver, \'__containerId__-page310606381-layer-rating586227224\', \'5\');" onclick="rabbit.facade.raiseEvent(rabbit.events.ratingResultChangedEvent, \'__containerId__-page310606381-layer-rating586227224\', \'5\');" /></div><script type="text/javascript">\
			rabbit.stencils.rating.onLoad("__containerId__-page310606381-layer-rating586227224", "4");\
		</script></div>\
      </div>\
      <div id="__containerId__-page310606381-layer-text184817720" style="position: absolute; left: 1090px; top: 170px; width: 111px; height: 23px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text184817720" data-review-reference-id="text184817720">\
         <div class="stencil-wrapper" style="width: 111px; height: 23px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.text2"><p class="none" style="font-size: 14px;"><span style="font-size: 20px;">13 đánh giá </span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page310606381-layer-text24658791" style="position: absolute; left: 1215px; top: 170px; width: 99px; height: 20px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text24658791" data-review-reference-id="text24658791">\
         <div class="stencil-wrapper" style="width: 99px; height: 20px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.link2"><p class="underline" style="font-size: 14px;"><span style="font-size: 18px;">1 nhận xét</span></p>\
                     <p class="underline" style="font-size: 14px;"> </p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page310606381-layer-text91490634" style="position: absolute; left: 900px; top: 265px; width: 403px; height: 20px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text91490634" data-review-reference-id="text91490634">\
         <div class="stencil-wrapper" style="width: 403px; height: 20px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline32"><span style="font-size: 18px;">AEON Mall Long Biên, Quận Long Biên, Hà Nội</span></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page310606381-layer-text790498912" style="position: absolute; left: 900px; top: 320px; width: 234px; height: 20px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text790498912" data-review-reference-id="text790498912">\
         <div class="stencil-wrapper" style="width: 234px; height: 20px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline32"><p><span class="bold" style="font-size: 18px; color: #658cd9;">Chương trình khuyến mại:</span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page310606381-layer-text4154276" style="position: absolute; left: 900px; top: 215px; width: 177px; height: 37px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text4154276" data-review-reference-id="text4154276">\
         <div class="stencil-wrapper" style="width: 177px; height: 37px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline12"><p><span style="font-size: 32px; color: #658cd9;">0121456756</span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page310606381-layer-text155070247" style="position: absolute; left: 895px; top: 355px; width: 295px; height: 76px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text155070247" data-review-reference-id="text155070247">\
         <div class="stencil-wrapper" style="width: 295px; height: 76px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textblock2"><p style="font-size: 14px;"><span style="font-size: 18px;">_ Giảm 30% cho khách mới</span><br /><span style="font-size: 18px;">_\
                     Giảm 10% cho đơn hàng trên 1 tr</span><br /><span style="font-size: 18px;"> </span><br /><br /></p>\
                     <p style="font-size: 14px;"> </p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page310606381-layer-text963000291" style="position: absolute; left: 900px; top: 475px; width: 370px; height: 20px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text963000291" data-review-reference-id="text963000291">\
         <div class="stencil-wrapper" style="width: 370px; height: 20px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline12"><p><span style="font-size: 18px;"><span class="bold">Loại hình ẩm thực</span> : Lẩu - Nướng - Ba miền</span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page310606381-layer-42333538" style="position: absolute; left: 900px; top: 515px; width: 435px; height: 60px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="42333538" data-review-reference-id="42333538">\
         <div class="stencil-wrapper" style="width: 435px; height: 60px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline12"><p><span style="font-size: 18px;"><span class="bold">Món đặc sắc</span> : Bánh xèo, lẩu hải sản, bún bò Huế, phở Hà Nội, bánh\
                     tôm Hồ Tây, bánh hỏi chạo tôm, hải sản nướng</span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page310606381-layer-996597469" style="position: absolute; left: 900px; top: 600px; width: 390px; height: 20px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="996597469" data-review-reference-id="996597469">\
         <div class="stencil-wrapper" style="width: 390px; height: 20px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline12"><p><span style="font-size: 18px;"><span class="bold">Giá trung bình</span> : 100.000 - 150.000 vnđ/người</span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page310606381-layer-2014622778" style="position: absolute; left: 900px; top: 655px; width: 451px; height: 40px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="2014622778" data-review-reference-id="2014622778">\
         <div class="stencil-wrapper" style="width: 451px; height: 40px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline12"><p><span style="font-size: 18px;"><span class="bold">Không gian</span> : Phong cách đường phố Việt truyền thống của 3 miền\
                     độc đáo. Sức chứa: 800 khách</span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page310606381-layer-iphoneButton414354944" style="position: absolute; left: 1250px; top: 760px; width: 92px; height: 30px" data-interactive-element-type="default.iphoneButton" class="iphoneButton stencil mobile-interaction-potential-trigger " data-stencil-id="iphoneButton414354944" data-review-reference-id="iphoneButton414354944">\
         <div class="stencil-wrapper" style="width: 92px; height: 30px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" title="" style="height: 30px;width:92px;">\
               <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" width="92" height="30" viewBox="0 0 92 30">\
                  <svg:a>\
                     <svg:path fill-rule="evenodd" clip-rule="evenodd" fill="#808080" stroke="#666666" d="M5,29.5 l-2,-0.5 -1,-1 -1,-1.5 -0.5,-1.5 0,-20 0.5,-2 1,-1 1,-1 2,-0.5 74,0 0.5,0.5 1,0 1,1 1.5,1.5 8.5,11 -7.5,11 -2,2.5 -1.5,1 -0.5,0.5 z"></svg:path>\
                     <svg:text x="43" y="15" dy="0.3em" fill="#FFFFFF" style="font-size:1em;stroke-width:0pt;" font-family="\'HelveticaNeue-Bold\'" text-anchor="middle" xml:space="preserve">Đạt chỗ ngay</svg:text>\
                  </svg:a>\
               </svg:svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page310606381-layer-image660004996" style="position: absolute; left: 20px; top: 860px; width: 830px; height: 580px" data-interactive-element-type="default.image" class="image stencil mobile-interaction-potential-trigger " data-stencil-id="image660004996" data-review-reference-id="image660004996">\
         <div class="stencil-wrapper" style="width: 830px; height: 580px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" title="">\
               <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" class="image-cropper" style="height: 580px;width:830px;" width="830" height="580" viewBox="0 0 830 580">\
                  <svg:g width="830" height="580">\
                     <svg:svg x="0" y="0" width="830" height="580">\
                        <svg:image width="80" height="60" xlink:href="../repoimages/508410.PNG" preserveAspectRatio="none" transform="scale(10.375,9.666666666666666) translate(-0,-0)  "></svg:image>\
                     </svg:svg>\
                  </svg:g>\
               </svg:svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page310606381-layer-image743413727" style="position: absolute; left: 20px; top: 900px; width: 830px; height: 580px" data-interactive-element-type="default.image" class="image stencil mobile-interaction-potential-trigger " data-stencil-id="image743413727" data-review-reference-id="image743413727">\
         <div class="stencil-wrapper" style="width: 830px; height: 580px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" title="">\
               <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" class="image-cropper" style="height: 580px;width:830px;" width="830" height="580" viewBox="0 0 830 580">\
                  <svg:g width="830" height="580">\
                     <svg:svg x="0" y="0" width="830" height="580">\
                        <svg:image width="80" height="60" xlink:href="../repoimages/508410.PNG" preserveAspectRatio="none" transform="scale(10.375,9.666666666666666) translate(-0,-0)  "></svg:image>\
                     </svg:svg>\
                  </svg:g>\
               </svg:svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page310606381-layer-image529488340" style="position: absolute; left: 20px; top: 1480px; width: 860px; height: 278px" data-interactive-element-type="default.image" class="image stencil mobile-interaction-potential-trigger " data-stencil-id="image529488340" data-review-reference-id="image529488340">\
         <div class="stencil-wrapper" style="width: 860px; height: 278px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" title="">\
               <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" class="image-cropper" style="height: 278px;width:860px;" width="860" height="278" viewBox="0 0 860 278">\
                  <svg:g width="860" height="278">\
                     <svg:svg x="0" y="0" width="860" height="278">\
                        <svg:image width="80" height="60" xlink:href="../repoimages/508411.PNG" preserveAspectRatio="none" transform="scale(10.75,4.633333333333334) translate(-0,-0)  "></svg:image>\
                     </svg:svg>\
                  </svg:g>\
               </svg:svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page310606381-layer-map379231884" style="position: absolute; left: 50px; top: 1765px; width: 820px; height: 430px" data-interactive-element-type="static.map" class="map stencil mobile-interaction-potential-trigger " data-stencil-id="map379231884" data-review-reference-id="map379231884">\
         <div class="stencil-wrapper" style="width: 820px; height: 430px">\
            <div style="background:white;width:814px; height:424px;border:none" title="">\
               <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" style="height: 430px;width:820px;" width="820" height="430">\
                  <svg:g id="__containerId__-page310606381-layer-map379231884svg" width="820" height="430"><svg:path d="M 2.00, 2.00 Q 12.20, 2.97, 22.40, 2.97 Q 32.60, 4.27, 42.80, 2.69 Q 53.00, 2.78, 63.20, 3.90 Q 73.40, 2.39,\
                     83.60, 1.05 Q 93.80, 0.16, 104.00, 1.34 Q 114.20, 3.22, 124.40, 2.80 Q 134.60, 2.00, 144.80, 1.29 Q 155.00, 1.22, 165.20,\
                     1.04 Q 175.40, 0.45, 185.60, 0.69 Q 195.80, 1.34, 206.00, 1.10 Q 216.20, 3.64, 226.40, 2.37 Q 236.60, 1.15, 246.80, 1.17 Q\
                     257.00, 0.84, 267.20, 0.14 Q 277.40, 0.20, 287.60, 0.28 Q 297.80, 0.17, 308.00, 0.09 Q 318.20, -0.16, 328.40, -0.20 Q 338.60,\
                     0.43, 348.80, 0.56 Q 359.00, 0.01, 369.20, 0.72 Q 379.40, 1.60, 389.60, 1.21 Q 399.80, 0.16, 410.00, 0.27 Q 420.20, 2.03,\
                     430.40, 3.29 Q 440.60, 3.24, 450.80, 1.86 Q 461.00, 0.78, 471.20, 0.45 Q 481.40, 0.49, 491.60, 0.43 Q 501.80, 0.20, 512.00,\
                     0.56 Q 522.20, 0.77, 532.40, 0.70 Q 542.60, 0.66, 552.80, 1.29 Q 563.00, 0.83, 573.20, 0.80 Q 583.40, 0.46, 593.60, 0.58 Q\
                     603.80, 0.48, 614.00, 0.44 Q 624.20, 0.36, 634.40, 0.09 Q 644.60, 0.51, 654.80, 0.46 Q 665.00, 0.95, 675.20, 1.29 Q 685.40,\
                     1.19, 695.60, 1.72 Q 705.80, 0.39, 716.00, 0.44 Q 726.20, 0.45, 736.40, 1.46 Q 746.60, 1.88, 756.80, 2.76 Q 767.00, 2.80,\
                     777.20, 2.69 Q 787.40, 1.42, 797.60, 1.01 Q 807.80, 1.52, 818.79, 1.21 Q 818.96, 11.82, 818.21, 22.26 Q 817.87, 32.44, 817.26,\
                     42.60 Q 817.18, 52.73, 817.67, 62.86 Q 819.16, 73.00, 819.39, 83.14 Q 819.43, 93.28, 819.33, 103.43 Q 819.30, 113.57, 818.92,\
                     123.71 Q 819.10, 133.86, 819.83, 144.00 Q 820.02, 154.14, 819.22, 164.29 Q 819.85, 174.43, 819.98, 184.57 Q 819.55, 194.71,\
                     819.55, 204.86 Q 819.13, 215.00, 818.68, 225.14 Q 818.82, 235.29, 818.52, 245.43 Q 818.83, 255.57, 819.02, 265.71 Q 819.34,\
                     275.86, 818.38, 286.00 Q 818.94, 296.14, 819.18, 306.29 Q 819.03, 316.43, 819.26, 326.57 Q 819.65, 336.71, 819.37, 346.86\
                     Q 818.71, 357.00, 819.10, 367.14 Q 819.18, 377.29, 819.43, 387.43 Q 819.49, 397.57, 819.64, 407.71 Q 819.77, 417.86, 818.38,\
                     428.38 Q 808.13, 428.99, 797.82, 429.51 Q 787.50, 429.44, 777.24, 429.13 Q 767.02, 429.16, 756.81, 429.36 Q 746.61, 429.22,\
                     736.40, 428.26 Q 726.20, 428.10, 716.00, 428.15 Q 705.80, 428.32, 695.60, 428.44 Q 685.40, 428.11, 675.20, 427.23 Q 665.00,\
                     428.29, 654.80, 429.23 Q 644.60, 428.61, 634.40, 428.90 Q 624.20, 429.02, 614.00, 429.14 Q 603.80, 428.44, 593.60, 428.82\
                     Q 583.40, 428.36, 573.20, 428.55 Q 563.00, 427.89, 552.80, 428.10 Q 542.60, 428.62, 532.40, 428.05 Q 522.20, 428.15, 512.00,\
                     428.12 Q 501.80, 429.11, 491.60, 428.69 Q 481.40, 428.89, 471.20, 429.47 Q 461.00, 428.76, 450.80, 429.34 Q 440.60, 428.54,\
                     430.40, 428.89 Q 420.20, 429.29, 410.00, 429.00 Q 399.80, 429.17, 389.60, 429.03 Q 379.40, 429.25, 369.20, 428.99 Q 359.00,\
                     428.36, 348.80, 428.70 Q 338.60, 427.76, 328.40, 428.15 Q 318.20, 428.28, 308.00, 427.68 Q 297.80, 428.50, 287.60, 429.20\
                     Q 277.40, 428.08, 267.20, 429.19 Q 257.00, 429.39, 246.80, 429.39 Q 236.60, 428.90, 226.40, 429.37 Q 216.20, 428.48, 206.00,\
                     428.75 Q 195.80, 427.73, 185.60, 428.40 Q 175.40, 427.80, 165.20, 428.81 Q 155.00, 428.97, 144.80, 429.83 Q 134.60, 429.39,\
                     124.40, 429.48 Q 114.20, 429.90, 104.00, 428.83 Q 93.80, 429.29, 83.60, 429.71 Q 73.40, 429.72, 63.20, 429.52 Q 53.00, 428.91,\
                     42.80, 428.81 Q 32.60, 427.83, 22.40, 428.98 Q 12.20, 428.84, 1.71, 428.29 Q 1.92, 417.88, 2.01, 407.71 Q 2.48, 397.54, 1.99,\
                     387.43 Q 2.02, 377.29, 2.69, 367.14 Q 1.66, 357.00, 2.10, 346.86 Q 1.76, 336.71, 1.92, 326.57 Q 1.75, 316.43, 1.34, 306.29\
                     Q 1.94, 296.14, 2.12, 286.00 Q 2.66, 275.86, 1.51, 265.71 Q 0.60, 255.57, 0.62, 245.43 Q 0.61, 235.29, 0.57, 225.14 Q 0.23,\
                     215.00, 0.19, 204.86 Q 0.02, 194.71, -0.30, 184.57 Q 0.12, 174.43, 0.51, 164.29 Q 0.96, 154.14, 1.38, 144.00 Q 0.99, 133.86,\
                     0.81, 123.71 Q 0.98, 113.57, 1.03, 103.43 Q 0.92, 93.29, 0.65, 83.14 Q 0.73, 73.00, 0.37, 62.86 Q 0.80, 52.71, 0.03, 42.57\
                     Q 0.00, 32.43, 0.27, 22.29 Q 2.00, 12.14, 2.00, 2.00" style=" fill:white;" class="svg_unselected_element"/>\
                  </svg:g>\
               </svg:svg><img src="../resources/icons/map_default.png" style="position:absolute;left:4px;top:4px;;width:814px;height:424px;overflow:auto;" width="814" height="424" preserveAspectRatio="none" /></div>\
         </div>\
      </div>\
      <div id="__containerId__-page310606381-layer-image761310260" style="position: absolute; left: 45px; top: 2210px; width: 820px; height: 300px" data-interactive-element-type="default.image" class="image stencil mobile-interaction-potential-trigger " data-stencil-id="image761310260" data-review-reference-id="image761310260">\
         <div class="stencil-wrapper" style="width: 820px; height: 300px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" title="">\
               <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" class="image-cropper" style="height: 300px;width:820px;" width="820" height="300" viewBox="0 0 820 300">\
                  <svg:g width="820" height="300">\
                     <svg:svg x="0" y="0" width="820" height="300">\
                        <svg:image width="80" height="60" xlink:href="../repoimages/508412.PNG" preserveAspectRatio="none" transform="scale(10.25,5) translate(-0,-0)  "></svg:image>\
                     </svg:svg>\
                  </svg:g>\
               </svg:svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page310606381-layer-434730018" style="position: absolute; left: 900px; top: 710px; width: 425px; height: 20px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="434730018" data-review-reference-id="434730018">\
         <div class="stencil-wrapper" style="width: 425px; height: 20px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline12"><p><span style="font-size: 18px;"><span class="bold">Giờ mở cửa</span> : 7h sáng - 10h đêm / làm cả ngày lễ</span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page310606381-layer-icon742604360" style="position: absolute; left: 320px; top: 105px; width: 32px; height: 32px" data-interactive-element-type="fonticon.icon" class="icon pidoco-clickable-element stencil mobile-interaction-potential-trigger " data-stencil-id="icon742604360" data-review-reference-id="icon742604360">\
         <div class="stencil-wrapper" style="width: 32px; height: 32px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" style="width:32px;height:32px;" title="">\
               <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" class="fill-green">\
                  <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#icon-glyph-e210"></use>\
               </svg>\
            </div>\
         </div><script type="text/javascript">\
			$(document).ready(function(){\
				rabbit.interaction.manager.registerInteraction(\'__containerId__-page310606381-layer-icon742604360\', \'interaction524586502\', \
		{\
		\
			\'button\': \'left\'\
			\
				,\
			\
			\'id\': \'action702678278\'\
			\
				,\
			\
			\'numberOfFinger\': \'1\'\
			\
				,\
			\
			\'type\': \'click\'\
			\
		}\
	,  \
					[\
						\
		{\
		\
			\'delay\': \'0\'\
			\
				,\
			\
			\'id\': \'reaction792968331\'\
			\
				,\
			\
			\'options\': \'withoutReloadOnly\'\
			\
				,\
			\
			\'target\': \'page584926941\'\
			\
				,\
			\
			\'transition\': \'none\'\
			\
				,\
			\
			\'type\': \'showPage\'\
			\
		}\
	\
					]\
				);\
			});\
		</script></div>\
   </div>\
</div>');