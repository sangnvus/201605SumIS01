rabbit.data.layerStore.addLayerFromHtml('<div xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:fn="http://www.w3.org/2005/xpath-functions" id="result">\
   <div xmlns:xs="http://www.w3.org/2001/XMLSchema" xmlns="http://www.w3.org/1999/xhtml" id="__containerId__page584926941-layer" class="layer" name="__containerId__pageLayer" data-layer-id="page584926941" data-layer-type="pageLayer" style="position:absolute;left:0px;top:0px;">\
      <div id="__containerId__-page584926941-layer-image827368748" style="position: absolute; left: 0px; top: 5px; width: 1366px; height: 2000px" data-interactive-element-type="default.image" class="image stencil mobile-interaction-potential-trigger " data-stencil-id="image827368748" data-review-reference-id="image827368748">\
         <div class="stencil-wrapper" style="width: 1366px; height: 2000px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" title="">\
               <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" class="image-cropper" style="height: 2000px;width:1366px;" width="1366" height="2000">\
                  <svg:g width="1366" height="2000">\
                     <svg:svg x="1" y="1" width="1364" height="1998">\
                        <svg:image width="432" height="253" xlink:href="../repoimages/508372.PNG" preserveAspectRatio="none" transform="scale(3.162037037037037,7.905138339920948) translate(-0,-0)  "></svg:image>\
                     </svg:svg>\
                  </svg:g>\
               </svg:svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page584926941-layer-image708809043" style="position: absolute; left: 0px; top: 0px; width: 1366px; height: 145px" data-interactive-element-type="default.image" class="image stencil mobile-interaction-potential-trigger " data-stencil-id="image708809043" data-review-reference-id="image708809043">\
         <div class="stencil-wrapper" style="width: 1366px; height: 145px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" title="">\
               <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" class="image-cropper" style="height: 145px;width:1366px;" width="1366" height="145">\
                  <svg:g width="1366" height="145">\
                     <svg:svg x="1" y="1" width="1364" height="143">\
                        <svg:image width="80" height="60" xlink:href="../repoimages/508416.PNG" preserveAspectRatio="none" transform="scale(17.075,2.4166666666666665) translate(-0,-0)  "></svg:image>\
                     </svg:svg>\
                  </svg:g>\
               </svg:svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page584926941-layer-image267936877" style="position: absolute; left: 970px; top: 170px; width: 385px; height: 1500px" data-interactive-element-type="default.image" class="image pidoco-clickable-element stencil mobile-interaction-potential-trigger " data-stencil-id="image267936877" data-review-reference-id="image267936877">\
         <div class="stencil-wrapper" style="width: 385px; height: 1500px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" title="">\
               <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" class="image-cropper" style="height: 1500px;width:385px;" width="385" height="1500">\
                  <svg:g width="385" height="1500">\
                     <svg:svg x="1" y="1" width="383" height="1498">\
                        <svg:image width="93" height="25" xlink:href="../repoimages/508405.PNG" preserveAspectRatio="none" transform="scale(4.139784946236559,60) translate(-0,-0)  "></svg:image>\
                     </svg:svg>\
                  </svg:g>\
               </svg:svg>\
            </div>\
         </div><script type="text/javascript">\
			$(document).ready(function(){\
				rabbit.interaction.manager.registerInteraction(\'__containerId__-page584926941-layer-image267936877\', \'interaction382033057\', \
		{\
		\
			\'button\': \'left\'\
			\
				,\
			\
			\'id\': \'action26215521\'\
			\
				,\
			\
			\'numberOfFinger\': \'1\'\
			\
				,\
			\
			\'type\': \'click\'\
			\
		}\
	,  \
					[\
						\
		{\
		\
			\'delay\': \'0\'\
			\
				,\
			\
			\'id\': \'reaction78556891\'\
			\
				,\
			\
			\'options\': \'reloadOnly\'\
			\
				,\
			\
			\'target\': \'\'\
			\
				,\
			\
			\'transition\': \'none\'\
			\
				,\
			\
			\'type\': \'showPage\'\
			\
		}\
	\
					]\
				);\
			});\
		</script></div>\
      <div id="__containerId__-page584926941-layer-image225078985" style="position: absolute; left: 970px; top: 210px; width: 385px; height: 1500px" data-interactive-element-type="default.image" class="image pidoco-clickable-element stencil mobile-interaction-potential-trigger " data-stencil-id="image225078985" data-review-reference-id="image225078985">\
         <div class="stencil-wrapper" style="width: 385px; height: 1500px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" title="">\
               <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" class="image-cropper" style="height: 1500px;width:385px;" width="385" height="1500">\
                  <svg:g width="385" height="1500">\
                     <svg:svg x="1" y="1" width="383" height="1498">\
                        <svg:image width="93" height="25" xlink:href="../repoimages/508405.PNG" preserveAspectRatio="none" transform="scale(4.139784946236559,60) translate(-0,-0)  "></svg:image>\
                     </svg:svg>\
                  </svg:g>\
               </svg:svg>\
            </div>\
         </div><script type="text/javascript">\
			$(document).ready(function(){\
				rabbit.interaction.manager.registerInteraction(\'__containerId__-page584926941-layer-image225078985\', \'2081145029\', \
		{\
		\
			\'button\': \'left\'\
			\
				,\
			\
			\'id\': \'1718242533\'\
			\
				,\
			\
			\'numberOfFinger\': \'1\'\
			\
				,\
			\
			\'type\': \'click\'\
			\
		}\
	,  \
					[\
						\
		{\
		\
			\'delay\': \'0\'\
			\
				,\
			\
			\'id\': \'1915818756\'\
			\
				,\
			\
			\'options\': \'reloadOnly\'\
			\
				,\
			\
			\'target\': \'\'\
			\
				,\
			\
			\'transition\': \'none\'\
			\
				,\
			\
			\'type\': \'showPage\'\
			\
		}\
	\
					]\
				);\
			});\
		</script></div>\
      <div id="__containerId__-page584926941-layer-tabbutton283931937" style="position: absolute; left: 20px; top: 185px; width: 112px; height: 30px" data-interactive-element-type="default.tabbutton" class="tabbutton stencil mobile-interaction-potential-trigger " data-stencil-id="tabbutton283931937" data-review-reference-id="tabbutton283931937">\
         <div class="stencil-wrapper" style="width: 112px; height: 30px">\
            <div title="">\
               <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" xmlns="http://www.w3.org/2000/svg" overflow="hidden" style="position: absolute; left: -3px; top: -6px; height: 41px;width:123px;" width="117" height="36">\
                  <svg:g id="target" width="120" height="30" name="target" class="iosTab">\
                     <svg:g class="smallSkechtedTab"><svg:path d="M 7.00, 32.00 Q 6.17, 25.50, 5.75, 19.00 Q 5.47, 17.50, 6.41, 15.86 Q 7.28, 14.92, 7.33, 13.71 Q 7.96, 12.75,\
                        9.07, 12.07 Q 10.06, 11.58, 10.81, 10.69 Q 11.84, 10.20, 12.67, 9.25 Q 14.24, 8.82, 15.90, 8.47 Q 27.32, 8.36, 38.72, 8.41\
                        Q 50.11, 8.20, 61.49, 8.15 Q 72.87, 8.73, 84.25, 8.01 Q 95.62, 8.18, 107.03, 8.84 Q 108.74, 8.52, 110.05, 9.87 Q 111.25, 9.91,\
                        112.28, 10.40 Q 113.33, 10.82, 114.56, 11.43 Q 115.90, 11.99, 116.34, 13.19 Q 116.36, 14.53, 117.63, 15.29 Q 118.36, 16.79,\
                        118.87, 18.65 Q 119.00, 25.32, 117.99, 32.92 Q 106.18, 33.13, 94.76, 33.13 Q 83.45, 32.79, 72.26, 33.95 Q 61.04, 34.35, 49.81,\
                        32.77 Q 38.60, 32.52, 27.40, 33.04 Q 16.20, 32.00, 5.00, 32.00" style=" fill:white;" class="svg_unselected_element"/>\
                     </svg:g>\
                  </svg:g>\
               </svg:svg>\
               <div id="target" name="target" onmouseover="rabbit.facade.raiseEvent(rabbit.events.tabButtonMouseOver, \'tabbutton283931937\', \'result\');" onmouseout="rabbit.facade.raiseEvent(rabbit.events.tabButtonMouseOut, \'tabbutton283931937\', \'result\');" class="selected">\
                  <div class="smallSkechtedTab">\
                     <div id="tabbutton283931937_div_small" class="ClickableSketch helvetica-font" style="line-height: 17px;position: absolute; left: 2px; height: 24px;width:116px;text-align:center;font-size:1em;fill:none;cursor:pointer;padding-top:6px;" xml:space="preserve">Khai vị\
                        							\
                        <addMouseOverListener></addMouseOverListener>\
                        							\
                        <addMouseOutListener></addMouseOutListener>\
                        						\
                     </div>\
                  </div>\
                  <div class="bigSkechtedTab">\
                     <div id="tabbutton283931937_div_big" class="ClickableSketch helvetica-font" style="line-height: 17px;position: absolute; left: 2px; top: -6px; height: 30px;width:119px;text-align:center;font-size:1em;fill:none;cursor:pointer;padding-top:13px;" xml:space="preserve">Khai vị\
                        							\
                        <addMouseOverListener></addMouseOverListener>\
                        							\
                        <addMouseOutListener></addMouseOutListener>\
                        						\
                     </div>\
                  </div>\
               </div>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page584926941-layer-797513605" style="position: absolute; left: 150px; top: 185px; width: 112px; height: 30px" data-interactive-element-type="default.tabbutton" class="tabbutton stencil mobile-interaction-potential-trigger " data-stencil-id="797513605" data-review-reference-id="797513605">\
         <div class="stencil-wrapper" style="width: 112px; height: 30px">\
            <div title="">\
               <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" xmlns="http://www.w3.org/2000/svg" overflow="hidden" style="position: absolute; left: -3px; top: -6px; height: 41px;width:123px;" width="117" height="36">\
                  <svg:g id="target" width="120" height="30" name="target" class="iosTab">\
                     <svg:g class="smallSkechtedTab"><svg:path d="M 7.00, 32.00 Q 8.38, 25.50, 8.22, 19.00 Q 7.49, 17.50, 8.28, 16.30 Q 7.96, 15.17, 8.05, 14.02 Q 8.77, 13.12,\
                        9.37, 12.36 Q 10.65, 12.40, 10.62, 10.37 Q 11.70, 9.96, 12.73, 9.37 Q 14.58, 9.71, 15.92, 8.59 Q 27.40, 9.26, 38.72, 8.37\
                        Q 50.12, 9.00, 61.50, 9.17 Q 72.87, 7.97, 84.25, 7.32 Q 95.62, 8.07, 107.13, 8.22 Q 108.61, 9.04, 110.23, 9.37 Q 111.31, 9.79,\
                        112.19, 10.59 Q 113.03, 11.45, 114.90, 11.09 Q 115.51, 12.28, 114.77, 14.14 Q 115.29, 15.12, 116.75, 15.67 Q 117.13, 17.26,\
                        116.97, 19.01 Q 116.70, 25.53, 116.92, 31.92 Q 105.93, 32.40, 94.75, 33.05 Q 83.50, 33.53, 72.26, 33.88 Q 61.03, 33.97, 49.81,\
                        33.65 Q 38.61, 33.37, 27.40, 34.33 Q 16.20, 32.00, 5.00, 32.00" style=" fill:white;" class="svg_unselected_element"/>\
                     </svg:g>\
                  </svg:g>\
               </svg:svg>\
               <div id="target" name="target" onmouseover="rabbit.facade.raiseEvent(rabbit.events.tabButtonMouseOver, \'797513605\', \'result\');" onmouseout="rabbit.facade.raiseEvent(rabbit.events.tabButtonMouseOut, \'797513605\', \'result\');" class="selected">\
                  <div class="smallSkechtedTab">\
                     <div id="797513605_div_small" class="ClickableSketch helvetica-font" style="line-height: 17px;position: absolute; left: 2px; height: 24px;width:116px;text-align:center;font-size:1em;fill:none;cursor:pointer;padding-top:6px;" xml:space="preserve">Món Chính\
                        							\
                        <addMouseOverListener></addMouseOverListener>\
                        							\
                        <addMouseOutListener></addMouseOutListener>\
                        						\
                     </div>\
                  </div>\
                  <div class="bigSkechtedTab">\
                     <div id="797513605_div_big" class="ClickableSketch helvetica-font" style="line-height: 17px;position: absolute; left: 2px; top: -6px; height: 30px;width:119px;text-align:center;font-size:1em;fill:none;cursor:pointer;padding-top:13px;" xml:space="preserve">Món Chính\
                        							\
                        <addMouseOverListener></addMouseOverListener>\
                        							\
                        <addMouseOutListener></addMouseOutListener>\
                        						\
                     </div>\
                  </div>\
               </div>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page584926941-layer-1514918685" style="position: absolute; left: 290px; top: 185px; width: 112px; height: 30px" data-interactive-element-type="default.tabbutton" class="tabbutton stencil mobile-interaction-potential-trigger " data-stencil-id="1514918685" data-review-reference-id="1514918685">\
         <div class="stencil-wrapper" style="width: 112px; height: 30px">\
            <div title="">\
               <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" xmlns="http://www.w3.org/2000/svg" overflow="hidden" style="position: absolute; left: -3px; top: -6px; height: 41px;width:123px;" width="117" height="36">\
                  <svg:g id="target" width="120" height="30" name="target" class="iosTab">\
                     <svg:g class="smallSkechtedTab"><svg:path d="M 7.00, 32.00 Q 4.98, 25.50, 6.08, 19.00 Q 6.84, 17.50, 6.70, 15.93 Q 7.43, 14.98, 8.51, 14.22 Q 8.75, 13.12,\
                        8.51, 11.52 Q 9.24, 10.45, 10.16, 9.61 Q 11.17, 9.00, 12.45, 8.74 Q 14.35, 9.11, 15.77, 7.73 Q 27.26, 7.76, 38.66, 7.07 Q\
                        50.08, 6.97, 61.48, 7.01 Q 72.87, 7.22, 84.25, 7.35 Q 95.62, 7.20, 107.30, 7.17 Q 108.92, 7.78, 110.66, 8.22 Q 111.36, 9.67,\
                        112.28, 10.40 Q 113.53, 10.41, 115.09, 10.89 Q 115.57, 12.23, 115.15, 13.91 Q 116.03, 14.71, 117.06, 15.54 Q 117.83, 16.99,\
                        118.33, 18.75 Q 118.27, 25.39, 117.61, 32.57 Q 106.16, 33.06, 94.75, 33.08 Q 83.48, 33.19, 72.25, 33.59 Q 61.03, 33.85, 49.81,\
                        33.83 Q 38.61, 33.81, 27.40, 33.95 Q 16.20, 32.00, 5.00, 32.00" style=" fill:white;" class="svg_unselected_element"/>\
                     </svg:g>\
                  </svg:g>\
               </svg:svg>\
               <div id="target" name="target" onmouseover="rabbit.facade.raiseEvent(rabbit.events.tabButtonMouseOver, \'1514918685\', \'result\');" onmouseout="rabbit.facade.raiseEvent(rabbit.events.tabButtonMouseOut, \'1514918685\', \'result\');" class="selected">\
                  <div class="smallSkechtedTab">\
                     <div id="1514918685_div_small" class="ClickableSketch helvetica-font" style="line-height: 17px;position: absolute; left: 2px; height: 24px;width:116px;text-align:center;font-size:1em;fill:none;cursor:pointer;padding-top:6px;" xml:space="preserve">Tráng miệng\
                        							\
                        <addMouseOverListener></addMouseOverListener>\
                        							\
                        <addMouseOutListener></addMouseOutListener>\
                        						\
                     </div>\
                  </div>\
                  <div class="bigSkechtedTab">\
                     <div id="1514918685_div_big" class="ClickableSketch helvetica-font" style="line-height: 17px;position: absolute; left: 2px; top: -6px; height: 30px;width:119px;text-align:center;font-size:1em;fill:none;cursor:pointer;padding-top:13px;" xml:space="preserve">Tráng miệng\
                        							\
                        <addMouseOverListener></addMouseOverListener>\
                        							\
                        <addMouseOutListener></addMouseOutListener>\
                        						\
                     </div>\
                  </div>\
               </div>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page584926941-layer-346976431" style="position: absolute; left: 430px; top: 185px; width: 112px; height: 30px" data-interactive-element-type="default.tabbutton" class="tabbutton stencil mobile-interaction-potential-trigger " data-stencil-id="346976431" data-review-reference-id="346976431">\
         <div class="stencil-wrapper" style="width: 112px; height: 30px">\
            <div title="">\
               <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" xmlns="http://www.w3.org/2000/svg" overflow="hidden" style="position: absolute; left: -3px; top: -6px; height: 41px;width:123px;" width="117" height="36">\
                  <svg:g id="target" width="120" height="30" name="target" class="iosTab">\
                     <svg:g class="smallSkechtedTab"><svg:path d="M 7.00, 32.00 Q 7.11, 25.50, 6.21, 19.00 Q 4.90, 17.50, 5.68, 15.69 Q 6.21, 14.53, 5.84, 13.07 Q 7.29, 12.43,\
                        8.57, 11.58 Q 9.64, 11.01, 10.58, 10.30 Q 11.07, 8.81, 12.27, 8.33 Q 14.00, 8.20, 15.91, 8.49 Q 27.36, 8.87, 38.74, 8.67 Q\
                        50.10, 7.93, 61.49, 7.81 Q 72.87, 8.39, 84.25, 8.45 Q 95.62, 7.57, 107.19, 7.85 Q 108.77, 8.40, 110.41, 8.90 Q 111.51, 9.31,\
                        112.54, 9.84 Q 113.32, 10.83, 114.71, 11.28 Q 115.41, 12.35, 116.11, 13.33 Q 116.68, 14.35, 116.75, 15.67 Q 118.32, 16.80,\
                        118.56, 18.71 Q 118.41, 25.37, 117.90, 32.83 Q 106.24, 33.32, 94.84, 33.70 Q 83.53, 33.92, 72.26, 33.88 Q 61.02, 33.49, 49.81,\
                        33.44 Q 38.61, 33.49, 27.40, 32.81 Q 16.20, 32.00, 5.00, 32.00" style=" fill:white;" class="svg_unselected_element"/>\
                     </svg:g>\
                  </svg:g>\
               </svg:svg>\
               <div id="target" name="target" onmouseover="rabbit.facade.raiseEvent(rabbit.events.tabButtonMouseOver, \'346976431\', \'result\');" onmouseout="rabbit.facade.raiseEvent(rabbit.events.tabButtonMouseOut, \'346976431\', \'result\');" class="selected">\
                  <div class="smallSkechtedTab">\
                     <div id="346976431_div_small" class="ClickableSketch helvetica-font" style="line-height: 17px;position: absolute; left: 2px; height: 24px;width:116px;text-align:center;font-size:1em;fill:none;cursor:pointer;padding-top:6px;" xml:space="preserve">Đồ uống\
                        							\
                        <addMouseOverListener></addMouseOverListener>\
                        							\
                        <addMouseOutListener></addMouseOutListener>\
                        						\
                     </div>\
                  </div>\
                  <div class="bigSkechtedTab">\
                     <div id="346976431_div_big" class="ClickableSketch helvetica-font" style="line-height: 17px;position: absolute; left: 2px; top: -6px; height: 30px;width:119px;text-align:center;font-size:1em;fill:none;cursor:pointer;padding-top:13px;" xml:space="preserve">Đồ uống\
                        							\
                        <addMouseOverListener></addMouseOverListener>\
                        							\
                        <addMouseOutListener></addMouseOutListener>\
                        						\
                     </div>\
                  </div>\
               </div>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page584926941-layer-1367773495" style="position: absolute; left: 570px; top: 185px; width: 112px; height: 30px" data-interactive-element-type="default.tabbutton" class="tabbutton stencil mobile-interaction-potential-trigger " data-stencil-id="1367773495" data-review-reference-id="1367773495">\
         <div class="stencil-wrapper" style="width: 112px; height: 30px">\
            <div title="">\
               <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" xmlns="http://www.w3.org/2000/svg" overflow="hidden" style="position: absolute; left: -3px; top: -6px; height: 41px;width:123px;" width="117" height="36">\
                  <svg:g id="target" width="120" height="30" name="target" class="iosTab">\
                     <svg:g class="smallSkechtedTab"><svg:path d="M 7.00, 32.00 Q 6.28, 25.50, 6.56, 19.00 Q 6.33, 17.50, 7.11, 16.03 Q 6.60, 14.67, 6.99, 13.57 Q 8.11, 12.82,\
                        9.06, 12.05 Q 9.34, 10.59, 10.15, 9.60 Q 11.76, 10.07, 12.44, 8.71 Q 14.42, 9.30, 15.93, 8.62 Q 27.38, 9.10, 38.76, 9.17 Q\
                        50.11, 8.50, 61.49, 8.09 Q 72.87, 7.51, 84.25, 8.01 Q 95.62, 8.30, 106.91, 9.54 Q 108.69, 8.72, 110.44, 8.80 Q 111.19, 10.06,\
                        112.01, 10.98 Q 113.14, 11.21, 114.43, 11.57 Q 114.13, 13.27, 114.63, 14.22 Q 114.44, 15.58, 115.79, 16.09 Q 117.09, 17.27,\
                        117.70, 18.87 Q 117.91, 25.42, 117.48, 32.45 Q 106.08, 32.84, 94.76, 33.10 Q 83.52, 33.87, 72.24, 33.21 Q 61.02, 33.43, 49.81,\
                        33.38 Q 38.60, 32.98, 27.40, 32.30 Q 16.20, 32.00, 5.00, 32.00" style=" fill:white;" class="svg_unselected_element"/>\
                     </svg:g>\
                  </svg:g>\
               </svg:svg>\
               <div id="target" name="target" onmouseover="rabbit.facade.raiseEvent(rabbit.events.tabButtonMouseOver, \'1367773495\', \'result\');" onmouseout="rabbit.facade.raiseEvent(rabbit.events.tabButtonMouseOut, \'1367773495\', \'result\');" class="selected">\
                  <div class="smallSkechtedTab">\
                     <div id="1367773495_div_small" class="ClickableSketch helvetica-font" style="line-height: 17px;position: absolute; left: 2px; height: 24px;width:116px;text-align:center;font-size:1em;fill:none;cursor:pointer;padding-top:6px;" xml:space="preserve">Khác\
                        							\
                        <addMouseOverListener></addMouseOverListener>\
                        							\
                        <addMouseOutListener></addMouseOutListener>\
                        						\
                     </div>\
                  </div>\
                  <div class="bigSkechtedTab">\
                     <div id="1367773495_div_big" class="ClickableSketch helvetica-font" style="line-height: 17px;position: absolute; left: 2px; top: -6px; height: 30px;width:119px;text-align:center;font-size:1em;fill:none;cursor:pointer;padding-top:13px;" xml:space="preserve">Khác\
                        							\
                        <addMouseOverListener></addMouseOverListener>\
                        							\
                        <addMouseOutListener></addMouseOutListener>\
                        						\
                     </div>\
                  </div>\
               </div>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page584926941-layer-text151602484" style="position: absolute; left: 990px; top: 180px; width: 162px; height: 37px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text151602484" data-review-reference-id="text151602484">\
         <div class="stencil-wrapper" style="width: 162px; height: 37px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline12"><p class="none" style="font-size: 32px;"><span style="font-size: 20px; color: #658cd9;">Đặt bàn trực tiếp: </span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page584926941-layer-text41729053" style="position: absolute; left: 990px; top: 225px; width: 183px; height: 37px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text41729053" data-review-reference-id="text41729053">\
         <div class="stencil-wrapper" style="width: 183px; height: 37px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline12"><span style="font-size: 32px; color: #000000;">0121456756</span></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page584926941-layer-1412037920" style="position: absolute; left: 990px; top: 265px; width: 219px; height: 37px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="1412037920" data-review-reference-id="1412037920">\
         <div class="stencil-wrapper" style="width: 219px; height: 37px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline12"><p class="none" style="font-size: 32px;"><span style="color: #658cd9;">Đặt bàn <span style="font-size: 26px;">online :</span></span> </p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page584926941-layer-combobox612942485" style="position: absolute; left: 995px; top: 325px; width: 260px; height: 30px" data-interactive-element-type="default.combobox" class="combobox stencil mobile-interaction-potential-trigger " data-stencil-id="combobox612942485" data-review-reference-id="combobox612942485">\
         <div class="stencil-wrapper" style="width: 260px; height: 30px">\
            <div style="position:absolute;left:2px;top:0px;">\
               <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" style="position: absolute; height: 30px;width:260px;" width="260" height="30">\
                  <svg:g id="__containerId__-page584926941-layer-combobox612942485" width="260" height="30"><svg:path id="__containerId__-page584926941-layer-combobox612942485_input_svg_border" d="M 2.00, 2.00 Q 12.67, 2.07, 23.33,\
                     1.47 Q 34.00, 1.82, 44.67, 0.72 Q 55.33, 1.62, 66.00, 1.57 Q 76.67, 0.92, 87.33, 0.01 Q 98.00, 0.37, 108.67, 1.03 Q 119.33,\
                     0.94, 130.00, 0.39 Q 140.67, 0.04, 151.33, -0.05 Q 162.00, -0.12, 172.67, -0.26 Q 183.33, 0.17, 194.00, 0.72 Q 204.67, 0.67,\
                     215.33, 0.56 Q 226.00, 0.36, 236.67, 0.32 Q 247.33, 0.24, 258.82, 1.18 Q 259.04, 14.65, 258.62, 28.62 Q 247.65, 29.18, 236.85,\
                     29.61 Q 226.09, 29.83, 215.38, 29.87 Q 204.69, 30.02, 194.01, 30.26 Q 183.34, 29.83, 172.67, 29.19 Q 162.00, 30.04, 151.33,\
                     28.95 Q 140.67, 28.48, 130.00, 29.02 Q 119.33, 29.08, 108.67, 28.92 Q 98.00, 29.03, 87.33, 28.85 Q 76.67, 29.03, 66.00, 29.16\
                     Q 55.33, 28.73, 44.67, 28.82 Q 34.00, 29.10, 23.33, 29.17 Q 12.67, 28.69, 1.56, 28.44 Q 2.00, 15.00, 2.00, 2.00" style=" fill:white;"\
                     class="svg_unselected_element"/>\
                  </svg:g>\
               </svg:svg>\
               <div title="" style="position:absolute"><select id="__containerId__-page584926941-layer-combobox612942485select" onblur="rabbit.facade.raiseEvent(rabbit.events.svgBlur, \'__containerId__-page584926941-layer-combobox612942485_input_svg_border\')" onfocus="rabbit.facade.raiseEvent(rabbit.events.svgFocus, \'__containerId__-page584926941-layer-combobox612942485_input_svg_border\')" style="width:256px; height:26px;" title="">\
                     <option title="">Số người</option>\
                     <option title="">1 người</option>\
                     <option title="">2 người</option>\
                     <option title="">3 người</option>\
                     <option title="">4 người</option>\
                     <option title="">&gt;4 người</option>\
                     <option title=""></option></select></div>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page584926941-layer-datepicker728303515" style="position: absolute; left: 995px; top: 395px; width: 150px; height: 30px" data-interactive-element-type="default.datepicker" class="datepicker stencil mobile-interaction-potential-trigger " data-stencil-id="datepicker728303515" data-review-reference-id="datepicker728303515">\
         <div class="stencil-wrapper" style="width: 150px; height: 30px">\
            <div>\
               <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" style="position: absolute; height: 30px;width:150px;" width="150" height="30">\
                  <svg:g width="150px" height="30px"><svg:path id="__containerId__-page584926941-layer-datepicker728303515_input_svg_border" d="M 2.00, 2.00 Q 13.20, 0.62, 24.40,\
                     1.28 Q 35.60, 1.40, 46.80, 1.95 Q 58.00, 2.39, 69.20, 2.01 Q 80.40, 2.26, 91.60, 2.81 Q 102.80, 3.71, 113.56, 2.44 Q 113.03,\
                     15.32, 113.82, 27.82 Q 102.69, 27.59, 91.52, 27.31 Q 80.39, 27.84, 69.19, 27.68 Q 58.00, 28.17, 46.80, 27.47 Q 35.60, 27.75,\
                     24.40, 28.76 Q 13.20, 28.77, 2.09, 27.91 Q 2.00, 15.00, 2.00, 2.00" style=" fill:white;" class="svg_unselected_element"/><svg:path id="__containerId__-page584926941-layer-datepicker728303515_line1" d="M 3.00, 3.00 Q 14.90, 3.84, 26.80, 3.02 Q\
                     38.70, 2.76, 50.60, 2.63 Q 62.50, 2.61, 74.40, 3.10 Q 86.30, 2.97, 98.20, 2.41 Q 110.10, 3.00, 122.00, 3.00" style=" fill:none;"\
                     class="svg_unselected_element"/><svg:path id="__containerId__-page584926941-layer-datepicker728303515_line2" d="M 3.00, 3.00 Q 3.00, 15.00, 3.00, 27.00" style="\
                     fill:none;" class="svg_unselected_element"/><svg:path id="__containerId__-page584926941-layer-datepicker728303515_line3" d="M 3.00, 3.00 Q 14.90, 0.51, 26.80, 1.13 Q\
                     38.70, 1.90, 50.60, 2.26 Q 62.50, 1.57, 74.40, 2.57 Q 86.30, 2.52, 98.20, 2.64 Q 110.10, 3.00, 122.00, 3.00" style=" fill:none;"\
                     class="svg_unselected_element"/><svg:path id="__containerId__-page584926941-layer-datepicker728303515_line4" d="M 3.00, 3.00 Q 3.00, 15.00, 3.00, 27.00" style="\
                     fill:none;" class="svg_unselected_element"/>\
                  </svg:g>\
                  <svg:g width="150px" height="30px"><svg:path id="__containerId__-page584926941-layer-datepicker728303515_input_svg_border2" d="M 118.00, 2.00 Q 133.00, 0.69,\
                     148.02, 1.98 Q 147.55, 15.15, 147.77, 27.77 Q 132.80, 27.27, 117.94, 28.05 Q 118.00, 15.00, 118.00, 2.00" style=" fill:white;"\
                     class="svg_unselected_element"/>\
                  </svg:g>\
               </svg:svg>\
               <div style="white-space: nowrap;" title=""><input type="text" onblur="rabbit.facade.raiseEvent(rabbit.events.svgBlur, new Array(\'__containerId__-page584926941-layer-datepicker728303515_input_svg_border\',\'__containerId__-page584926941-layer-datepicker728303515_line1\',\'__containerId__-page584926941-layer-datepicker728303515_line2\',\'__containerId__-page584926941-layer-datepicker728303515_line3\',\'__containerId__-page584926941-layer-datepicker728303515_line4\'))" onfocus="rabbit.facade.raiseEvent(rabbit.events.svgFocus, new Array(\'__containerId__-page584926941-layer-datepicker728303515_input_svg_border\',\'__containerId__-page584926941-layer-datepicker728303515_line1\',\'__containerId__-page584926941-layer-datepicker728303515_line2\',\'__containerId__-page584926941-layer-datepicker728303515_line3\',\'__containerId__-page584926941-layer-datepicker728303515_line4\'))" style="width:116px; height:30px;padding: 0px;border-width:1px; position: absolute;" id="__containerId__-page584926941-layer-datepicker728303515_input" /><button type="button" onblur="rabbit.facade.raiseEvent(rabbit.events.svgBlur, \'__containerId__-page584926941-layer-datepicker728303515_input_svg_border2\')" onfocus="rabbit.facade.raiseEvent(rabbit.events.svgFocus, \'__containerId__-page584926941-layer-datepicker728303515_input_svg_border2\')" style="position:absolute; left:116px; top:0px; width:34px; height:30px; vertical-align: top; padding: 0px;border-width:1px; cursor:pointer;" id="__containerId__-page584926941-layer-datepicker728303515_button"><img src="../resources/icons/date.png" /></button></div>\
               <div id="__containerId__-page584926941-layer-datepicker728303515_ov" class="yui-skin-sam" style="position: absolute; width: 16em;visibility:visible;">\
                  <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" style="position: absolute; left: -6px; top: -4px; height: 204px;width:200px;display:none" id="__containerId__-page584926941-layer-datepicker728303515_open_calendar" width="150" height="204"><svg:path id="__containerId__-page584926941-layer-datepicker728303515_open_calendar_border" d="M 2.00, 2.00 Q 12.89, 1.35,\
                     23.78, 1.97 Q 34.67, 2.81, 45.56, 2.76 Q 56.44, 3.38, 67.33, 3.23 Q 78.22, 2.83, 89.11, 2.32 Q 100.00, 1.36, 110.89, 2.58\
                     Q 121.78, 2.73, 132.67, 1.92 Q 143.56, 1.67, 154.44, 1.89 Q 165.33, 1.59, 176.22, 2.26 Q 187.11, 2.01, 198.17, 1.83 Q 198.45,\
                     11.85, 197.72, 22.04 Q 197.38, 32.04, 197.83, 42.01 Q 198.20, 52.00, 198.18, 62.00 Q 198.68, 72.00, 197.94, 82.00 Q 198.63,\
                     92.00, 197.98, 102.00 Q 199.12, 112.00, 198.64, 122.00 Q 197.76, 132.00, 197.85, 142.00 Q 197.29, 152.00, 197.19, 162.00 Q\
                     198.02, 172.00, 197.44, 182.00 Q 197.73, 192.00, 198.01, 202.01 Q 187.15, 202.11, 176.15, 201.52 Q 165.22, 200.27, 154.42,\
                     201.25 Q 143.55, 201.85, 132.67, 202.13 Q 121.78, 202.78, 110.89, 201.83 Q 100.00, 202.35, 89.11, 202.31 Q 78.22, 203.00,\
                     67.33, 203.08 Q 56.44, 202.47, 45.56, 201.72 Q 34.67, 201.75, 23.78, 203.00 Q 12.89, 203.14, 1.95, 202.05 Q 1.58, 192.14,\
                     1.37, 182.09 Q 0.63, 172.09, 1.72, 162.01 Q 1.35, 152.01, 1.95, 142.00 Q 1.05, 132.00, 0.58, 122.00 Q 0.78, 112.00, 0.98,\
                     102.00 Q 0.83, 92.00, 1.82, 82.00 Q 2.16, 72.00, 1.80, 62.00 Q 2.33, 52.00, 2.80, 42.00 Q 2.89, 32.00, 2.14, 22.00 Q 2.00,\
                     12.00, 2.00, 2.00" style=" fill:white;" class="svg_unselected_element"/>\
                  </svg:svg>\
                  <div id="__containerId__-page584926941-layer-datepicker728303515_cal"></div>\
               </div><script type="text/javascript">\
				rabbit.stencils.datepicker.setupDatepicker("__containerId__-page584926941-layer-datepicker728303515");\
			</script></div>\
         </div>\
      </div>\
      <div id="__containerId__-page584926941-layer-combobox555000136" style="position: absolute; left: 1175px; top: 395px; width: 80px; height: 30px" data-interactive-element-type="default.combobox" class="combobox stencil mobile-interaction-potential-trigger " data-stencil-id="combobox555000136" data-review-reference-id="combobox555000136">\
         <div class="stencil-wrapper" style="width: 80px; height: 30px">\
            <div style="position:absolute;left:2px;top:0px;">\
               <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" style="position: absolute; height: 30px;width:80px;" width="80" height="30">\
                  <svg:g id="__containerId__-page584926941-layer-combobox555000136" width="80" height="30"><svg:path id="__containerId__-page584926941-layer-combobox555000136_input_svg_border" d="M 2.00, 2.00 Q 14.67, -0.45, 27.33,\
                     -0.34 Q 40.00, -0.47, 52.67, -0.05 Q 65.33, 0.42, 79.12, 0.88 Q 79.54, 14.49, 78.61, 28.61 Q 65.56, 28.82, 52.73, 28.56 Q\
                     40.05, 29.05, 27.36, 28.96 Q 14.69, 30.07, 1.21, 28.78 Q 2.00, 15.00, 2.00, 2.00" style=" fill:white;" class="svg_unselected_element"/>\
                  </svg:g>\
               </svg:svg>\
               <div title="" style="position:absolute"><select id="__containerId__-page584926941-layer-combobox555000136select" onblur="rabbit.facade.raiseEvent(rabbit.events.svgBlur, \'__containerId__-page584926941-layer-combobox555000136_input_svg_border\')" onfocus="rabbit.facade.raiseEvent(rabbit.events.svgFocus, \'__containerId__-page584926941-layer-combobox555000136_input_svg_border\')" style="width:76px; height:26px;" title="">\
                     <option title="">1h - AM</option>\
                     <option title="">2h - AM</option>\
                     <option title="">3h - AM</option>\
                     <option title="">1h - PM</option>\
                     <option title="">2h - pM</option>\
                     <option title="">3h - PM</option></select></div>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page584926941-layer-icon871960425" style="position: absolute; left: 1275px; top: 395px; width: 32px; height: 32px" data-interactive-element-type="fonticon.icon" class="icon stencil mobile-interaction-potential-trigger " data-stencil-id="icon871960425" data-review-reference-id="icon871960425">\
         <div class="stencil-wrapper" style="width: 32px; height: 32px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" style="width:32px;height:32px;" title="">\
               <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" class="fill-blue">\
                  <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#icon-glyph-e055"></use>\
               </svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page584926941-layer-arrow503608692" style="position: absolute; left: 995px; top: 470px; width: 335px; height: 33px" data-interactive-element-type="static.line" class="line stencil mobile-interaction-potential-trigger " data-stencil-id="arrow503608692" data-review-reference-id="arrow503608692">\
         <div class="stencil-wrapper" style="width: 335px; height: 33px">\
            <div title="">\
               <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" style="position: absolute; left: -5px; top: -5px; height: 43px;width:345px;" viewBox="-5 -5 345 43" width="345" height="43"><svg:path d="M 0.00, 16.00 Q 10.47, 16.75, 20.94, 15.69 Q 31.41, 15.76, 41.88, 15.06 Q 52.34, 15.36, 62.81, 15.99 Q 73.28,\
                  15.72, 83.75, 16.16 Q 94.22, 15.19, 104.69, 16.06 Q 115.16, 15.47, 125.62, 16.33 Q 136.09, 16.51, 146.56, 15.59 Q 157.03,\
                  16.28, 167.50, 16.65 Q 177.97, 15.40, 188.44, 15.27 Q 198.91, 15.64, 209.38, 15.97 Q 219.84, 15.88, 230.31, 14.31 Q 240.78,\
                  14.55, 251.25, 16.01 Q 261.72, 16.15, 272.19, 15.79 Q 282.66, 15.79, 293.12, 15.30 Q 303.59, 15.79, 314.06, 16.45 Q 324.53,\
                  16.00, 335.00, 16.00" style="marker-start:;marker-end:" class="svg_unselected_element"/>\
               </svg:svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page584926941-layer-517631034" style="position: absolute; left: 990px; top: 505px; width: 199px; height: 37px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="517631034" data-review-reference-id="517631034">\
         <div class="stencil-wrapper" style="width: 199px; height: 37px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline12"><p class="none" style="font-size: 32px;"><span style="color: #658cd9;">Món đã chọn</span> </p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page584926941-layer-1858259876" style="position: absolute; left: 1000px; top: 435px; width: 166px; height: 37px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="1858259876" data-review-reference-id="1858259876">\
         <div class="stencil-wrapper" style="width: 166px; height: 37px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline12"><p class="none" style="font-size: 32px;"><span style="font-size: 20px; color: #000000;"><span class="bold">Cần đặt cọc</span>\
                     : 0% </span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page584926941-layer-image675566991" style="position: absolute; left: 25px; top: 280px; width: 944px; height: 522px" data-interactive-element-type="default.image" class="image stencil mobile-interaction-potential-trigger " data-stencil-id="image675566991" data-review-reference-id="image675566991">\
         <div class="stencil-wrapper" style="width: 944px; height: 522px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" title="">\
               <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" class="image-cropper" style="height: 522px;width:944px;" width="944" height="522">\
                  <svg:g width="944" height="522">\
                     <svg:svg x="1" y="1" width="942" height="520">\
                        <svg:image width="80" height="60" xlink:href="../repoimages/508428.PNG" preserveAspectRatio="none" transform="scale(11.8,8.7) translate(-0,-0)  "></svg:image>\
                     </svg:svg>\
                  </svg:g>\
               </svg:svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page584926941-layer-text273581906" style="position: absolute; left: 30px; top: 230px; width: 155px; height: 37px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text273581906" data-review-reference-id="text273581906">\
         <div class="stencil-wrapper" style="width: 155px; height: 37px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline12"><p><span style="font-size: 32px; color: #658cd9;">Món chính</span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page584926941-layer-image422327871" style="position: absolute; left: 995px; top: 560px; width: 330px; height: 420px" data-interactive-element-type="default.image" class="image stencil mobile-interaction-potential-trigger " data-stencil-id="image422327871" data-review-reference-id="image422327871">\
         <div class="stencil-wrapper" style="width: 330px; height: 420px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" title="">\
               <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" class="image-cropper" style="height: 420px;width:330px;" width="330" height="420">\
                  <svg:g width="330" height="420">\
                     <svg:svg x="1" y="1" width="328" height="418">\
                        <svg:image width="80" height="60" xlink:href="../repoimages/508429.PNG" preserveAspectRatio="none" transform="scale(4.125,7) translate(-0,-0)  "></svg:image>\
                     </svg:svg>\
                  </svg:g>\
               </svg:svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page584926941-layer-text509771342" style="position: absolute; left: 995px; top: 1010px; width: 203px; height: 37px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text509771342" data-review-reference-id="text509771342">\
         <div class="stencil-wrapper" style="width: 203px; height: 37px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline12"><p><span style="font-size: 32px; color: #658cd9;">Yêu cầu thêm</span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page584926941-layer-textinput613408713" style="position: absolute; left: 1000px; top: 1070px; width: 330px; height: 150px" data-interactive-element-type="default.textinput" class="textinput stencil mobile-interaction-potential-trigger " data-stencil-id="textinput613408713" data-review-reference-id="textinput613408713">\
         <div class="stencil-wrapper" style="width: 330px; height: 150px">\
            <div>\
               <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" style="height: 150px;width:330px;" width="330" height="150">\
                  <svg:g id="__containerId__-page584926941-layer-textinput613408713svg" width="330" height="150"><svg:path id="__containerId__-page584926941-layer-textinput613408713_input_svg_border" d="M 2.00, 2.00 Q 12.19, -0.02, 22.38,\
                     0.30 Q 32.56, 0.39, 42.75, 0.81 Q 52.94, 0.81, 63.12, 0.86 Q 73.31, 1.33, 83.50, 1.97 Q 93.69, 1.98, 103.88, 1.53 Q 114.06,\
                     1.91, 124.25, 1.33 Q 134.44, 0.82, 144.62, 1.61 Q 154.81, 1.62, 165.00, 2.36 Q 175.19, 1.43, 185.38, 1.76 Q 195.56, 1.23,\
                     205.75, 0.94 Q 215.94, 0.87, 226.12, 1.57 Q 236.31, 1.92, 246.50, 1.11 Q 256.69, 0.58, 266.88, 0.36 Q 277.06, 0.48, 287.25,\
                     1.85 Q 297.44, 1.47, 307.62, 1.64 Q 317.81, 2.26, 327.62, 2.38 Q 327.61, 12.56, 328.60, 22.77 Q 328.62, 33.24, 328.20, 43.71\
                     Q 328.44, 54.14, 328.63, 64.57 Q 329.22, 75.00, 329.18, 85.43 Q 328.88, 95.86, 329.40, 106.29 Q 328.60, 116.71, 327.54, 127.14\
                     Q 327.57, 137.57, 327.70, 147.70 Q 317.75, 147.81, 307.71, 148.61 Q 297.49, 148.81, 287.30, 149.50 Q 277.08, 149.21, 266.89,\
                     150.20 Q 256.69, 149.18, 246.50, 149.61 Q 236.31, 148.53, 226.12, 147.84 Q 215.94, 147.97, 205.75, 148.51 Q 195.56, 148.62,\
                     185.38, 147.78 Q 175.19, 147.41, 165.00, 147.22 Q 154.81, 147.72, 144.62, 147.64 Q 134.44, 148.09, 124.25, 147.61 Q 114.06,\
                     148.27, 103.88, 149.61 Q 93.69, 150.00, 83.50, 150.08 Q 73.31, 149.17, 63.12, 149.77 Q 52.94, 149.80, 42.75, 149.57 Q 32.56,\
                     149.53, 22.38, 149.15 Q 12.19, 148.85, 1.61, 148.39 Q 1.33, 137.80, 1.36, 127.23 Q 0.61, 116.81, 0.88, 106.32 Q 0.33, 95.88,\
                     0.03, 85.44 Q -0.00, 75.01, 0.68, 64.57 Q 0.77, 54.14, 1.16, 43.71 Q 1.95, 33.29, 1.56, 22.86 Q 2.00, 12.43, 2.00, 2.00" style="\
                     fill:white;" class="svg_unselected_element"/><svg:path id="__containerId__-page584926941-layer-textinput613408713_line1" d="M 3.00, 3.00 Q 13.12, 2.81, 23.25, 2.79 Q 33.38,\
                     2.37, 43.50, 3.29 Q 53.62, 2.82, 63.75, 2.71 Q 73.88, 4.40, 84.00, 4.61 Q 94.12, 4.50, 104.25, 4.25 Q 114.38, 2.81, 124.50,\
                     3.08 Q 134.62, 3.07, 144.75, 3.59 Q 154.88, 4.48, 165.00, 3.73 Q 175.12, 3.81, 185.25, 3.61 Q 195.38, 3.43, 205.50, 3.06 Q\
                     215.62, 2.23, 225.75, 2.36 Q 235.88, 2.74, 246.00, 4.03 Q 256.12, 3.79, 266.25, 2.60 Q 276.38, 1.79, 286.50, 2.13 Q 296.62,\
                     3.59, 306.75, 3.46 Q 316.88, 3.00, 327.00, 3.00" style=" fill:none;" class="svg_unselected_element"/><svg:path id="__containerId__-page584926941-layer-textinput613408713_line2" d="M 3.00, 3.00 Q 3.00, 13.29, 2.44, 23.57 Q 2.22,\
                     33.86, 1.83, 44.14 Q 2.38, 54.43, 2.36, 64.71 Q 2.21, 75.00, 2.43, 85.29 Q 2.13, 95.57, 3.51, 105.86 Q 3.57, 116.14, 2.65,\
                     126.43 Q 3.00, 136.71, 3.00, 147.00" style=" fill:none;" class="svg_unselected_element"/><svg:path id="__containerId__-page584926941-layer-textinput613408713_line3" d="M 3.00, 3.00 Q 13.12, 0.89, 23.25, 0.82 Q 33.38,\
                     1.38, 43.50, 1.28 Q 53.62, 1.09, 63.75, 1.85 Q 73.88, 1.13, 84.00, 1.39 Q 94.12, 0.73, 104.25, 1.17 Q 114.38, 2.04, 124.50,\
                     3.07 Q 134.62, 1.91, 144.75, 1.65 Q 154.88, 2.56, 165.00, 1.88 Q 175.12, 1.36, 185.25, 1.17 Q 195.38, 1.52, 205.50, 1.33 Q\
                     215.62, 1.36, 225.75, 1.39 Q 235.88, 1.62, 246.00, 2.45 Q 256.12, 1.63, 266.25, 1.41 Q 276.38, 1.11, 286.50, 1.59 Q 296.62,\
                     2.72, 306.75, 2.67 Q 316.88, 3.00, 327.00, 3.00" style=" fill:none;" class="svg_unselected_element"/><svg:path id="__containerId__-page584926941-layer-textinput613408713_line4" d="M 3.00, 3.00 Q 3.69, 13.29, 2.96, 23.57 Q 2.61,\
                     33.86, 2.49, 44.14 Q 3.05, 54.43, 2.83, 64.71 Q 2.69, 75.00, 2.96, 85.29 Q 3.89, 95.57, 3.10, 105.86 Q 2.87, 116.14, 2.52,\
                     126.43 Q 3.00, 136.71, 3.00, 147.00" style=" fill:none;" class="svg_unselected_element"/>\
                  </svg:g>\
               </svg:svg>\
               <div style="position:absolute;left: 6px; top: 1px;" title=""><textarea id="__containerId__-page584926941-layer-textinput613408713input" onblur="rabbit.facade.raiseEvent(rabbit.events.svgBlur, new Array(\'__containerId__-page584926941-layer-textinput613408713_input_svg_border\',\'__containerId__-page584926941-layer-textinput613408713_line1\',\'__containerId__-page584926941-layer-textinput613408713_line2\',\'__containerId__-page584926941-layer-textinput613408713_line3\',\'__containerId__-page584926941-layer-textinput613408713_line4\'))" onfocus="rabbit.facade.raiseEvent(rabbit.events.svgFocus, new Array(\'__containerId__-page584926941-layer-textinput613408713_input_svg_border\',\'__containerId__-page584926941-layer-textinput613408713_line1\',\'__containerId__-page584926941-layer-textinput613408713_line2\',\'__containerId__-page584926941-layer-textinput613408713_line3\',\'__containerId__-page584926941-layer-textinput613408713_line4\'))" rows="" cols="" style="width:323px;height:144px;"></textarea></div>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page584926941-layer-iphoneButton412712734" style="position: absolute; left: 1230px; top: 1250px; width: 100px; height: 30px" data-interactive-element-type="default.iphoneButton" class="iphoneButton stencil mobile-interaction-potential-trigger " data-stencil-id="iphoneButton412712734" data-review-reference-id="iphoneButton412712734">\
         <div class="stencil-wrapper" style="width: 100px; height: 30px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" title="" style="position: absolute; left: -2px; top: -2px;height: 34px;width:104px;">\
               <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" class="helvetica-font" width="104" height="34" viewBox="-2 -2 104 34">\
                  <svg:a><svg:path d="M 4.00, 29.00 Q 2.99, 29.01, 3.16, 27.93 Q 2.99, 15.00, 3.82, 2.27 Q 3.38, 1.42, 3.85, 0.70 Q 14.64, 0.48, 25.52,\
                     1.21 Q 36.22, 0.31, 46.98, 0.07 Q 57.75, 0.89, 68.50, 0.38 Q 79.25, 1.21, 90.15, 0.36 Q 91.11, 1.20, 92.32, 1.59 Q 96.96,\
                     8.07, 102.10, 14.94 Q 97.82, 21.94, 92.76, 28.71 Q 91.57, 29.28, 89.90, 28.68 Q 79.33, 29.58, 68.58, 30.17 Q 57.79, 30.03,\
                     47.00, 29.00 Q 36.26, 30.34, 25.51, 30.60 Q 14.75, 29.00, 4.00, 29.00" style="fill-rule:evenodd;clip-rule:evenodd;fill:#808080;stroke:#666666;"\
                     class="svg_unselected_element"/>\
                     <svg:text x="47" y="15" dy="0.3em" fill="#FFFFFF" style="font-size:1em;stroke-width:0pt;" font-family="\'HelveticaNeue-Bold\'" text-anchor="middle" xml:space="preserve">Hoàn tất</svg:text>\
                  </svg:a>\
               </svg:svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page584926941-layer-317517354" style="position: absolute; left: 20px; top: 770px; width: 944px; height: 522px" data-interactive-element-type="default.image" class="image stencil mobile-interaction-potential-trigger " data-stencil-id="317517354" data-review-reference-id="317517354">\
         <div class="stencil-wrapper" style="width: 944px; height: 522px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" title="">\
               <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" class="image-cropper" style="height: 522px;width:944px;" width="944" height="522">\
                  <svg:g width="944" height="522">\
                     <svg:svg x="1" y="1" width="942" height="520">\
                        <svg:image width="80" height="60" xlink:href="../repoimages/508428.PNG" preserveAspectRatio="none" transform="scale(11.8,8.7) translate(-0,-0)  "></svg:image>\
                     </svg:svg>\
                  </svg:g>\
               </svg:svg>\
            </div>\
         </div>\
      </div>\
   </div>\
</div>');