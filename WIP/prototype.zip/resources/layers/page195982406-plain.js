rabbit.data.layerStore.addLayerFromHtml('<div xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:fn="http://www.w3.org/2005/xpath-functions" id="result">\
   <div xmlns:xs="http://www.w3.org/2001/XMLSchema" xmlns="http://www.w3.org/1999/xhtml" id="__containerId__page195982406-layer" class="layer" name="__containerId__pageLayer" data-layer-id="page195982406" data-layer-type="pageLayer" style="position:absolute;left:0px;top:0px;">\
      <div id="__containerId__-page195982406-layer-image40232402" style="position: absolute; left: 5px; top: 0px; width: 1366px; height: 2000px" data-interactive-element-type="default.image" class="image stencil mobile-interaction-potential-trigger " data-stencil-id="image40232402" data-review-reference-id="image40232402">\
         <div class="stencil-wrapper" style="width: 1366px; height: 2000px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" title="">\
               <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" class="image-cropper" style="height: 2000px;width:1366px;" width="1366" height="2000" viewBox="0 0 1366 2000">\
                  <svg:g width="1366" height="2000">\
                     <svg:svg x="0" y="0" width="1366" height="2000">\
                        <svg:image width="432" height="253" xlink:href="../repoimages/506332.PNG" preserveAspectRatio="none" transform="scale(3.162037037037037,7.905138339920948) translate(-0,-0)  "></svg:image>\
                     </svg:svg>\
                  </svg:g>\
               </svg:svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page195982406-layer-text964319955" style="position: absolute; left: 490px; top: 40px; width: 299px; height: 37px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text964319955" data-review-reference-id="text964319955">\
         <div class="stencil-wrapper" style="width: 299px; height: 37px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline12"><p class="none" style="font-size: 32px;"><span class="bold" style="color: #658cd9;">Đăng kí thành viên </span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page195982406-layer-text983126157" style="position: absolute; left: 170px; top: 145px; width: 83px; height: 28px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text983126157" data-review-reference-id="text983126157">\
         <div class="stencil-wrapper" style="width: 83px; height: 28px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline22"><p><span style="font-size: 24px; color: #658cd9;">Họ tên:</span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page195982406-layer-textinput797440193" style="position: absolute; left: 395px; top: 145px; width: 400px; height: 30px" data-interactive-element-type="default.textinput" class="textinput stencil mobile-interaction-potential-trigger " data-stencil-id="textinput797440193" data-review-reference-id="textinput797440193">\
         <div class="stencil-wrapper" style="width: 400px; height: 30px">\
            <div title=""><input id="__containerId__-page195982406-layer-textinput797440193input" value="" style="width:398px;height:28px;padding: 0px;border-width:1px;" type="text" /></div>\
         </div>\
      </div>\
      <div id="__containerId__-page195982406-layer-1600488173" style="position: absolute; left: 395px; top: 220px; width: 400px; height: 30px" data-interactive-element-type="default.textinput" class="textinput stencil mobile-interaction-potential-trigger " data-stencil-id="1600488173" data-review-reference-id="1600488173">\
         <div class="stencil-wrapper" style="width: 400px; height: 30px">\
            <div title=""><input id="__containerId__-page195982406-layer-1600488173input" value="" style="width:398px;height:28px;padding: 0px;border-width:1px;" type="text" /></div>\
         </div>\
      </div>\
      <div id="__containerId__-page195982406-layer-1786337216" style="position: absolute; left: 170px; top: 220px; width: 153px; height: 28px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="1786337216" data-review-reference-id="1786337216">\
         <div class="stencil-wrapper" style="width: 153px; height: 28px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline22"><p><span style="font-size: 24px; color: #658cd9;">Số điện thoại:</span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page195982406-layer-2146370051" style="position: absolute; left: 170px; top: 300px; width: 113px; height: 28px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="2146370051" data-review-reference-id="2146370051">\
         <div class="stencil-wrapper" style="width: 113px; height: 28px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline22"><p><span style="font-size: 24px; color: #658cd9;">Ngày sinh</span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page195982406-layer-875716220" style="position: absolute; left: 395px; top: 380px; width: 400px; height: 30px" data-interactive-element-type="default.textinput" class="textinput stencil mobile-interaction-potential-trigger " data-stencil-id="875716220" data-review-reference-id="875716220">\
         <div class="stencil-wrapper" style="width: 400px; height: 30px">\
            <div title=""><input id="__containerId__-page195982406-layer-875716220input" value="" style="width:398px;height:28px;padding: 0px;border-width:1px;" type="text" /></div>\
         </div>\
      </div>\
      <div id="__containerId__-page195982406-layer-1573620076" style="position: absolute; left: 170px; top: 380px; width: 93px; height: 28px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="1573620076" data-review-reference-id="1573620076">\
         <div class="stencil-wrapper" style="width: 93px; height: 28px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline22"><p class="none" style="font-size: 24px;"><span style="color: #658cd9;">Địa chỉ:</span> </p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page195982406-layer-1916668307" style="position: absolute; left: 170px; top: 540px; width: 118px; height: 28px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="1916668307" data-review-reference-id="1916668307">\
         <div class="stencil-wrapper" style="width: 118px; height: 28px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline22"><p class="none" style="font-size: 24px;"><span style="color: #658cd9;">Mật khẩu:</span> </p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page195982406-layer-1255023614" style="position: absolute; left: 395px; top: 540px; width: 400px; height: 30px" data-interactive-element-type="default.textinput" class="textinput stencil mobile-interaction-potential-trigger " data-stencil-id="1255023614" data-review-reference-id="1255023614">\
         <div class="stencil-wrapper" style="width: 400px; height: 30px">\
            <div title=""><input id="__containerId__-page195982406-layer-1255023614input" value="" style="width:398px;height:28px;padding: 0px;border-width:1px;" type="text" /></div>\
         </div>\
      </div>\
      <div id="__containerId__-page195982406-layer-1987119085" style="position: absolute; left: 170px; top: 625px; width: 226px; height: 28px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="1987119085" data-review-reference-id="1987119085">\
         <div class="stencil-wrapper" style="width: 226px; height: 28px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline22"><p class="none" style="font-size: 24px;"><span style="color: #658cd9;">Xác nhận mật khẩu:</span> </p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page195982406-layer-1874987766" style="position: absolute; left: 395px; top: 625px; width: 400px; height: 30px" data-interactive-element-type="default.textinput" class="textinput stencil mobile-interaction-potential-trigger " data-stencil-id="1874987766" data-review-reference-id="1874987766">\
         <div class="stencil-wrapper" style="width: 400px; height: 30px">\
            <div title=""><input id="__containerId__-page195982406-layer-1874987766input" value="" style="width:398px;height:28px;padding: 0px;border-width:1px;" type="text" /></div>\
         </div>\
      </div>\
      <div id="__containerId__-page195982406-layer-1223754287" style="position: absolute; left: 170px; top: 455px; width: 79px; height: 28px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="1223754287" data-review-reference-id="1223754287">\
         <div class="stencil-wrapper" style="width: 79px; height: 28px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline22"><p class="none" style="font-size: 24px;"><span style="color: #658cd9;">Email:</span> </p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page195982406-layer-501165204" style="position: absolute; left: 395px; top: 455px; width: 400px; height: 30px" data-interactive-element-type="default.textinput" class="textinput stencil mobile-interaction-potential-trigger " data-stencil-id="501165204" data-review-reference-id="501165204">\
         <div class="stencil-wrapper" style="width: 400px; height: 30px">\
            <div title=""><input id="__containerId__-page195982406-layer-501165204input" value="" style="width:398px;height:28px;padding: 0px;border-width:1px;" type="text" /></div>\
         </div>\
      </div>\
      <div id="__containerId__-page195982406-layer-icon934293370" style="position: absolute; left: 115px; top: 145px; width: 32px; height: 32px" data-interactive-element-type="fonticon.icon" class="icon stencil mobile-interaction-potential-trigger " data-stencil-id="icon934293370" data-review-reference-id="icon934293370">\
         <div class="stencil-wrapper" style="width: 32px; height: 32px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" style="width:32px;height:32px;" title="">\
               <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" class="fill-red">\
                  <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#icon-glyph-e196"></use>\
               </svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page195982406-layer-532913823" style="position: absolute; left: 115px; top: 220px; width: 32px; height: 32px" data-interactive-element-type="fonticon.icon" class="icon stencil mobile-interaction-potential-trigger " data-stencil-id="532913823" data-review-reference-id="532913823">\
         <div class="stencil-wrapper" style="width: 32px; height: 32px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" style="width:32px;height:32px;" title="">\
               <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" class="fill-red">\
                  <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#icon-glyph-e196"></use>\
               </svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page195982406-layer-1151361062" style="position: absolute; left: 110px; top: 455px; width: 32px; height: 32px" data-interactive-element-type="fonticon.icon" class="icon stencil mobile-interaction-potential-trigger " data-stencil-id="1151361062" data-review-reference-id="1151361062">\
         <div class="stencil-wrapper" style="width: 32px; height: 32px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" style="width:32px;height:32px;" title="">\
               <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" class="fill-red">\
                  <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#icon-glyph-e196"></use>\
               </svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page195982406-layer-932295922" style="position: absolute; left: 110px; top: 540px; width: 32px; height: 32px" data-interactive-element-type="fonticon.icon" class="icon stencil mobile-interaction-potential-trigger " data-stencil-id="932295922" data-review-reference-id="932295922">\
         <div class="stencil-wrapper" style="width: 32px; height: 32px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" style="width:32px;height:32px;" title="">\
               <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" class="fill-red">\
                  <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#icon-glyph-e196"></use>\
               </svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page195982406-layer-1963586773" style="position: absolute; left: 115px; top: 620px; width: 32px; height: 32px" data-interactive-element-type="fonticon.icon" class="icon stencil mobile-interaction-potential-trigger " data-stencil-id="1963586773" data-review-reference-id="1963586773">\
         <div class="stencil-wrapper" style="width: 32px; height: 32px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" style="width:32px;height:32px;" title="">\
               <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" class="fill-red">\
                  <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#icon-glyph-e196"></use>\
               </svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page195982406-layer-datepicker303767136" style="position: absolute; left: 395px; top: 300px; width: 150px; height: 30px" data-interactive-element-type="default.datepicker" class="datepicker stencil mobile-interaction-potential-trigger " data-stencil-id="datepicker303767136" data-review-reference-id="datepicker303767136">\
         <div class="stencil-wrapper" style="width: 150px; height: 30px">\
            <div>\
               <div style="position:absolute; white-space: nowrap;" title=""><input type="text" style="width:114px; height:28px;padding: 0px;border-width:1px;" id="__containerId__-page195982406-layer-datepicker303767136_input" /><button type="button" style="width:34px; height:28px; vertical-align: top; padding: 0px;border-width:1px;" id="__containerId__-page195982406-layer-datepicker303767136_button"><img src="../resources/icons/date.png" /></button></div>\
               <div id="__containerId__-page195982406-layer-datepicker303767136_ov" class="yui-skin-sam" style="position: absolute; width: 16em;visibility:visible;">\
                  <div id="__containerId__-page195982406-layer-datepicker303767136_cal"></div>\
               </div><script type="text/javascript">\
				rabbit.stencils.datepicker.setupDatepicker("__containerId__-page195982406-layer-datepicker303767136");\
			</script></div>\
         </div>\
      </div>\
      <div id="__containerId__-page195982406-layer-radiobutton384608409" style="position: absolute; left: 610px; top: 305px; width: 52px; height: 20px" data-interactive-element-type="default.radiobutton" class="radiobutton stencil mobile-interaction-potential-trigger " data-stencil-id="radiobutton384608409" data-review-reference-id="radiobutton384608409">\
         <div class="stencil-wrapper" style="width: 52px; height: 20px">\
            <div class="" style="font-size:1.17em;" xml:space="preserve" title="">\
               					<input id="__containerId__-page195982406-layer-radiobutton384608409input" xml:space="default" type="radio" name="group1" value="__containerId__-page195982406-layer-radiobutton384608409" style="padding-right:8px" />\
               \
               					<label for="__containerId__-page195982406-layer-radiobutton384608409input">\
                  						\
                  						\
                  							Nam\
                  							\
                  						\
                  					</label>\
               				\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page195982406-layer-823983834" style="position: absolute; left: 705px; top: 305px; width: 41px; height: 20px" data-interactive-element-type="default.radiobutton" class="radiobutton stencil mobile-interaction-potential-trigger " data-stencil-id="823983834" data-review-reference-id="823983834">\
         <div class="stencil-wrapper" style="width: 41px; height: 20px">\
            <div class="" style="font-size:1.17em;" xml:space="preserve" title="">\
               					<input id="__containerId__-page195982406-layer-823983834input" xml:space="default" type="radio" name="group1" value="__containerId__-page195982406-layer-823983834" style="padding-right:8px" />\
               \
               					<label for="__containerId__-page195982406-layer-823983834input">\
                  						\
                  						\
                  							Nữ\
                  							\
                  						\
                  					</label>\
               				\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page195982406-layer-iphoneButton620649085" style="position: absolute; left: 875px; top: 745px; width: 120px; height: 55px" data-interactive-element-type="default.iphoneButton" class="iphoneButton stencil mobile-interaction-potential-trigger " data-stencil-id="iphoneButton620649085" data-review-reference-id="iphoneButton620649085">\
         <div class="stencil-wrapper" style="width: 120px; height: 55px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" title="" style="height: 55px;width:120px;">\
               <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" width="120" height="55" viewBox="0 0 120 55">\
                  <svg:a>\
                     <svg:path fill-rule="evenodd" clip-rule="evenodd" fill="#808080" stroke="#666666" d="M5,54.5 l-2,-0.5 -1,-1 -1,-1.5 -0.5,-1.5 0,-45 0.5,-2 1,-1 1,-1 2,-0.5 102,0 0.5,0.5 1,0 1,1 1.5,1.5 8.5,23.5 -7.5,23.5 -2,2.5 -1.5,1 -0.5,0.5 z"></svg:path>\
                     <svg:text x="57" y="27.5" dy="0.3em" fill="#FFFFFF" style="font-size:1em;stroke-width:0pt;" font-family="\'HelveticaNeue-Bold\'" text-anchor="middle" xml:space="preserve">Đăng ký</svg:text>\
                  </svg:a>\
               </svg:svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page195982406-layer-checkbox5875495" style="position: absolute; left: 185px; top: 680px; width: 238px; height: 20px" data-interactive-element-type="default.checkbox" class="checkbox stencil mobile-interaction-potential-trigger " data-stencil-id="checkbox5875495" data-review-reference-id="checkbox5875495">\
         <div class="stencil-wrapper" style="width: 238px; height: 20px">\
            <div class="" style="font-size:1.17em;" xml:space="preserve" title="">\
               			\
               <nobr>\
                  				<label>\
                     					<input id="__containerId__-page195982406-layer-checkbox5875495input" xml:space="default" style="padding-right:9px" type="checkbox" />\
                     					\
                     						\
                     						Đăng ký với tư cách chủ cửa hàng\
                     						\
                     					\
                     				</label>\
                  			\
               </nobr>\
               		\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page195982406-layer-361062599" style="position: absolute; left: 185px; top: 720px; width: 268px; height: 20px" data-interactive-element-type="default.checkbox" class="checkbox stencil mobile-interaction-potential-trigger " data-stencil-id="361062599" data-review-reference-id="361062599">\
         <div class="stencil-wrapper" style="width: 268px; height: 20px">\
            <div class="" style="font-size:1.17em;" xml:space="preserve" title="">\
               			\
               <nobr>\
                  				<label>\
                     					<input id="__containerId__-page195982406-layer-361062599input" xml:space="default" style="padding-right:9px" type="checkbox" checked="true" />\
                     					\
                     						\
                     						Tôi đồng ý với các điều khoản sử dụng\
                     						\
                     					\
                     				</label>\
                  			\
               </nobr>\
               		\
            </div>\
         </div>\
      </div>\
   </div>\
</div>');