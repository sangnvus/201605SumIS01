rabbit.data.layerStore.addLayerFromHtml('<div xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:fn="http://www.w3.org/2005/xpath-functions" id="result">\
   <div xmlns:xs="http://www.w3.org/2001/XMLSchema" xmlns="http://www.w3.org/1999/xhtml" id="__containerId__page584926941-layer" class="layer" name="__containerId__pageLayer" data-layer-id="page584926941" data-layer-type="pageLayer" style="position:absolute;left:0px;top:0px;">\
      <div id="__containerId__-page584926941-layer-image827368748" style="position: absolute; left: 0px; top: 5px; width: 1366px; height: 2000px" data-interactive-element-type="default.image" class="image stencil mobile-interaction-potential-trigger " data-stencil-id="image827368748" data-review-reference-id="image827368748">\
         <div class="stencil-wrapper" style="width: 1366px; height: 2000px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" title="">\
               <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" class="image-cropper" style="height: 2000px;width:1366px;" width="1366" height="2000" viewBox="0 0 1366 2000">\
                  <svg:g width="1366" height="2000">\
                     <svg:svg x="0" y="0" width="1366" height="2000">\
                        <svg:image width="432" height="253" xlink:href="../repoimages/508372.PNG" preserveAspectRatio="none" transform="scale(3.162037037037037,7.905138339920948) translate(-0,-0)  "></svg:image>\
                     </svg:svg>\
                  </svg:g>\
               </svg:svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page584926941-layer-image708809043" style="position: absolute; left: 0px; top: 0px; width: 1366px; height: 145px" data-interactive-element-type="default.image" class="image stencil mobile-interaction-potential-trigger " data-stencil-id="image708809043" data-review-reference-id="image708809043">\
         <div class="stencil-wrapper" style="width: 1366px; height: 145px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" title="">\
               <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" class="image-cropper" style="height: 145px;width:1366px;" width="1366" height="145" viewBox="0 0 1366 145">\
                  <svg:g width="1366" height="145">\
                     <svg:svg x="0" y="0" width="1366" height="145">\
                        <svg:image width="80" height="60" xlink:href="../repoimages/508416.PNG" preserveAspectRatio="none" transform="scale(17.075,2.4166666666666665) translate(-0,-0)  "></svg:image>\
                     </svg:svg>\
                  </svg:g>\
               </svg:svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page584926941-layer-image267936877" style="position: absolute; left: 970px; top: 170px; width: 385px; height: 1500px" data-interactive-element-type="default.image" class="image pidoco-clickable-element stencil mobile-interaction-potential-trigger " data-stencil-id="image267936877" data-review-reference-id="image267936877">\
         <div class="stencil-wrapper" style="width: 385px; height: 1500px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" title="">\
               <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" class="image-cropper" style="height: 1500px;width:385px;" width="385" height="1500" viewBox="0 0 385 1500">\
                  <svg:g width="385" height="1500">\
                     <svg:svg x="0" y="0" width="385" height="1500">\
                        <svg:image width="93" height="25" xlink:href="../repoimages/508405.PNG" preserveAspectRatio="none" transform="scale(4.139784946236559,60) translate(-0,-0)  "></svg:image>\
                     </svg:svg>\
                  </svg:g>\
               </svg:svg>\
            </div>\
         </div><script type="text/javascript">\
			$(document).ready(function(){\
				rabbit.interaction.manager.registerInteraction(\'__containerId__-page584926941-layer-image267936877\', \'interaction382033057\', \
		{\
		\
			\'button\': \'left\'\
			\
				,\
			\
			\'id\': \'action26215521\'\
			\
				,\
			\
			\'numberOfFinger\': \'1\'\
			\
				,\
			\
			\'type\': \'click\'\
			\
		}\
	,  \
					[\
						\
		{\
		\
			\'delay\': \'0\'\
			\
				,\
			\
			\'id\': \'reaction78556891\'\
			\
				,\
			\
			\'options\': \'reloadOnly\'\
			\
				,\
			\
			\'target\': \'\'\
			\
				,\
			\
			\'transition\': \'none\'\
			\
				,\
			\
			\'type\': \'showPage\'\
			\
		}\
	\
					]\
				);\
			});\
		</script></div>\
      <div id="__containerId__-page584926941-layer-image225078985" style="position: absolute; left: 970px; top: 210px; width: 385px; height: 1500px" data-interactive-element-type="default.image" class="image pidoco-clickable-element stencil mobile-interaction-potential-trigger " data-stencil-id="image225078985" data-review-reference-id="image225078985">\
         <div class="stencil-wrapper" style="width: 385px; height: 1500px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" title="">\
               <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" class="image-cropper" style="height: 1500px;width:385px;" width="385" height="1500" viewBox="0 0 385 1500">\
                  <svg:g width="385" height="1500">\
                     <svg:svg x="0" y="0" width="385" height="1500">\
                        <svg:image width="93" height="25" xlink:href="../repoimages/508405.PNG" preserveAspectRatio="none" transform="scale(4.139784946236559,60) translate(-0,-0)  "></svg:image>\
                     </svg:svg>\
                  </svg:g>\
               </svg:svg>\
            </div>\
         </div><script type="text/javascript">\
			$(document).ready(function(){\
				rabbit.interaction.manager.registerInteraction(\'__containerId__-page584926941-layer-image225078985\', \'2081145029\', \
		{\
		\
			\'button\': \'left\'\
			\
				,\
			\
			\'id\': \'1718242533\'\
			\
				,\
			\
			\'numberOfFinger\': \'1\'\
			\
				,\
			\
			\'type\': \'click\'\
			\
		}\
	,  \
					[\
						\
		{\
		\
			\'delay\': \'0\'\
			\
				,\
			\
			\'id\': \'1915818756\'\
			\
				,\
			\
			\'options\': \'reloadOnly\'\
			\
				,\
			\
			\'target\': \'\'\
			\
				,\
			\
			\'transition\': \'none\'\
			\
				,\
			\
			\'type\': \'showPage\'\
			\
		}\
	\
					]\
				);\
			});\
		</script></div>\
      <div id="__containerId__-page584926941-layer-tabbutton283931937" style="position: absolute; left: 20px; top: 185px; width: 112px; height: 30px" data-interactive-element-type="default.tabbutton" class="tabbutton stencil mobile-interaction-potential-trigger " data-stencil-id="tabbutton283931937" data-review-reference-id="tabbutton283931937">\
         <div class="stencil-wrapper" style="width: 112px; height: 30px">\
            <div title="">\
               <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" xmlns="http://www.w3.org/2000/svg" style="position: absolute; left: -5px; top: -5px; height: 40px;width:122px;" width="112" height="35">\
                  <svg:g id="target" x="-5" y="0" width="112" height="30" name="target" class="">\
                     <svg:path id="__containerId__-page584926941-layer-tabbutton283931937_small_path" width="112" height="30" style="stroke:black; stroke-width:1; fill:white" class="smallTab" d="M 5,15 C 5,5 15,5 15,5 L 107,5 C 117,5 117,15 117,15 L 117,35 L 5,35 L 5,15"></svg:path>\
                  </svg:g>\
               </svg:svg>\
               <div id="__containerId__-page584926941-layer-tabbutton283931937div" class="helvetica-font" style="position: absolute; top: 4px; height: 30px;width:112px;text-align:center;font-size:1em;fill:none;cursor:pointer;padding-top:5px;" xml:space="preserve" onmouseover="rabbit.facade.raiseEvent(rabbit.events.tabButtonMouseOver, \'__containerId__-page584926941-layer-tabbutton283931937\', \'result\');" onmouseout="rabbit.facade.raiseEvent(rabbit.events.tabButtonMouseOut, \'__containerId__-page584926941-layer-tabbutton283931937\', \'result\');">\
                  				Khai vị\
                  				\
                  <addMouseOverListener></addMouseOverListener>\
                  				\
                  <addMouseOutListener></addMouseOutListener>\
                  			\
               </div>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page584926941-layer-797513605" style="position: absolute; left: 150px; top: 185px; width: 112px; height: 30px" data-interactive-element-type="default.tabbutton" class="tabbutton stencil mobile-interaction-potential-trigger " data-stencil-id="797513605" data-review-reference-id="797513605">\
         <div class="stencil-wrapper" style="width: 112px; height: 30px">\
            <div title="">\
               <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" xmlns="http://www.w3.org/2000/svg" style="position: absolute; left: -5px; top: -5px; height: 40px;width:122px;" width="112" height="35">\
                  <svg:g id="target" x="-5" y="0" width="112" height="30" name="target" class="">\
                     <svg:path id="__containerId__-page584926941-layer-797513605_small_path" width="112" height="30" style="stroke:black; stroke-width:1; fill:white" class="smallTab" d="M 5,15 C 5,5 15,5 15,5 L 107,5 C 117,5 117,15 117,15 L 117,35 L 5,35 L 5,15"></svg:path>\
                  </svg:g>\
               </svg:svg>\
               <div id="__containerId__-page584926941-layer-797513605div" class="helvetica-font" style="position: absolute; top: 4px; height: 30px;width:112px;text-align:center;font-size:1em;fill:none;cursor:pointer;padding-top:5px;" xml:space="preserve" onmouseover="rabbit.facade.raiseEvent(rabbit.events.tabButtonMouseOver, \'__containerId__-page584926941-layer-797513605\', \'result\');" onmouseout="rabbit.facade.raiseEvent(rabbit.events.tabButtonMouseOut, \'__containerId__-page584926941-layer-797513605\', \'result\');">\
                  				Món Chính\
                  				\
                  <addMouseOverListener></addMouseOverListener>\
                  				\
                  <addMouseOutListener></addMouseOutListener>\
                  			\
               </div>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page584926941-layer-1514918685" style="position: absolute; left: 290px; top: 185px; width: 112px; height: 30px" data-interactive-element-type="default.tabbutton" class="tabbutton stencil mobile-interaction-potential-trigger " data-stencil-id="1514918685" data-review-reference-id="1514918685">\
         <div class="stencil-wrapper" style="width: 112px; height: 30px">\
            <div title="">\
               <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" xmlns="http://www.w3.org/2000/svg" style="position: absolute; left: -5px; top: -5px; height: 40px;width:122px;" width="112" height="35">\
                  <svg:g id="target" x="-5" y="0" width="112" height="30" name="target" class="">\
                     <svg:path id="__containerId__-page584926941-layer-1514918685_small_path" width="112" height="30" style="stroke:black; stroke-width:1; fill:white" class="smallTab" d="M 5,15 C 5,5 15,5 15,5 L 107,5 C 117,5 117,15 117,15 L 117,35 L 5,35 L 5,15"></svg:path>\
                  </svg:g>\
               </svg:svg>\
               <div id="__containerId__-page584926941-layer-1514918685div" class="helvetica-font" style="position: absolute; top: 4px; height: 30px;width:112px;text-align:center;font-size:1em;fill:none;cursor:pointer;padding-top:5px;" xml:space="preserve" onmouseover="rabbit.facade.raiseEvent(rabbit.events.tabButtonMouseOver, \'__containerId__-page584926941-layer-1514918685\', \'result\');" onmouseout="rabbit.facade.raiseEvent(rabbit.events.tabButtonMouseOut, \'__containerId__-page584926941-layer-1514918685\', \'result\');">\
                  				Tráng miệng\
                  				\
                  <addMouseOverListener></addMouseOverListener>\
                  				\
                  <addMouseOutListener></addMouseOutListener>\
                  			\
               </div>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page584926941-layer-346976431" style="position: absolute; left: 430px; top: 185px; width: 112px; height: 30px" data-interactive-element-type="default.tabbutton" class="tabbutton stencil mobile-interaction-potential-trigger " data-stencil-id="346976431" data-review-reference-id="346976431">\
         <div class="stencil-wrapper" style="width: 112px; height: 30px">\
            <div title="">\
               <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" xmlns="http://www.w3.org/2000/svg" style="position: absolute; left: -5px; top: -5px; height: 40px;width:122px;" width="112" height="35">\
                  <svg:g id="target" x="-5" y="0" width="112" height="30" name="target" class="">\
                     <svg:path id="__containerId__-page584926941-layer-346976431_small_path" width="112" height="30" style="stroke:black; stroke-width:1; fill:white" class="smallTab" d="M 5,15 C 5,5 15,5 15,5 L 107,5 C 117,5 117,15 117,15 L 117,35 L 5,35 L 5,15"></svg:path>\
                  </svg:g>\
               </svg:svg>\
               <div id="__containerId__-page584926941-layer-346976431div" class="helvetica-font" style="position: absolute; top: 4px; height: 30px;width:112px;text-align:center;font-size:1em;fill:none;cursor:pointer;padding-top:5px;" xml:space="preserve" onmouseover="rabbit.facade.raiseEvent(rabbit.events.tabButtonMouseOver, \'__containerId__-page584926941-layer-346976431\', \'result\');" onmouseout="rabbit.facade.raiseEvent(rabbit.events.tabButtonMouseOut, \'__containerId__-page584926941-layer-346976431\', \'result\');">\
                  				Đồ uống\
                  				\
                  <addMouseOverListener></addMouseOverListener>\
                  				\
                  <addMouseOutListener></addMouseOutListener>\
                  			\
               </div>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page584926941-layer-1367773495" style="position: absolute; left: 570px; top: 185px; width: 112px; height: 30px" data-interactive-element-type="default.tabbutton" class="tabbutton stencil mobile-interaction-potential-trigger " data-stencil-id="1367773495" data-review-reference-id="1367773495">\
         <div class="stencil-wrapper" style="width: 112px; height: 30px">\
            <div title="">\
               <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" xmlns="http://www.w3.org/2000/svg" style="position: absolute; left: -5px; top: -5px; height: 40px;width:122px;" width="112" height="35">\
                  <svg:g id="target" x="-5" y="0" width="112" height="30" name="target" class="">\
                     <svg:path id="__containerId__-page584926941-layer-1367773495_small_path" width="112" height="30" style="stroke:black; stroke-width:1; fill:white" class="smallTab" d="M 5,15 C 5,5 15,5 15,5 L 107,5 C 117,5 117,15 117,15 L 117,35 L 5,35 L 5,15"></svg:path>\
                  </svg:g>\
               </svg:svg>\
               <div id="__containerId__-page584926941-layer-1367773495div" class="helvetica-font" style="position: absolute; top: 4px; height: 30px;width:112px;text-align:center;font-size:1em;fill:none;cursor:pointer;padding-top:5px;" xml:space="preserve" onmouseover="rabbit.facade.raiseEvent(rabbit.events.tabButtonMouseOver, \'__containerId__-page584926941-layer-1367773495\', \'result\');" onmouseout="rabbit.facade.raiseEvent(rabbit.events.tabButtonMouseOut, \'__containerId__-page584926941-layer-1367773495\', \'result\');">\
                  				Khác\
                  				\
                  <addMouseOverListener></addMouseOverListener>\
                  				\
                  <addMouseOutListener></addMouseOutListener>\
                  			\
               </div>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page584926941-layer-text151602484" style="position: absolute; left: 990px; top: 180px; width: 162px; height: 37px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text151602484" data-review-reference-id="text151602484">\
         <div class="stencil-wrapper" style="width: 162px; height: 37px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline12"><p class="none" style="font-size: 32px;"><span style="font-size: 20px; color: #658cd9;">Đặt bàn trực tiếp: </span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page584926941-layer-text41729053" style="position: absolute; left: 990px; top: 225px; width: 183px; height: 37px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text41729053" data-review-reference-id="text41729053">\
         <div class="stencil-wrapper" style="width: 183px; height: 37px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline12"><span style="font-size: 32px; color: #000000;">0121456756</span></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page584926941-layer-1412037920" style="position: absolute; left: 990px; top: 265px; width: 219px; height: 37px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="1412037920" data-review-reference-id="1412037920">\
         <div class="stencil-wrapper" style="width: 219px; height: 37px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline12"><p class="none" style="font-size: 32px;"><span style="color: #658cd9;">Đặt bàn <span style="font-size: 26px;">online :</span></span> </p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page584926941-layer-combobox612942485" style="position: absolute; left: 995px; top: 325px; width: 260px; height: 30px" data-interactive-element-type="default.combobox" class="combobox stencil mobile-interaction-potential-trigger " data-stencil-id="combobox612942485" data-review-reference-id="combobox612942485">\
         <div class="stencil-wrapper" style="width: 260px; height: 30px">\
            <div title=""><select id="__containerId__-page584926941-layer-combobox612942485select" style="width:260px;height:30px;" title="">\
                  <option title="">Số người</option>\
                  <option title="">1 người</option>\
                  <option title="">2 người</option>\
                  <option title="">3 người</option>\
                  <option title="">4 người</option>\
                  <option title="">&gt;4 người</option>\
                  <option title=""></option></select></div>\
         </div>\
      </div>\
      <div id="__containerId__-page584926941-layer-datepicker728303515" style="position: absolute; left: 995px; top: 395px; width: 150px; height: 30px" data-interactive-element-type="default.datepicker" class="datepicker stencil mobile-interaction-potential-trigger " data-stencil-id="datepicker728303515" data-review-reference-id="datepicker728303515">\
         <div class="stencil-wrapper" style="width: 150px; height: 30px">\
            <div>\
               <div style="position:absolute; white-space: nowrap;" title=""><input type="text" style="width:114px; height:28px;padding: 0px;border-width:1px;" id="__containerId__-page584926941-layer-datepicker728303515_input" /><button type="button" style="width:34px; height:28px; vertical-align: top; padding: 0px;border-width:1px;" id="__containerId__-page584926941-layer-datepicker728303515_button"><img src="../resources/icons/date.png" /></button></div>\
               <div id="__containerId__-page584926941-layer-datepicker728303515_ov" class="yui-skin-sam" style="position: absolute; width: 16em;visibility:visible;">\
                  <div id="__containerId__-page584926941-layer-datepicker728303515_cal"></div>\
               </div><script type="text/javascript">\
				rabbit.stencils.datepicker.setupDatepicker("__containerId__-page584926941-layer-datepicker728303515");\
			</script></div>\
         </div>\
      </div>\
      <div id="__containerId__-page584926941-layer-combobox555000136" style="position: absolute; left: 1175px; top: 395px; width: 80px; height: 30px" data-interactive-element-type="default.combobox" class="combobox stencil mobile-interaction-potential-trigger " data-stencil-id="combobox555000136" data-review-reference-id="combobox555000136">\
         <div class="stencil-wrapper" style="width: 80px; height: 30px">\
            <div title=""><select id="__containerId__-page584926941-layer-combobox555000136select" style="width:80px;height:30px;" title="">\
                  <option title="">1h - AM</option>\
                  <option title="">2h - AM</option>\
                  <option title="">3h - AM</option>\
                  <option title="">1h - PM</option>\
                  <option title="">2h - pM</option>\
                  <option title="">3h - PM</option></select></div>\
         </div>\
      </div>\
      <div id="__containerId__-page584926941-layer-icon871960425" style="position: absolute; left: 1275px; top: 395px; width: 32px; height: 32px" data-interactive-element-type="fonticon.icon" class="icon stencil mobile-interaction-potential-trigger " data-stencil-id="icon871960425" data-review-reference-id="icon871960425">\
         <div class="stencil-wrapper" style="width: 32px; height: 32px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" style="width:32px;height:32px;" title="">\
               <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" class="fill-blue">\
                  <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#icon-glyph-e055"></use>\
               </svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page584926941-layer-arrow503608692" style="position: absolute; left: 995px; top: 470px; width: 335px; height: 33px" data-interactive-element-type="static.line" class="line stencil mobile-interaction-potential-trigger " data-stencil-id="arrow503608692" data-review-reference-id="arrow503608692">\
         <div class="stencil-wrapper" style="width: 335px; height: 33px">\
            <div title="">\
               <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" style="position: absolute; left: -5px; top: -5px; height: 43px;width:345px;" viewBox="-5 -5 345 43" width="345" height="43">\
                  <svg:path d="M 0,16.5 L 335,16.5" marker-start="" marker-end="" style="fill:none; stroke-width:2px;stroke:black;"></svg:path>\
               </svg:svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page584926941-layer-517631034" style="position: absolute; left: 990px; top: 505px; width: 199px; height: 37px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="517631034" data-review-reference-id="517631034">\
         <div class="stencil-wrapper" style="width: 199px; height: 37px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline12"><p class="none" style="font-size: 32px;"><span style="color: #658cd9;">Món đã chọn</span> </p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page584926941-layer-1858259876" style="position: absolute; left: 1000px; top: 435px; width: 166px; height: 37px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="1858259876" data-review-reference-id="1858259876">\
         <div class="stencil-wrapper" style="width: 166px; height: 37px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline12"><p class="none" style="font-size: 32px;"><span style="font-size: 20px; color: #000000;"><span class="bold">Cần đặt cọc</span>\
                     : 0% </span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page584926941-layer-image675566991" style="position: absolute; left: 25px; top: 280px; width: 944px; height: 522px" data-interactive-element-type="default.image" class="image stencil mobile-interaction-potential-trigger " data-stencil-id="image675566991" data-review-reference-id="image675566991">\
         <div class="stencil-wrapper" style="width: 944px; height: 522px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" title="">\
               <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" class="image-cropper" style="height: 522px;width:944px;" width="944" height="522" viewBox="0 0 944 522">\
                  <svg:g width="944" height="522">\
                     <svg:svg x="0" y="0" width="944" height="522">\
                        <svg:image width="80" height="60" xlink:href="../repoimages/508428.PNG" preserveAspectRatio="none" transform="scale(11.8,8.7) translate(-0,-0)  "></svg:image>\
                     </svg:svg>\
                  </svg:g>\
               </svg:svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page584926941-layer-text273581906" style="position: absolute; left: 30px; top: 230px; width: 155px; height: 37px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text273581906" data-review-reference-id="text273581906">\
         <div class="stencil-wrapper" style="width: 155px; height: 37px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline12"><p><span style="font-size: 32px; color: #658cd9;">Món chính</span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page584926941-layer-image422327871" style="position: absolute; left: 995px; top: 560px; width: 330px; height: 420px" data-interactive-element-type="default.image" class="image stencil mobile-interaction-potential-trigger " data-stencil-id="image422327871" data-review-reference-id="image422327871">\
         <div class="stencil-wrapper" style="width: 330px; height: 420px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" title="">\
               <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" class="image-cropper" style="height: 420px;width:330px;" width="330" height="420" viewBox="0 0 330 420">\
                  <svg:g width="330" height="420">\
                     <svg:svg x="0" y="0" width="330" height="420">\
                        <svg:image width="80" height="60" xlink:href="../repoimages/508429.PNG" preserveAspectRatio="none" transform="scale(4.125,7) translate(-0,-0)  "></svg:image>\
                     </svg:svg>\
                  </svg:g>\
               </svg:svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page584926941-layer-text509771342" style="position: absolute; left: 995px; top: 1010px; width: 203px; height: 37px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text509771342" data-review-reference-id="text509771342">\
         <div class="stencil-wrapper" style="width: 203px; height: 37px">\
            <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline12"><p><span style="font-size: 32px; color: #658cd9;">Yêu cầu thêm</span></p></span></span></div>\
         </div>\
      </div>\
      <div id="__containerId__-page584926941-layer-textinput613408713" style="position: absolute; left: 1000px; top: 1070px; width: 330px; height: 150px" data-interactive-element-type="default.textinput" class="textinput stencil mobile-interaction-potential-trigger " data-stencil-id="textinput613408713" data-review-reference-id="textinput613408713">\
         <div class="stencil-wrapper" style="width: 330px; height: 150px">\
            <div title=""><textarea id="__containerId__-page584926941-layer-textinput613408713input" rows="" cols="" style="width:328px;height:146px;padding: 0px;border-width:1px;"></textarea></div>\
         </div>\
      </div>\
      <div id="__containerId__-page584926941-layer-iphoneButton412712734" style="position: absolute; left: 1230px; top: 1250px; width: 100px; height: 30px" data-interactive-element-type="default.iphoneButton" class="iphoneButton stencil mobile-interaction-potential-trigger " data-stencil-id="iphoneButton412712734" data-review-reference-id="iphoneButton412712734">\
         <div class="stencil-wrapper" style="width: 100px; height: 30px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" title="" style="height: 30px;width:100px;">\
               <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" width="100" height="30" viewBox="0 0 100 30">\
                  <svg:a>\
                     <svg:path fill-rule="evenodd" clip-rule="evenodd" fill="#808080" stroke="#666666" d="M5,29.5 l-2,-0.5 -1,-1 -1,-1.5 -0.5,-1.5 0,-20 0.5,-2 1,-1 1,-1 2,-0.5 82,0 0.5,0.5 1,0 1,1 1.5,1.5 8.5,11 -7.5,11 -2,2.5 -1.5,1 -0.5,0.5 z"></svg:path>\
                     <svg:text x="47" y="15" dy="0.3em" fill="#FFFFFF" style="font-size:1em;stroke-width:0pt;" font-family="\'HelveticaNeue-Bold\'" text-anchor="middle" xml:space="preserve">Hoàn tất</svg:text>\
                  </svg:a>\
               </svg:svg>\
            </div>\
         </div>\
      </div>\
      <div id="__containerId__-page584926941-layer-317517354" style="position: absolute; left: 20px; top: 770px; width: 944px; height: 522px" data-interactive-element-type="default.image" class="image stencil mobile-interaction-potential-trigger " data-stencil-id="317517354" data-review-reference-id="317517354">\
         <div class="stencil-wrapper" style="width: 944px; height: 522px">\
            <div xmlns:pidoco="http://www.pidoco.com/util" title="">\
               <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" class="image-cropper" style="height: 522px;width:944px;" width="944" height="522" viewBox="0 0 944 522">\
                  <svg:g width="944" height="522">\
                     <svg:svg x="0" y="0" width="944" height="522">\
                        <svg:image width="80" height="60" xlink:href="../repoimages/508428.PNG" preserveAspectRatio="none" transform="scale(11.8,8.7) translate(-0,-0)  "></svg:image>\
                     </svg:svg>\
                  </svg:g>\
               </svg:svg>\
            </div>\
         </div>\
      </div>\
   </div>\
</div>');