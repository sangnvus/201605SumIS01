DROP DATABASE IF EXISTS angiproject;

create database angiproject;

use angiproject;


CREATE TABLE CategoriesOfRestaurant (
 categoryOfResID INT  NOT NULL auto_increment,
 nameCOR NVARCHAR(300),
 desciptionCOR NVARCHAR(2000),
 PRIMARY KEY (categoryOfResID),
 statusCOR BOOLEAN
);



CREATE TABLE Images (
 imageID INT  NOT NULL auto_increment,
 nameImage NVARCHAR(300),
 desciptionImage NVARCHAR(2000),
 typeImage INT,
 addressImage NVARCHAR(1000),
 statusImage BOOLEAN,
 useID CHAR(10),
PRIMARY KEY (imageID)
);



CREATE TABLE Province (
 provinceID INT  NOT NULL auto_increment,
 namePro NVARCHAR(3000),
 typePro INT,
 PRIMARY KEY (provinceID)
);


CREATE TABLE District (
 districtID INT  NOT NULL auto_increment,
 nameDis NVARCHAR(300),
 typeDis INT,
 locationDis NVARCHAR(300),
 provinceID INT NOT NULL,
 PRIMARY KEY (districtID)
);



CREATE TABLE Ward (
 wardID INT  NOT NULL auto_increment,
 nameWard NVARCHAR(300),
 typeWard INT,
 locationWard NVARCHAR(300),
 districtID INT NOT NULL,
 PRIMARY KEY (wardID)
);



CREATE TABLE Address (
 addressID INT  NOT NULL auto_increment,
 address NVARCHAR(1000),
 provinceID INT NOT NULL,
 districtID INT NOT NULL,
 wardID INT NOT NULL,
 PRIMARY KEY (addressID),
 statusAdd BOOLEAN
);



CREATE TABLE Users (
 userID INT  NOT NULL auto_increment,
 firstNameUser NVARCHAR(300),
 lastNameUser NVARCHAR(300),
 dateOfBirthUser CHAR(10),
 genderUser BOOLEAN,
 descriptionUser VARCHAR(2000),
 emailUser NVARCHAR(100),
 phoneUser INT,
 authorityUser INT,
 passworkUser NVARCHAR(10),
 dateCreateUser DATETIME,
 imageID INT NOT NULL,
 addressID INT NOT NULL,
 PRIMARY KEY (userID),
 satusUser BOOLEAN
);



CREATE TABLE Restaurants (
 restaurantID INT  NOT NULL auto_increment,
 nameRe NVARCHAR(300),
 shortDesRes NVARCHAR(300),
 longDesRes NVARCHAR(2000),
 phoneRe INT,
 openTimeRe TIME,
 closeTimeRe TIME,
 latitudeRe NVARCHAR(100),
 longitudeRe NVARCHAR(300),
 rateRe FLOAT,
 minPrice FLOAT,
 maxPrice FLOAT,
 discount FLOAT,
 quantityBooking INT,
 dateCreateRe DATE,
 isDepositBo INT,
 isDeactivate INT,
 addressID INT NOT NULL,
 userID INT NOT NULL,
 PRIMARY KEY (restaurantID),
 satusRes BOOLEAN
);



CREATE TABLE Booking (
 bookingID INT  NOT NULL auto_increment,
 dateCreateBo DATETIME,
 dateBooking DATETIME,
 quantityMember INT,
 commentBo NVARCHAR(3000),
 isDeactivate BOOLEAN,
 restaurantID INT NOT NULL,
 userID INT NOT NULL,
 PRIMARY KEY (bookingID),
 statusBo BOOLEAN
);



CREATE TABLE Comments (
 comID INT  NOT NULL auto_increment,
 textCom NVARCHAR(3000),
 dateCreateCom DATE,
 restaurantID INT NOT NULL,
 userID INT NOT NULL,
 PRIMARY KEY (comID),
 statusCom BOOLEAN
);


CREATE TABLE Food (
 foodID INT  NOT NULL auto_increment,
 nameFo NVARCHAR(300),
 desciptionFo NVARCHAR(2000),
 priceFo FLOAT,
 typeFo INT,
 imageID  INT NOT NULL,
 restaurantID INT NOT NULL,
 PRIMARY KEY (foodID),
 statusFo BOOLEAN
);



CREATE TABLE History (
 historyID INT NOT NULL,
 dateCreateBo DATETIME,
 isDeactivate INT,
 bookingID INT NOT NULL,
 restaurantID INT NOT NULL,
 userID INT NOT NULL,
 PRIMARY KEY (historyID),
 statusHis BOOLEAN
);



CREATE TABLE Rate (
 rateID INT NOT NULL,
 rate FLOAT,
 restaurantID INT NOT NULL,
 userID INT NOT NULL,
 PRIMARY KEY (rateID),
 satusRate BOOLEAN
);



CREATE TABLE RestaurantCategories (
 restaurantID INT NOT NULL,
 categoryOfResID INT NOT NULL,
 PRIMARY KEY (restaurantID,categoryOfResID)
);



CREATE TABLE BookingDetail (
 bookingDetailID INT NOT NULL,
 sumPrice FLOAT,
 bookingID INT NOT NULL,
 foodID INT NOT NULL,
 PRIMARY KEY (bookingDetailID),
 statusBookingDetail BOOLEAN
);


ALTER TABLE District ADD CONSTRAINT FK_District_0 FOREIGN KEY (provinceID) REFERENCES Province (provinceID);


ALTER TABLE Ward ADD CONSTRAINT FK_Ward_0 FOREIGN KEY (districtID) REFERENCES District (districtID);


ALTER TABLE Address ADD CONSTRAINT FK_Address_0 FOREIGN KEY (provinceID) REFERENCES Province (provinceID);
ALTER TABLE Address ADD CONSTRAINT FK_Address_1 FOREIGN KEY (districtID) REFERENCES District (districtID);
ALTER TABLE Address ADD CONSTRAINT FK_Address_2 FOREIGN KEY (wardID) REFERENCES Ward (wardID);


ALTER TABLE Users ADD CONSTRAINT FK_Users_0 FOREIGN KEY (imageID) REFERENCES Images (imageID);
ALTER TABLE Users ADD CONSTRAINT FK_Users_1 FOREIGN KEY (addressID) REFERENCES Address (addressID);


ALTER TABLE Restaurants ADD CONSTRAINT FK_Restaurants_0 FOREIGN KEY (addressID) REFERENCES Address (addressID);
ALTER TABLE Restaurants ADD CONSTRAINT FK_Restaurants_1 FOREIGN KEY (userID) REFERENCES Users (userID);


ALTER TABLE Booking ADD CONSTRAINT FK_Booking_0 FOREIGN KEY (restaurantID) REFERENCES Restaurants (restaurantID);
ALTER TABLE Booking ADD CONSTRAINT FK_Booking_1 FOREIGN KEY (userID) REFERENCES Users (userID);


ALTER TABLE Comments ADD CONSTRAINT FK_Comments_0 FOREIGN KEY (restaurantID) REFERENCES Restaurants (restaurantID);
ALTER TABLE Comments ADD CONSTRAINT FK_Comments_1 FOREIGN KEY (userID) REFERENCES Users (userID);


ALTER TABLE Food ADD CONSTRAINT FK_Food_0 FOREIGN KEY (imageID ) REFERENCES Images (imageID);
ALTER TABLE Food ADD CONSTRAINT FK_Food_1 FOREIGN KEY (restaurantID) REFERENCES Restaurants (restaurantID);


ALTER TABLE History ADD CONSTRAINT FK_History_0 FOREIGN KEY (bookingID) REFERENCES Booking (bookingID);
ALTER TABLE History ADD CONSTRAINT FK_History_1 FOREIGN KEY (restaurantID) REFERENCES Restaurants (restaurantID);
ALTER TABLE History ADD CONSTRAINT FK_History_2 FOREIGN KEY (userID) REFERENCES Users (userID);


ALTER TABLE Rate ADD CONSTRAINT FK_Rate_0 FOREIGN KEY (restaurantID) REFERENCES Restaurants (restaurantID);
ALTER TABLE Rate ADD CONSTRAINT FK_Rate_1 FOREIGN KEY (userID) REFERENCES Users (userID);


ALTER TABLE RestaurantCategories ADD CONSTRAINT FK_RestaurantCategories_0 FOREIGN KEY (restaurantID) REFERENCES Restaurants (restaurantID);
ALTER TABLE RestaurantCategories ADD CONSTRAINT FK_RestaurantCategories_1 FOREIGN KEY (categoryOfResID) REFERENCES CategoriesOfRestaurant (categoryOfResID);


ALTER TABLE BookingDetail ADD CONSTRAINT FK_BookingDetail_0 FOREIGN KEY (bookingID) REFERENCES Booking (bookingID);
ALTER TABLE BookingDetail ADD CONSTRAINT FK_BookingDetail_1 FOREIGN KEY (foodID) REFERENCES Food (foodID);


